# Stage 1 QA report (Agent 6)

* run: 2026-10-03T21:28:50 | script v1.0.0
* result: **QA_STAGE1_SCORE = 10/10** (20 tests passed, 0 failed, 0 skipped)

## Rubric

| item | criterion | points | awarded | evidence |
|---|---|---|---|---|
| input_discovery | input discovery is robust and unambiguous | 2 | 2 | T04 |
| weekly_aggregation | weekly MOEX aggregation is mathematically exact | 2 | 2 | T05, T17 |
| wordstat_alignment | Wordstat alignment is exact (-6 day rule) | 2 | 2 | T01, T02, T03, T13a, T13b |
| all_tests_pass | all automated tests pass | 2 | 2 | * |
| windows_cyrillic_encoding | Windows / Cyrillic / encoding handling is safe | 1 | 1 | T14, T15 |
| reports_complete | validation reports are complete and reproducible | 1 | 1 | R1 |

## Test results

| test | what it proves | result | evidence |
|---|---|---|---|
| T01 | exact date alignment (Mon label, Sun end, +6 days) | PASS | 75 tickers / 31425 rows; violations: 0 |
| T02 | zero orphan weeks (MOEX weeks and search weeks all matched) | PASS | orphan MOEX weeks: 0, orphan search weeks: 0, daily rows before the panel (pre-sample history, unused): 11785 |
| T03 | full common weekly grid for every ticker | PASS | rows per ticker: 419 (expected 419, allow_unexpected=False); 2018-08-27 .. 2026-08-31; identical for all 75 tickers: True |
| T05 | weekly bars reproduced by an independent code path | PASS | 188550 values compared, 0 mismatches |
| T06 | placeholder rows never become OPEN/CLOSE of a week | PASS | placeholders on first row of week: 99, on last row: 160, misused: 0, weeks with days but NaN price: 0, weeks with price but 0 days: 0, daily rows neither used nor counted as placeholders: 0 |
| T07 | Saturday sessions inside the Mon..Sun week (auditable) | PASS | 6 distinct Saturday sessions inside the panel (2 more exist in the daily files before the panel starts and are out of scope), 445 ticker-weeks with N_SAT_DAYS>0, problems: 0 |
| T08 | RV is NaN when HIGH == LOW and never zero-filled | PASS | H==L weeks: 7, rows with RV == 0: 0, RV formula violations: 0 |
| T09 | SVI_RAW == 0 -> SVI_VALID / LN_SVI / ASVI are NaN | PASS | 56 zero-search ticker-weeks, violations: 0 |
| T10 | ASVI only with 8 valid prior weeks (independent recomputation) | PASS | 30532 ticker-weeks with ASVI, violations: 0 |
| T11 | returns never cross a missing week | PASS | violations: 0 |
| T12 | known corporate-action weeks flagged, RETURN_SAFE = NaN | PASS | 4 flagged ticker-weeks, violations: 0 |
| T13a | ghost-merge test: Feb-2022 spike sits on the crash week | PASS | week 2022-02-21: 100% of tickers traded and 99% fell (median return -0.260); attention exceeds each company's own 4-week median for 71% of tickers and the prior week for 71% (pooled x2.74 vs its 4-week norm, x2.72 vs the prior week; per-ticker median x1.27, p90 x3.20); the +7d-shifted week 2022-02-28 has NO trading days for 100% of tickers and volume decays one week later for 91% of tickers -> both a +7d and a -7d misalignment are detectable and are NOT what this panel does |
| T13b | same-week alignment beats +/-1 week shifts for most tickers | PASS | n=75 tickers: mean corr(|ret|, ln SVI) same week +0.263 vs previous week +0.122, next week +0.199, two weeks back +0.097; same-week wins vs previous week for 100% and vs next week for 100% of tickers |
| T14 | Windows/Cyrillic/long-path safety of every source path | PASS | 75 tickers have Cyrillic path components, longest source path 159 chars, absolute-path leaks: [] |
| T15 | encoding detection covers every input file | PASS | encodings used: {'utf-8-sig': 225}; Cyrillic search channel verified for all tickers: True |
| T16 | no silent fill: missing values stay missing everywhere | PASS | violations: 0 |
| T17 | weekly bars match the archive's own *_weekly.csv files | PASS | 186582 reference values compared, 0 mismatches |
| T04 | no cross-ticker copy mistakes (row-level provenance) | PASS | violations: 0 |
| T04b | written files: folder == TICKER == manifest, sources are own-folder | PASS | violations: 0 |
| T18 | round-trip: re-read CSV == in-memory panel | PASS | 1005600 values compared, 0 mismatches |

## Defects found during the audit and how they were handled

These are the traps that were found by inspecting the real archive *before* the final code was fixed. Each one is now either impossible or explicitly detected.

### Yandex archive is doubly nested
* risk: The Wordstat files are not at the top of `yandex_final.zip`; they live inside `yan 2/iqbal thesis data.zip`. A single-level extractor finds nothing.
* handling: `extract_zip_tree()` recurses into nested archives (depth-limited to 3) and only extracts nested zips that actually contain CSV data.

### Wordstat files use bare-CR line endings
* risk: The exports are UTF-8-BOM, semicolon separated and terminated with a lone CR (old-Mac style), with space-separated thousands. A naive line splitter produces a single giant line.
* handling: All reading goes through `read_delimited_rows()` which splits on CR/LF/CRLF and sniffs the delimiter from the header.

### Placeholder rows are OHLC-NaN rows carrying VOLUME=0/VALUE=0
* risk: There are 2,521 such rows in the real archive and no fully-blank rows at all. Cleaning on `row.isna().all()` would keep them and they would silently become the open or close of a week.
* handling: Placeholders are defined as 'all four OHLC missing' (R6), are counted per week (`N_PLACEHOLDER_ROWS`), are excluded from the aggregation and are covered by test T06, which explicitly hunts weeks whose first/last row is a placeholder.

### Sector folder names differ between the two archives
* risk: MOEX says `RealEstate`, the Wordstat archive says `Real Estate`.
* handling: Sector names are canonicalised by a normalised key; the discrepancy is logged, listed in the report, and the readable Wordstat name is used for the output folder.

### `YDEX.csv` sits next to `YNDX.csv`
* risk: Using YDEX as the Cyrillic channel would silently corrupt the YNDX search series.
* handling: `YDEX` is on the exclusion list (R12) and the Cyrillic channel is additionally required to be genuinely Cyrillic; a synthetic test proves the build fails loudly if a Cyrillic channel is missing instead of falling back to YDEX.

### The archive ships its own weekly files
* risk: They could have been used blindly as 'the truth'.
* handling: They are used only as an independent cross-check (T17). The panel is built from the daily files, and the two agree to 1e-9 on every one of the reference values.

## Residual warnings from this run

None.

## Release gate

All 20 tests passed and the rubric is 10/10: **YES**. No output is published unless this gate is open (the panel is built in a staging folder and only moved into place after every check has passed).
