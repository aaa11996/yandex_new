# Stage 2 Judge report (Agent 7)

* run: 2026-10-03T21:28:50 | script v1.0.0
* verdict: **APPROVED - RELEASE** (JUDGE_STAGE2_SCORE = 10/10)

## Veto checklist

| veto condition | verdict | evidence |
|---|---|---|
| join rule is the -6 day rule (never +1 / -7) | clear | 75 tickers / 31425 rows; violations: 0 |
| ghost merge impossible / actively disproved | clear | T13a: week 2022-02-21: 100% of tickers traded and 99% fell (median return -0.260); attention exceeds each company's own 4-week median for 71% of tickers and the prior week for 71% (pooled x2.74 vs its 4-week norm, x2.72 vs the prior week; per-ticker median x1.27, p90 x3.20); the +7d-shifted week 2022-02-28 has NO trading days for 100% of tickers and volume decays one week later for 91% of tickers -> both a +7d and a -7d misalignment are detectable and are NOT what this panel does | T13b: n=75 tickers: mean corr(|ret|, ln SVI) same week +0.263 vs previous week +0.122, next week +0.199, two weeks back +0.097; same-week wins vs previous week for 100% and vs next week for 100% of tickers |
| realized volatility is never zero-filled | clear | H==L weeks: 7, rows with RV == 0: 0, RV formula violations: 0 |
| no NaN was silently filled | clear | violations: 0 |
| corporate-action weeks flagged and neutralised in RETURN_SAFE | clear | 4 flagged ticker-weeks, violations: 0 |
| Saturday sessions kept and auditable | clear | 6 distinct Saturday sessions inside the panel (2 more exist in the daily files before the panel starts and are out of scope), 445 ticker-weeks with N_SAT_DAYS>0, problems: 0 |
| no cross-ticker copy mistake possible | clear | violations: 0 |
| output structure <Sector>/<TICKER>/<TICKER>_combined.csv | clear | Banking/AVAN/AVAN_combined.csv; Banking/BSPB/BSPB_combined.csv; Banking/CBOM/CBOM_combined.csv; Banking/SBER/SBER_combined.csv ... |
| script is fully offline (no network imports) | clear | no network imports found |
| no unfinished markers or missing implementations in the code | clear | clean |
| no test was skipped without justification | clear | skipped: none |
| Stage 1 score is not inflated (equals the computed rubric) | clear | declared 10/10 vs computed 10/10 |
| final code is complete and runnable offline | clear | pipeline, self-test and CLI all present in the single file |

## Independent review notes

1. **Wrong join rule / ghost merge.** The -6 day rule is asserted for every single row (T01) and, additionally, disproved empirically: the February-2022 attention spike is shown to sit on the week that contains the crash, while the +7 day alternative would place it on a week in which the exchange did not trade at all (T13a). A second, purely statistical test shows that the same-week alignment produces a higher |return| ~ ln(SVI) correlation than either neighbouring week for (almost) every company (T13b). A shift of one week in either direction would have to make the data less coherent - it cannot be a hidden ghost merge.
2. **Silent repair.** No forward fill, backward fill, interpolation or zero fill exists anywhere in the code, and T16 checks the consequences: weeks with no trading day keep empty cells, the number of non-empty closes equals the number of weeks with trading days, and NaN counts of `SVI_VALID` and `RV` match exactly the number of zero-search weeks and of HIGH==LOW weeks.
3. **Realized volatility.** `RV = ln(HIGH/LOW)` and HIGH==LOW yields NaN (T08); a zero from this route is impossible to write because the mask requires HIGH != LOW.
4. **Saturday sessions.** Kept inside the Mon..Sun week and audited through `N_SAT_DAYS`; T07 re-derives the Saturday contribution to high/low/volume independently. Nothing was dropped.
5. **Corporate actions.** The four known structural events are flagged, `RETURN_SAFE` is NaN there while `RETURN_RAW` is preserved for audit, and no raw price was modified (T12). Weeks with extreme raw returns that are *not* in the configured list are additionally marked with the diagnostic `CA_CANDIDATE_FLAG` so the student can see them - that flag deliberately does not change any data.
6. **Offline usability.** The script contains no network imports and no downloads (checked mechanically against the source text); it only reads the two inputs next to itself and writes into `combined_panel/`.
7. **Reproducibility.** Dates are written as `YYYY-MM-DD`, missing values as empty cells, files as UTF-8 with BOM for Excel; every output file is hashed into `manifest.csv` and re-read for a round-trip test (T18) before publication.

## Standing limitations (disclosed, not hidden)

* Weeks without a single valid trading day remain empty by design (328 ticker-weeks; most affected: BLNG (23), AVAN (16), LSNG (12), YNDX (9), MSTT (7)). Their OHLCV/VALUE cells are blank and N_TRADING_DAYS = 0 - no value was interpolated, carried forward or invented.
* Reasons include the March-2022 exchange closure (all tickers) and instrument-specific suspensions: YNDX did not trade for ~6 weeks in June-July 2024 (redomiciliation; the successor line YDEX is deliberately NOT used, per rule R12), BLNG and LSNG have long suspensions, illiquid names such as AVAN trade only sporadically in the early part of the sample.
* The final week (2026-08-31 .. 2026-09-06) is flagged PARTIAL_WEEK_FLAG = 1 for 75 tickers because the daily files end before the Sunday, so that bar covers fewer than 7 calendar days. Wordstat's own export ends with the same week label.
* RV is the Parkinson range term ln(HIGH/LOW) computed on the weekly bar; it is NOT annualised and NOT a sum of squared daily returns, and it is NaN - never 0 - when HIGH == LOW (e.g. weeks with a single flat session).
* The corporate-action list covers the four structural events that were identified in the audit (VTBR 2024-07-15, GMKN 2024-04-08, PLZL 2025-03-24, ROLO 2023-01-16). Any other structural break is NOT adjusted; weeks whose raw return exceeds 50% in absolute value are marked with the diagnostic CA_CANDIDATE_FLAG so they can be inspected, but nothing is modified.
* Search data: SVI_RAW is the plain sum of the Latin and Cyrillic weekly query counts exactly as reported in the Wordstat exports - no seasonal adjustment, no scaling, no interpolation is applied, and 56 ticker-weeks with zero reported queries are NaN rather than logged.
* Daily history before 2018-08-27 exists in the MOEX files but lies outside the Wordstat grid; it is reported and left unused (it never enters a weekly bar).
