# Validation summary - combined MOEX x Wordstat weekly panel

* run timestamp: 2026-10-03T21:28:50
* script version: 1.0.0
* input mode: zip
* QA Stage 1 score: **10/10**   Judge Stage 2 score: **10/10**
* final status: **READY FOR OFFLINE USE**

## What was built
A weekly panel for **75 companies** covering **419 weeks** (2018-08-27 .. 2026-08-31), i.e. 31425 ticker-weeks in total.
For every company: MOEX OHLCV aggregated over the calendar week `SEARCH_MONDAY .. SEARCH_MONDAY + 6` (Monday-Friday **and** Saturday sessions), the Latin ticker search series, the Cyrillic company-name search series, `SVI_RAW = Latin + Cyrillic`, `LN_SVI`, `ASVI`, Parkinson range volatility `RV`, raw and gap-safe log returns, corporate-action flags and diagnostic flags.

## Headline numbers

| quantity | value |
|---|---|
| date mismatches (must be 0) | 0 |
| orphan MOEX weeks (must be 0) | 0 |
| orphan search weeks (must be 0) | 0 |
| duplicate ticker-weeks (must be 0) | 0 |
| copy mistakes (must be 0) | 0 |
| RV values zero-filled by HIGH==LOW (must be 0) | 0 |
| silent fills (must be 0) | 0 |
| placeholder rows misused as OPEN/CLOSE (must be 0) | 0 |
| daily rows neither used nor counted as placeholders (must be 0) | 0 |
| distinct Saturday sessions inside the panel | 6 |
| ticker-weeks with HIGH == LOW (RV = NaN by rule) | 7 |
| ticker-weeks with zero search volume (SVI = NaN) | 56 |
| ticker-weeks flagged as corporate actions | 4 |

## Missing MOEX weeks (kept as empty cells - never filled, never dropped)

328 ticker-weeks have no valid trading day at all (exchange closure, suspension or illiquidity). Their OHLCV cells are empty and `N_TRADING_DAYS = 0`; returns that would have to jump such a gap are NaN.

| ticker | weeks with no trading | first such weeks |
|---|---|---|
| BLNG | 23 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21, 2024-07-29, 2024-08-05 ... |
| AVAN | 16 | 2018-08-27, 2018-09-10, 2018-09-17, 2018-10-01, 2018-10-08, 2018-10-22 ... |
| LSNG | 12 | 2020-03-23, 2020-03-30, 2020-04-06, 2020-04-13, 2020-04-20, 2020-04-27 ... |
| YNDX | 9 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21, 2024-06-17, 2024-06-24 ... |
| MSTT | 7 | 2020-09-21, 2020-09-28, 2020-10-05, 2022-02-28, 2022-03-07, 2022-03-14 ... |
| VJGZ | 6 | 2018-12-31, 2019-01-28, 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| ABRD | 5 | 2018-10-01, 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| FEES | 5 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-12-26, 2023-01-02 |
| KAZT | 5 | 2018-10-29, 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| MFGS | 5 | 2018-12-31, 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| AKRN | 4 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| BANE | 4 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| BSPB | 4 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| CHMK | 4 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |
| FESH | 4 | 2022-02-28, 2022-03-07, 2022-03-14, 2022-03-21 |

## Saturday sessions

Distinct Saturdays with trading inside the panel: 2018-12-29, 2021-02-20, 2024-04-27, 2024-11-02, 2024-12-28, 2025-11-01 (6 sessions). 2 further Saturday sessions exist in the daily files before the first panel week (pre-sample history, outside the panel). 445 ticker-weeks record `N_SAT_DAYS > 0`; Saturday volume, high and low are inside the weekly bar (T07).

## HIGH == LOW weeks

7 ticker-weeks have `HIGH == LOW`; their `RV` is NaN by rule R5 and `H_EQ_L_FLAG = 1`. Zero rows have `RV == 0`.

## Corporate actions

| ticker | search monday | week end | flag | note | return_raw | return_safe |
|---|---|---|---|---|---|---|
| GMKN | 2024-04-08 | 2024-04-14 | CA_FLAG=1 | 100:1 split, effective 2024-04-08 | -4.5147 |  |
| PLZL | 2025-03-24 | 2025-03-30 | CA_FLAG=1 | 10:1 split, trading resumed 2025-03-27 | -2.3141 |  |
| ROLO | 2023-01-16 | 2023-01-22 | CA_FLAG=1 | dilution / large share issue, trading resumed 2023-01-19 | -2.2193 |  |
| VTBR | 2024-07-15 | 2024-07-21 | CA_FLAG=1 | 5000:1 consolidation (reverse split), effective 2024-07-15 | +8.4833 |  |

## Search-volume integrity

Zero-search ticker-weeks: 56 (both channels reported 0). For those `SVI_VALID`, `LN_SVI` and `ASVI` are NaN - no small constant was substituted.
ASVI is available for 30532 ticker-weeks (current SVI valid AND the previous 8 weeks all valid).

## Alignment evidence (anti ghost-merge)

* Feb-2022 test: week 2022-02-21: 100% of tickers traded and 99% fell (median return -0.260); attention exceeds each company's own 4-week median for 71% of tickers and the prior week for 71% (pooled x2.74 vs its 4-week norm, x2.72 vs the prior week; per-ticker median x1.27, p90 x3.20); the +7d-shifted week 2022-02-28 has NO trading days for 100% of tickers and volume decays one week later for 91% of tickers -> both a +7d and a -7d misalignment are detectable and are NOT what this panel does
* correlation test: n=75 tickers: mean corr(|ret|, ln SVI) same week +0.263 vs previous week +0.122, next week +0.199, two weeks back +0.097; same-week wins vs previous week for 100% and vs next week for 100% of tickers

## Independent cross-checks

* weekly bars reproduced by a second, independent code path: 188550 values compared, no mismatch.
* archive's own `*_weekly.csv` files re-checked: 186582 reference values, 0 mismatches.

## Warnings

None.

## Final status

`READY FOR OFFLINE USE` - all 20 automated checks passed, 0 failed, 0 auto-skipped with a recorded reason.
