# FINAL COMPLETE METHODOLOGY — 75-Company MOEX ASVI Panel

This document is the single authoritative methodology. It supersedes and
fully incorporates the earlier ULTIMATE_METHODOLOGY_BLUEPRINT, with two
additions: sector-wise pooled panels and a government/non-government
pooled split. Where anything elsewhere conflicts with this document, this
document governs.

**Standing rule:** if any step below cannot be executed exactly as
written, stop and report the specific blocker. Never substitute,
approximate, or silently reconstruct missing data and present the result
as equivalent to the original.

---

## 1. Study Window and Company Universe

**Window:** 2018-08-27 through 2026-09-06 (raw price range). Wordstat
grid: Mondays 2018-08-27 → 2026-08-31, 419 weeks. Never truncate.

**Universe:** 75 companies (full list in UNIFIED_METHODOLOGY_MANUAL §2.2).
Every result table must reconcile its exact N against 75 by name — a
table using fewer than 75 must list which specific companies are absent
and why (insufficient observations, ROLO's RV-test exclusion, a data
gap), never just a smaller count with no explanation.

## 2. Core Variable Construction

**SVI/ASVI:**
- 74 non-Yandex companies: `SVI(t) = ticker_count(t) + cyrillic_count(t)`
  (raw counts summed before any log transform).
- Yandex: `SVI(t) = YNDX_count(t) + cyrillic_count(t)` — **YDEX is never
  used**, by final decision. Documented limitation: this excludes
  roughly two years of real YDEX search volume post-2024.
- `ASVI(t) = ln(SVI(t)) − median(ln(SVI(t−1)), ..., ln(SVI(t−8)))`.
  `SVI = 0` → treated as missing (never substituted with a small
  constant). Requires 8 valid prior weeks; otherwise ASVI is missing.

**Price variables:**
- `RV(i,t) = (High(i,t) − Low(i,t)) / Close(i,t)`
- `R(i,t) = ln(Price(i,t) / Price(i,t−1))`
- `V(i,t)` = raw weekly volume; regressions use `ln(V(i,t))`.

**Date join:** Wordstat's Monday date = the price file's Sunday-labeled
date + 1 day (a price bar's Sunday label is the day BEFORE the Mon–Fri
week it reports — verified directly from raw data).

**Mandatory data-quality handling:**
- Exclude week 2024-06-16 from cross-sectional event detection.
- Exclude week 2024-08-25 from volume-based metrics.
- Drop the twelve 2022-02-27 flat placeholder rows (treat as missing,
  never forward-filled).
- ROLO is excluded from every RV-dependent test (M1, M4, M5, and both new
  pooled analyses below) due to confirmed tick-size mechanical RV
  inflation. It may remain in R-only or volume-only analysis unless
  separately excluded there for a stated reason.
- All other documented company-specific gaps (LSNG, MSTT, FEES, the YNDX
  relisting gap, AVAN's early gaps) remain as missing values, never
  filled.

## 3. The Four Event/Structural Controls

**Build in this exact order — later controls depend on earlier ones for
deduplication.**

**(a) Crisis(t)** — market-wide, time-varying, identical value across all
companies in a given week. A company "spikes" in week t if
`RV_ratio(t) ≥ 2` AND `Vol_ratio(t) ≥ 2` relative to its own trailing
52-week median. A week is a "stress week" if ≥25% of eligible companies
(≥30 trailing observations) spike. A window is confirmed if contiguous
stress weeks (one-week bridging allowed) reach a peak spike fraction of
≥40%. Four confirmed windows: W1 (COVID onset), W2 (invasion/MOEX
suspension), W3 (September 2023 ruble/rate event), W4 (2026 bear-market
capitulation) — exact dates as documented in the source reports.

**(b) Sanction(i,t)** — company-specific, PERMANENT step function (0
before, 1 from the confirmed first-designation date onward, forever, no
end date). 23 primary anchor events sourced from OFAC/OFSI/EU primary
lists. Verified via the same 2×-trailing-median RV/Volume test in the 4
weeks following the anchor date. Only 7 of 23 anchors show a confirmed
reaction — this low confirmation rate is retained as a documented
finding, not treated as something to fix.

**(c) News(i,t)** — company-specific, TRANSIENT, data-driven duration
(turns on at the event week, stays on while RV or Volume ≥1.5× trailing
median, capped at 4 weeks). Category bar: discrete, exceptional events
only (M&A, surprise earnings, sudden leadership change, major legal/
regulatory action, major operational disruption, debt distress, a single
major contract win/loss) — never routine coverage. **Mandatory
deduplication before testing:** discard any candidate within ±2 weeks of
a confirmed Crisis window or that company's confirmed Sanction date.
This guarantees `News ∩ Crisis = 0` and `News ∩ Sanction = 0` by
construction — verify this is exactly 0, not approximately 0.

**(d) Div(i,t)** — company-specific, built INDEPENDENTLY, with NO
deduplication against Crisis/Sanction/News. Confirmed-PAID record dates
only (reject anything only announced or later cancelled/withdrawn — a
real, documented pattern post-2022). Div = 1 for the 4 calendar weeks
immediately preceding each confirmed record week (the record week itself
excluded); overlapping windows from multiple same-year dividends are
unioned, never double-counted. Requires the full row-level date list
(587 confirmed dates, 63 dividend-paying companies target) — a
per-company aggregate count cannot substitute for this, since an
aggregate carries no positional information about which weeks are 1.

**(e) SOE(i)** — time-invariant, per company (1 / 0 / UNDETERMINED),
Russian government ≥25% voting control, direct or through a
state-controlled holding entity, sourced from primary disclosure. Not
date-indexed — no temporal overlap concept applies to it.

**Overlap measurement (after all four/five are built):**
- `Crisis ∩ Sanction`, `Crisis ∩ News`, `Sanction ∩ News` must equal
  exactly 0. A nonzero value is a construction bug to fix, not a finding.
- `Div ∩ Crisis`, `Div ∩ Sanction`, `Div ∩ News` are measured and
  disclosed, never removed. Flag any company where this overlap reaches
  ≥4 weeks or ≥25% of that company's own Div=1 weeks as a "robustness-
  check candidate" (target: 11 companies — if a reconstruction produces
  a materially different count, the exact company lists under each
  definition must be shown side by side to diagnose why).

## 4. Hypotheses and Exact Equations

**H1 (M1, per-company OLS):**
`RV(i,t) = α + β1·ASVI(i,t−1) + β2·RV(i,t−1) + β3·ln[V(i,t−1)] + β4·Crisis(t−1) + β5·Sanction(i,t−1) + β6·Div(i,t−1) + ε(i,t)`
Newey-West HAC, bandwidth 4.

**H2 (M2, per-company OLS):**
`R(i,t) = α + β1·ASVI(i,t−1) + β2·R(i,t−1) + β3·RV(i,t−1) + β4·Crisis(t−1) + β5·Sanction(i,t−1) + β6·Div(i,t−1) + ε(i,t)`

**H1/H2 robustness (M3, Granger causality):** restricted (own lags +
controls) vs. unrestricted (+ L lags of ASVI, L = 1, 2, 4), F-test per
company per hypothesis. Benjamini-Hochberg applied SEPARATELY within the
H1 block and the H2 block — never pooled together. Bonferroni-Holm
reported alongside as a conservative check.

**H1 aggregate / H4 / H5 / H6 (M4, pooled panel, full sample):**
`RṼ(i,t) = β1·ÃSVI(i,t−1) + β2·RṼ(i,t−1) + β3·ln[Ṽ(i,t−1)] + β4·Dĩv(i,t−1) + ε̃(i,t)`
Entity + time fixed effects; tilde = entity-and-time-demeaned. β3
(lagged volume) is a documented correction — its earlier omission was
the likely cause of a sign contradiction between this pooled model and
the per-company (M1) results; this reasoning must be stated wherever this
equation is reported, not just implemented silently.
- **H4:** add ASVI×Sector interaction terms; Wald test on joint
  significance.
- **H5:** add ASVI×Div_lag1 interaction. Report both the full-sample
  result and the result excluding the confirmed robustness-check
  candidates from Section 3.
- **H6:** add ASVI×SOE interaction. Report both the base result and the
  result with sector fixed effects also included (checks whether the SOE
  effect is actually a sector effect in disguise, given SOE status is
  concentrated in Utilities/Energy).

**H3 (M5, Chow structural break):** asymmetric Chow at 2022-02-24,
reduced form (ASVI_lag1, RV_lag1 only, plus a crisis_chow dummy in the
post-period), q = 3, k_pool = 4. Apply Giles-Lieberman heteroscedasticity-
robust bounds using the actual published tabulation (source:
`canterbury-nz-034.pdf`, already available) — do not use an approximate
substitute without first attempting genuine extraction from that source;
if extraction is genuinely impossible, this is a named blocker, not a
silent substitution.

**M6 (permutation + power, H1/H2 robustness):** 1,000 random shuffles of
each company's ASVI series, re-fit M1, compute the permutation p-value.
Statistical power and minimum detectable effect (MDE) at 80% power via
the non-central t-distribution, for every company. Any null result must
be reported alongside its power — "inconclusive due to insufficient
power," never "no effect exists," whenever power < 0.80.

## 5. NEW — Sector-Wise Pooled Panels

**Purpose:** a direct, subgroup-level complement to H4's interaction-term
test — instead of one combined model estimating how the ASVI effect
*shifts* by sector, this runs the base pooled equation *separately within
each sector*, producing a directly comparable, independently-estimated
β1 per sector.

**Equation, run separately for each sector:**
`RṼ(i,t) = β1·ÃSVI(i,t−1) + β2·RṼ(i,t−1) + β3·ln[Ṽ(i,t−1)] + β4·Dĩv(i,t−1) + ε̃(i,t)`
(same entity + time fixed effects, same controls, same lagged-volume
correction — identical specification to the main M4 equation, just
estimated on one sector's companies at a time instead of the full panel.)

**Minimum-N rule (state this explicitly, do not skip it):** only run a
sector-wise pool for a sector with **at least 4 companies** — a smaller
sector cannot support meaningful entity fixed effects, and its ASVI
effect is already captured only through the interaction-term approach in
the unified H4 model. Any sector below this threshold (documented cases
include Industrial and Insurance, each with very few companies) must be
explicitly listed as "insufficient N for a separate sector pool" rather
than silently omitted or force-estimated on too few companies.

**Report:** each qualifying sector's β1, standard error, p-value, and N
(companies × weeks), presented alongside the corresponding sector
coefficient from H4's interaction-term model — these two approaches
should tell a consistent story; if they materially disagree for a given
sector, that disagreement itself is worth reporting, not resolved by
picking whichever number looks better.

## 6. NEW — Government / Non-Government (SOE) Pooled Split

**Purpose:** a direct, subgroup-level complement to H6's interaction-term
test — instead of one combined model estimating how the ASVI effect
*shifts* with SOE status, this splits the panel into two groups and
estimates the base equation separately in each.

**Construction:** split the 75-company panel into two groups using
SOE(i): **Group G (government)** = all companies with SOE=1; **Group P
(private)** = all companies with SOE=0. Companies classified UNDETERMINED
are EXCLUDED from both groups for this specific analysis (report how many
and which, do not force a guess) — this exclusion applies only to this
Section 6 analysis, not to the rest of the study.

**Equation, run separately for Group G and Group P:**
`RṼ(i,t) = β1·ÃSVI(i,t−1) + β2·RṼ(i,t−1) + β3·ln[Ṽ(i,t−1)] + β4·Dĩv(i,t−1) + ε̃(i,t)`
(identical specification to the main M4 equation, estimated once on each
ownership group.)

**Mandatory sector-confound check:** because SOE status is heavily
concentrated in specific sectors (documented: 13/14 Utilities and 8/13
Energy companies are SOE=1), re-estimate Group G's equation a second time
WITH sector fixed effects included, if Group G contains enough
within-group sector diversity to support them. Report both versions side
by side. If Group G's β1 changes substantially once sector effects are
added, state plainly that the apparent "government ownership effect" may
be partly or wholly a sector effect, not an ownership effect — this is a
required, not optional, disclosure.

**Report:** β1, standard error, p-value, and N for Group G and Group P
side by side, plus the sector-controlled Group G re-estimate, presented
alongside H6's interaction-term coefficient — again, these should tell a
consistent story, and any disagreement is itself a reportable finding.

## 7. Named Sensitivity Checks (run exactly these six; nothing substituted)

1. Drop the 5 revision-affected News events; confirm the explained-spike
   share moves from 62.2% toward the documented 61.7%.
2. Widen News windows to t...t+5 for persistence-flagged events.
3. Re-run with strict Crisis/Sanction definitions; confirm the residual
   unexplained-spike share moves toward 49.2%.
4. Re-run H5 excluding the confirmed robustness-check candidates from
   Section 3 (target: 11 companies).
5. Re-run H6 (and the Section 6 government-group re-estimate) using
   federal-only SOE classification, excluding regional-only control.
6. Flip-test VSMO's SOE classification (0 vs. 1) given its documented
   knife-edge 25%+1 ownership stake.

## 8. Protocol for Missing or Unrecoverable Data

Never reconstruct silently and present the result as equivalent to the
original. When something is missing: (a) state plainly what is missing,
(b) state what was tried to recover it, (c) if a substitute was used,
state precisely how it differs from the original and its quantitative
consequence, (d) flag the affected result as PROVISIONAL until the real
data is recovered. This applies without exception to: the Giles-Lieberman
tabulation, the full 587-row dividend date table, the company exclusion
registry, and any other gap discovered that isn't listed here.
