# AGENT 4 — FINAL VERIFIED EXPANSION LIST

**77 additional companies verified for the pooled panel** (study window 2018-08-27 → 2026-02-28, weekly).
Combined with the existing 75-company panel → **152 companies**. Ranked by sector, then market capitalisation
(PREVPRICE × ISSUESIZE from MOEX ISS, 2026-09-14; approximate).

## Banking — 2 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **PRMB** | AKB Primorye (Vladivostok) | Банк «Приморье» | 4.5 | 357/392 | FLAG: no trades for 17 consecutive weeks Aug-Dec 2018 + 7 wks Jan-Feb 2019 (357/392 window weeks) — illiquidity, not suspension (no suspension records |
| 2 | **KUZB** | Bank Kuznetsky (Novokuznetsk) | Банк Кузнецкий | 0.6 | 388/392 | FLAG: very thin float; speculative rally Oct 2019 (price action); no rename found in registry/news |

## Financials (non-bank) — 3 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **MOEX** | Moscow Exchange | Московская биржа (МосБиржа) | 344.9 | 389/392 | FLAG: 'мосбиржа' is used as a generic market term — search-contamination risk (analogous to 'Сбер' in the existing panel) |
| 2 | **RUSI** | IK Russ-Invest (investment co) | Русс-Инвест | 6.7 | 368/392 | FLAG: thin trading 2018 (24 wks without trades, incl. 8-wk and 7-wk stretches); early identity history to be confirmed by researcher (no in-window ren |
| 3 | **ARSA** | UK Arsagera (asset manager) | Арсагера | 0.8 | 387/392 | FLAG: repeated share issues (dilution) — use adjusted series |

## Insurance — 0 new
*No new verified companies in this sector (see shortfall report).*

## Energy — 3 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **TRNFP** | Transneft (preferred — the only publicly traded class) | Транснефть | 158.1 | 389/392 | note: ordinary shares are state-held and not exchange-listed; prefs are the liquid instrument |
| 2 | **KRKN** | Saratov Refinery | Саратовский НПЗ | 7.5 | 387/392 | note: trading resumed June 2016 after a long pre-window suspension |
| 3 | **CHGZ** | RN-Zapadnaya Sibir (Rosneft sub, ex-Chernogorneft) | РН-Западная Сибирь | 3.3 | 379/392 | note: renamed from «Черногорнефть» in Dec 2016 — PRE-window |

## Metals & Mining — 6 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **MTLR** | Mechel | Мечел | 16.0 | 388/392 | FLAG: deep financial distress (restructuring 2015-17, creditor pressure 2024-25) — but no delisting/suspension occurred; pref MTLRP also liquid (near- |
| 2 | **URKZ** | Uralskaya Kuznitsa (Uralkuz, Mechel) | Уральская кузница (Уралкуз) | 11.2 | 388/392 | - |
| 3 | **BRZL** | Buryatzoloto (gold) | Бурятзолото | 8.9 | 388/392 | - |
| 4 | **KOGK** | Korshunovsky Mining & Processing Plant (iron ore) | Коршуновский ГОК | 5.7 | 388/392 | - |
| 5 | **UNKL** | South-Ural Nickel Combine | ЮУНК (Южно-Уральский никелевый комбинат) | 1.9 | 388/392 | - |
| 6 | **LNZL** | Lenzoloto (gold; holds Polyus stake) | Лензолото | 1.4 | 388/392 | note: huge special dividend 2021 (~48% price drop at ex-date — dividend, not a split) |

## Chemicals — 3 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **HIMCP** | Khimprom (preferred) | Химпром | 3.2 | 388/392 | note: only the preferred class is listed |
| 2 | **NKSH** | Nizhnekamskshina (tyres) | Нижнекамскшина | 2.0 | 388/392 | note: TAIF group (related to NKNC in existing panel) but a distinct listed entity — not a duplicate |
| 3 | **VLHZ** | Vladimir Chemical Plant | Владимирский химический завод | 0.7 | 388/392 | - |

## Healthcare & Pharma — 4 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **APTK** | Aptechnaya Set 36,6 (pharmacy chain) | Аптеки 36,6 | 45.8 | 388/392 | FLAG: numeric/temperature brand '36,6' — search-contamination risk; speculative rally mid-2019; long distress history (not a listing criterion) |
| 2 | **LVHK** | Levenguk (medical clinic network) | Левенгук | 1.0 | 388/392 | note: contrary to common recollection, MOEX listing predates 2016 (weekly data continuous since at least Jun 2016; 54/56 pre-2017 weeks) |
| 3 | **LIFE** | Pharmsintez (Novosibirsk) | Фармсинтез | 0.8 | 388/392 | - |
| 4 | **DIOD** | DIOD Plant (medical equipment) | Завод ДИОД | 0.7 | 388/392 | - |

## Consumer & Retail — 2 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **KROT** | Krasny Oktyabr (confectionery) | Красный Октябрь | 8.7 | 388/392 | FLAG: 'красный октябрь' is a common historical phrase — moderate search contamination; Guta/United Confectioners group; tiny free float |
| 2 | **ROST** | Rosinter Restaurants | Росинтер | 1.1 | 388/392 | - |

## Agriculture & Food — 1 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **NKHP** | Novorossiysk Grain Terminal (NKHP) | НКХП | 25.9 | 388/392 | - |

## Telecom — 3 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **NSVZ** | Nauka-Svyaz (telecom operator) | Наука-Связь | 3.1 | 388/392 | FLAG: contains common word 'наука' — moderate search-contamination risk |
| 2 | **CNTL** | Central Telegraph | Центральный телеграф | 1.4 | 388/392 | note: preferred (CNTLP) is the more liquid class; display shortname 'Телеграф' is an abbreviation |
| 3 | **BISVP** | Bashinformsvyaz (preferred) | Башинформсвязь | 0.4 | 388/392 | note: only the preferred class remains listed (ord bought out by Rostelecom in 2015, pre-window) |

## Technology — 2 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **RKKE** | RKK Energia im. Koroleva (rocket-space corp) | РКК «Энергия» | 21.3 | 388/392 | - |
| 2 | **RBCM** | RBC Group | РБК | 2.8 | 388/392 | FLAG: 'РБК' is a top Russian news brand — MAJOR search contamination (people search 'РБК' for news, not the stock) |

## Real Estate — 1 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **WTCM** | World Trade Center Moscow (Centr Mezhdunarodnoy Torgovli) | ЦМТ (Центр международной торговли) | 16.4 | 388/392 | - |

## Transportation — 0 new
*No new verified companies in this sector (see shortfall report).*

## Industrials — 16 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **UWGN** | NPC United Wagon Company (railcars) | ОВК (Объединённая вагонная компания) | 59.2 | 388/392 | flags: 2021-22 bankruptcy restructuring (equity survived, trading never halted); dilutive SPO Nov 2023 (price -40%); heavy speculative turnover |
| 2 | **OMZZP** | OMZ / United Heavy Machinery (preferred; Gazprombank group) | ОМЗ | 25.9 | 387/392 | note: only the preferred class is listed; possible group-level rebranding ('ОМЗ Перспективные Технологии') with colloquial 'ОМЗ' stable throughout |
| 3 | **VSYD** | Vyborg Shipyard | Выборгский судостроительный завод | 25.6 | 387/392 | - |
| 4 | **PAZA** | Pavlovsk Bus Plant | Павловский автобус (ПАЗ) | 12.7 | 377/392 | note: GAZ-group related (distinct entity from GAZA candidate and KMAZ in panel); speculative rally early 2018 |
| 5 | **ZILL** | ZIL (Likhachev Plant; land/asset shell) | ЗИЛ | 12.0 | 388/392 | flags: large share consolidation during the period (current share count ~2.7m vs ~2.7bn pre-consolidation ⇒ ~1000:1, 2021) — exchange & investing.com  |
| 6 | **SVAV** | Sollers (auto holding) | Соллерс | 11.6 | 388/392 | notes: 2022 change of controlling shareholder (MBO by management — no minority squeeze-out); large dividends 2022-24 (45-89 RUB) explain price drops;  |
| 7 | **CHKZ** | Chelyabinsk Forge-and-Press Plant (ChKPZ) | ЧКПЗ | 10.0 | 385/392 | - |
| 8 | **GAZA** | GAZ (Gorky Automobile Plant) | ГАЗ | 7.8 | 388/392 | FLAG: 'газ' is a common Russian word (gas) — MAJOR search-contamination risk; US SDN sanctions since Apr 2018 (shares kept trading on MOEX); distresse |
| 9 | **NAUK** | NPO Nauka (aerospace systems) | НПО «Наука» | 4.9 | 388/392 | FLAG: 'наука' is a common word (science) — MAJOR search-contamination risk |
| 10 | **KMEZ** | Kovrov Mechanical Plant (Rosatom/TVEL gas centrifuges) | Ковровский механический завод (КМЗ) | 4.1 | 388/392 | - |
| 11 | **IGST** | Izhstal (special steels, Mechel) | Ижсталь | 3.1 | 388/392 | - |
| 12 | **ZVEZ** | Zvezda (St Petersburg diesel/reducer plant) | Звезда | 3.0 | 388/392 | flags: 'звезда' is a common word (star) — MAJOR search-contamination risk; stock restricted to qualified investors (MOEX note) |
| 13 | **NFAZ** | NEFAZ (Neftekamsk truck/bus plant) | НЕФАЗ | 1.6 | 388/392 | note: KAMAZ subsidiary — different legal entity from KAMAZ already in panel (not a share-class duplicate) |
| 14 | **KRKOP** | TKZ Krasny Kotelshchik (Taganrog boilers, PM-sub) | Красный котельщик | 1.0 | 388/392 | note: only the preferred class is listed |
| 15 | **TUZA** | Tuymazy Concrete-Mixer Truck Plant | Туймазинский завод автобетоновозов (ТЗА) | 0.7 | 383/392 | - |
| 16 | **DZRD** | Donskoy Radio Components Plant | Донской завод радиодеталей (ДЗРД) | 0.4 | 387/392 | - |

## Utilities — 31 new

| # | Ticker | Company | Search term (RU) | Mcap, bn ₽ | Weeks traded | Key flags |
|---|--------|---------|------------------|-----------|--------------|-----------|
| 1 | **MRKY** | Rosseti Yug (ex-MRSK Yuga) | Россети Юг | 49.5 | 388/392 | FLAG: 2019-20 rebrand (as above) |
| 2 | **TNSE** | TNS Energo Holding (parent of the regional sbyt companies) | ТНС энерго | 46.1 | 388/392 | note: parent of KBSB/NNSB/MISB/RTSB/VRSB/YRSB candidates — same-group clustering to note in regression design |
| 3 | **MRKV** | Rosseti Volga (ex-MRSK Volgi) | Россети Волга | 36.3 | 388/392 | FLAG: rebranded from «МРСК Волги» in 2019-20 (in-window legal rename; SAME convention as existing panel's MRKC/MRKK/MRKP/MRKS/MRKU/MSRS which had iden |
| 4 | **DVEC** | Far Eastern Energy Co (DTEK) | ДЭК | 24.6 | 388/392 | - |
| 5 | **RTSB** | TNS Energo Rostov-on-Don | ТНС энерго Ростов-на-Дону | 21.9 | 387/392 | note: thin trading spells 2018-2021 |
| 6 | **KCHE** | Kamchatskenergo | Камчатскэнерго | 21.5 | 387/392 | - |
| 7 | **KBSB** | TNS Energo Kuban | ТНС энерго Кубань | 15.6 | 385/392 | note: thin trading autumn 2018 (7 wks without trades) |
| 8 | **PMSB** | Perm Energy Sales Co | Пермэнергосбыт | 15.3 | 388/392 | - |
| 9 | **VRSB** | TNS Energo Voronezh | ТНС энерго Воронеж | 13.1 | 380/392 | note: thin trading 2018 (12 wks without trades) |
| 10 | **MRKZ** | Rosseti North-West (ex-MRSK Severo-Zapada) | Россети Северо-Запад | 12.3 | 388/392 | FLAG: 2019-20 rebrand (as above) |
| 11 | **NNSB** | TNS Energo Nizhny Novgorod | ТНС энерго Нижний Новгород | 12.3 | 379/392 | note: thin trading 2018 (13 wks without trades) |
| 12 | **KRSB** | Krasnoyarsk Energy Sales Co | Красноярская энергосбытовая | 11.8 | 388/392 | - |
| 13 | **YRSB** | TNS Energo Yaroslavl | ТНС энерго Ярославль | 10.9 | 365/392 | FLAG: thin trading 2018 (27 wks without trades, longest streak 6 wks — vs existing panel worst AVAN 16 wks/4-wk streaks); no suspension records |
| 14 | **LPSB** | Lipetsk Energy Sales Co (LESK) | ЛЭСК (Липецкая энергосбытовая) | 7.6 | 379/392 | note: thin trading 2018 (13 wks without trades) |
| 15 | **RZSB** | Ryazan Energy Sales Co | Рязанская энергосбытовая | 7.2 | 387/392 | - |
| 16 | **SAGO** | Samaraenergo (ex-Volga TGC) | Самараэнерго | 7.2 | 386/392 | note: traded separately since 2011 after TGC-7 collapse |
| 17 | **TGKB** | TGC-2 (generation, North-West) | ТГК-2 | 7.0 | 388/392 | note: distinct from TGC-1 (TGKA) already in panel |
| 18 | **MISB** | TNS Energo Mari El | ТНС энерго Марий Эл | 6.2 | 379/392 | note: thin trading 2018-19 (13 wks without trades, longest 6w) |
| 19 | **SLEN** | Sakhalinenergo | Сахалинэнерго | 6.0 | 388/392 | note: no trades Jun 2016-Feb 2017, trading (re)started 6 Feb 2017 — PRE-window resumption; continuous thereafter |
| 20 | **VGSB** | Volgograd Energy Sales Co | Волгоградская энергосбытовая | 5.3 | 386/392 | - |
| 21 | **TGKN** | TGC-14 (Chita generation) | ТГК-14 | 5.0 | 388/392 | - |
| 22 | **RTGZ** | Gazprom Gazoraspredeleniye Rostov-on-Don (ex-Rostovoblgaz) | Газпром газораспределение Ростов-на-Дону | 4.2 | 386/392 | note: renamed from «Ростовоблгаз» in Oct 2013 — PRE-window; Gazprom-group entity distinct from GAZP |
| 23 | **SARE** | Saratovenergo (ex-Volga TGC) | Саратовэнерго | 3.7 | 388/392 | note: traded separately since 2012 |
| 24 | **YKEN** | Yakutskenergo | Якутскэнерго | 3.7 | 388/392 | note: DISTINCT from YATEK (YAKG) already in panel — easily confused names, verify search terms separately |
| 25 | **STSB** | Stavropolenergosbyt | Ставропольэнергосбыт | 3.0 | 388/392 | note: legal rename to ПАО «ЕГП» (Единый Гарантирующий Поставщик) occurred Jun-Jul 2026 — AFTER the study window; throughout 2018-2026 the public name  |
| 26 | **TORS** | Rosseti Tomsk (ex-Tomsk Distribution Co) | Россети Томск | 2.8 | 383/392 | FLAG: 2019-20 rebrand (as other Rosseti subs) |
| 27 | **TASB** | Tambov Energy Sales Co | Тамбовская энергосбытовая | 2.1 | 387/392 | - |
| 28 | **ASSB** | Astrakhan Energy Sales Co | Астраханская энергосбытовая | 1.9 | 388/392 | - |
| 29 | **KLSB** | Kaluga Sales Co | Калужская сбытовая компания | 1.7 | 388/392 | - |
| 30 | **MRSB** | Mordovia Energy Sales Co | Мордовская энергосбытовая | 1.3 | 388/392 | - |
| 31 | **MAGE** | Magadanenergo | Магаданэнерго | 0.9 | 388/392 | - |

---

## Honest shortfall report: 77 verified vs ~100 targeted

The pipeline verified **77** additional companies, not 100. This is not for lack of candidates
(144 issuer-level candidates were examined) — it reflects the arithmetic of the eligibility criteria
over what MOEX actually lists:

1. **57 of 144 candidates began trading under their current instrument after mid-2017** (criterion 1):
   the 2018–2026 period was an IPO wave (Ozon, Sovcombank, Positive, Fix Price, Cian, Astra, Yandex-MKPAO,
   HeadHunter, …) plus re-listings of redomiciled groups (X5, Rusagro, Europlan, Evraz) whose current
   instruments have no pre-2017 history.
2. **10 more failed on continuity/identity grounds**: in-window going-private events and suspensions
   (AMEZ — squeeze-out by «Урал-ВК» and MOEX trading termination 15.03.2025; MGNZ suspended from
   Nov 2022 to study end; KGKC; the ГАЗКОН/ГАЗ-сервис/ГАЗ-Тек shell family with 2–3 window weeks each)
   and in-window brand/ticker changes (AQUA→«Инарктика» Sep 2022; ИСКЧ→«Артген» Jul 2023 incl. ticker
   ISKJ→ABIO; ЧЗПСН→«Теплант Восток» Apr 2025; Enel→ЭЛ5 2023; Tinkoff→Т-Технологии 2024) plus SPB
   Exchange (current instrument from Nov 2021, 1:500 consolidation, license revoked Nov 2024).
3. **~25 preferred-share classes of new issuers were excluded** as near-duplicates under criterion 6
   (one class per issuer).
4. **The eligible universe is essentially exhausted.** Of ~506 TQBR securities, only 114 traded under
   their current ticker before mid-2017; subtract the existing 75 issuers and their second classes, the
   documented failures, and what remains is the 77 companies above. Getting to 100 would require
   relaxing one of the six criteria (e.g., accepting 2017 H2 listings or in-window renames) — that is
   the researcher's call to make explicitly, not this pipeline's. **No company was padded in.**

Sector gaps that follow from the same arithmetic: **Transportation +0, Insurance +0** (every candidate
in these sectors is a post-2017 listing: Sovcomflot, Whoosh, Renaissance Insurance, etc.). Banking adds
only 2 (KUZB, PRMB — both flagged for thin 2018 trading). Utilities contributes 31 of 77 (40%) — the
surviving pre-2017 universe is heavily sbyt/grid-weighted; note the ТНС-энерго and Россети group
clusters (7 and 4 companies respectively) for cross-sectional dependence controls.

## Integrity confirmation

- **The six criteria in the user's specification were the only basis** for every inclusion/exclusion.
  No company was excluded for illiquidity, size, sector, or data convenience; no company was included
  for sector balance or to reach a target count.
- **Every determination is company-specific**: backed by MOEX ISS exchange data (ticker-level daily
  history for 2017 presence; weekly candles across the 392-week window; gap analysis with the
  Feb 18 – Apr 24, 2022 market closure whitelisted) and, where the exchange data cannot see the fact,
  by dated web/registry evidence (renames, consolidations, buyouts, suspensions) — 26+ documented sources.
- The previous attempt's failure mode (templated identical justifications hiding real delistings) was
  explicitly audited — and the audit **caught one real delisting that Agent 2 had passed (AMEZ: Mar-2025
  squeeze-out)**, demoting it to FAIL. Justification similarity was cut to 6 genuinely-parallel pairs;
  20 high-risk micro-caps were re-verified through a second, independent data path — 20/20 confirmed.
- Known open items are flagged, not hidden: search-term contamination (GAZA, NAUK, NSVZ, ZVEZ, MOEX,
  RBCM, KROT), thin 2018 trading (PRMB 35 wk, RUSI 24 wk, YRSB 27 wk missing), ZILL's ~1000:1
  consolidation (adjusted series continuous), qualified-investors-only status (ZVEZ), UWGN's Nov-2023
  dilutive SPO, and the Rosseti 2019–20 rebrand convention inherited from the existing panel.

**Final answer: 77 additional verified companies → pooled panel of 152 companies.**
