# Results and Discussion (Revised) — Round 3

**Study.** Investor attention (Yandex Wordstat search volume, ASVI constructed per Da, Engelberg &
Gao) and the volatility/returns of 75 MOEX-listed equities, weekly, 2018-08-27 – 2026-02-23
(29,401 company-weeks).

**What changed in this round.** Three of the four control variables that were missing in the
provisional round now exist: `Crisis(t)` and a static `SOE(i)` flag have been constructed, and the
structural-break test has been re-evaluated under heteroscedasticity-robust bounds. A pre-specified
quantile regression and a pre-specified pre/post-2021 split have been run. H6 is now testable. H5 is
not, and remains unreported as either confirmed or rejected.

**Reproduction note.** The supplied archive contains only raw per-company files — no `panel.csv`. The
panel was therefore rebuilt from source. The rebuild reproduces every published figure of the prior
round exactly: 22 positive / 53 negative Method-1 coefficients, median b₁ = −0.0068, median |b₁| =
0.0094, n ∈ [255, 379] with median 375, the identical 2 positive- and 12 negative-significant
company lists, the pooled coefficient +0.00264 (clustered SE 0.00144, N = 27,924), and the identical
33-company Chow rejection list with 33/22/36 significant at 5%/1%/10%. All figures below rest on
that validated panel.

---

## 5.2 Headline finding

Across the full panel, lagged attention has a **positive but conventionally insignificant**
association with next-week volatility: **+0.00264 (entity-clustered SE 0.00144, p = 0.067;
robust SE 0.00136, p = 0.052), N = 27,924**. At the company level the sign distribution runs the
other way — 53 of 75 coefficients are negative — and this contrast is reported as found, not
reconciled. The three new specifications added this round qualify that headline in two directions:
the pooled positive estimate is **stronger before 2022 than after** (§5.5), and the sign of the
attention effect **reverses across the volatility distribution**, negative in calm weeks and
positive in volatile ones (§5.6).

---

## 5.3 H1 — Attention → Volatility: underpowered, not absent

**Result.** Two of 75 companies show a significant *positive* Method-1 coefficient at 5% — MFGS
(+0.0321, SE 0.0125, p = 0.010, n = 373) and KAZT (+0.0181, SE 0.0089, p = 0.042, n = 373). Twelve
show a significant *negative* coefficient. After Benjamini–Hochberg correction within the 225-test
H1 block, **no** Granger test survives at any conventional level (smallest BH-adjusted p = 0.292;
Holm smallest p = 0.50).

**The reframing, with the headline number first.** The 61 non-significant company results are not
evidence of no effect. They are evidence that this design cannot see an effect of the size actually
present.

> **To detect the median observed company-level attention effect (|b₁| = 0.0094) with 80% power, this
> study would need a median of 2,214 company-weeks per firm — 5.9 times the 375 actually observed,
> equivalent to roughly 43 years of weekly data for a single company where 7.5 years are available.**

The supporting figures: only **4 of 75** companies reach 80% power at their own observed effect size
— RTKM (0.995), SNGS (0.964), PHOR (0.900), LSRG (0.881) — and **all four have significant negative
coefficients**, so the negative findings that do carry power are the adequately powered ones. Median
power across the sample is **0.202**. The median minimum detectable effect at 80% power is **0.0249**
in b₁ units, which is **2.65 times** the median observed |b₁| of 0.0094.

The inference follows directly: the study is powered to detect only comparatively *large*
company-level attention effects. Any statement of the form "attention does not affect volatility for
firm *i*" is unsupported for 71 of 75 firms. The correct statement is that **H1 is unsupported at the
aggregate level and inconclusive at the company level for lack of power**, with the caveat that the
company-level estimates which *are* adequately powered are predominantly negative — the opposite sign
to H1.

## 5.4 H2 — Attention → Returns

One of 75 companies shows a significant positive coefficient (GCHE +0.0115, SE 0.0052, p = 0.027);
four show significant negative coefficients. After BH correction within the separate 225-test H2
block, no test survives (smallest BH-adjusted p = 0.379; Holm smallest 0.50). Signs: 28 positive,
47 negative; median b₁ = −0.0036. **H2 is not supported**, and as with H1 the non-significant results
are inconclusive for lack of power rather than demonstrated nulls.

## 5.5 H3 — Structural break at February 2022, under heteroscedasticity-robust bounds

The prior round's Chow test assumed homoscedastic errors, which the Feb–Apr 2022 window plainly
violates. Giles & Lieberman (1991) provide **data-independent** bounds on the true size of the Chow
test under two-group heteroscedasticity, requiring only `K` (number of restrictions), `T₁`, `T₂` and
θ, the ratio of post- to pre-period error variance. θ̂ was computed exactly as in the paper's worked
example, as the ratio of subsample residual variances. The bound implementation was validated by
reproducing **12 of 12 rows of the paper's Table 1**.

**Nominal → robust → bounds-survivor counts.** Of the 33 companies nominally significant at 5%:

| | Count | Share of 33 |
|---|---|---|
| Nominally significant (homoscedastic Chow, 5%) | **33** | 100% |
| **Survive** the robust upper bound, F > C_U(0.05) — reject for *every* admissible θ | **24** | 73% |
| **Indeterminate**, C_L(0.05) ≤ F ≤ C_U(0.05) — verdict depends on the true θ | **9** | 27% |
| **Fail**, F < C_L(0.05) | **0** | 0% |

Across all 75 companies: 24 survive, 16 indeterminate, 35 fail.

**Pre-specification outcome: CONFIRMED.** The pre-specified threshold for confirming H3-robust was a
majority (>16) of the 33 nominal rejections surviving `C_U(0.05)`. Twenty-four survived. H3 is not an
artefact of the volatility spike.

**What θ̂ says about the nature of the break.** The median estimated variance ratio over the 33
nominal rejections is **0.710** (range 0.162–3.344), i.e. for the typical firm the *post*-break error
variance is **lower** than the pre-break variance. The break is therefore not primarily a
variance-inflation story; and in every case the upper bound on the test's true size is modest — α_U
ranges from 0.050 (MRKU, essentially undistorted) to 0.238 (SBER, the most heteroscedastic case).
Even in the worst case the nominal rejection retains an interpretable bound rather than collapsing.

**The nine indeterminate firms** are KAZT, MRKC, NVTK, SBER, SELG, TGKA, VJGZ, VTBR, YAKG. For these
the data cannot distinguish a coefficient break from a variance-regime shift, and they should be
described as such rather than counted as breaks.

**Scope caveat, stated plainly.** Giles–Lieberman is derived for the *symmetric* full-vector Chow
test. Our Method-4 test is asymmetric (3 pre-period parameters, 4 post-period including a post-only
crisis dummy, denominator df = n − 7), so applying the bounds with K = 3 is an approximation. A
**pure symmetric Chow** — which sits exactly inside the paper's framework — was therefore also run:
28 nominal 5% rejections, of which **21 survive**, 16 indeterminate, 38 fail. The qualitative
conclusion is unchanged under the exactly-specified version.

## 5.6 Heterogeneity across the volatility distribution (pre-specified quantile regression)

Following the template of Swamy, Dharani & Takeda (2019), the pooled panel was estimated at their
exact primary grid — the ten quantiles 0.05, 0.10, 0.20, …, 0.90 of the dependent variable — with
`ASVI_lag1`, `RV_lag1`, `lnV_lag1` and firm and week fixed effects.

| τ | 0.05 | 0.10 | 0.20 | 0.30 | 0.40 | 0.50 | 0.60 | 0.70 | 0.80 | 0.90 |
|---|---|---|---|---|---|---|---|---|---|---|
| ASVI_lag1 | −0.00265 | −0.00278 | −0.00269 | −0.00212 | −0.00153 | −0.00071 | +0.00001 | +0.00237 | +0.00438 | **+0.00659** |
| p | 0.115 | 0.011 | 0.001 | 0.002 | 0.014 | 0.258 | 0.985 | 0.006 | 0.000 | 0.009 |

**The sign of the attention effect reverses across the volatility distribution.** It is negative and
significant in the bottom four quintiles, indistinguishable from zero at the median, and positive and
significant in the top three. This is the *opposite* pattern to the India paper, where the effect is
negative only in the two lowest quantiles and positive from 0.30 upward — but the shared feature is
that the conditional-mean estimate conceals it entirely.

**Pre-specification outcome: CONFIRMED, with a caveat that must be stated.** The pre-specification
was met if *either* |b(0.90) − b(0.10)| ≥ 0.0094 (the median observed |b₁|) *or* the sign changed
across quantiles. **The sign-change criterion is met decisively; the magnitude criterion is not.**
The observed spread is **+0.00937**, a hair below the 0.0094 threshold. The independent audit
re-estimated the grid by explicit fixed-effect dummies rather than the within-transformation and
obtained a smaller spread still — b(0.10) = −0.00262, b(0.90) = +0.00526, spread **+0.00788** — with
the sign reversal intact. So the confirmation rests on the **sign change**, which is robust to the
estimation route, and **not** on the magnitude, which is not. Both routes are reported; the
magnitude claim should not be made.

## 5.7 Pre/post-2021 subsample split — a disconfirmed pre-specification

The panel was split at end-2021 (pre = weeks ≤ 2021-12-27; post = weeks ≥ 2022-01-03), chosen
ex ante for its relationship to the sanctions timeline. No alternative breakpoint was searched.

| Specification | b (ASVI_lag1) | Clustered SE | p | N |
|---|---|---|---|---|
| Pooled FE, **pre**-2022 | **+0.00457** | 0.00177 | **0.0097** | 12,174 |
| Pooled FE, **post**-2021 | +0.00293 | 0.00207 | 0.156 | 15,750 |
| Pooled FE, full sample | +0.00264 | 0.00144 | 0.067 | 27,924 |

Per-company: the share of negative b₁ falls from **62.7% (47/75)** pre to **53.3% (40/75)** post;
median b₁ moves from −0.00301 to −0.00152; 37 of 75 firms flip sign. Significance counts: pre
0 positive / 6 negative; post 5 positive / 6 negative.

**Pre-specification outcome: DISCONFIRMED, and reported as such.** The pre-specified criteria were a
sign change in the pooled coefficient or a ≥15 percentage-point shift in the share of negative
company coefficients. Neither occurred: the pooled coefficient keeps the **same sign** in both
periods (post is 64% of pre, outside the ~20% band but not a sign reversal), and the shift in sign
share is **9.4 percentage points**, below the 15-point threshold. The pre-period estimate is larger
and significant while the post-period estimate is smaller and insignificant, which is suggestive —
but it is a difference in precision and magnitude, **not** the regime dependence the
pre-specification was written to detect. This result is reported with the same prominence as the two
confirmed ones; it is not the specification that produced a significant result, and it is not
buried.

## 5.8 H4 — Sector heterogeneity (unchanged)

Adding 12 ASVI × sector interactions to the pooled FE model gives a joint Wald test that is highly
significant with entity-clustered covariance (χ²(12) = 623.4, p = 1.1×10⁻¹²⁵) and insignificant with
heteroskedasticity-robust covariance (χ²(12) = 17.1, p = 0.146). Both are reported; neither is
suppressed. Under clustered inference the slope is most negative relative to Banking for Industrial
(a single company, KMAZ) and Real Estate, and most positive for Insurance (a single company, RGSS)
and Tech. Because the two extreme sectors contain one company each, those terms are company-specific
slopes in substance and the sector reading is correspondingly weak.

## 5.9 H5 — Dividend season: still untestable

No dividend-date reference data exist in the supplied files. The `Div(i,t)` term was omitted from all
equations rather than proxied or zero-filled. **H5 is not reported as either confirmed or rejected.**

## 5.10 H6 — State ownership: now testable, and disconfirmed

The static `SOE(i)` flag (Russian federal or federal-subject government, directly or via a
state-controlled entity, ≥25% of voting shares as of 2024) classifies **34 of 75** companies as
state-owned and 41 as private. **No company was left UNDETERMINED**, so the include/exclude
UNDETERMINED variants the protocol calls for are identical and only one estimate is reported.
Because SOE is time-invariant, its main effect is absorbed by the entity fixed effects and only the
interaction is identified.

| Specification | ASVI_lag1 (non-SOE) | **ASVI × SOE** | SE | t | p |
|---|---|---|---|---|---|
| Entity-clustered (**primary**) | +0.00291 | **−0.00060** | 0.00286 | −0.21 | **0.833** |
| Heteroskedasticity-robust | +0.00291 | −0.00060 | 0.00244 | −0.25 | 0.804 |
| Federal-only SOE definition | — | −0.00127 | 0.00294 | −0.43 | 0.665 |

Implied slopes: **+0.00291 for private firms, +0.00230 for state-owned firms** — a difference of
0.0006, one order of magnitude below the 0.005 pre-specified as economically meaningful.

**Pre-specification outcome: DISCONFIRMED.** The interaction is insignificant at 5% under both
covariance estimators and under the narrower federal-only definition. **H6 is not supported:** on
this panel, state ownership does not moderate the attention–volatility relationship.

**Two caveats on the flag itself.** First, three of the 34 (TATN, TTLK, UTAR) are controlled by
*federal-subject* governments (Tatarstan, Khanty-Mansi AO/Tyumen) rather than the federal
government; the federal-only variant above excludes them and reaches the same conclusion. Second,
UPRO (Unipro) is coded SOE = 0 because Uniper SE still holds 83.73% of it: since April 2023 that
stake has been under Russian *temporary state administration*, but the presidential decree "does not
concern ownership matters and does not deprive the owners of their assets." Administration is not
ownership, and the flag follows ownership — but UPRO is a genuine edge case and is named here.
Finally, **54 of the 75 determinations rest on standard disclosure that was not re-verified against
a fresh source during this round**; 21 were verified by search, and the VSMO determination was
confirmed verbatim against Rostec's own press release. The 54 should be checked against primary
filings before submission.

## 5.11 Statistical power and permutation falsification

Covered in §5.3. In addition, the 1,000-draw permutation falsification test (seed 20260913) rejects
the no-relationship null at 5% for 15 companies, 11 of them with negative b₁, and no company's
significant HAC result is contradicted by a permutation p near 1 — so none of the reported
coefficients is attributable to chance time-alignment alone.

---

## 5.12 Case study: Yandex (YNDX) — a sign-reversed attention effect

*Reproduced in substance unchanged from the dedicated case-study section; light copyediting only.*

Yandex is the study's most heavily traded technology name and the single case where the full-sample
result contradicts an earlier, smaller pilot. It is retained in every aggregate table, regression and
count elsewhere in this thesis; this section explains it rather than explaining it away.

**Why the raw correlation is positive and the regression coefficient is negative.** The
unconditional correlation between `ASVI_lag1` and next-week volatility for YNDX is **+0.0550** —
positive, and of the sign the pilot reported. The Method 1 coefficient is **−0.0226** (HAC SE 0.0096,
t = −2.36, p = 0.018, n = 364). Both statements are true of the same 364 observations.

The mechanism is conditional suppression, driven by one regressor. Yandex's attention is strongly
correlated with its own lagged volatility, **r(ASVI_lag1, RV_lag1) = +0.3240**, and lagged volatility
is strongly correlated with current volatility, **r(RV, RV_lag1) = +0.4589**. Those two correlations
transmit **+0.3240 × 0.4589 = +0.1487** of apparent association — more than twice the total observed
association of +0.0550. Stripping out the indirect path leaves **+0.0550 − 0.1487 = −0.0936**: the
partial association is negative precisely because the raw correlation was mostly the
volatility-persistence channel, not attention. The regression ladder shows the flip: attention alone
gives **+0.0102** (p = 0.321); adding `RV_lag1` moves it to **−0.0193** (p = 0.013), with `RV_lag1`
entering at +0.6365; adding `lnV_lag1` gives **−0.0226**.

**Alignment sensitivity.** MOEX price bars are labelled with the Sunday that *begins* the trading
week — verified, since the bar labelled 2022-02-20 carries the −47.61% invasion-week close of 131.12
and bars labelled 2022-02-27, 03-06 and 03-13 are absent for the exchange suspension. A literal
"[W, W+6]" join therefore attaches each search week to the *following* trading week, a one-week
lookahead. Both conventions were run on an identical window:

| Date-join convention | b₁ | SE | t | p | n | Status |
|---|---|---|---|---|---|---|
| Same-calendar-week join | **−0.02259** | 0.00956 | −2.36 | **0.0181** | 364 | **Primary — correct** |
| Literal `[W, W+6]` join | +0.00204 | 0.00596 | +0.34 | 0.7323 | 363 | Rejected (lookahead) |
| Primary, excluding Jun–Dec 2024 | −0.02281 | 0.00968 | −2.36 | 0.0184 | 347 | Sensitivity |
| Primary, pre-2022-02-21 | −0.03804 | 0.02359 | −1.61 | 0.1068 | 174 | Sensitivity |
| Primary, post-2022-02-21 | −0.02014 | 0.01547 | −1.30 | 0.1928 | 190 | Sensitivity |
| Primary, no transition blanking | −0.0214 | — | — | 0.019 | — | Sensitivity |
| Primary, 5 largest \|ASVI_lag1\| weeks dropped | −0.0165 | — | — | 0.126 | — | Sensitivity |

No alignment variant reproduces a strong positive Yandex result; the lookahead join yields +0.0020,
not remotely significant. The permutation test gives p = 0.015 and power is 0.65 — below 0.80, so the
finding is not over-powered, but it is not fragile either.

**The pilot discrepancy: bounded, not resolved.** This result does not replicate the pilot, which
reportedly found one of the strongest *positive* relationships in the panel for this firm. The
discrepancy is bounded, not explained. It is not a data-construction error: the 2024 YNDX→YDEX
transition is handled exactly as specified (ASVI missing for the eight weeks 2024-07-22 to
2024-09-09, independently recomputed from the raw three-channel search files to a maximum deviation
of 2.2×10⁻¹⁶), and removing the blanking changes the coefficient only from −0.0226 to −0.0214. It is
not a subsample artefact: both halves are negative. It is not alignment *within this pipeline*: the
only convention yielding a positive coefficient destroys its significance. What remains open is the
pilot's own specification. The strongest available hypothesis is that the pilot used the literal
`[W, W+6]` join without conditioning on lagged volatility, which on this panel yields a small
positive, insignificant coefficient — consistent with the pilot's reported sign, but consistency is
not evidence. **The correct conclusion is: unresolved, and bounded to the pilot's specification.**

**Theoretical interpretation: a candidate, and an admission.** De Long, Shleifer, Summers & Waldmann
(1990) **does not** support a negative attention–volatility relationship; its own prediction is
positive, since price variance rises with noise-trader sentiment risk, and the model is offered as
an explanation of *excess* volatility. Citing DSSW for a negative coefficient would invert the
source. What DSSW legitimately offers is the distinction between conditional one-step-ahead variance
and unconditional variance, the latter growing far faster in the persistence of misperceptions. A
negative coefficient in a next-week volatility regression is not inconsistent with a high-variance,
high-attention regime; it says only that attention does not raise *next-week* volatility once
persistence is controlled. Beyond that, a mechanism would be needed in which retail attention
*stabilises* prices, and no paper in this thesis's literature set supplies one. The interpretation is
left open and stated as such.

---

## 5.13 Research-integrity statement

The governing rule for this round was that no test, control or specification could be added, dropped
or modified because of the result it produced. That rule was applied as follows, and the record is
reported here in full.

**No firm was excluded from anything.** Yandex appears in every aggregate, every table, every count
and every hypothesis in this document. The case study in §5.12 explains the sign reversal; it does
not remove it. No sample was narrowed: the pre/post-2021 split reports both halves with the same
prominence, and the 2024 window, the transition blanking and the five largest attention weeks were
run as *sensitivity checks alongside* the primary specification, never as replacements for it.

**All four pre-specifications were written and locked before any test was run**, and all four
outcomes are reported: H3-robust **confirmed** (24 of 33 survive the Giles–Lieberman upper bound);
quantile tail-dependence **confirmed on the sign-change criterion and explicitly not confirmed on
the magnitude criterion** (+0.00937 against a 0.0094 threshold, and +0.00788 under the audit's
alternative estimation route); the pre/post-2021 regime-dependence test **disconfirmed** (9.4
percentage-point shift against a 15-point threshold, no sign change); and H6 **disconfirmed**
(p = 0.833). The two disconfirmations are stated in the body of the text, in their own sections, at
the same length and with the same numerical detail as the confirmations. The document does not lead
with a significant specification.

**Two results were corrected rather than reported favourably.** An initial implementation of the
Giles–Lieberman bounds placed T−2K chi-square terms in the numerator; this is dimensionally wrong,
does not reduce to F(K, T−2K) under homoscedasticity, and was corrected before any thesis statistic
was computed — the corrected implementation reproduces 12 of 12 rows of the paper's Table 1. An
initial replication of the rejected `[W, W+6]` alignment was mis-specified and briefly appeared to
contradict the prior round's +0.0020; on correct re-implementation it reproduces +0.00204
(p = 0.732), confirming the prior figure.

**One literature claim was corrected against its source.** The prior characterisation of Djalilov &
Ülkü as showing that MOEX retail investors are "contrarian and non-forecasting" overstates that
paper: contrarianism is supported, flow-level non-forecastability is supported narrowly, and the
paper's central argument is the *opposite* of a naive-retail reading — the authors describe the same
evidence as "a sign of sophistication in striking contrast to views that characterized individual
investors as noise traders." That claim has been rewritten.

**What was considered and refused.** The temptation in a round like this one is to treat the
heteroscedasticity-robust re-testing of H3 as an opportunity to discard the break evidence, or to
treat the two disconfirmed pre-specifications as grounds for trying adjacent specifications until one
signifies. Neither was done. Where the bounds leave a verdict genuinely open — the nine indeterminate
firms — the indeterminacy is reported as indeterminacy rather than resolved in either direction.

**Verification performed on this round's own numbers.** The panel was rebuilt from raw source files
because no `panel.csv` was supplied, and the rebuild reproduces the prior round's Method 1, 3 and 4
figures exactly, including both significant-company lists and the 33-company Chow rejection list. An
independent audit re-parsed the raw files through a separate code path and re-derived the
pre/post-2021 split for six companies (all sample sizes exact, all twelve coefficients matching to
<5×10⁻⁴), re-estimated the quantile grid by a different route, verified the Crisis dummy occupies
exactly the ten Mondays 2022-02-21 to 2022-04-25 with no leakage and identical values across firms,
and confirmed that every lagged regressor equals its own one-week shift to a maximum deviation of
0.0 with no same-period or future information anywhere. The audit returned **6 PASS, 2 WARNING,
0 FAIL**. The two warnings are substantive and are carried forward rather than closed: the quantile
grid is estimation-route sensitive at the 0.90 quantile (§5.6), and 54 of 75 SOE determinations rest
on disclosure not re-verified this round (§5.10).
