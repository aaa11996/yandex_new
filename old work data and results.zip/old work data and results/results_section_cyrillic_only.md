# Results (corrected attention proxy: Cyrillic-only search volume)

**Study:** Investor attention (Yandex Wordstat search volume, ASVI) and volatility/returns of MOEX-listed equities, weekly, 2018–2026.
**Specification change vs. the previous results section:** search volume index SVI(i,t) is now the **Cyrillic Wordstat query count only** («… акции» phrases); ticker-query counts (and, for Yandex, the YNDX/YDEX ticker counts) are **no longer summed in**. Everything else — sample, alignment convention, variable definitions, lag construction, windowing, estimation methods, seeds — is unchanged from the previous run, and the implementation was benchmark-verified to reproduce the previous run's published numbers exactly when fed the previous (summed) SVI definition (§5.12.1). All differences reported below are therefore attributable to the attention-proxy correction itself.
**Status of all estimates below: PROVISIONAL.** The four control variables required by the full model — `Crisis(t)`, `Sanction(i,t)`, `Div(i,t)`, `SOE(i)` — were unavailable in the input data (all-NaN placeholder columns produced by the data-construction step). Per the analysis protocol, the corresponding terms were omitted from every regression equation rather than zero-filled, and no values were invented. This omission affects which hypotheses could be tested (H5 and H6 could not be tested at all) and may bias the remaining coefficients if the omitted controls correlate with attention and volatility. All results should be re-estimated once the controls are supplied.

## 5.1 Data and estimation summary

The final panel contains 29,400 company-weeks: 75 MOEX-listed companies across 13 sectors on a rectangular weekly grid from Monday 2018-08-27 (earliest available source week in every Wordstat file) through Monday 2026-02-23 (last week fully inside the 2018-01-01–2026-02-28 study window). Source search data extend to 2026-08-31 and price data to 2026-09-06; observations after February 2026 were discarded as specified. **SVI is the Cyrillic-file count alone** under the corrected definition; the ticker files were parsed and retained solely for the QC duplicate-series check. For Yandex, SVI is the «Яндекс акции» series alone (YNDX/YDEX ticker counts are not used); the 2024-07-22–2024-09-09 ASVI blanking window was retained per spec even though its original structural rationale (mixing of the pre-launch YDEX channel into the baseline) no longer applies to a single-channel series — a no-blanking sensitivity estimate is reported in §5.10. ASVI is the log SVI deviation from its trailing 8-week median; log(0) is undefined, so any zero-count week makes ASVI missing for that week and the following 8 weeks (no small-constant substitution). Regressors enter all predictive specifications lagged one week; an independent audit re-derived every lag cell from the raw files and found no lookahead contamination (audit check 1, PASS).

The correction has a direct coverage cost, because Cyrillic phrase queries are sparser than ticker queries: 11 companies have zero-count weeks (SFIN 364 of 392, IRKT 257, MRKU 213, MRKK 195, MRKC 155, MRKP 152, MSRS 122, MRKS 116, FESH 55, AVAN 16, UKUZ 1). **SFIN has zero usable ASVI observations and is not computable in any method** (it drops out of Methods 1, 2, 4, 5 and contributes nothing to Method 3, which therefore has 74 entities). Panel-wide there are 26,913 non-missing ASVI observations; M1 estimation samples range from 114 (MRKK) to 379 (VTBR) complete cases (median 375); Method 3 uses 26,353 company-weeks.

Estimation: per-company OLS with Newey-West HAC standard errors (4-week bandwidth; Method 1); Granger-causality F-tests at lags 1, 2, 4 with Benjamini–Hochberg (BH) and Bonferroni–Holm corrections applied separately within the H1 and H2 test blocks of 222 tests each (Method 2); pooled panel fixed-effects (entity and week) regression with entity-clustered and heteroskedasticity-robust standard errors (Method 3); per-company asymmetric Chow break tests around 2022-02-24 (Method 4; 71 feasible); 1,000-draw permutation falsification tests and non-central-t power calculations (Method 5; seed 20260913).

## 5.2 Aggregate panel-level finding (Method 3)

The pooled two-way fixed-effects regression of RV(i,t) on ASVI(i,t−1) and RV(i,t−1), with company and week fixed effects, yields a positive coefficient on lagged attention that is significant at conventional levels under both covariance estimators:

**Aggregate attention across the full panel does predict volatility, at +0.00346, p = 0.012 (entity-clustered SE = 0.00138), based on N = 26,353 company-weeks.**

With heteroskedasticity-robust (non-clustered) standard errors the same coefficient is +0.00346, SE = 0.00131, t = 2.64, p = 0.008. Lagged volatility is strongly persistent (RV_lag1 = +0.329, p < 0.001); the within R² is 0.135; 74 entities over 380 weeks contribute. Under the previous summed-SVI definition the same specification gave +0.00264 with clustered p = 0.066 (robust p = 0.052) — i.e., the correction moves the aggregate test from marginally insignificant to significant at the 5% level under both estimators (§5.12.3). As in the previous run, the pooled positive estimate contrasts with the per-company results below, where the majority of individual b1 estimates are negative; the contrast is reported as-is and is not further reconciled here.

## 5.3 H1 — Attention → Volatility

**Per-company OLS (Method 1, M1: RV on ASVI_lag1 + RV_lag1 + lnV_lag1, HAC SEs).** 4 of the 74 computable companies show a significant *positive* ASVI coefficient at the 5% level:

| Ticker | b1 | HAC SE | p | n |
|---|---|---|---|---|
| JNOS (Bashneft) | +0.0202 | 0.0081 | 0.013 | 375 |
| MFGS (Mosenergo) | +0.0313 | 0.0127 | 0.013 | 373 |
| KAZT (KuybyshevAzot) | +0.0192 | 0.0086 | 0.026 | 373 |
| MRKU (Rosseti Ural) | +0.0204 | 0.0100 | 0.041 | **139** |

MRKU's estimate rests on 139 complete cases (60% sample loss from Cyrillic zero-weeks; below the 350-observation threshold) and carries a small-sample caveat; it was insignificant under the summed proxy (b1 = −0.0003, p = 0.95, n = 348). AVAN is additionally positive-significant at 10% (+0.0155, p = 0.065, n = 321).

15 of 74 companies show a significant *negative* coefficient at 5%: RTKM (−0.0347, p = 0.000004), SNGS (−0.0400, p = 0.0002), PHOR (−0.0166, p = 0.0006), LSRG (−0.0218, p = 0.0025), IRAO (−0.0206, p = 0.0027), BSPB (−0.0155, p = 0.0078), NLMK (−0.0177, p = 0.0114), MAGN (−0.0251, p = 0.0150), AFKS (−0.0147, p = 0.0162), VSMO (−0.0195, p = 0.0270), HYDR (−0.0181, p = 0.0290), YNDX (−0.0209, p = 0.030; see §5.10), SIBN (−0.0137, p = 0.0313), AKRN (−0.0129, p = 0.0331), MRKS (−0.0279, p = 0.045, n = 241 — below the 350 threshold, small-sample caveat). SBER is negative at 10% (−0.0231, p = 0.099). The remaining 55 companies are insignificant at 5%. Across the 74 computable companies, 25 b1 estimates are positive and 49 negative; the median b1 is −0.0068 (median |b1| = 0.0112). SFIN is not computable (0 usable ASVI weeks) and is excluded from all counts.

**Granger cross-check (Method 2, H1 block: 222 tests = 74 companies × 3 lags).** At the primary lag of 1 week, 12 of 74 companies reject non-causality at raw p < 0.05 (in F-value order: SNGS 9.59, RTKM 9.49, MFGS 9.23, JNOS 8.42, LSRG 6.37, MAGN 5.86, HYDR 5.61, MRKS 5.00, BSPB 4.37, YNDX 4.18, SIBN 4.10, PHOR 3.90); at lag 2, 6 of 74 (SNGS, RTKM, MFGS, JNOS, MVID, LSRG); at lag 4, 4 of 74 (CHMF, MFGS, JNOS, RTKM). **After BH correction within the H1 block, no test survives at any conventional level** (smallest BH-adjusted p = 0.188); the more conservative Holm correction likewise leaves zero survivors (smallest Holm-adjusted p = 0.468). Overlap with Method 1: of the four positive-significant M1 companies, MFGS (raw p = 0.0025, BH 0.188) and JNOS (raw p = 0.0039, BH 0.202) are also raw-significant in the lag-1 Granger test; KAZT (raw p = 0.16) and MRKU (raw p = 0.065) are not. Ten of the twelve raw Granger-significant companies have negative M1 coefficients.

**Assessment of H1.** H1 (positive attention→volatility effect) is supported for 4 of 74 computable companies at the nominal 5% level in Method 1 (one of which, MRKU, is small-sample) and for none after multiple-testing correction in Method 2; at 74 tests, ~3.7 false positives are expected at a 5% nominal rate even under the global null, so the raw count of positive-significant companies is at the edge of that range. The significant company-level coefficients remain predominantly negative (15 vs 4), which is the opposite sign to H1; the pooled panel coefficient is positive and significant at 5% (§5.2). For the 55 insignificant companies the result is *inconclusive due to insufficient power* rather than evidence of no effect: 69 of 74 companies have statistical power below 0.80 at their observed effect size (median power 0.26; §5.9). No company-level result carries BH/Holm-corrected significance.

## 5.4 H2 — Attention → Returns

**Per-company OLS (Method 1, M2: R on ASVI_lag1 + R_lag1 + RV_lag1, HAC SEs).** 1 of 74 computable companies shows a significant positive ASVI coefficient at 5%: GCHE (+0.0121, SE 0.0051, p = 0.019, n = 376) — the same company as under the summed proxy. 3 of 74 show significant negative coefficients: PHOR (−0.0126, p = 0.015), IRKT (−0.0513, p = 0.015, n = 124 — below the 350-observation threshold and the largest |b1| in either M1 or M2; small-sample/data-scarcity caveat applies, audit check 10), MTSS (−0.0136, p = 0.043). PLZL is positive at 10% (+0.0320, p = 0.069). Signs: 28 positive, 46 negative; median b1 = −0.0025. SFIN not computable; MRKK — significant-negative under the summed proxy at n = 256 — is now insignificant (−0.0015, p = 0.81, n = 115).

**Granger cross-check (Method 2, H2 block: 222 tests).** At lag 1, 7 of 74 companies are raw-significant (MSRS F = 8.53, IRKT 6.93, PHOR 5.87, LSNG 5.46, OGKB 4.74, RNFT 4.51, SBER 4.07); at lag 2, 6 of 74 (VJGZ, MSRS, MTSS, IRKT, LSNG, USBN); at lag 4, 7 of 74 (VJGZ, SBER, TGKA, CHMF, IRKT, LSNG, GMKN). **After BH correction within the separate H2 block, no test survives** (smallest BH-adjusted p = 0.237, from the block-minimum raw p = 0.0011, VJGZ at lag 4); Holm likewise yields zero survivors.

**Assessment of H2.** H2 is not supported: one nominally positive-significant company of 74, no corrected significance anywhere, and a predominantly negative sign distribution — the same qualitative conclusion as under the summed proxy. As with H1, the insignificant companies are *inconclusive due to insufficient power* rather than demonstrated nulls. (Method 5 power is computed for the M1 volatility specification per the protocol; company-level M2 power was not separately computed — see Limitations.)

## 5.5 H3 — Structural break at February 2022 (Method 4)

The asymmetric Chow test (pre-period: 3 parameters, no crisis dummy; post-period: 4 parameters including a crisis dummy for the lagged 2022-02-24–2022-04-25 window; q = 3, denominator df = n−7) rejects parameter stability at the 5% level for **32 of the 71 computable companies** (20 at the 1% level; 35 at 10%). Four companies are not computable: SFIN (no usable ASVI) and IRKT, MRKK, MRKU (zero pre-break complete cases — their Cyrillic zero-weeks eliminate all pre-2022-02-24 ASVI). Against an expected ~3.6 false positives among 71 tests at a 5% nominal rate, the excess is substantial. The ten largest F-statistics:

| Ticker | F(3, n−7) | p |
|---|---|---|
| BANE | 15.63 | 1.4×10⁻⁹ |
| AFLT | 13.94 | 1.3×10⁻⁸ |
| ALRS | 11.02 | 6.1×10⁻⁷ |
| AFKS | 8.52 | 1.7×10⁻⁵ |
| MRKC | 7.52 | 8.4×10⁻⁵ (n_pre = 18; marginal pre-period) |
| MSTT | 7.21 | 1.0×10⁻⁴ |
| MSNG | 7.05 | 1.3×10⁻⁴ |
| CBOM | 6.65 | 2.2×10⁻⁴ |
| SBER | 5.49 | 1.1×10⁻³ |
| MGNT | 5.44 | 1.1×10⁻³ |

The remaining 5%-significant companies: AKRN, BSPB, CHMF, CHMK, HYDR, IRAO, KAZT, LSRG, MFGS, MGTS, MTSS, NMTP, NVTK, SELG, SIBN, TGKA, UNAC, UPRO, VJGZ, VTBR, YAKG, YNDX (F = 4.89, p = 0.0024). All computed F-statistics were positive (no negative RSS differentials). **H3 is supported for a substantial plurality of the computable sample**: the ASVI–volatility relationship changed around the February 2022 crisis for 32 companies spanning 11 of the 13 sectors (all except Insurance and Industrial, whose single-company tests are insignificant: RGSS F = 0.36, p = 0.78; KMAZ F = 0.69, p = 0.56). No multiple-testing correction was specified for Method 4; the reported p-values are raw (see Limitations).

## 5.6 H4 — Sector heterogeneity (Method 3 interactions)

Adding 12 ASVI_lag1 × sector interactions (reference sector: Banking) to the pooled FE model produces a joint Wald test that is highly significant with entity-clustered covariance, χ²(12) = 695.1, p = 4.9×10⁻¹⁴¹, but insignificant with heteroskedasticity-robust covariance, χ²(12) = 17.10, p = 0.146. As in the previous run, the two covariance estimators disagree on the joint hypothesis; both are reported and neither is suppressed. Individual interaction estimates (Banking slope = −0.0005, p = 0.80 clustered / 0.87 robust):

| Sector (vs Banking) | Interaction coef. | p (clustered) | p (robust) | Contributing companies |
|---|---|---|---|---|
| Industrial | −0.0157 | <0.001 | 0.063 | 1 (KMAZ) |
| Insurance | +0.0123 | <0.001 | 0.331 | 1 (RGSS) |
| Energy | +0.0125 | 0.028 | 0.016 | 12 |
| Transportation | +0.0098 | 0.033 | 0.054 | 4 |
| Tech | +0.0087 | 0.062 | 0.336 | 3 (IRKT with only 123 obs, UNAC, YNDX) |
| Metals&Mining | +0.0037 | 0.170 | 0.313 | 15 |
| Consumer&Retail | +0.0025 | 0.371 | 0.593 | 4 |
| Chemicals | +0.0028 | 0.456 | 0.517 | 5 |
| Real Estate | −0.0016 | 0.486 | 0.750 | 3 |
| Utilities | +0.0019 | 0.505 | 0.594 | 15 |
| Telecom | +0.0005 | 0.896 | 0.919 | 4 |
| Diversified | −0.0002 | 0.933 | 0.977 | 1 (AFKS only; SFIN contributes no rows) |

Under clustered inference, **H4 is supported**: the attention–volatility slope differs across sectors, most negative relative to Banking for Industrial (a single company, KMAZ) and most positive for Energy, Insurance (a single company, RGSS) and Transportation. Because the two extreme sectors contain one company each, those interaction terms are company-specific slopes in substance; the sector interpretation is correspondingly weak for them. Under robust inference, only Energy remains individually significant (p = 0.016), with Transportation (p = 0.054) and Industrial (p = 0.063) borderline, and the joint test does not reject.

## 5.7 H5 — Dividend season

The `Div(i,t)` variable (4 weeks preceding each firm's annual dividend record date) could not be constructed: no dividend-date reference data were present in the provided files, the panel column is entirely missing, and the term was omitted from all equations rather than proxied. **H5 could not be tested due to missing dividend-date data and is not reported as either confirmed or rejected.**

## 5.8 H6 — State ownership

The `SOE(i)` flag (government ≥25% voting control) could not be constructed from the provided files; the panel column is entirely missing, and the Method-3 ASVI × SOE extension was skipped per protocol. **H6 could not be tested due to missing ownership-structure data and is not reported as either confirmed or rejected.**

## 5.9 Statistical power, permutation falsification, and minimum detectable effects (Method 5)

Per-company power at the observed M1 effect size (non-central t, two-sided 5%): **only 5 of 74 computable companies reach 0.80** — RTKM (0.996), SNGS (0.960), PHOR (0.929), LSRG (0.855), IRAO (0.848) — and all five have significant *negative* b1, so their negative findings are adequately powered. The other 69 companies have power below 0.80 (median 0.26; YNDX 0.58; the four positive-significant companies JNOS 0.70, MFGS 0.69, KAZT 0.61, MRKU 0.53). The median minimum detectable effect at 80% power is 0.0242 in b1 units — approximately 2.2 times the median observed |b1| of 0.0112. Consequently, every non-significant company-level result in §§5.3–5.4 is properly read as **inconclusive due to insufficient power**, not as evidence that no effect exists; the study is powered to detect only comparatively large company-level attention effects.

Permutation falsification (1,000 shuffles of ASVI_lag1 within company, seed 20260913) rejects the no-relationship null at p ≤ 0.05 for 21 companies (20 at p < 0.05): MAGN p = 0.000, MFGS 0.000 (positive), LSRG 0.001, RTKM 0.001, SNGS 0.002, JNOS 0.003 (positive), MRKS 0.005, PHOR 0.007, HYDR 0.008, VJGZ 0.010 (positive), AKRN 0.014, BSPB 0.014, MRKU 0.016 (positive), YNDX 0.022, SBER 0.023, NLMK 0.025, UTAR 0.025, VSMO 0.035, YAKG 0.043 (positive), KAZT 0.044 (positive), MVID 0.050. **All four positive-significant M1 companies (JNOS, KAZT, MFGS, MRKU) are simultaneously permutation-significant** — in the previous run only one (MFGS) of the two positive-significant companies was. Twelve of the 15 negative HAC-significant companies are permutation-significant; IRAO, AFKS and SIBN are not (at p < 0.05). SBER (HAC p = 0.099), UTAR and MVID are permutation-significant but not HAC-significant. No company's significant HAC result is contradicted by a permutation p near 1, i.e., none of the reported coefficients is attributable to chance time-alignment alone.

## 5.10 Yandex (YNDX) replication check

A prior pilot on a smaller sample reportedly found one of the strongest positive ASVI–volatility relationships in the panel for Yandex. In this corrected run, YNDX's M1 coefficient is again significant but **negative**: b1 = −0.0209 (HAC SE 0.0096, t = −2.18, p = 0.030, n = 364), permutation p = 0.022, power = 0.58 — materially unchanged from the summed-SVI run (−0.0226, p = 0.018). The independent audit flagged the divergence again (audit check 11, WARNING). The investigation found:

1. The 2024 blanking window was applied exactly as specified (8 weeks NaN, verified against independent recomputation from the raw Cyrillic file; audit check 2, PASS) — and is not the cause: re-estimating **without** the blanking gives b1 = −0.0191 (p = 0.037, n = 372). Note that under the corrected single-channel SVI the blanking's original structural rationale does not apply; it was retained for spec compliance and comparability, and this sensitivity shows the choice is immaterial to the conclusion.
2. Excluding June–December 2024 gives −0.0219 (p = 0.024); the pre-2022-02-24 subsample gives −0.0348 (p = 0.140, n = 174) and the post-2022 subsample −0.0147 (p = 0.234, n = 190) — the negative sign is stable across subsamples.
3. The raw unconditional correlation between ASVI_lag1 and RV for YNDX is slightly positive (+0.060); the negative partial slope arises after conditioning on RV_lag1 and lnV_lag1 (same pattern as the previous run, +0.043 there).
4. Under the alternative (literal `[W, W+6]`) search-to-price join — which pairs each search week with the *following* trading week's price bar — b1 = +0.0047 (p = 0.400): positive-signed but insignificant.

The divergence from the pilot persists under **both** SVI definitions (summed and Cyrillic-only), so it is not attributable to the attention-proxy correction. It is reported factually as unresolved and worth investigating (candidate explanations to be examined with the pilot's exact specification and sample dates, not adjudicated here). All other pipeline checks passed, so the divergence does not by itself invalidate the remaining results, but per the audit protocol the YNDX anomaly remains an open item that should be resolved before the panel-level conclusions are treated as final.

## 5.11 Limitations

The following limitations are stated in full, including every WARNING from the independent quality-control audit (0 FAIL, 3 WARNING, 9 PASS).

**(a) Missing control variables (affects all methods; H5/H6 untestable).** `Crisis`, `Sanction`, `Div`, and `SOE` require external reference data not present in the provided files and must be supplied before Methods 1, 2, 3 and the Method-3 SOE extension can be run correctly. The terms were omitted (not zero-filled) from all equations; every estimate here is provisional. In particular: without the Crisis dummy, the Feb–Apr 2022 weeks — which combine extreme volatility and extreme attention — are not separately controlled in Methods 1–2 (they are absorbed only insofar as the panel week fixed effects in Method 3 capture market-wide shocks); without Sanction, firm-specific sanction shocks may load onto ASVI; H5 (dividends) and H6 (state ownership) could not be tested at all and are reported as neither confirmed nor rejected.

**(b) Audit WARNING 3b — date-alignment convention.** Verbatim from the audit: *"Price labels are 100% Sundays (verified in this audit across all 31,061 bars; 0 non-Sunday), NOT Fridays as the task spec assumed; the literal '[W,W+6]' rule would match each search week to the FOLLOWING trading week (1-week lookahead). Same-calendar-week alignment (bar labeled W-1) applied instead, empirically verified via the Feb-Mar 2022 MOEX suspension pattern (bar labeled 2022-02-20 carries the invasion-week Friday 2022-02-25 close 131.12, -47.6%; bars labeled 2022-02-27/03-06/03-13 absent). Deviation from literal rule text documented."* All reported coefficients are conditional on this alignment judgment; §5.10 item 4 quantifies the sensitivity for YNDX (the only alignment-sensitive check performed).

**(c) Audit WARNING 6 — marginal samples, materially aggravated by the correction.** Verbatim: *"M1 complete cases <350 for 10 companies: SFIN 0, MRKK 114, IRKT 123, MRKU 139, MRKC 219, MRKP 222, MRKS 241, MSRS 247, FESH 280, AVAN 321 (min=0, median=375, max=379). Cause: zero-count Cyrillic weeks blank ASVI for the week plus 8 following weeks (SFIN's Cyrillic series is 364/392 zeros -> 0 usable ASVI; Methods 1/2/4/5 not computable for SFIN). Marginal samples for per-company OLS; per-spec WARNING."* Under the previous summed proxy only four companies were below 350 (min 255); the Cyrillic-only proxy reduces usable observations for ten. Per-company results for these ten companies carry a small-sample caveat; MRKU's positive-significant M1 coefficient (n = 139) and IRKT's negative-significant M2 coefficient (n = 124) in particular rest on heavily attrited samples, and any statement about SFIN must read "not computable", not "insignificant". Method 4 is not computable for SFIN, IRKT, MRKK, MRKU (zero pre-break observations for the latter three); MRKC's Chow test has only 18 pre-period complete cases.

**(d) Audit WARNING 11 — Yandex replication divergence.** Verbatim (abridged where indicated, full text in the audit report): *"YNDX M1 b1 = -0.02088 (HAC p = 0.0296, n = 364), permutation p = 0.022, power = 0.58: significant but NEGATIVE - sign-reversed vs the expected strong positive pilot result; replication NOT achieved under the corrected Cyrillic-only SVI (previous summed-SVI run: -0.0226, p = 0.018 - materially unchanged). … no alignment variant reproduces a strong positive result. Divergence is substantive, not a pipeline error; flagged per protocol."* Per the audit protocol this WARNING requires investigation before other results are fully trusted; the investigation outcomes are documented in §5.10 and do not localize the divergence to any pipeline step.

**(e) Multiple testing.** BH/Holm corrections were applied only within the Method 2 blocks (222 tests each), as specified. The 148 Method-1 coefficients, 71 Method-4 Chow tests, and the Method-3 interactions carry raw p-values; at ~71–75 tests per method, ~3.6–3.8 false positives per method are expected at a 5% nominal rate even under the global null. The H1/H2 company-level counts (4 and 1 positive-significant) are within or near that range; the H3 count (32) is far above it.

**(f) Inference choices in Method 3.** The sector-heterogeneity Wald test is significant under entity-clustered SEs (p ≈ 5×10⁻¹⁴¹) and insignificant under robust SEs (p = 0.146); the conclusion for H4 is therefore inference-dependent. Two of the extreme sector interactions (Industrial, Insurance) are single-company sectors and are effectively firm-specific slopes; the Diversified interaction now rests on a single company (AFKS) because SFIN contributes no rows. Clustering on 74 entities is at the lower end of the conventional range for cluster-robust inference. Note also the implementation detail that `linearmodels` silently returns heteroskedasticity-robust SEs when `cov_type='clustered'` is requested without an explicit clusters argument; explicit entity-cluster codes were passed and the clustered SEs were cross-validated against a statsmodels dummy-variable estimation (0.001384 vs 0.001393).

**(g) Power.** Post-hoc power at observed effect sizes (Method 5 specification) is below 0.80 for 69 of 74 computable companies; all null company-level findings are inconclusive rather than demonstrably zero, and the median MDE (0.0242) exceeds the median observed |b1| (0.0112) by a factor of ~2.2. Company-level power for the M2 (returns) specification was not separately computed.

**(h) Data-quality items carried from construction.** Eleven companies have zero-count Cyrillic weeks; by the no-substitution rule each zero blanks ASVI for 9 weeks (the zero week plus 8 baseline weeks), which is the sole cause of the attrition in (c). Weekly log returns are computed across consecutive price-file rows and therefore span trading suspensions (matching the source export's own `Change %`): the Feb–Mar 2022 MOEX suspension, a mid-June-2024 bar absent from 72 of 75 exports (verified genuine; the export's own Change % spans it), and, for YNDX, the June–July 2024 old-YNDX suspension into the YDEX relisting week. 86 rows have missing volume ('-') → lnV missing there. ROLO trades near ₽0.20 with 2-decimal price resolution (one tick ≈ 5%); its returns and range volatility carry heavy quantization noise. All Wordstat files share an identical 419-week grid with explicitly reported zeros; the missing-date-as-zero rule was never invoked in practice.

**(i) Scope.** The sample is limited to the 75 companies with complete raw file triads in the provided archive; results describe this sample of mostly mid/large-cap MOEX names and not the Russian equity market as a whole. Under the corrected proxy the effective sample is 74 companies (SFIN not computable) and, for the affected low-frequency-query names, substantially shorter time series.

## 5.12 Differences from the previous run (summed SVI) — required comparison section

### 5.12.1 What changed, and implementation transparency

Exactly one input changed: SVI = Cyrillic counts only, instead of Cyrillic + ticker counts (Yandex: «Яндекс акции» only, instead of YNDX + YDEX + Cyrillic). To guarantee that the comparison below isolates this change, the current codebase was re-run on a rebuilt summed-SVI panel and **reproduced every published number of the previous results section checked** (spot checks: MFGS +0.0321/p = 0.010; KAZT +0.0181/p = 0.042; RTKM −0.0339; SNGS −0.0398; YNDX −0.0226/p = 0.018; GCHE M2 +0.0115; Chow BANE 15.37, AFLT 14.09, ALRS 11.04, YNDX 5.11, SBER 4.73, RGSS 0.28, KMAZ 0.67; Granger SNGS 9.48, RTKM 9.19, MFGS 8.44, YNDX 4.53; min BH 0.292/0.379; power RTKM 0.995, SNGS 0.964, PHOR 0.900, LSRG 0.881; permutation RTKM/MFGS 0.001, LSRG/MRKS 0.002, YNDX 0.015; panel FE +0.00264, clustered p = 0.066, robust p = 0.052, N = 27,924, Wald 623.4/17.1). Differences below are therefore data-definition effects, not code effects.

### 5.12.2 Sample and coverage

| | Previous (summed) | Current (Cyrillic-only) |
|---|---|---|
| Panel rows | 29,401 | 29,400 |
| Non-missing ASVI | 28,517 (zeros: 6 companies, ≤26 weeks each) | 26,913 (zeros: 11 companies, ≤364 weeks) |
| Companies computable in Method 1 | 75 | 74 (SFIN has 0 usable ASVI) |
| Method-1 sample range (median) | 255–379 (375) | 114–379 (375) |
| Companies with M1 n < 350 | 4 (MRKC 308, MRKK 255, MRKS 341, MRKU 348) | 10 (SFIN 0, MRKK 114, IRKT 123, MRKU 139, MRKC 219, MRKP 222, MRKS 241, MSRS 247, FESH 280, AVAN 321) |
| Method-2 block size | 225 | 222 |
| Method-3 N (entities) | 27,924 (75) | 26,353 (74) |
| Method-4 feasible tests | 75 | 71 (SFIN, IRKT, MRKK, MRKU not computable) |

The largest per-company sample losses: SFIN −359, IRKT −252, MRKU −209, MRKP −153, MRKK −141, MSRS −128, MRKS −100, FESH −95.

### 5.12.3 Aggregate panel finding (the headline change)

| | Previous (summed) | Current (Cyrillic-only) |
|---|---|---|
| b1 (ASVI_lag1), two-way FE | +0.00264 | **+0.00346** |
| SE / p, entity-clustered | 0.00143 / **0.066** | 0.00138 / **0.012** |
| SE / p, robust | 0.00136 / 0.052 | 0.00131 / 0.008 |
| N company-weeks | 27,924 | 26,353 |
| Within R² | 0.140 | 0.135 |
| RV_lag1 | +0.340 | +0.329 |

The aggregate attention effect on next-week volatility was **not significant at 5% under the summed proxy and is significant under the Cyrillic-only proxy** (p = 0.012 clustered, p = 0.008 robust), with a ~31% larger point estimate despite the smaller sample. The mandated framing sentence therefore flips from "does not predict" to "does predict" (§5.2). This is the single most consequential difference between the two runs.

### 5.12.4 Company-level H1/H2 results

- Per-company M1 b1 estimates are highly stable across the two definitions: Pearson correlation 0.969, Spearman 0.973 across the 74 companies computable in both; only 3 sign flips (AFLT −0.0009→+0.0031 and BLNG −0.0018→+0.0000, both insignificant in both runs; MRKU −0.0003 (p = 0.95, n = 348) → +0.0204 (p = 0.041, n = 139) — the only flip into significance, on a 60%-reduced sample, and read with caution).
- Positive-significant at 5%: 2 → 4 (MFGS +0.0321→+0.0313 and KAZT +0.0181→+0.0192 retained; JNOS strengthened into significance from a positive-but-insignificant estimate, +0.0147 p = 0.25 → +0.0202 p = 0.013; MRKU gained, see caveat). None lost.
- Negative-significant at 5%: 12 → 15 (all 12 retained with similar magnitudes; BSPB, HYDR, NLMK gained). Median b1 is virtually unchanged (−0.00677 → −0.00678); median |b1| rises 0.0094 → 0.0112; sign split 22/53 → 25/49. The predominantly negative company-level pattern is definition-independent.
- M2: GCHE positive-significant in both (+0.0115 → +0.0121). Negative-significant: FEES (−0.0315, p = 0.016) and MRKK (−0.0100, p = 0.026) lost (FEES now −0.0075, p = 0.32; MRKK insignificant at n = 115); IRKT gained (−0.0513, p = 0.015, n = 124, small-sample caveat); PHOR and MTSS retained.
- Granger raw-significant counts rise modestly (H1 lag-1: 9 → 12; H2 lag-1: 6 → 7) and the smallest BH-adjusted p-values fall (H1: 0.292 → 0.188; H2: 0.379 → 0.237), but **no test survives BH or Holm correction under either definition** — the multiple-testing conclusion is unchanged.
- Permutation falsification: 15 → 21 companies at p ≤ 0.05; the overlap of HAC- and permutation-significant positive results improves from 1 of 2 (MFGS) to 4 of 4 (JNOS, KAZT, MFGS, MRKU).
- Power: companies at power ≥ 0.80: 4 → 5 (IRAO added; all have significant negative b1 in both runs). Median power 0.20 → 0.26; median MDE 0.0250 → 0.0242. The "inconclusive due to insufficient power" framing applies to essentially the same set of nulls under both definitions.

### 5.12.5 H3 (Chow) and H4 (sector heterogeneity)

- Chow: 33/75 significant → 32/71 (1%: 22 → 20; 10%: 36 → 35). Thirty companies are significant in **both** runs; the top-3 (BANE, AFLT, ALRS) and their ordering are unchanged. IRKT and SFIN were significant in the previous run and are *not computable* in this one (attrition, not reversal); IRAO and MGTS are newly significant. H3's substantive conclusion — a widespread structural break around February 2022 far in excess of false-positive expectations — is unchanged.
- Sector Wald: clustered χ²(12) 623.4 → 695.1 (both p ≈ 0); robust χ²(12) 17.1 → 17.10 (both p = 0.146). The audit flagged the robust-statistic equality as a numerical coincidence at reporting precision — the underlying sample, interaction coefficients and clustered statistic all differ — verified with two independent estimators on each panel. Composition shifts: Energy becomes the strongest positive interaction and is the only sector individually significant under robust inference in this run (p = 0.016; it was insignificant previously, +0.0069, p = 0.265); Industrial remains the most negative in both runs (−0.0200 → −0.0157); Insurance strengthens (+0.0086 → +0.0123). The inference-dependence of H4 (supported under clustering, not under robust SEs) is unchanged.

### 5.12.6 Yandex and overall assessment

YNDX's M1 coefficient is significant-negative under both definitions (−0.0226, p = 0.018 → −0.0209, p = 0.030), its permutation significance persists (0.015 → 0.022), its Chow break remains significant (5.11 → 4.89), and its Granger lag-1 test remains raw-significant (F 4.53 → 4.18). The pilot-replication divergence (§5.10) is therefore **not** an artifact of the summed-vs-Cyrillic choice.

Overall: the correction (i) leaves the company-level landscape qualitatively unchanged (rank correlation 0.97; same predominantly negative sign pattern; same zero-survivor multiple-testing picture), (ii) materially strengthens the aggregate panel finding, which crosses conventional significance, (iii) costs substantial coverage for ten low-Cyrillic-frequency companies — one of which (SFIN) becomes entirely unanalyzable — and (iv) does not resolve the Yandex divergence. Where the two runs disagree at the company level, the disagreement is concentrated in the attrited small-sample names (MRKU, IRKT, MRKK, MRKC), which is where the corrected proxy should be trusted least.

---
*Prepared by the reporting agent from: `output/agent2/method{1..5}_*.csv`, `output/agent2/method3_sector_*.csv` (validated results), `output/agent3/audit_report.md` (QC audit; 0 FAIL, 3 WARNING, 9 PASS), `output/agent4/comparison_by_company.csv` and `comparison_summary.json` (side-by-side benchmark whose previous-spec side reproduces the published `results_section.md` numbers), and the previous results section. No numbers were recomputed for this section beyond the quoted benchmark validation.*
