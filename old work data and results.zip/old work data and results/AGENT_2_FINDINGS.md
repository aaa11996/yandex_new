# Agent 2 findings — MOEX weekly price panel

**Status:** Agent 2 workstream complete. **Severity counts:** S1: 0; S2: 3; S3: 4; S4: 0. **Core panel error count:** 0 in the structure, weekly date, OHLCV, VWAP, and daily-to-weekly aggregation checks below. This is not a finding that the econometric specifications or downstream model inputs are correct.

**Execution note:** The prompt describes independent agents, but no agent-spawning/delegation tool was available. This report is the Agent 2 role-separated workstream in the current session; it does not claim that an independent Agent 2 was spawned. Only new files under `audit_round1/agent_2/` were created or edited. The supplied thesis/source inputs remained read-only.

## Executive summary

1. **S2 — Share-volume control has material scale breaks.** The four panel `CA_FLAG` rows coincide with large share-volume changes. For VTBR, the median log share volume shifts −8.066 (26.89 to 18.82) while median log ruble value shifts only +0.172. Similar, directionally different volume/value shifts occur for GMKN, PLZL and ROLO. This is a result-neutral reason to run the pre-defined `ln(VALUE)` or split-adjusted-volume sensitivity; this audit has not rerun regressions, so impact on reported coefficients, significance, or survivor counts is **unknown and requires Agent 5's model rerun**.
2. **S2 — The available returns are raw-price returns, and the CA return fields are not interchangeable.** Across 30,926 adjacent, non-CA observations, `RETURN_RAW` matches the log close-to-close formula to floating-point precision. On all four CA-flagged weeks, however, `RETURN_RAW` retains the extreme close-ratio return while `RETURN_SAFE` is missing. The downstream estimation code/model input is unavailable, so I cannot verify which field was used. Separately, the supplied dividend table has record dates, not ex-dividend dates; an exact ex-dividend drop cannot be isolated or quantified from these inputs.
3. **S3 — The independent vendor check is broadly supportive but exposes four below-95% tickers.** On the prescribed seven-day offset, strict OHLC matches are 29,280/30,953 = 94.595% pooled. GMKN, ROLO and VTBR show clear time-varying scale factors around flagged corporate actions; BLNG has 51 complete-week failures and 20 incomplete aligned weeks, with no comparable scale break in its factor distribution. This is a vendor cross-check, not evidence that the primary panel is wrong: all 75 primary daily series reaggregate to the weekly panel with zero mismatches.

## Findings register

| ID | Class | Severity | Status | Short finding | Main affected results / limitation |
|---|---|---:|---|---|---|
| A2-001 | RISK | S2 | VERIFIED-BY-CODE | Raw share-volume levels jump across corporate-action scales; `lnV` as a control is not split-invariant. | M1/H1 and M3/M4 `lnV` specifications; exact number changes unknown pending full-spec sensitivity. |
| A2-002 | RISK | S2 | VERIFIED-BY-CODE; model use CANNOT-VERIFY | `RETURN_RAW` preserves four extreme CA-week close returns; `RETURN_SAFE` masks them. | M2/H2 if the wrong field is consumed; requires the actual estimation code/dataset. |
| A2-003 | RISK | S2 | VERIFIED-BY-READING + VERIFIED-BY-CODE; ex-date effect CANNOT-VERIFY | Raw close returns are not dividend-adjusted total returns, and the supplied dividend dates are record dates, not ex-dates. | Meaning of H2 and any H5 payout interpretation; exact ex-dividend return impact unknown. |
| A2-004 | RISK | S3 | VERIFIED-BY-CODE | Strict old-Investing.com cross-check is below 95% for BLNG, GMKN, ROLO and VTBR; denominator and scale shifts matter. | Data-source confidence only; primary MOEX panel independently passes daily reaggregation. |
| A2-005 | RISK | S3 | VERIFIED-BY-CODE; flag meaning CANNOT-VERIFY | All final-week rows are marked partial, but each has five trading days; the Sunday end is 2026-09-06, after the last Monday key 2026-08-31. | Boundary wording / partial-week interpretation; no return-model effect measured. |
| A2-006 | RISK | S3 | VERIFIED-BY-CODE; official schedule CANNOT-VERIFY | A minimum-observed-price-step proxy exceeds 0.1% in 129 ticker-years across 28 tickers. | RV quantization discussion; proxy is not an exchange tick schedule and triggers no exclusion. |
| A2-007 | RISK | S3 | VERIFIED-BY-CODE; trading-status reason CANNOT-VERIFY | YNDX has five no-trade weeks in June–July 2024, then a three-day restart week; this is an observed missing-price interval, not a stitched price return. | YNDX usable observations and interpretation around the relisting/conversion window. |

### A2-001 — Share-volume controls change scale across flagged corporate actions

**ID:** A2-001 | **Class:** RISK | **Severity:** S2 | **Status:** VERIFIED-BY-CODE  
**Where:** `combined_panel/Banking/VTBR/VTBR_combined.csv` (week 2024-07-15); `combined_panel/Metals&Mining/GMKN/GMKN_combined.csv` (2024-04-08); `combined_panel/Metals&Mining/PLZL/PLZL_combined.csv` (2025-03-24); `combined_panel/Metals&Mining/ROLO/ROLO_combined.csv` (2023-01-16).  
**What is wrong/risky:** `VOLUME` is a count of shares. A stock split or consolidation changes how many units are counted even when the economic amount traded is similar. Therefore a log-share-volume control has a level break at those events; it is not a stable, split-invariant measure of trading activity. This is a modeling risk, not an error in the raw share-count field.  
**Evidence:** `REPRO/evidence/volume_break_summary_75.csv` reports the largest share-volume/value divergence for every ticker. Its pre/post medians use 26 valid observations before the event and 26 starting at the event week. The four flagged cases are:

| Ticker / panel note | Event-week close ratio | Event-week volume ratio | Event-week value ratio | Median lnV before → after (shift) | Median lnVALUE before → after (shift) |
|---|---:|---:|---:|---:|---:|
| VTBR, 5000:1 consolidation, 2024-07-15 | 4,833.42 | 0.002667 | 12.54 | 26.890 → 18.824 (−8.066) | 23.125 → 23.297 (+0.172) |
| GMKN, 100:1 split, 2024-04-08 | 0.010947 | 2,676.16 | 28.48 | 13.065 → 17.888 (+4.823) | 22.753 → 22.737 (−0.016) |
| PLZL, 10:1 split/resumption note, 2025-03-24 | 0.098859 | 5.07 | 0.497 | 13.768 → 15.466 (+1.699) | 23.399 → 23.006 (−0.393) |
| ROLO, dilution/large share issue note, 2023-01-16 | 0.108686 | 57.24 | 6.54 | 15.360 → 19.181 (+3.821) | 17.211 → 18.957 (+1.747) |

The 75-ticker screen marks a >ln(2) post/pre median `lnV` shift for 42 tickers. This is a screen, not proof that all 42 breaks are corporate actions. The separate, pre-set 10× volume/value-divergence signature returns one candidate, PLZL, which is already among the flagged events; **no unflagged candidate met that particular threshold**, which does not prove no unflagged action exists. Full row-level screen: `REPRO/evidence/volume_break_summary_75.csv`, `REPRO/evidence/volume_split_signature_candidates.csv`, and `REPRO/evidence/corporate_action_rows.csv`.

**Affects:** M1/H1, M3 and M4 where `lnV` is used as a control; other results only if the model code uses `lnV`. Which coefficients, q-values or survivor counts would change is **unknown without the full model rerun**. `FINAL_REPORT.md` and the analysis code were not accessible in the workspace, so no result change is asserted.  
**Simple fix (proposal only):** Keep the primary specification unchanged until the thesis author decides; add the prescribed full-spec sensitivity replacing `lnV` with `ln(VALUE)` and/or split-adjusted share volume. Label it as a sensitivity.  
**Result-neutral reason:** Yes. The scale discontinuities follow from the share-count units and panel corporate-action flags, not from regression results.

### A2-002 — CA-week raw and safe return fields differ

**ID:** A2-002 | **Class:** RISK | **Severity:** S2 | **Status:** VERIFIED-BY-CODE  
**Where:** `REPRO/evidence/ca_return_rows.csv`, `REPRO/evidence/return_price_check_by_ticker.csv`, and the four CA rows in the combined panel listed above.  
**What is wrong/risky:** The panel stores both `RETURN_RAW` and `RETURN_SAFE`. For ordinary adjacent weeks, the raw field matches the stated log price-return formula. On each of the four flagged event weeks, the raw field retains the large close-to-close jump while the safe field is missing. The prompt's statement that “returns are set missing” is true for `RETURN_SAFE`, not for `RETURN_RAW`. A downstream model that selects the raw field would therefore include instrument-unit jumps; one that selects the safe field would mask them.  
**Evidence:** Verified by code for 30,926 adjacent-week, non-CA observations: 0 formula mismatches; maximum absolute difference is `1.04e-16`. On CA rows, `RETURN_RAW` is −4.514666 (GMKN), −2.314062 (PLZL), −2.219289 (ROLO), and +8.483309 (VTBR), while `RETURN_SAFE` is missing on all four. See `REPRO/evidence/return_corporate_action_dividend_note.md`.  
**Affects:** M2/H2 only if its estimation input is `RETURN_RAW`; the actual input column cannot be verified from the accessible files.  
**Simple fix (proposal only):** Before interpreting M2, trace the dependent-variable column in the actual regression dataset/code and confirm that CA weeks are masked as intended. Do not edit the panel or assume which column was used.  
**Result-neutral reason:** Yes. This is a column-definition and event-scale check.

### A2-003 — Raw price returns are not total returns; exact ex-dividend effects cannot be isolated

**ID:** A2-003 | **Class:** RISK | **Severity:** S2 | **Status:** VERIFIED-BY-CODE / VERIFIED-BY-READING for source definitions; exact ex-date price effect CANNOT-VERIFY  
**Where:** Combined-panel `RETURN_RAW`; `audit_work/yan 2/Final dividend table.md`, date-type note in §1; `audit_work/yan 2/data1/dividend_record_dates.csv`, which has `record_date` but no `ex_date` column.  
**What is wrong/risky:** The computed return is a log change in raw closing prices; it is not a dividend-adjusted total return. The supplied dividend list uses record dates (дата закрытия реестра), not ex-dividend dates. A record-date week must not be relabeled as an ex-dividend week, and its raw return must not be presented as a measured ex-dividend price drop.  
**Evidence:** 30,926 valid adjacent non-CA raw return values reproduce `ln(CLOSE_t/CLOSE_{t-1})` with zero mismatches. The Markdown source says all listed dates are record dates and that no ex-dividend or last-day-to-buy date was substituted. The supplied CSV has 587 rows and a `record_date` field but no ex-date field.  
**Affects:** The estimand and wording for H2 (“price return” versus “total return”) and any H5 interpretation that attributes a return movement to payout mechanics. No numeric ex-dividend effect or change to reported M2/H5 values can be calculated from the available inputs.  
**Simple fix (proposal only):** State explicitly that the outcome is a raw-price return, or obtain a verified total-return/ex-date source and run a separately labeled sensitivity.  
**Result-neutral reason:** Yes. The limitation follows from the source date type and return formula, not the observed estimates.  
**Could NOT verify:** Exact ex-dividend drop sizes “relative to weekly return noise” for even the largest per-share payments. Required input: verified ex-dividend dates (or total-return series) joined to daily prices with a documented trading-week convention. No proxy calculation is mislabeled as an ex-dividend effect.

### A2-004 — Four below-95% Investing.com checks; distinguish strict weekly rates from component averages

**ID:** A2-004 | **Class:** RISK | **Severity:** S3 | **Status:** VERIFIED-BY-CODE  
**Where:** `REPRO/evidence/investing_strict_weekly_rates.csv`, `investing_crosscheck_rows.csv`, `investing_crosscheck_offsets.csv`, and `investing_crosscheck_metric_note.md`.  
**What is wrong/risky:** A fixed, full-sample vendor scale factor is not suitable across a split/consolidation scale change. In addition, an average of close/high/low component matches is not the same metric as a weekly all-three-fields match. The reportable strict rate below uses the required seven-day label shift and requires all six MOEX/vendor OHLC prices to be present; incomplete aligned pairs are disclosed and excluded, not counted as mismatches.  
**Evidence:** At offset −7 days, 29,280 of 30,953 complete aligned weekly OHLC comparisons match all three prices within the 0.1% multiplicative tolerance (94.595% pooled; per-ticker mean 94.593%). There are 32 aligned weeks with at least one missing price pair. Four tickers are below 95%:

| Ticker | Strict matches / complete weeks | Rate | Incomplete aligned weeks | Median close factor before → after flagged event (26-week windows) | Interpretation supported by ratio screen |
|---|---:|---:|---:|---:|---|
| BLNG | 343 / 394 | 87.06% | 20 (2022-02-28 and 2024-07-29 through 2024-12-02) | full-sample median 1.000; 5th–95th percentiles 0.99946–1.00099 | Factor stays near 1; 51 complete weeks fail at least one price component. Quote-level/vendor differences remain unexplained by a scale change. |
| GMKN | 288 / 415 | 69.40% | 0 | 100 → 1 | Factor shift coincides with panel 100:1 split flag. |
| ROLO | 0 / 413 | 0.00% | 0 | 10 → 1.001 | Factor shift coincides with panel dilution/large-issue flag. |
| VTBR | 303 / 415 | 73.01% | 0 | 0.0002 → 1 | Factor shift coincides with panel 5000:1 consolidation flag. |

The all-ticker offset-7 mean component match rate is 96.58%; this is **not** the strict weekly rate. Offset 0 is only 3.32% on the same component-average metric, which supports the seven-day alignment. BLNG has 343 true all-three flags, not 363; its denominator is explicit above.  
**Affects:** Cross-check confidence and explanation only. The primary MOEX input is not replaced by Investing.com, and all 75 daily source series reaggregate exactly to the weekly panel.  
**Simple fix (proposal only):** Retain the row-level denominator and time-varying scale explanation in any data appendix; do not quote `mean_component_match_rate_0_1pct` as a strict weekly match percentage.  
**Result-neutral reason:** Yes; this is a measurement-definition and unit-scale issue.

### A2-005 — Last Monday key is flagged partial despite five price sessions

**ID:** A2-005 | **Class:** RISK | **Severity:** S3 | **Status:** VERIFIED-BY-CODE for observed rows; intended flag meaning CANNOT-VERIFY  
**Where:** `REPRO/evidence/last_week.csv`.  
**What is risky:** All 75 rows for `SEARCH_MONDAY=2026-08-31` have `PARTIAL_WEEK_FLAG=1`, but all 75 also have `N_TRADING_DAYS=5` and `N_SAT_DAYS=0`. Their `MOEX_WEEK_END_SUNDAY` is 2026-09-06. Thus the final price bars contain five weekday sessions and extend six calendar days beyond the last Monday key. The flag may indicate a study-window boundary rather than fewer observed trading days; its intended semantics cannot be confirmed without the panel-builder rule.  
**Affects:** Sample-end wording and any claim that the final price week is incomplete. It is not evidence that the five sessions are missing.  
**Simple fix (proposal only):** State both dates and the observed count (Monday key 2026-08-31; Sunday bar end 2026-09-06; five trading days) and define what `PARTIAL_WEEK_FLAG` means. Do not silently drop or truncate the last row.  
**Result-neutral reason:** Yes; date-boundary evidence is independent of estimates.

### A2-006 — Tick-size proxy suggests periods for review, but is not an authoritative tick schedule

**ID:** A2-006 | **Class:** RISK | **Severity:** S3 | **Status:** VERIFIED-BY-CODE for the proxy; official tick sizes CANNOT-VERIFY  
**Where:** `REPRO/evidence/tick_size_proxy_ticker_year.csv`.  
**What is risky:** The audit computes the smallest distinct observed daily close-price step divided by that ticker-year's median close. This proxy exceeds 0.1% in 129 of 675 ticker-years across 28 tickers. The highest proxy ratios include AVAN 2019 (1.50%), AVAN 2020 (0.64%), MGTS 2025 (0.45%), and UKUZ 2020 (0.38%). VTBR's median close is about 0.018–0.025 in 2022–2024 before consolidation, but its proxy remains below 0.1%.  
**Limit:** This is only an observed-price-grid proxy; it is not an MOEX tick-size schedule, and a coarse observed step may reflect liquidity or price precision. The audit excludes no firm and makes no tick-size causal claim.  
**Affects:** RV quantization discussion. No reported result is changed by this screen.  
**Simple fix (proposal only):** Describe it as a screen only; use official exchange tick schedules if a formal tick-size claim is needed.  
**Result-neutral reason:** Yes.

### A2-007 — YNDX has a preserved suspension gap, not a computed bridge return

**ID:** A2-007 | **Class:** RISK | **Severity:** S3 | **Status:** VERIFIED-BY-CODE for weekly panel rows; trading-status reason CANNOT-VERIFY from price files alone  
**Where:** `REPRO/evidence/yndx_transition_panel.csv`; `REPRO/evidence/no_trade_rows_by_ticker.csv`; YNDX source reference in the combined panel.  
**What is risky:** YNDX has no observed trading days in the 2024-06-17, 06-24, 07-01, 07-08 or 07-15 Monday weeks; the 2024-07-22 restart week has three trading days. The same `Tech/YNDX/YNDX_daily.csv` source feeds the panel around this interval, and the weekly grid contains no duplicate ticker-week. The restart-week return remains missing because the prior weekly close is missing; the audit found no forward-fill or bridge return. No separate YDEX price series was found in the primary weekly/daily price directories.  
**Affects:** YNDX observations around the transition; the price files alone do not establish the legal suspension/relisting history.  
**Simple fix (proposal only):** Keep the missing weeks missing and disclose the observed gap; use official trading-status records only if the exact legal reason is needed.  
**Result-neutral reason:** Yes.

## Checked and found OK

Every PASS below has row-level evidence. Empty exception files include their CSV header, so the zero counts are auditable.

- **Panel structure — VERIFIED-BY-CODE:** 75 unique tickers × 419 Monday rows = 31,425, 13 sector folders, 32 columns with a common column signature; zero duplicate ticker-weeks, missing/extra grid dates, folder/ticker/sector mismatches, or per-ticker structure failures. Sector ticker counts are in `REPRO/evidence/structure_by_ticker.csv`: Metals&Mining 15; Utilities 15; Energy 12; Banking 6; Chemicals 5; Telecom, Consumer&Retail, Transportation 4 each; Real Estate and Tech 3 each; Diversified 2; Industrial 1; Insurance 1.
- **Date rule — VERIFIED-BY-CODE:** `MOEX_WEEK_END_SUNDAY − SEARCH_MONDAY = 6` for all 31,425 rows. No exceptions in `REPRO/evidence/date_rule_violations.csv`.
- **OHLCV and VWAP — VERIFIED-BY-CODE:** zero rows violate high/low logic, positive-price checks, or nonnegative volume/value checks. With a pre-stated 0.1% multiplicative tolerance, `VALUE/VOLUME` falls within the weekly low/high interval on every eligible row; no exception in `REPRO/evidence/vwap_violations.csv`. This sanity check is not an independent reconciliation of turnover units.
- **Source pointers and daily aggregation — VERIFIED-BY-CODE:** all 75 tickers have one unique `SOURCE_MOEX_FILE` reference; each reference resolves to the selected daily file. Rebuilt OHLCV, `N_TRADING_DAYS`, `N_SAT_DAYS`, and `N_PLACEHOLDER_ROWS` were compared for 419 weeks × 9 fields = 3,771 cells per ticker. Total comparisons: 282,825; mismatches: 0; missing daily inputs: 0. The earlier apparent three missing files were a folder-name alias (`Real Estate` in the weekly panel vs `RealEstate` in the daily archive), now resolved and tested. See `REPRO/evidence/daily_aggregation_by_ticker.csv`.
- **No-trade handling — VERIFIED-BY-CODE:** all 328 `N_TRADING_DAYS=0` rows have OHLCV missing, not zero-filled. The three full-closure weeks are 2022-02-28, 2022-03-07 and 2022-03-14. Remaining no-trade rows are firm-specific; 2022-03-21 has 49 no-trade tickers but is not a full-market closure. All row dates are in `REPRO/evidence/no_trade_rows_by_ticker.csv`. Longer stretches include AVAN's 16 no-trade rows, BLNG's 19 non-closure rows from 2024-07-29 through 2024-12-02, LSNG's 2020-03-23 through 2020-05-11 interval, MSTT's 2020-09-21 through 2020-10-05 interval, FEES 2022-12-26 and 2023-01-02, and YNDX's transition interval. The data prove missing trading observations, not the legal or economic reason for each pause.
- **Corporate-action flags — VERIFIED-BY-CODE for ratios; panel note VERIFIED-BY-READING:** four `CA_FLAG` rows and 17 `CA_CANDIDATE_FLAG` rows are retained with event-week/previous-week close, volume, and value ratios in `REPRO/evidence/corporate_action_rows.csv`. The four notes and internal price/volume/value evidence are consistent with the flagged scale events; official corporate-action documentation was not independently fetched.
- **RV formula and equal high/low — VERIFIED-BY-CODE:** `RV=ln(HIGH/LOW)` recomputation has maximum absolute difference `2.22e-16` and zero differences above `1e-10`. Seven `HIGH=LOW` bars have missing RV, not zero: AVAN 2018-09-03, 2019-01-14 and 2019-01-28; ABRD 2018-09-03; JNOS 2018-12-31; VJGZ 2018-09-03 and 2018-09-17. The largest recomputed RV rows are listed in `REPRO/evidence/rv_top25.csv`; the top values cluster around 2022-02-21 (e.g., RASP 1.1233, ROSN 1.1123, SBER 1.0590), which is an extreme observed range screen, not a formula violation.
- **Volume screens — VERIFIED-BY-CODE:** the 75-row largest-discrepancy table is `REPRO/evidence/volume_break_summary_75.csv`; the selected 10× split-signature screen is `REPRO/evidence/volume_split_signature_candidates.csv`. The threshold is a pre-set heuristic and does not certify the absence of other corporate actions.
- **Raw return formula — VERIFIED-BY-CODE:** for 30,926 adjacent-week non-CA rows with two observed closes, zero `RETURN_RAW` formula mismatches; maximum absolute difference `1.04e-16`. The CA-week exception is separately disclosed in A2-002.

## Could NOT verify, and what is needed

- **Exact ex-dividend price drops / noise comparison — CANNOT-VERIFY.** The supplied dividend sources provide record dates, not ex-dates. Need a verified ex-date (or total-return) series and a documented weekly mapping. No record-week proxy is mislabeled as an ex-date return.
- **Which dependent-return field the thesis models actually consume — CANNOT-VERIFY.** The model script/regression dataset was not available. Need the actual dependent-variable selection showing `RETURN_RAW` or `RETURN_SAFE`.
- **Effect of the volume control break on H1/M3/M4 results — CANNOT-VERIFY in Agent 2.** Need Agent 5's full-spec `lnVALUE` and/or split-adjusted-volume re-estimation. No effect size is invented here.
- **Official tick-size schedules — CANNOT-VERIFY.** The allowed panel and daily files support only the minimum-observed-step proxy; a dated MOEX schedule is required to establish official price grids.
- **Reason for firm-specific no-trade spans / YNDX pause — CANNOT-VERIFY from price rows alone.** Need authorized trading-status, suspension, listing or delisting records. The audit preserves missing values.
- **Meaning of `PARTIAL_WEEK_FLAG` — CANNOT-VERIFY.** The observed final-week flag and session count are reported; the panel-builder definition is needed to identify the exact semantic rule.
- **Full-report number-to-file comparison — CANNOT-VERIFY.** `FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md`, and the analysis scripts cited in the prompt were not present in the accessible workspace. The audit prompt's listed headline numbers are treated as claims supplied for context, not as independently reproduced values.
- **Independent legal confirmation of the four corporate-action descriptions — CANNOT-VERIFY under this price-only workstream.** Internal panel notes and price/volume/value ratios are documented; confirming effective dates and event terms against exchange/company notices would require those primary notices.

## Reproducibility and publication status

The main script is `REPRO/moex_panel_audit.py`. It prints its Python/pandas/NumPy versions and the summary to `REPRO/run_output.txt`; it writes the per-check CSVs under `REPRO/evidence/`. Additional clean-start scripts are `REPRO/input_inventory.py` and `REPRO/plain_english_demos.py`. No thesis input was edited. Deliverables are in the local shared workspace; the public repository was not modified, so publish-and-refetch hash round-trip was not possible. Final Agent 2 file sizes and SHA-256 values are in `MANIFEST.sha256`.
