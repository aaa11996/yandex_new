# Agent 3 findings — emerging, developing, transition, and sanctioned-economy comparables

**Prepared:** 5 October 2026  
**Scope:** Literature comparison only; no Asif data were recomputed and no Asif source files were edited.  
**Governing method:** `methodology_final.md`, v2.0.  
**Important scope note:** The live repository root listing showed no separate `FINAL_REPORT.md` or `THESIS_HANDOFF_BRIEF.md` entries, and a workspace search found neither file. This report uses the governing methodology and available supporting documents. The review does not claim to be Agent 7’s unified master verdict.

## Executive summary

**Finding count:** 9 total — **2 STRENGTH**, **2 GAP**, **1 MISMATCH**, **4 OPEN-QUESTION**. Severity: **8 IMPORTANT**, **1 MINOR**, **0 CRITICAL**. “IMPORTANT” means address or disclose before defense; it does not mean the design is invalid.

### Three highest-priority points

1. **Russia novelty is plausible but not proven.** I verified three materially different Russian overlaps: Russian stock-related Google searches and trading activity; topical search statistics alongside issuer returns; and a national financial-stress index using Google plus Wordstat. I did **not** verify an exact study matching firm-specific Wordstat queries and weekly MOEX issuer returns/volatility. That is a bounded search conclusion, not proof of absence; do not claim “the first Russian search-attention study.”
2. **The written ASVI baseline is not algebraically identical to the original Da–Engelberg–Gao definition for an eight-observation window.** `median(log(counts))` differs from `log(median(counts))` under the conventional even-sample median. This is a real, result-neutral specification difference; a canonical-form sensitivity calculation would make the choice easy to defend.
3. **The return specification is narrower than the common attention-pressure/reversal story and is not market-adjusted in M2.** M2 estimates a one-week-ahead raw-return association. M3 tests joint predictive content at 1/2/4 lags, but not a full return path or long-run reversal. Several comparators use market-adjusted excess returns. Either narrow the claim to the one-week estimand or add a modest dynamic/market-adjusted robustness analysis if time permits.

## Comparability table

“Controls” lists only items confirmed in the source portions read. Where a source’s abstract does not give the controls, that is stated rather than guessed. Source tiers and reading scope are detailed under **References actually used**.

### Firm-level attention and market outcomes

| Country / study | Search source and sample | Frequency / outcome | Key controls or design details read | Main result and comparison to Asif |
|---|---|---|---|---|
| **United States — Da, Engelberg & Gao (2011)** | Google Trends SVI, chiefly ticker terms; Russell 3000 firms ever in the index, 3,606 stocks, Jan 2004–Jun 2008. | Weekly ASVI; short-run stock-price/return pressure and later reversal. | Tests SVI against other attention proxies and includes multiple stock/attention measures in the return analysis; the paper also directly links search changes to retail trading. | Search attention is followed by positive pressure in the next two weeks, largely reversed by year-end. This is the founding comparison for the mechanism, but it is not a Russian or emerging-market validation. Its canonical ASVI is `ln(SVI_t) − ln(median(SVI_{t−1…t−8}))`. |
| **Turkey — Düz Tan & Taş (2019)** | Google ticker ASVI; 313 BIST All Shares stocks, Apr 2013–Sep 2017. | Weekly firm-level returns. | The publisher abstract does not enumerate the full control set; the article’s empirical sections were consulted for its design and results. No unverified control list is reproduced here. | Finds short-run price pressure, stronger among smaller stocks, followed by reversal within a year; return predictability persists for about three weeks. Supports the relevance of multiweek horizons and heterogeneity rather than a universal long-run sign. |
| **Brazil — Yoshinaga & Rocco (2020)** | Google Trends restricted to Brazil; ticker searches for 57 stock listings representing 54 firms in the Ibovespa. | Weekly; Jan 2014–Dec 2018, 261 weeks; firm excess returns. | Five lags of excess returns, GSV change and volume; short-/long-horizon return and GSV volatility; size and industry effects; FGLS. Search terms were run separately because Google’s relative scale is not comparable across expressions. | Increases in GSV are followed by small negative return associations across early lags; effects are statistically detectable but economically small. The paper makes clear that emerging-market evidence can differ from the short-run positive-pressure pattern. |
| **India — Swamy, Dharani & Takeda (2019)** | Google Trends for India; company-name terms; final sample 436 S&P BSE 500 firms, Sep 2012–Aug 2017. | Weekly, 260-week unbalanced panel; excess returns; quantile regressions. | 52-week rolling market beta to form excess return; lagged excess returns, detrended log volume, short- and longer-horizon volatility; Fama–French four-factor trading strategy as robustness. | High search changes are associated with positive returns in higher return quantiles and across the first several weeks, while lower-quantile behavior can differ. This is a close developing-market, weekly firm-panel analogue, and a warning against treating a mean coefficient as the whole story. |
| **Vietnam — Bui & Nguyen (2019)** | Google Trends; 49 HOSE firms from the VN-100 as of Jan 2019, Jan 2014–Dec 2018; firm and VN-Index search measures. | Weekly; stock illiquidity and volatility. | Firm size, weekly return, return volatility, trading volume, a lag/time trend, and market-wide search; the paper uses weekly turnover-price-impact and return-volatility measures. | Firm-specific attention has mixed effects on illiquidity and volatility; market-wide attention increases illiquidity and volatility. This is a strong comparator for separating firm-specific from market-wide attention and for treating H1’s sign as unsettled. |
| **China — Yang et al. (2021)** | Abnormal Baidu SVI; 890,840 firm-week observations for listed firms, 2011–2018. | Firm-week returns and trading volume. | The inspected abstract does not specify a complete control set; none is inferred here. | ASVI is positively associated with contemporaneous returns, with a complete reversal in the subsequent period; the attention–volume association does not reverse in the same way. Directly supports the need to distinguish contemporaneous response from subsequent return path. |

### Russia, regional, and broader emerging-market context

| Country / study | Search source and sample | Frequency / outcome | Key controls or design details read | Main result and what it does **not** establish |
|---|---|---|---|---|
| **Russia — Teplova & Gurov (online 2022; issue 2025)** | Google relative search volume for Russian stocks, 2018–2021. | Intraday trading-activity synchronization/invariance, not a weekly firm-return regression in the abstract inspected. | Sample count and full model controls are not available from the abstract; not inferred. | A verified Russian securities/search-data comparator. It means Asif cannot claim to be the first Russian study applying search data to equities, but it is not the same outcome, provider, frequency, or design. |
| **Russia — Fayzulin (2025)** | Abstract describes topical economic, political, and investment search statistics alongside millions of social-platform messages in a study of Russian issuers’ returns/retail-investor behavior. | The abstract links search attention/opinion divergence with issuer returns; exact query level and construction are not established there. | Provider, query strings, firm-by-week mapping, and complete controls remain unverified because the linked PDF was not readable in the page viewer. | A potentially close Russian return-literature overlap, but not verified as firm-specific Yandex Wordstat attention. It prevents an unqualified “no Russian search-and-return work” statement. |
| **Russia — Stolbov & Shchepeleva (2025)** | Google plus Yandex Wordstat terms in a Russian national financial-stress index, 2018–2024. | Macro/national stress index, not firm-level attention or issuer returns. | Abstract and opening page read; full index construction not reviewed for this comparison. | Confirms that Wordstat appears in peer-reviewed Russian financial research, but does not validate Wordstat as an issuer-specific investor-attention measure. |
| **Poland — Kropiński & Anholcer (2022)** | Google Trends policy-uncertainty keywords and the WIG20 index; two windows, 2015–2019 and 2016–2021. | Market-index VAR/Granger tests; AIC used to choose lags. | Bivariate VAR, not a firm-level control set. | A regional transition-market search-data comparator, but it uses broad EPU queries rather than issuer-level attention. No firm-specific WSE study was verified in this search. |
| **Africa, including South Africa — Iyke & Ho (2021)** | Google searches for COVID-related terms and 14 national stock indices, including South Africa, 1 Jan–26 Nov 2020. | Country-index daily returns and conditional variance, EGARCH(1,1). | Lagged returns, exchange-rate returns and commodity returns; search attention also enters the variance equation. | Attention-return effects vary across countries and specifications. This supports contextual heterogeneity, but it is a pandemic-topic/index study, not an issuer-search study. |
| **Indonesia / Iran / Venezuela / other CEE** | Targeted searches were run for firm searches, local search providers, stock returns, and the relevant markets. | No directly comparable firm-specific study was verified to the source standard used here. | — | This is **CANNOT-VERIFY as an absence claim**. Search snippets and incomplete aggregator records were not promoted into evidence. It is not evidence that these literatures do not exist. |

## Findings register

### L3-001 | STRENGTH | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** 75-company weekly design, Aug 2018–Aug 2026 Wordstat panel.  
**Comparable source:** Düz Tan & Taş (2019), Turkey, *Borsa Istanbul Review*; Yoshinaga & Rocco (2020), Brazil, *Brazilian Business Review*; Swamy et al. (2019), India, *Research in International Business and Finance*; Bui & Nguyen (2019), Vietnam, *Journal of Economics and Development*. Read: relevant methods/results sections as noted in the table and inventory.  
**What it does similarly:** Weekly firm-level search measures and stock outcomes are already used in emerging markets. Published samples include 313 Turkish shares, 57 Brazilian listings, 436 Indian firms, and 49 Vietnamese stocks. Asif’s potential grid is 75 × 419, within the established weekly-panel design family; the total raw grid is not the same as the final estimation sample.  
**Why it matters:** The frequency and firm-level framing are not imported uncritically from US daily data; there are close emerging-market precedents. The Russian panel adds a long local-language, multi-event period.  
**Result-neutral reason:** The comparison is about design precedent and scope, not whether Asif’s coefficients are significant.  
**Suggestion (proposal only, Asif decides):** Keep weekly frequency and the 75-company panel as specified; explain that the contribution is the Russian setting and the chosen provider/measure combination, not a new estimator.

### L3-002 | STRENGTH | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** The premise that investor attention may be economically relevant on MOEX.  
**Comparable source:** Djalilov & Ülkü (2021), “Individual investors’ trading behavior in Moscow Exchange and the COVID-19 crisis,” *Journal of Behavioral and Experimental Finance* 31, 100549, [DOI](https://doi.org/10.1016/j.jbef.2021.100549). Read: article metadata, abstract, and opening material in the collected PDF.  
**What it adds:** The authors report that Russian individual investors bought during the COVID crash and remained net buyers through the market recovery; they interpret that persistence as evidence of sophistication, not as proof that all retail investors are noise traders.  
**Why it matters:** It supplies local evidence that individual-investor activity is a plausible channel in the Russian equity setting. It does **not** establish that a Wordstat query is an investor, that searches cause trades, or that the effect generalizes beyond the COVID episode.  
**Result-neutral reason:** This is context for the mechanism, independent of Asif’s estimates.  
**Suggestion (proposal only, Asif decides):** Cite it narrowly as local market-behavior context; do not use it as validation of the Wordstat measure.

### L3-003 | OPEN-QUESTION | IMPORTANT | Status: VERIFIED-BY-READING for partial comparators; CANNOT-VERIFY for absence of an exact match

**Where in Asif’s method:** Originality statement for firm-specific Yandex Wordstat ASVI and weekly MOEX returns/volatility.  
**Comparable source:** Teplova & Gurov (online 2022/issue 2025), *Annals of Operations Research*; Fayzulin (2025), *Lomonosov Economics Journal*; Stolbov & Shchepeleva (2025), *Borsa Istanbul Review*. Read: publisher abstracts/opening pages; Fayzulin PDF not readable.  
**What the sources show:** Russian financial research has used Google stock-related search volume with trading activity; a Russian issuer-return study’s abstract refers to topical search statistics; and a Russian national financial-stress index uses Google plus Wordstat. None of the inspected material verifies the same combination of issuer-specific Wordstat terms, weekly MOEX firm returns/range-volatility, and the 75-firm 2018–2026 panel.  
**Why it matters:** “First Russian study using search data” would be false or at least unsupported. A narrower contribution based on this exact measurement–market–outcome combination is plausible but is not globally proven by the search completed.  
**Result-neutral reason:** Originality is evaluated from the literature record, not from the desired direction or significance of Asif’s results.  
**Suggestion (proposal only, Asif decides):** State: “Among the sources reviewed, we did not identify an exact issuer-level Yandex Wordstat–MOEX weekly returns/volatility study; our contribution is this particular combination.” Avoid “first” unless a broader, documented search later establishes it. Treat Iran, Venezuela, Indonesia, and other CEE absence claims as **CANNOT-VERIFY**, not as proof that no work exists.

### L3-004 | MISMATCH | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** `ASVI_t = ln(SVI_t) − median{ln(SVI_{t−1}), …, ln(SVI_{t−8})}`.  
**Comparable source:** Da, Engelberg & Gao (2011), “In Search of Attention,” *The Journal of Finance* 66(5), 1461–1499, [DOI](https://doi.org/10.1111/j.1540-6261.2011.01679.x). Read: full article, including ASVI definition.  
**What it does differently:** Da et al. define abnormal search as `ln(SVI_t) − ln(median(SVI_{t−1}, …, SVI_{t−8}))`; Asif takes the median after logging the eight lagged values. Let `x_(1) ≤ … ≤ x_(8)` be the ordered, positive raw counts in the lag window. Under the conventional even-sample median, `median(ln x) = (ln x_(4) + ln x_(5))/2 = ln(√(x_(4)x_(5)))`, whereas `ln(median(x)) = ln((x_(4)+x_(5))/2)`. These differ unless the two middle counts match (arithmetic mean exceeds geometric mean); for an odd-sized window, the single middle observation makes the two forms equal.  
**Why it matters:** The two formulas can yield different ASVI values; therefore v2.0 is not an exact algebraic replication of Da et al. for the eight-week baseline. This does not make Asif’s transform invalid—it makes the difference worth disclosing and checking.  
**Result-neutral reason:** The mismatch is established by the definitions and even-sample median arithmetic, not by a desired coefficient.  
**Suggestion (proposal only, Asif decides):** Retain the frozen v2.0 series as primary, but compute `ln(SVI_t) − ln(median(SVI_{t−1…t−8}))` as a clearly labelled canonical-form sensitivity. Do not repeat the older prompt’s claim that the two formulas are equivalent for an eight-week window.

### L3-005 | GAP | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** H2/M2 uses `ASVI(i,t−1)` to explain week-*t* raw return; M3 tests joint ASVI lags at L = 1, 2, 4.  
**Comparable source:** Da et al. (2011); Düz Tan & Taş (2019); Swamy et al. (2019); Yang et al. (2021); Yoshinaga & Rocco (2020). Read: full-text sections for Da, India, and Brazil; relevant Turkey text; China abstract only.  
**What it does differently:** The attention-pressure account is often a path: short-run price pressure followed by partial or complete reversal. The published horizons are not identical—Da and Turkey report later reversal; India reports positive effects over several weeks; China’s abstract reports contemporaneous pressure followed by reversal; Brazil reports small negative lagged associations. Asif’s primary M2 coefficient is one-week-ahead. M3’s 1/2/4-lag joint tests help with predictive-content questions, but they do not by themselves estimate the sign and cumulative size of a return path or a year-long reversal.  
**Why it matters:** A defense answer should not claim that a one-week coefficient tests the whole pressure-and-reversal mechanism. The current primary equation has a narrower estimand than the full theoretical pattern.  
**Result-neutral reason:** This is a theory-to-equation coverage issue and does not depend on Asif’s result.  
**Suggestion (proposal only, Asif decides):** Either state that H2 is specifically a next-week predictive association and interpret M3 as joint predictability, or—if feasible within the thesis—show a small distributed-lag/cumulative-return robustness at the already specified horizons. Do not replace the frozen primary model without Asif’s decision.

### L3-006 | OPEN-QUESTION | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** H1 volatility and H2 return hypotheses. The governing v2.0 equations identify the ASVI coefficient but do not state a signed alternative in the equation block.  
**Comparable source:** Bui & Nguyen (2019), Vietnam; Yoshinaga & Rocco (2020), Brazil; Swamy et al. (2019), India; Düz Tan & Taş (2019), Turkey; Yang et al. (2021), China; Iyke & Ho (2021), African country indices. Read: relevant sections/abstracts as stated in the table.  
**What the literature does differently:** Search-attention effects are not sign-invariant. Attention may raise volatility through attention-driven trading or reduce it if information is absorbed more quickly. Vietnam reports mixed firm-level volatility effects; market-wide attention is positive. Return findings differ across Turkey, India, Brazil, China, and countries in Africa, and can vary by horizon or return quantile.  
**Why it matters:** A one-directional H1/H2 prediction needs a Russia-specific mechanism and an explicit time horizon; it cannot be justified by saying that “the literature” predicts one universal sign.  
**Result-neutral reason:** The sign heterogeneity is in published comparator evidence and theory, not in Asif’s estimates.  
**Suggestion (proposal only, Asif decides):** If the thesis intends a directional hypothesis, name the channel and horizon that imply the sign. If the mechanism is genuinely competing, state a two-sided or conditional prediction and discuss the alternatives directly. Keep “firm-specific” and “market-wide” attention distinct.

### L3-007 | GAP | IMPORTANT | Status: VERIFIED-BY-READING

**Where in Asif’s method:** Per-company M2 has raw weekly stock return as the dependent variable; the equation includes lagged return, lagged RV, Crisis, Sanction, and Div, but no MOEX market-return benchmark. The pooled M4 time effects apply to a different model and do not market-adjust M2.  
**Comparable source:** Swamy et al. (2019), India; Yoshinaga & Rocco (2020), Brazil; Vlastakis & Markellos (2012), *Journal of Banking & Finance*. Read: India/Brazil methods sections and Vlastakis–Markellos abstract/opening.  
**What they do differently:** The India and Brazil studies construct market-adjusted excess returns using a market index and rolling beta. Vlastakis & Markellos report controlling for market return in their information-demand models. Asif’s M2 controls several Russian event states, but an event dummy is not the same as removing the broad weekly market return.  
**Why it matters:** In a market with large common shocks, a raw firm return may reflect the market move as well as firm-specific attention. The pooled M4 time effects absorb common week shocks in that pooled specification, but they do not transform the per-company M2 outcome into an abnormal return.  
**Result-neutral reason:** This is a comparator-based estimand distinction, not an argument about the M2 estimate.  
**Suggestion (proposal only, Asif decides):** Add a market-adjusted excess-return version of M2 as a robustness check if a consistent MOEX benchmark is available, using a standard rolling-beta approach; otherwise explicitly describe M2 as a raw-return association and avoid calling it abnormal-return predictability.

### L3-008 | OPEN-QUESTION | IMPORTANT | Status: VERIFIED-BY-READING for query-choice comparators; CANNOT-VERIFY for firm-level Wordstat validation

**Where in Asif’s method:** Weekly SVI is the sum of a Latin ticker query and Cyrillic company-name-plus-«акции» query, using Yandex Wordstat raw counts before the log transform.  
**Comparable source:** Da et al. (2011), United States; Yoshinaga & Rocco (2020), Brazil; Swamy et al. (2019), India; Stolbov & Shchepeleva (2025), Russia. Read: Da, Brazil, and India full-text sections; Russian publisher abstract/opening page.  
**What they do differently:** Da and the Brazil paper use ticker searches to reduce consumer/company-name ambiguity; the India paper uses company names because many tickers are ambiguous. These are competing query-selection trade-offs. Asif’s Russian qualifier «акции» is a plausible local-language attempt to focus the name query, but the two Wordstat counts are query volumes, not a deduplicated count of unique searchers. The Russian Wordstat finance paper found uses Wordstat in a national stress index, not as a validated issuer-level attention series.  
**Why it matters:** Search activity can reflect investor research, news-seeking, customer interest, or repeated searches by one person. Summing two query series may broaden coverage but does not establish that the sum is a count of investors or unique people.  
**Result-neutral reason:** The concern is measurement interpretation and source validation; it is independent of coefficient outcomes.  
**Suggestion (proposal only, Asif decides):** Keep the frozen series as primary, publish exact query strings and Wordstat settings, describe ASVI as abnormal query/search intensity rather than a headcount of investors, and show ticker-only/name-only sensitivity if the stored channels permit it. Do not claim that macro-level use of Wordstat validates issuer-level attention.

### L3-009 | OPEN-QUESTION | MINOR | Status: VERIFIED-BY-READING

**Where in Asif’s method:** Lagged `ln(V)` is included in M1 and pooled M4; M2 does not include lagged volume. No separate liquidity/illiquidity outcome is specified.  
**Comparable source:** Bui & Nguyen (2019), Vietnam; Yoshinaga & Rocco (2020), Brazil; Swamy et al. (2019), India. Read: relevant methods sections.  
**What they do differently:** These papers include turnover/volume in some return or activity specifications, and some treat illiquidity as an outcome. That does not make an Amihud-style illiquidity variable a universal required control in a thesis whose stated outcomes are returns and volatility. Volume can be a confounder, a proxy for trading activity, or part of the attention-to-price channel.  
**Why it matters:** The control choice depends on whether Asif wants a total attention association or an association conditional on trading activity. Its absence from M2 is a defensible point to explain, not a demonstrated fatal omission.  
**Result-neutral reason:** This is an estimand question derived from the different roles assigned to volume in published models.  
**Suggestion (proposal only, Asif decides):** Explain why M2 omits volume, or add lagged `ln(V)` as a low-cost M2 sensitivity if consistent with the thesis estimand. No need to add a separate liquidity outcome solely to imitate papers with a different research question.

## Direct answers for Asif

### Does an exact Russian Yandex Wordstat–MOEX firm-return study already exist?

**Not verified among the sources checked.** The verified Russian overlaps are different: (i) Teplova & Gurov use Google stock-related searches with intraday trading activity; (ii) Fayzulin’s abstract combines topical search attention and issuer returns but does not disclose enough to verify issuer-specific Wordstat terms; (iii) Stolbov & Shchepeleva use Google plus Wordstat for a national financial-stress index. Therefore, do not claim that no Russian search-attention work exists, and do not claim “first” on this record. A narrower contribution around issuer-related Yandex Wordstat ASVI and weekly MOEX firm outcomes is plausible but remains an **unproven originality claim**.

### Where does Asif align with the field?

- Weekly firm-level search attention is a well-established empirical design in Turkey, Brazil, India, and Vietnam.
- The eight-week abnormal-search baseline is close to the founding Da–Engelberg–Gao design, though the order of the log and even-sample median differs.
- Russian investor-behavior evidence makes the local retail-attention mechanism worth studying; it does not validate the search proxy.
- M1/M4’s lagged volume and the pooled model’s firm/time fixed effects are recognizably within the broader empirical toolkit. A separate liquidity outcome is not automatically required by the stated question.

### Where does it diverge or need disclosure?

- The even-window median transformation is not exactly the original Da formula.
- M2 is one-week, raw-return prediction; it does not estimate a complete price-pressure/reversal path or market-adjusted return.
- Search query choice and Wordstat issuer-level validity remain open measurement questions; a query count is not a count of unique investors.
- The sign of attention effects is heterogeneous across markets and horizons, especially for volatility.
- M2’s volume omission is a minor estimand choice; explain it or test a lagged-volume sensitivity rather than adding a new liquidity outcome by default.

## References actually used

Source tiers: **Tier A** = peer-reviewed article, relevant full text read; **Tier B** = peer-reviewed publisher page/abstract or bibliographic record, abstract only; **Tier C** = local collected PDF/partial extract; reading scope is stated. RePEc/IDEAS is a bibliographic/abstract source, not the journal publisher; the cited journal is named separately.

1. **Da, Zhi, Joseph Engelberg & Pengjie Gao (2011).** “In Search of Attention.” *The Journal of Finance* 66(5), 1461–1499. [DOI](https://doi.org/10.1111/j.1540-6261.2011.01679.x); [full PDF](https://academicweb.nd.edu/~zda/Google.pdf). **Tier A:** full paper, including ASVI definition and price-pressure discussion.
2. **Düz Tan, Selin & Oktay Taş (2019).** “Investor attention and stock returns: Evidence from Borsa Istanbul.” *Borsa Istanbul Review* 19(2), 106–116. [DOI](https://doi.org/10.1016/j.bir.2018.10.003). **Tier A:** open-access full-text chunks covering sample/design and findings; the full control list is not reproduced here.
3. **Yoshinaga & Rocco (2020).** “Investor Attention: Can Google Search Volumes Predict Stock Returns?” *Brazilian Business Review* 17(5), 523–539. [DOI](https://doi.org/10.15728/bbr.2020.17.5.3); [article](https://www.redalyc.org/journal/1230/123064464003/html/). **Tier A:** data, method, and results sections read.
4. **Bui, Vinh Xuan & Hang Thu Nguyen (2019).** “Stock market activity and Google Trends: the case of a developing economy.” *Journal of Economics and Development* 21(2), 191–212. [DOI](https://doi.org/10.1108/JED-07-2019-0017); [publisher article](https://www.emerald.com/jed/article/21/2/191/206745/Stock-market-activity-and-Google-Trends-the-case). **Tier A:** publisher full text, including methods and results.
5. **Swamy, Vighneswara, M. Dharani & Fumiko Takeda (2019).** “Investor attention and Google Search Volume Index: Evidence from an emerging market using quantile regression analysis.” *Research in International Business and Finance* 50, 1–17. [DOI](https://doi.org/10.1016/j.ribaf.2019.04.010). **Tier A:** full 17-page local article and publisher abstract.
6. **Yang, Dan, Tingyu Ma, Yuetang Wang & Guojun Wang (2021).** “Does Investor Attention Affect Stock Trading and Returns? Evidence from Publicly Listed Firms in China.” *Journal of Behavioral Finance* 22(4), 368–381. [DOI](https://doi.org/10.1080/15427560.2020.1785469); [RePEc record](https://ideas.repec.org/a/taf/hbhfxx/v22y2021i4p368-381.html). **Tier B:** peer-reviewed citation and abstract verified; publisher full text restricted.
7. **Iyke & Ho (2021).** “Investor attention on COVID-19 and African stock returns.” *MethodsX* 8, 101195. [DOI](https://doi.org/10.1016/j.mex.2020.101195); [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC8374205/). **Tier A:** methods and results in the full text read; country-index rather than firm-level evidence.
8. **Kropiński, Paweł & Marcin Anholcer (2022).** “How Google Trends can improve market predictions—the case of the Warsaw Stock Exchange.” *Economics and Business Review* 8(2), 7–28. [DOI](https://doi.org/10.18559/ebr.2022.2.2); [publisher page](https://journals.ue.poznan.pl/ebr/article/view/455). **Tier B:** publisher abstract and citation read; full article not read.
9. **Teplova & Gurov (online 2022; issue 2025).** “Nonlinear intraday trading invariance in the Russian stock market.” *Annals of Operations Research* 352, 441–469. [DOI](https://doi.org/10.1007/s10479-022-04683-7). **Tier B:** Springer abstract read; full paper not read. The abstract supports only the Russian stock-search/trading-activity overlap described above.
10. **Fayzulin, M. S. (2025).** “Search attention and opinion divergence in explaining retail investor behavior.” *Lomonosov Economics Journal* 60(5), 3–41. [DOI](https://doi.org/10.55959/MSU0130-0105-6-60-5-1); [journal page](https://msuecon.elpub.ru/jour/article/view/1289/665). **Tier B:** publisher metadata and abstract read; linked PDF viewer did not provide readable full text.
11. **Stolbov & Shchepeleva (2025).** “A sentiment-based financial stress index for Russia.” *Borsa Istanbul Review* 25(2), 350–359. [DOI](https://doi.org/10.1016/j.bir.2025.01.007). **Tier B:** publisher abstract and opening page read; used only to establish macro-level Wordstat application.
12. **Djalilov, Abdulaziz & Numan Ülkü (2021).** “Individual investors’ trading behavior in Moscow Exchange and the COVID-19 crisis.” *Journal of Behavioral and Experimental Finance* 31, 100549. [DOI](https://doi.org/10.1016/j.jbef.2021.100549). **Tier C:** collected article PDF; abstract/opening material read. Used only for Russian retail-investor context.
13. **Vlastakis, Nikolaos & Raphael N. Markellos (2012).** “Information demand and stock market volatility.” *Journal of Banking & Finance* 36, 1808–1821. [DOI](https://doi.org/10.1016/j.jbankfin.2012.02.007). **Tier C:** a three-page local extract; title, abstract, and opening sections read. Used only for the point that market and firm-level information demand can be distinguished and market return can be controlled.
