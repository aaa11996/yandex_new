# Final Results & Defense Pack — MOEX × Wordstat H1–H6 / M1–M6

**Execution freeze:** 3 October 2026. **Primary panel:** `combined_panel.zip`; controls/literature: `yandex_final.zip`. **Primary inference:** 74 firms (ROLO excluded under the documented one-kopeck-grid rule); the full 75-firm panel remains available for QA and sensitivity. The project was rerun after the M3 classical-F/Holm reconciliation and the H3-power/pooled-export additions. Machine-readable outputs are in `analysis/results/`.

> **Honesty-gate status: PASS 10/10.** The independent Stage 2 judge also scored 10/10, but **for panel integrity only**, not model results. The separate results-honesty gate and its scope are in `analysis/results/JUDGE_10_OF_10_HONESTY_GATE.md`. H6 remains provisional; weekly News-conditioned models are not estimable from the supplied files.

---

## 1. Literature Alignment Memo

### What the supplied literature supports—and what it does not

| Source | Relevant result/design in the supplied text | Alignment to this study | Boundary on interpretation |
|---|---|---|---|
| **Da, Engelberg & Gao (2011), “In Search of Attention,” *Journal of Finance* 66(5), 1461–1499** (`Paul Gao Paper.pdf`) | Develops abnormal search volume from the log search index relative to the prior eight-week median and studies subsequent returns and attention-related price pressure/reversal in U.S. equities. The paper’s eight-lag/Newey–West choice belongs to its own Fama–MacBeth design. | Motivates the supplied ASVI construction and testing ASVI one week ahead for RV and returns. | It does not prescribe a universal sign, an eight-lag bandwidth for every weekly firm regression, or a benchmark coefficient for Russian Wordstat queries. H1’s predominantly negative firm-level slopes and H2’s inconclusive return estimates are not forced toward the U.S. result. |
| **Vlastakis & Markellos (2012), “Information demand and stock market volatility,” *Journal of Banking & Finance* 36, 1808–1821** (`information-demand-and-stock-market-volatility-3f9rke46sb.pdf`) | Relates information demand/search activity to volatility and trading, with market-wide and firm-level results that are not uniform. The paper distinguishes information demand from information supply. | Provides direct motivation for ASVI→RV and for allowing heterogeneous firm responses. | A weekly News matrix is absent here, so the present analysis cannot reproduce their information-supply controls. Our lagged firm-specific ASVI coefficient is not a direct replication of their full information-demand/supply design. |
| **Swamy, Dharani & Takeda (2019), “Investor attention and Google Search Volume Index: Evidence from an emerging market using quantile regression analysis,” *Research in International Business and Finance* 50, 1–17, DOI 10.1016/j.ribaf.2019.04.010** (`GSVI_India.pdf`) | Reports positive first-/second-week return relationships in Indian large-cap firms using Google search data and quantile-regression methods. | Shows that attention-return associations can appear in an emerging-market sample and can vary with the conditional return distribution. | It differs in country, search platform, return construction, estimator, and horizon. The current H2 is one-week-ahead firm-level OLS with HAC; three nominal findings and zero BH survivors are **inconclusive**, not evidence of no return response. |
| **Djalilov & Ülkü (2021), “Individual investors’ trading behavior in Moscow Exchange and the COVID-19 crisis,” *Journal of Behavioral and Experimental Finance* 31, 100549** (`Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis.pdf`) | Uses weekly MOEX data and selects VAR(3) by AIC for aggregate investor-trading outcomes. | Establishes that weekly MOEX dynamics and empirical lag selection have precedent. | Their dependent variable is aggregate trading behavior, not ticker-level search attention. VAR(3) is an AIC precedent, not a mandate for this Granger test; the present L∈{1,2,4} set is reported in full, with AIC/BIC diagnostics. |
| **Newey & West (1987)** (`A SIMPLE, POSITIVE SEMI-DEFINITE,.pdf`) | Supplies the HAC covariance foundation. | Supports robust inference for per-firm regressions and the HAC-Wald sensitivity. | Bandwidth remains design-specific. The eight-lag value in Da et al. is not treated as a universal rule; HAC4 is primary for M1/M2 and HAC8 is disclosed as sensitivity. |
| **Giles & Lieberman, “Bounds on the Effect of Heteroscedasticity on the Chow Test for Structural Change”** (`canterbury-nz-034.pdf`, Table A3, p.19) | Provides classical critical bounds used by the legacy method draft. | Relevant to the archived M5 design and recorded in the methodology amendment register. | Those classical bounds are not applied to the current full-controls HAC-Wald statistic; the legacy draft also documents a q=3/k=4 row mismatch. The current M5 reports HAC-based p-values, not a borrowed threshold or a forced legacy survivor count. |

### Alignment conclusion

The literature supports attention as a plausible proxy for information demand and motivates testing volatility, returns, and heterogeneous responses. It does **not** imply that every firm’s coefficient must be positive, nor that Russian Wordstat results should match Google-based U.S. or Indian estimates. The current evidence is compatible with a heterogeneous attention–volatility relationship, while the return and ownership results are not conclusive. The missing News matrix prevents a direct information-supply-adjusted comparison with Vlastakis and Markellos. Andrews (1991) was not located in the supplied corpus and is not cited as an independently checked source.

---

## 2. H1–H6 Results (with M1–M6)

### Sample and panel audit

The merged panel has **31,425 rows, 75 tickers, 419 Monday keys**. `SEARCH_MONDAY` is the master key and equals the MOEX Sunday week-end minus six days. The 328 no-trade ticker-weeks remain missing, including the three full-market closures (2022-02-28, 2022-03-07, 2022-03-14). There are seven weekly H==L bars (RV is missing, never zero), four corporate-action flags (retained in RV, returns set missing), and no ghost lag carry. The final partial week remains in the primary grid and is dropped in a dedicated sensitivity. The 74-firm primary rule excludes ROLO because its one-kopeck grid mechanically quantizes RV; all-75 results are reported separately.

The supplied Stage 2 audit reports **APPROVED—RELEASE, 10/10 for panel integrity**. In firm-level equations, `Sanction_l1` is constant in 50 firms and `Div_l1` in 13, so those nuisance terms are recorded as unidentifiable/dropped within those equations; all 74 target ASVI slopes are identified. The independent numerical checks reproduce the complete-data NW covariance and the conventional M3 F-test against `statsmodels` to numerical precision; TWFE point coefficients match `linearmodels.PanelOLS` to numerical precision. Calendar-gap-aware standard errors differ modestly from compressed-date implementations by design.

### Summary table

| Hypothesis/model | Primary result | Interpretation |
|---|---|---|
| **H1 / M1: ASVI→RV** | 74 HAC4 regressions; n=277–406 (median 405); 12 nominal p<.05; **5 BH survivors**. Median β=−0.00404. | Firm-level evidence is mixed in sign, with four negative and one positive BH survivor. The 62 nominal-null firms all have descriptive observed-effect power <.80; those nulls are inconclusive. HAC8 adds AFKS to the BH set. |
| **H2 / M2: ASVI→R** | 74 HAC4 regressions; n=276–405 (median 404); 3 nominal p<.05; **0 BH survivors**. Median β=−0.00272. | No multiplicity-adjusted return effect is established. All 71 nominal-null firms have observed-effect power <.80; this is inconclusive, not “no effect.” |
| **M3: Granger tests** | 444 conventional nested OLS F-tests: 222 per outcome. H1/RV: 27 nominal, 6 BH, **4 Holm**. H2/R: 11 nominal, 0 BH, 0 Holm. | H1 robust predictive content remains for a small set of firm–lag combinations; there is no multiplicity-adjusted H2 finding. HAC-Wald results are retained as a separate sensitivity. |
| **H3 / M5: 2022 break** | 26/74 nominal omnibus breaks; 2/74 nominal ASVI-slope shifts; 23 post-level shifts; 6 RV-persistence shifts. | The omnibus test is not an ASVI-slope test. Neither of the two slope p-values is multiplicity-adjusted. In ≥4-firm sectors, no pooled ASVI-slope break is significant. |
| **M4: pooled baseline TWFE** | 29,642 observations; 74 firms; 419 weeks; within R²=.1331. ASVI β=.001014, SE=.001833, p=.5803, MDE80=.005132. | The pooled baseline ASVI slope is not distinguishable from zero at conventional levels; MDE shows the resolution of the design. |
| **H4: ASVI×Sector** | Calendar-gap-aware DK4 joint Wald-F(12,418)=1.9575, p=.02668; equal-interaction MDE80=.01474. | Nominal all-sector heterogeneity is **fragile**: it disappears in thin/singleton-sector checks and changes under the disputed YAKG label. Do not call it robust general sector heterogeneity. |
| **H5: ASVI×Div_l1** | β=.007527, SE=.004534, p=.09763, MDE80=.01269. | No 5% evidence of dividend-window moderation. The lagged window overlaps the record week whenever the previous market week is observed, so this is not a pure anticipation effect. |
| **H6: ASVI×SOE** | Base β=.006575, SE=.004967, p=.18624; Sector×Week β=.006731, SE=.005137, p=.19080. | Not significant; MDE80=.01391/.01438. **PROVISIONAL** because the required 34/41 SOE comparison/reconciliation is missing. |
| **M6: circular-block permutation** | 1,000 L=4 draws per firm; 10 raw empirical p<.05; median empirical p=.33916. | Exploratory, raw/unadjusted evidence only; no BH. The L=8 sensitivity has 12 raw p<.05. |

### H1 and H2 firm-level results

**H1/M1 BH survivors (HAC4):**

| Ticker | β(ASVI_l1) | HAC4 SE | p | BH q |
|---|---:|---:|---:|---:|
| LSRG | −0.021268 | 0.006571 | 0.001309 | 0.019378 |
| MFGS | +0.046297 | 0.012602 | 0.000272 | 0.010051 |
| PHOR | −0.016384 | 0.004694 | 0.000536 | 0.013211 |
| RTKM | −0.039908 | 0.007216 | 5.79×10⁻⁸ | 4.28×10⁻⁶ |
| SNGS | −0.033895 | 0.010456 | 0.001288 | 0.019378 |

AFKS is nominal at HAC4 (β=−.016483, p=.00519, q=.06396) and becomes a BH survivor under the pre-defined HAC8 sensitivity. The five primary BH results are therefore not a sign-homogeneous effect.

**H2/M2 nominal p<.05 (none survives BH; q=.78457 for each):** GCHE β=+.012371 (p=.01559); FEES β=−.029034 (p=.02897); PLZL β=+.023924 (p=.04267). Median MDE80 among H2 nominal-null tests is .02474; among H1 nominal-null tests it is .02426. The size of those MDEs relative to typical fitted coefficients is why the non-significant results are described as inconclusive.

### M3 Granger findings and Holm reconciliation

The archived `methodology_final.md` v2.0 §4 calls for per-company Granger F-tests, BH within the H1/RV and H2/return blocks, and a Bonferroni–Holm check alongside; the earlier current-panel export omitted Holm and used only HAC-Wald inference. This has been resolved in the rerun: the **conventional nested OLS F is primary**, both BH and Holm are applied separately within each 222-test outcome block, and calendar-gap-aware HAC-Wald F is a separately labelled sensitivity. A classical-F cross-check against `statsmodels` differs by 1.8×10⁻¹⁵.

- **Primary conventional F, H1/RV:** 27 nominal tests; 6 BH survivors (JNOS L1, MFGS L1/L2/L4, RTKM L1/L2); **4 Holm survivors** (MFGS L1/L2/L4 and RTKM L1).
- **Primary conventional F, H2/returns:** 11 nominal tests; no BH or Holm survivors.
- **HAC-Wald sensitivity:** H1 has 29 nominal tests, 7 BH and 4 Holm survivors; H2 has 11 nominal and no corrected survivors.
- Secondary BH within `(block,L)` is reported in the CSV; it is not substituted for block-level correction. AIC chooses H1 lags 1/2/4 for 32/20/22 firms and H2 lags 1/2/4 for 57/14/3 firms; BIC selects H1 lags 1/2/4 for 65/8/1 and H2 lag 1 for all 74. These are diagnostics, not significance selection.

### H3/M5 break results

The post regime starts Monday **2022-02-21**, placing the week containing the 24 February invasion in the post period. The three-restriction HAC-Chow-type Wald-F is nominally significant for **26/74 firms**, but the focal ASVI-slope shift is nominally significant for only:

| Ticker | ASVI slope shift | p (HAC4) | MDE80 | Descriptive power at observed shift |
|---|---:|---:|---:|---:|
| IRKT | +0.04552 | .020995 | .05500 | .637 |
| OGKB | +0.03049 | .004970 | .03022 | .805 |

There is no multiple-testing correction across the 74 slope tests. The focal-slope null-test set has median MDE80=.04382; all 72 non-significant slope tests have descriptive power below .80. Of the eight pooled sectors with at least four firms, none has a significant ASVI post-slope change (small sectors are explicitly `insufficient_n`). Separately, there are 23 nominal post-level shifts and six nominal RV-persistence shifts; these tests can overlap with omnibus rejections and should not be paraphrased as 26 ASVI-slope breaks. The reported M5 statistic is the full-controls HAC-robust Wald-F. Legacy Giles–Lieberman cutoffs are not applied: they refer to a different classical Chow statistic/specification, and the archived method notes a q=3/k=4 mismatch. No GL survivor count or forced benchmark match is claimed.

### M4 and H4 sector detail

M4’s identified VIFs are low (ASVI 1.30; RV_l1 1.54; lnV 1.35; Div_l1 1.01; Sanction_l1 1.00). Crisis_l1 is absorbed by week FE; News is absent; SOE main effect is absorbed by firm FE.

The H4 interaction **joint** test is nominally significant in the all-sector map, but the individual sector slopes below are unadjusted; only Industrial is individually nominally significant, and Industrial is a single-firm KMAZ cell. A slope table is included in `analysis/results/H4_sector_slopes.csv`.

| Sector | Firms | Total ASVI slope | Unadjusted p | Note |
|---|---:|---:|---:|---|
| Banking | 6 | −.001784 | .6335 | Reference-sector total slope |
| Chemicals | 5 | −.001849 | .5855 |  |
| Consumer & Retail | 4 | −.003158 | .4333 |  |
| Diversified | 2 | −.005233 | .4480 | Thin sector |
| Energy | 12 | +.013675 | .0698 |  |
| Industrial | 1 | −.020199 | .0021 | Single ticker, KMAZ; not sector-general |
| Insurance | 1 | +.007319 | .4861 | Single ticker, RGSS |
| Metals & Mining | 14 | −.000328 | .9012 |  |
| Real Estate | 3 | −.005113 | .1310 | Thin sector |
| Tech | 3 | +.010966 | .2555 | Thin sector |
| Telecom | 4 | −.002288 | .6377 |  |
| Transportation | 4 | +.004827 | .3135 |  |
| Utilities | 15 | −.002075 | .3294 |  |

**Pre-specified H4/H5 sensitivity results:**

- Include ROLO (75 firms): H4 p=.02408; H5 p=.09903; H6 base p=.19505.
- Exclude the final partial week: H4 p=.02764; H5 p=.09891; H6 base p=.17850.
- Exclude the two singleton sectors (72 firms): H4 F(10,418)=1.0531, p=.39782.
- Restrict to sectors with at least four firms (64 firms): H4 F(7,418)=.9696, p=.45294.
- Reclassify YAKG from primary-panel Utilities to Energy: H4 p=.00899; Energy slope +.01425 (p=.03562), Utilities slope −.00368 (p=.03917). This label conflict therefore materially changes the nominal result.
- H5 excluding 11 documented overlap candidates (63 firms): β=.009065, p=.05911; H4 in that subsample p=.06863. This does not cross .05. Contemporaneous-Div interaction: β=−.001880, p=.49149.
- Move the LKOH/ROSN sanction anchors one week earlier to 2025-10-13: H1/H2 BH sets remain unchanged; LKOH β moves −.001041→−.000967, ROSN −.005752→−.005693, H4 p .02668→.02675, H5 p .09763→.09761, and H6 base p .18624→.18604. The shipped 2025-10-20 matrix remains primary.

### H5/H6 and M6 interpretation

H5’s primary interaction is positive but not significant at 5%; the 80%-power MDE (.01269) exceeds its fitted estimate. The audit finds 529 record-week cells, 2,108 valid `Div_l1` cells, and 528 overlaps; AKRN 2022-03-07 has no lag after the suspension. Therefore, H5 is a lagged-window moderation check, not a clean anticipation estimate.

H6’s positive point estimate is not significant with or without Sector×Week FE; the interaction MDEs (.01391 and .01438) exceed the fitted coefficients. The Sector×Week model explicitly absorbs ASVI×Industrial and ASVI×Insurance because each has one company. More importantly, the 34/41 comparison file required by the archived C6 rule is missing: **do not make a final SOE claim**.

M6’s ten raw 4-week-block empirical p<.05 tickers are AFKS, JNOS, LSRG, MFGS, NLMK, PHOR, RTKM, SNGS, VSMO, and YNDX (median p=.33916). The eight-week sensitivity has 12 raw p<.05: AFKS, GAZP, JNOS, LSRG, MAGN, MFGS, NLMK, PHOR, RTKM, SNGS, VSMO, and YNDX (median p=.33866). Each zero-exceedance result is p=1/1,001≈.000999, not zero. These are exploratory, unadjusted permutation findings, not multiplicity-adjusted confirmations.

### Results-facing limitations

- No weekly News matrix: News-conditioned models and event-window sensitivities are not estimable and have not been reconstructed.
- H6 provisional under missing SOE reconciliation.
- H4 nominal joint rejection is fragile to thin sectors and the YAKG mapping.
- H3 p-values are nominal; per-firm family corrections are not claimed.
- H5’s lagged dividend indicator overlaps the record week, limiting an anticipation interpretation.
- M6 is raw/unadjusted and block-length-sensitive.
- Non-significant estimates with inadequate power are described as inconclusive.

---

## 3. Exact Methodology Replacement Blocks

The following are the **verbatim, paste-ready replacement texts**. The same blocks are also supplied as `METHODOLOGY_REPLACEMENT_BLOCKS.md`; the integrated controlling chapter is `FINAL_COMPLETE_METHODOLOGY.md`.

## Block 1 — Data provenance, time key, and calendar

> The primary analysis uses the validated 75-firm weekly panel in `combined_panel.zip`, built from daily MOEX observations and firm-level Yandex Wordstat series. The master key is `SEARCH_MONDAY`. A Wordstat Monday is matched to the MOEX week ending Sunday six calendar days later: `Wordstat Monday = MOEX_WEEK_END_SUNDAY − 6 days`. Each observation is a Monday–Sunday calendar week, and all valid MOEX sessions in that interval, including Saturday sessions, are retained. The price and control matrices are joined on `(TICKER, SEARCH_MONDAY)`; the control files’ `week_sunday` field is not used as a join key. The analysis grid contains 419 Mondays from 27 August 2018 through 31 August 2026 (31,425 ticker-weeks before the documented inference exclusion). The last grid week, 31 August–6 September 2026, is flagged as partial because the source bars end before Sunday; it is retained in the primary specification and excluded in a reported sensitivity.

## Block 2 — Missing price data, suspensions, and lag construction

> Missing observations are kept missing. The 328 ticker-weeks with no trading days, including the full-market suspension weeks of 28 February, 7 March, and 14 March 2022, are not imputed or removed from the Monday calendar. Trading resumed for only part of the cross-section in the week of 21 March 2022; this is not treated as a fourth full-market closure. All lagged variables are constructed on the original weekly calendar: a lag at week *t* is the value at the immediately preceding Monday-grid week, and it is set to missing when that preceding source week has no trading observation. No value is carried across a gap, and the time axis is never compressed before constructing a lag.

## Block 3 — Volatility, returns, H==L, and corporate actions

> Range volatility is `RV(i,t) = ln[HIGH(i,t)/LOW(i,t)]`. A week with `HIGH == LOW` contains no usable range information and is coded missing, not zero. The validated weekly panel has seven such ticker-weeks; a separate source-level daily audit has 650 daily H==L observations, which are not weekly observations and must not be reported as approximately 657 weeks. The return outcome is the gap-safe `RETURN_SAFE`; returns are not computed across a missing prior market week. The four flagged corporate-action weeks are retained for RV because the log high/low ratio is scale-invariant, but the return outcome is set to missing on those rows because raw-price returns are not scale-invariant to the actions. No raw price adjustment or imputation is performed.

## Block 4 — Search index and primary inferential sample

> The weekly search measure is the sum of the supplied Latin- and Cyrillic-channel raw counts before logarithms. Zero-count search observations remain missing for logarithmic construction; no pseudocount is added. Abnormal search volume is defined as `ASVI(i,t) = ln(SVI_RAW(i,t)) − median{ln(SVI_RAW(i,t−1)), …, ln(SVI_RAW(i,t−8))}` and is missing unless the current count and all eight preceding weekly counts are valid. The full validated universe contains 75 firms. ROLO is excluded from all primary inference involving RV because its one-kopeck price grid mechanically quantizes the high–low range; it remains in the full panel and is restored in an all-75-firm sensitivity. The primary inferential sample is therefore 74 firms, consistent with the documented v2.0 rule. No other ticker is removed solely because of its estimated result.

## Block 5 — Per-firm H1/M1 and H2/M2 equations and correction

> For each of the 74 primary firms, H1/M1 estimates `RV(i,t) = α_i + β_A ASVI_l1(i,t) + β_RV RV_l1(i,t) + β_V lnV_l1(i,t) + β_C Crisis_l1(t) + β_S Sanction_l1(i,t) + β_D Div_l1(i,t) + ε(i,t)`. H2/M2 replaces the dependent variable with gap-safe return `R(i,t)` and includes `R_l1` as its own-lag control. Both are estimated by OLS with Bartlett Newey–West HAC covariance, fixed bandwidth four weekly lags, using the full Monday calendar so missing weeks do not compress HAC lag distance. Apply Benjamini–Hochberg correction separately to the 74 H1 ASVI tests and the 74 H2 ASVI tests. If a nuisance control is constant within a firm, mark that coefficient unidentifiable and record its omission; do not silently change the target ASVI specification. Non-significant findings are reported as inconclusive when their MDE/power indicates inadequate sensitivity, not as evidence of no effect.

## Block 6 — M3 Granger tests and lag families

> For each firm and each lag depth `L ∈ {1,2,4}`, the M3 test compares a restricted own-lag/control equation to an unrestricted equation that adds `ASVI_l1` through `ASVI_lL`, using a common L=4 complete-case sample for lag-depth comparability. The null is that all included ASVI-lag coefficients are jointly zero. The primary statistic is the conventional nested-model OLS F-test specified by methodology v2.0. The 222 RV tests and 222 return tests form separate multiplicity families; apply both Benjamini–Hochberg and Bonferroni–Holm within H1/RV and within H2/returns, never across the two outcomes. Retain the calendar-gap-aware HAC-Wald F result as a separately labelled and separately corrected robustness sensitivity. A secondary BH summary within each outcome-by-lag-depth family and AIC/BIC-selected lag counts are reported as diagnostics, not as post hoc routes to significance.

## Block 7 — Pooled M4 two-way fixed effects

> The pooled baseline is `RV(i,t) = β_A ASVI_l1(i,t) + β_RV RV_l1(i,t) + β_V lnV_l1(i,t) + β_D Div_l1(i,t) + β_S Sanction_l1(i,t) + α_i + λ_t + ε(i,t)`, where `α_i` and `λ_t` are firm and Monday-week fixed effects. The market-wide Crisis control is absorbed by week fixed effects and is not separately identified in this model; News is not estimated because the required weekly News matrix is absent. Inference uses calendar-gap-aware Driscoll–Kraay/Bartlett covariance with bandwidth four, retaining the Monday grid when an observation is absent. Report the number of observations, firms, weeks, within R-squared, and an MDE80 for a non-significant ASVI estimate.

## Block 8 — H4/H5/H6 nested interactions

> H4 adds every `ASVI_l1 × Sector` interaction to M4, using Banking as the reference sector, and tests the 12 interactions jointly with a Wald-F test. Report the implied ASVI slope and MDE80 for each sector. Industrial and Insurance each contain one firm, so their coefficients are company-specific and not sector-general; report both the singleton-excluded and the sectors-with-at-least-four-firms sensitivities. H5 is the complete H4 specification plus `ASVI_l1 × Div_l1`; H6 is the complete H4 specification plus `ASVI_l1 × SOE`. H5 and H6 must retain all H4 sector interactions. The static SOE main effect is absorbed by firm fixed effects. H6’s sector-time confound check replaces week fixed effects with Sector×Week fixed effects while retaining firm fixed effects; explicitly identify any sector interactions absorbed by that specification. H6 remains provisional until the required firm-level SOE reconciliation is supplied.

## Block 9 — Dividend timing and independent controls

> Crisis, Sanction, and Div are independent supplied control matrices and are not forced to be mutually exclusive. Their observed company-week overlaps are Crisis∩Sanction = 204, Crisis∩Div = 85, and Sanction∩Div = 217; the Crisis–Sanction overlap is retained because sanction onsets for VTBR and NMTP coincide with the invasion crisis period. Dividend `Div_l1` is computed from the preceding calendar week only and is masked after a no-trade week. The audit identifies 529 current RecordWeek cells, 2,108 valid lagged-Div cells, and 528 overlaps; AKRN’s RecordWeek of 7 March 2022 has no lag because the prior week was suspended. Consequently, the lagged-dividend interaction is not described as a pure pre-record-date anticipation effect. A contemporaneous-Div interaction is reported separately as a timing sensitivity.

## Block 10 — H3/M5 invasion break and robust inference

> Define `Post_t = 1` beginning 21 February 2022, so the calendar week containing the 24 February invasion belongs to the post regime. For each firm, estimate the full-controls range-volatility regression with `Post`, `ASVI_l1×Post`, and `RV_l1×Post`. The primary M5 break test is the HAC-robust Chow-type Wald-F test of the three restrictions that the post-level, ASVI-slope, and RV-persistence shifts are jointly zero. Report the ASVI-slope-shift test separately: an omnibus break does not establish a change in the ASVI slope. Per-firm p-values are unadjusted across firms and must be described as nominal. For pooled sector ASVI-slope-break models, sectors with fewer than four firms are reported as insufficient-N.

## Block 11 — M5 legacy critical values

> The Giles–Lieberman Table A3 bounds in the legacy method (5.206, 3.372, and 18.127) are retained for documentation but are not applied to the current HAC-Wald statistic. The bounds correspond to a classical Chow statistic and a different regressor/testing specification; the legacy method also documented a q=3 versus k=4 mismatch. A robust Wald statistic and those classical bounds are not interchangeable. The present run therefore reports HAC-based p-values and does not claim a GL-based survivor count. Any future classical GL replication must be run as a separately labelled specification with all relevant tabulated-row alternatives reported.

## Block 12 — M6 circular-block permutation

> M6 refits the M1 equation after permuting the full 419-week `ASVI_l1` series within each firm. For each firm, perform 1,000 circular block permutations using primary block length four weeks; choose a circular partition offset, partition the series into contiguous non-overlapping blocks (with one final short block if required), and permute the blocks without replacement. Preserve each block’s within-block order, all values, and the missingness pattern; keep the dependent variable and other regressors fixed. Use a stable ticker-specific seed derived from the global seed. The two-sided empirical p-value is `(exceedances + 1)/(valid draws + 1)`. Report the eight-week block-length sensitivity separately. M6 p-values are raw and are not BH-adjusted.

## Block 13 — Power, MDE, multiplicity, and interpretation

> Report an 80%-power minimum detectable effect for every non-significant scalar coefficient or test where a scalar contrast is meaningful. For M3, report an equal-shift MDE for the joint ASVI-lag restriction. A single scalar MDE is not defined for M5’s three-restriction omnibus test because its restrictions mix level and slope units; report the ASVI-slope-shift MDE instead. Observed-effect power is descriptive only and is not a basis for claiming no effect. Apply BH only to the pre-defined H1 and H2 coefficient families; apply both BH and Holm to the separate M3 outcome families, with the by-lag BH secondary family stated explicitly. Do not apply an unreported correction to H3–H6 or M6; label their multiple unadjusted tests clearly. If a model is rank deficient, collinear, or unidentified, report the status and affected terms rather than silently dropping the target term.

## Block 14 — Source limitations and sensitivity reporting

> No weekly News matrix is available; News-adjusted models and event-window checks are not estimable and are not replaced with reconstructed values. H6 uses the 35/40 SOE map in `Combined_Data_File.md` but is provisional because the required 34/41 comparison file is missing. The primary sector map follows the primary archive folder labels; the YAKG Utilities-versus-Energy conflict is reported as a sensitivity. The supplied Sanction matrix is primary; the earlier LKOH/ROSN anchor week is reported as a sensitivity. The final partial week, all-75-firm sample, thin/singleton sector composition, H5 overlap-candidate exclusion, contemporaneous Div, and M6 block length are all reported transparently. Results from older Investing.com weekly files are not substituted for the current MOEX-daily-aggregated panel.

---

## 4. Thesis-Defense Talking Points

### Short opening statement

> I test whether firm-specific abnormal Yandex Wordstat search activity predicts next-week MOEX range volatility or returns in a gap-preserving weekly panel. The main inferential sample is 74 firms because ROLO’s one-kopeck price grid mechanically quantizes the range; the validated 75-firm panel and an all-75 sensitivity are retained. The strongest adjusted evidence is heterogeneous firm-level ASVI–volatility association, not a universal direction. The pooled sector result is fragile; return, dividend-moderation, and ownership conclusions are inconclusive or provisional. I preserve missing weeks, use separate multiplicity families, report MDEs, and do not force-match prior results.

### Core points to defend

1. **What does ASVI measure?** It is the current log Wordstat count above the firm’s own prior-eight-week log median. It is a proxy for attention/information demand—not a direct measure of investor intention or a randomized treatment.
2. **Why this date alignment?** `SEARCH_MONDAY` is the master key; Wordstat Monday equals MOEX Sunday minus six days. The Mon–Sun bin includes Saturdays and is verified row by row.
3. **How were suspensions handled?** The 328 no-trade ticker-weeks remain missing; the three full-market March 2022 suspension weeks are retained in the calendar, and no lag crosses a missing prior week.
4. **Why separate RV from returns around corporate actions?** The log high/low ratio is scale-invariant to a multiplicative split/consolidation, so the four flagged rows remain for RV. Raw-price returns are not scale-invariant, so their four return outcomes are missing.
5. **Why exclude ROLO from the primary estimates?** Its one-kopeck grid mechanically quantizes the range. This follows the archived exclusion rule for all RV-bearing inference; the full panel is retained and all-75 estimates are reported as sensitivity.
6. **What is the H1 conclusion?** Five firms survive H1 BH correction, with four negative coefficients and one positive. That is heterogeneous company-level evidence, not a single market-wide sign. HAC8 adds AFKS, which is disclosed rather than hidden.
7. **Does H2 show no return effect?** No. Three tests are nominal, none survives BH, and the nominal-null models have observed-effect power below 80%. The honest conclusion is “no multiplicity-adjusted evidence; underpowered nulls remain inconclusive.”
8. **What is the strongest M3 claim?** Under the repository-specified classical Granger F, six H1 tests survive BH and four survive Holm; none survive in H2. These are firm–lag predictive tests, not structural causal effects. The HAC-Wald version is a separately reported sensitivity.
9. **Do 26 M5 omnibus rejections mean 26 ASVI structural breaks?** No. They jointly test post-level, ASVI-slope, and RV-persistence changes. Only two ASVI-slope tests are nominally significant, with no cross-firm correction; eligible-sector pooled tests are not significant.
10. **Does H4 establish sector heterogeneity?** Not robustly. The all-sector joint p=.0267, but the test is p=.453 among sectors with at least four firms and p=.398 after removing singleton sectors; the YAKG label changes the result. The individual significant Industrial slope is one ticker (KMAZ), not evidence about an industry population.
11. **Can H5 be called dividend anticipation?** No. The lagged indicator overlaps record weeks when the previous market week is observed. H5 is a moderation check; its coefficient is positive but p=.0976, and candidate/timing sensitivities remain above .05.
12. **Can H6 support a state-ownership conclusion?** Not yet. The point estimates are positive but not significant, and the required alternative SOE classification/reconciliation is missing. The H6 result remains provisional.
13. **What does M6 add?** It tests whether M1’s t-statistic is unusual when ASVI is rearranged in serially ordered blocks. The 4-week result is raw and unadjusted; the 8-week sensitivity differs. This is exploratory corroboration, not a multiplicity-adjusted confirmatory test.
14. **Why not use the legacy GL cutoff for M5?** A classical critical bound for a different Chow statistic/model is not interchangeable with the current full-controls HAC-Wald statistic; the source also documents a restriction-count/table-row mismatch. I report the robust test transparently and do not threshold it against an incompatible value.
15. **What cannot be answered with these files?** Whether the ASVI results survive firm-level News/information-supply adjustment, because there is no weekly News matrix; and whether H6 survives the missing 34/41 SOE reconciliation. Neither gap is filled by reconstruction.

### Likely examiner questions and concise answers

- **“Why not claim the H4 p=.027 proves sector differences?”** Because the result fails the pre-specified thin-sector and singleton checks and changes under the contested YAKG mapping. I report it as fragile nominal evidence, not robust sector heterogeneity.
- **“Why call a non-significant coefficient inconclusive?”** The design’s MDE80 is often larger than the observed coefficient, and observed-effect power is below .80 for the nominal-null H1/H2 models. Failure to reject does not establish equivalence to zero.
- **“Why does H1 include negative slopes?”** Attention effects can differ by firm, horizon, liquidity, and information environment. The supplied literature motivates a relationship, not a universal sign; I report all coefficients and do not select a desired direction.
- **“Why use HAC4?”** It is fixed as the primary weekly bandwidth for the specified models, with HAC8 reported as a pre-defined sensitivity. The cited eight-lag precedent is from a different Fama–MacBeth setting.
- **“What does the panel-integrity 10/10 mean?”** It validates the panel construction and missingness/date rules. It is not an endorsement of the econometric specification or results; a separate results-honesty gate checks those aspects and preserves the limitations.

---

## Reproduction and supporting files

- Run the primary models and exports: `python analysis/econometric_run.py`.
- Run the stated sensitivity suite: `python analysis/run_sensitivities.py`.
- Re-run the honesty gate: `python analysis/judge_gate.py`.
- Full integrated methodology: `FINAL_COMPLETE_METHODOLOGY.md`.
- Paste-ready blocks: `METHODOLOGY_REPLACEMENT_BLOCKS.md`.
- Results and QA: `analysis/results/results_summary.json`, `data_QA_audit.json`, `pre_specified_sensitivities.json`, the CSV tables, and `JUDGE_10_OF_10_HONESTY_GATE.md`.
