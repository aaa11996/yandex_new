# THESIS HANDOFF BRIEF — for a successor AI with zero prior context

You are taking over mid-project from a previous Claude conversation that grew
too long. Everything below is what that assistant knew. Read sections 0-2 and
11 before doing anything. Do not assume anything not written here; when a
fact matters, verify it against the live files.

## 0. Confidence legend (used throughout)
- **[V]** verified directly by the previous assistant (opened/computed it)
- **[R]** reported by an agent run or document, not independently verified
- **[I]** the previous assistant's inference or judgment
- **[?]** unknown — ask the user or check the files

---

## 1. The person and the goal
- **Asif** (Khandaker Asikh Iqbal), Bangladeshi, 37, Master's student in
  Finance (Group 25 УФ, Year 1) at HSE University, Nizhny Novgorod. [V]
- Long-term goal: a fully funded Finance PhD in Europe (Germany / Nordics /
  Netherlands) targeting 2027, with HSE Moscow aspirantura as the backup. The
  thesis is his main research asset for that. He is over the 35-year age cap
  for the Open Doors doctoral track, so that track is closed to him. [V]
- He runs the project largely through **external autonomous agents** (see §12)
  and brings their outputs back to Claude for review.

## 2. The thesis in one paragraph
Tests whether **investor attention**, measured by Yandex Wordstat search
volume (an Abnormal Search Volume Index, ASVI, built as in Da, Engelberg & Gao
2011), predicts **weekly volatility and returns** of **75 MOEX-listed companies**,
2018-08-27 → 2026-08/09. Context: Russia post-2022 is sanctioned, capital-
restricted and retail-dominated; Google is effectively unavailable, so Yandex
Wordstat is the attention proxy (no prior academic use found). The original
prospectus framed two ideas: the **Retail Dominance Paradox** (despite retail
dominance, aggregate attention does not predict volatility because it is
swamped by synchronized geopolitical news) and the **Idiosyncratic Signal
Hypothesis** (attention carries signal only when tied to firm-specific
events). Original prospectus title: *"Does Online Search Predict Stock Market
Volatility? Evidence from Yandex Wordstat ASVI on 40 Russian MOEX Equities"*
(programme 38.04.08 Finance and Credit). The pilot had 15 companies and 10
keywords per company; the thesis replaced keywords with **ticker + Cyrillic
company name**.

## 3. People
- **Prof. Andrey Aistov** (HSE, econometrician). **Agreed by email to formally
  supervise the thesis.** He proposed the title *"Web Search Queries and
  Market Movements."* Asif proposed adding the subtitle *"Evidence from the
  Russian Equity Market."* Aistov replied that Asif's title is also acceptable
  and that the title can be corrected once the research trajectory or data
  change (the supervising office demands a title before research). [V] Which
  exact title was submitted to the office: [?]. Earlier (March 2026) he said he
  does not use Python, asked Asif for the main hypothesis, novelty, why weekly
  data and why only 15 companies, and said the Python script "looks too long,
  nevertheless AI has made a good job." Asif had disclosed AI-assisted coding
  to him. [V]
- **Yana Zotova** — programme coordinator; listed as "Academic Advisor" on the
  prospectus cover; helped with GOST formatting and PhD-path information.
  Asif describes her as useful but unreliable at times. A draft email asking
  her which other faculty could supervise (written before Aistov accepted) may
  or may not have been sent: [?].
- **Prof. Boryshneva** (sociology; supervised his separate conference paper,
  not the thesis). **Prof. Larin** (Python/data analysis).
- Conference: 2nd place, "Economic Policy: Regions and Industries," HSE student
  conference, April 22-23 2026; abstracts accepted for ISBN publication (status
  of publication: [?]). The finance paper was the 15-company pilot. [R]

## 4. Where things live, and what can be accessed
**Current repository:** `https://github.com/aaa11996/yandex_new` [V]
- `README.md` ("this is final place of thesis papers")
- `Combined_Data_File.md` — compiled control-variable data (~1,030 lines). The
  previous assistant read it fully. [V]
- `News_Div_Overlap_Addendum.md`
- `yandex final.zip` → folder `yan 2/`: `methodology_final.md` (**governing
  methodology**), `news.md`, `Sanctions Events, Crisis Windows & Data
  Readiness.md`, `Final dividend table.md`, `UNIFIED_PAPER_about_state_ownership.md`,
  `iqbal thesis data.zip` (raw per-company data), `thesis books.zip`
  (literature PDFs), `agent_prompt_dividend_dates_reexport.md` (an old prompt,
  not data). [V]
- `yandex_data.zip` — later agent outputs; contents not examined in detail. [?]
- Raw-file URL pattern: `https://github.com/aaa11996/yandex_new/raw/refs/heads/main/<url-encoded filename>`

**Older repository:** `https://github.com/aaa11996/yandex.data.` — superseded;
holds earlier reports and `iqbal thesis v2.zip` (the 75-company raw archive).
`pilot test 15 company.zip` is the **superseded 15-company pilot — never use it
for current work.**

**MOEX direct price fetch:** Asif ran a Python script (written by the previous
assistant, `fetch_moex_data.py`: MOEX ISS API, board TQBR, 76 tickers = 75 plus
both YNDX and YDEX, start 2018-01-01, end 2026-09-06), got daily data, made
weekly files, and uploaded them at `https://files.catbox.moe/y826ah.zip`. The
previous assistant could not open it (see below). An agent comparison report
exists (§8).

**Claude sandbox limits [V]:** bash can reach github.com, raw.githubusercontent.com,
PyPI/npm; `api.github.com` is rate-limited (fallback: fetch the github.com repo
page HTML and regex `"name":"...","path":"..."`); **cannot reach catbox.moe,
moex.com or iss.moex.com** (web_fetch can confirm a catbox zip exists but only
returns binary placeholder). Big files: ask Asif to upload them, or have his
agents run the check.
**File-format gotchas [V]:** the `unrar` CLI mangled Cyrillic filenames — use
Python `zipfile`/`rarfile`. Wordstat CSVs are semicolon-delimited, UTF-8 BOM,
`DD.MM.YYYY`, Monday-dated weeks, space thousands separators, `\r` line
endings (Python text mode converts them to `\n`, so split on `\n`).
investing.com CSVs are comma-delimited, quoted, `MM/DD/YYYY`, newest first,
volume strings like `1.2M`.

## 5. Data and variable construction (authoritative rules)
- **Window:** Wordstat Mondays 2018-08-27 → 2026-08-31 (419 weeks); price bars
  labeled 2018-08-19 → 2026-09-06. **Never truncate.** An earlier run stopped at
  2026-02-23 and silently lost the 2026 crisis window and the April-2026 EU
  sanction rounds. [V]
- **Universe (75 tickers):** AVAN, BSPB, CBOM, SBER, USBN, VTBR, AKRN, KAZT, KZOS,
  NKNC, PHOR, ABRD, GCHE, MGNT, MVID, AFKS, SFIN, BANE, GAZP, JNOS, LKOH, MFGS,
  NVTK, RNFT, ROSN, SIBN, SNGS, TATN, VJGZ, KMAZ, RGSS, ALRS, BLNG, CHMF, CHMK,
  GMKN, MAGN, NLMK, PLZL, RASP, ROLO, RUAL, SELG, TRMK, UKUZ, VSMO, LSRG, MSTT,
  PIKK, IRKT, UNAC, YNDX, MGTS, MTSS, RTKM, TTLK, AFLT, FESH, NMTP, UTAR, FEES,
  HYDR, IRAO, LSNG, MRKC, MRKK, MRKP, MRKS, MRKU, MSNG, MSRS, OGKB, TGKA, UPRO,
  YAKG. 13 sectors. **Sector membership must be read from the raw archive's
  `Data/<Sector>/<Ticker>/` folder names** (methodology_final.md forbids
  hard-coded sector lists). Known disputes: YAKG (Energy vs Utilities), IRKT/UNAC
  (Tech vs Industrial). [V]
- **Known exclusions (19, all absent from the 75):** TCSG, BELU, AQUA, ELFV
  (name/ticker change or relisting); SMLT, SGZH, POSI, RENI, SPBE (listed after
  mid-2017); GAZS, GAZT, GAZC, APTK, DVEC (search channels sparse or missing);
  FLOT, IRGZ, TGKD, LENT, AMEZ (price-data gaps / late IPO). Roughly 6 further
  exclusions from the original ~100-candidate list are **unrecoverable** (the
  candidate list was not preserved). [V/R]
- **Model sample:** companies with <300 complete-case weeks are excluded from
  regressions (MRKK has 282). ROLO is excluded from every RV-containing model
  (tick-size distortion). Typical model N is 73-74; every table must name who is
  missing and why. [V/R]
- **SVI / ASVI:** for 74 companies SVI = ticker count + Cyrillic "<name> акции"
  count (raw sums, then log). `ASVI(t) = ln SVI(t) − median(ln SVI(t−1..t−8))`;
  SVI=0 → missing; needs 8 valid prior weeks. A per-company ticker-vs-Cyrillic
  ASVI correlation test (threshold 0.85) put **all 74 in the "sum" branch**
  (max correlation 0.807, TRMK). [R]
- **Yandex:** search = **YNDX ticker + Cyrillic only; YDEX deliberately
  excluded** (Asif's decision: YNDX showed no behavior change at the 2024
  ticker switch). Documented limitation: YDEX was the *larger* channel for
  about two years after July 2024, then collapsed in June 2026 (unexplained).
  For *price* data Yandex trades as YNDX before 2024-07-24 and YDEX after. [V]
- **Price variables:** `RV = ln(High/Low)` (primary — matches the original
  prospectus and Alizadeh et al. 2002; `(H−L)/Close` and |R| are robustness
  rows); `R = ln(P_t/P_{t−1})`; use `ln(Volume)`. Weeks with High==Low → RV
  missing (log undefined). [V]
- **Date join (investing.com):** price bars are Sunday-labeled where the label
  is the day BEFORE the Mon-Fri trading week (label 2022-02-20 contains the
  Friday 2022-02-25 close). Join Wordstat Monday W to price label W−1. [V]
- **Data-quality registry [R]:** exclude week 2024-06-16 from cross-sectional
  event detection (artifact in ~55/75 files); exclude 2024-08-25 from volume
  metrics; twelve flat placeholder rows dated 2022-02-27 in the raw
  investing.com files are missing data; known gaps (LSNG Mar-May 2020, MSTT
  Sep-Oct 2020, FEES Dec 2022/Jan 2023, YNDX relisting Jun-Jul 2024, AVAN early
  weeks) stay missing, never forward-filled.

## 6. Control variables
Four event/structural controls plus ownership. **Never infer these from
memory — they are compiled in `Combined_Data_File.md` and the source reports.**
- **Crisis(t)** — market-wide, identical across firms in a week. A firm
  "spikes" when RV ratio ≥2 AND volume ratio ≥2 versus its own trailing-52-week
  median; a week is a stress week if ≥25% of eligible firms (≥30 trailing obs)
  spike; a window is confirmed if contiguous stress weeks (one-week bridge)
  reach peak ≥40%. Four windows: COVID (~Mar 2020), invasion/MOEX suspension
  (2022-02-21 → ~03-28), Sept 2023 ruble/rate shock, and a June-July 2026
  "bear-market capitulation" (documented as 2026-06-22 → 07-27). One agent
  report mislabels the 2022 window as "W4" — exact dates are in
  `Combined_Data_File.md`. [R]
- **Sanction(i,t)** — company-specific **permanent step** (0 before the
  confirmed first designation, 1 forever after). Sourced from OFAC/OFSI/EU
  lists; verified by a 2× trailing-median RV/volume spike test in the 4 weeks
  after. Verification report: 23 primary anchors, only 7 showed a market
  reaction; a later document mentions 34 anchors — reconcile against the
  sanctions report. About 24 of 75 companies have a confirmed designation. [R]
- **News(i,t)** — company-specific, transient (on at the event week; stays on
  while RV or volume ≥1.5× trailing median; capped at 4 weeks). Strict bar:
  discrete, exceptional events only (M&A, surprise earnings, sudden leadership
  change, major legal/regulatory action, operational disruption, debt distress,
  one-off contract). Old benchmark: 31 events, 23 companies, 89 weeks (shown to
  be internally contradictory with "zero sanction overlap"). A later rebuild
  (`NEWS_LAYER_RECONCILIATION_REPORT.md`) produced **17 confirmed events** with
  2+ sources each. News is an attribution/sensitivity instrument, not a main
  regressor. [R]
- **Div(i,t)** — Div=1 for the 4 weeks before each confirmed-PAID record week
  (record week excluded; overlapping windows unioned). Targets: 587 record dates
  (334 in 2018-21, 253 in 2022-26), 63 payers, 12 non-payers (JNOS, MFGS, RNFT,
  VJGZ, BLNG, CHMK, ROLO, UKUZ, UNAC, FESH, UTAR, MRKK), 2,110 Div=1 weeks
  (6.71% of panel), 18 announced-but-not-paid exclusions (mostly 2022+).
  Sources: smart-lab.ru, dohod.ru, T-Bank, ЗакрытияРеестров.рф. **The row-level
  587-date table was never persisted in earlier rounds; a rebuild was ordered.
  Check whether it now exists in the repo. [?]** Because every regressor is
  lagged one week, Div_lag1's effective window shifts forward and includes the
  record week — disclose this.
- **SOE(i)** — time-invariant; 1 if the Russian state (directly or via a
  state holding) holds ≥25% of voting shares, 0 if not, UNDETERMINED if unclear.
  Appendix table says **35 SOE / 40 non-SOE**; an earlier pre-pass said 34/41
  (`agent2b_soe.csv`, **never published; does not exist**). Which firm differs
  is unresolved, so H6 is **PROVISIONAL**. VSMO is a knife-edge (25% + 1
  share). SOE is concentrated in Utilities/Energy, so any ownership effect must
  be checked against sector. [R]

**Overlap rules [V — corrected in conversation]:**
- Crisis∩News = 0 and Sanction∩News = 0 **by construction** (News admission is
  checked against both).
- **Crisis∩Sanction is NOT forced to 0** (Amendment A1): VTBR's sanction date
  2022-02-24 sits inside the invasion window. Measure and disclose.
- Div overlaps with Crisis/Sanction/News are **measured and disclosed, never
  removed** (Div is the variable H5 tests). Found: Div∩Crisis = 85 weeks (55 in
  the 2026 window), Div∩Sanction = 3, Div∩News = 0; the documented list of 11
  "robustness-check candidates" is AVAN, SBER, USBN, VTBR, AKRN, GCHE, NVTK,
  TATN, LSRG, RTKM, AFLT; a later reconstruction produced 29-30, an unexplained
  discrepancy. [R]
- **Proposed but never formalized:** (a) a News admission order — reject if in a
  Crisis window, else if the company is under an active Sanction, else apply the
  bar and spike test; (b) **A2 — News causal-attribution exclusion**: discard a
  News candidate whose own reporting attributes its cause to the war, sanctions
  or COVID, regardless of timing. Ask Asif whether to write these as formal
  amendments. [I]

## 7. Hypotheses and methods (from methodology_final.md; check it for exact text)
- **H1** attention → volatility; **H2** attention → returns; **H3** structural
  break at the 2022-02-24 invasion; **H4** sector heterogeneity; **H5** dividend
  season; **H6** state-ownership moderation (prospectus predicted weaker for
  SOEs).
- **M1:** per-company OLS, `RV_t = α + β1·ASVI_{t−1} + β2·RV_{t−1} + β3·lnV_{t−1}
  + β4·Crisis + β5·Sanction + β6·Div + ε` (all lagged one week), Newey-West HAC
  bandwidth 4. **M2:** same for returns (`R_t` on `ASVI_{t−1}, R_{t−1}, RV_{t−1}`
  + controls).
- **M3:** Granger tests (L=1,2,4), Benjamini-Hochberg applied separately within
  the H1 block and the H2 block, Holm alongside.
- **M4:** pooled two-way fixed effects (firm + week) with `ASVI, RV_{t−1},
  lnV_{t−1}`, Sanction and Div; **the lagged-volume term was added to fix a
  pooled-vs-per-company sign contradiction (omitted-variable bias)** — say so
  wherever M4 is reported. Interactions: ASVI×Sector (H4, Wald), ASVI×Div (H5),
  ASVI×SOE (H6). Crisis is absorbed by week FE.
- **M5:** asymmetric Chow at 2022-02-24 (reduced form: ASVI and RV lags only),
  Giles-Lieberman heteroscedasticity-robust bounds. The exact tabulation
  (`canterbury-nz-034.pdf` in the books archive) was never extracted; agents
  used a disclosed substitute. Also an unresolved q=3 vs k=4 table-row note.
- **M6:** permutation test with **circular/block shifts as primary** (i.i.d.
  shuffle only secondary — it manufactures significance under serial
  correlation) plus power and minimum detectable effect; any null with power
  <0.80 must be reported as "inconclusive due to insufficient power."
- **Section 5 (sector-wise pooled panels, only sectors with ≥4 firms)** and
  **Section 6 (government vs non-government pooled split, with a sector-
  confound re-estimate)** were added at Asif's request. Section 6 is blocked
  until the SOE reconciliation is done.
- **Named sensitivity checks (six):** drop revision-affected News events; widen
  News windows; strict Crisis/Sanction definitions; H5 without the 11
  candidates; H6 with federal-only SOE; VSMO flip-test.

## 8. Results so far (all [R] from agent reports; two runs that differ)
- **Run 1 (`AGENT6_FINAL_REPORT.md`):** M1 3 BH survivors (MFGS, RTKM, SNGS);
  H2 nothing survives correction; H3 32/73 survive bounds (substitute bounds);
  H4 Wald p=0.0071; H5 p=0.091; H6 p=0.0132; pooled M4 null. Audit: 9 PASS, 0
  FAIL, 3 WARNING.
- **Run 2 (`EXECUTION_AND_BLOCKER_REPORT.md`; believed later, follows the 8
  methodology corrections — order is [I]):** H1 four BH survivors (RTKM, SNGS,
  LSRG negative; MFGS positive, Granger-consistent); H2 nothing robust; H3
  robust for 15 of 74 firms (9 Utilities/power); H4 pooled null but sector
  heterogeneity significant (p≈0.019, Utilities negative); H5 p≈0.19 (null);
  H6 p≈0.09 and it **attenuates under sector×week fixed effects**; all ~62
  per-company nulls are underpowered. News was not in the panel; SOE
  reconciliation blocked.
- **Read together:** the pooled effect is null while firm-, sector- and
  period-specific structure appears — consistent with the prospectus theory.
  **But results move materially across specifications (H6 p 0.013 → 0.09, H3
  32 → 15), so avoid overselling.** [I]
- **Pilot facts (prospectus):** pooled β=0.000747, p=0.566 (15 firms); Yandex
  β=+0.016, p=0.024. Under later, more rigorous runs Yandex did *not*
  replicate and showed a negative effect (earlier round: −0.0226, p=0.018, from a
  corrected date alignment; the pilot's positive number came from a flawed
  one). Never cite De Long et al. (1990) to explain a negative sign — it
  predicts positive; Djalilov & Ülkü (2021) call retail MOEX behavior "a sign
  of sophistication," not "contrarian and non-forecasting." [V]
- **MOEX-vs-investing.com comparison (`WEEKLY_PRICE_COMPARISON.md`):** after
  shifting by 7 days the two weekly series match to the cent on ~99% of weeks
  (96% within 0.1% on all firms). MOEX weekly files label the week by its END
  Sunday, investing.com by its START → **subtract 7 days from the MOEX label
  before joining**. Three scale mismatches: VTBR (5000×), GMKN (100×), ROLO
  (10×). Report recommends the MOEX files as the price panel. **My doubts:**
  (i) ROLO is Rusolovo in this project, but the report calls it Rosseti
  Lenenergo (that is LSNG); (ii) for VTBR the report says the MOEX side is
  post-split, yet a direct earlier check showed investing.com VTBR smooth at
  96-106 RUB across July 2024, and the report itself notes volume ratio 1.0
  against a 5000× price ratio. **[I] My reading: raw MOEX prices are
  unadjusted for splits while investing.com prices are adjusted — verify
  before using MOEX files, and adjust history if so.** Also confirm how
  Yandex's YNDX/YDEX prices are stitched.

## 9. Decisions already made (do not relitigate without a stated new reason)
- 75-company universe and the exclusion list; sector map from folders.
- Search channels summed (ticker + Cyrillic); Cyrillic-only is a robustness
  row (it flipped the pooled p from ~0.066 to ~0.012 — never make it primary
  for that reason).
- Yandex: YNDX + Cyrillic only.
- RV = ln(H/L) primary; ROLO out of RV models; M4 includes Sanction and lagged
  volume; Crisis is lagged (interprets spillover/decay, not a contemporaneous
  premium; Crisis(t) only as a flagged robustness row).
- News is attribution/sensitivity only. Div overlaps disclosed, not removed.
- More firms do not fix per-firm power (that needs more weeks); the answer to
  "why not 100/150 firms?" is the documented screening standard.
- Freeze protocol proposed: stamp methodology v1.0, then only numbered
  amendments, never silent edits. Whether it was formally stamped: [?].

## 10. Errors caught and lessons (so you do not repeat them)
1. **Phantom files:** agents cite scripts/CSVs that only existed inside their
   sandboxes (`final_dividend_table.csv`, `agent2b_soe.csv`, `lib/build_final.py`).
   Always list the live repo first; after any publish, **re-fetch from the live
   URL** to prove it persisted.
2. The previous assistant itself drifted: RV as `(H−L)/Close` (prospectus says
   ln(H/L)); an inferred H1-H6 list in a manual was scrambled; a rule forcing
   Crisis∩Sanction=0 was impossible. Re-check specs against the prospectus.
3. Templated "verified" lists hid delistings (Uralkali 2019, Dixy, TransContainer,
   MegaFon). Demand company-specific evidence.
4. Sunday/Friday date mix-up; AFLT duplicate download; 2024-06-16 artifact;
   unit changes at VTBR/GMKN/ROLO.
5. Agents blend archives: tell them explicitly which files are data sources and
   forbid the raw-data and literature zips as sources of control values.
6. Results-driven decisions: Asif twice leaned toward dropping something because
   of its effect (Yandex, News "flattening"). Hold the line: exclusions need
   independent, pre-stated criteria.
7. Literature gaps: Cheng et al. (2021, attention effects reverse by horizon)
   and Hu et al. (2025, ownership moderation) are not yet in the books folder.

## 11. Open items, in priority order
1. Settle the MOEX price source: check VTBR/GMKN/ROLO adjustment, then rebuild
   the panel with the −7-day join and Yandex stitching.
2. Confirm the row-level Div table (587 dates) is in the repo; if not, rebuild
   (QA loop). Recompute the Div–overlap candidate list (11 vs 29-30).
3. Resolve SOE (35/40 vs 34/41, YAKG sector, VSMO) via independent double
   classification; unblock H6 and Section 6.
4. Feed the 17-event News layer into sensitivity checks 1-3; decide News
   admission order and A2.
5. Extract the real Giles-Lieberman bounds from the PDF.
6. Re-run the full pipeline against a frozen methodology v1.0 and audit it.
7. Write the results chapter around: pooled null + sector/ownership/period
   structure + honest power statements. Draft committee answers (why 75 firms,
   why weekly, why Yandex excludes YDEX, why the sign differs from the pilot).
8. Admin: confirm the submitted title; whether Yana was emailed; whether to
   send Aistov a progress update; check HSE rules on AI-assisted work.

## 12. How the work has been run
Asif uses autonomous agents (6-7 hour runs; outputs saved to GitHub) and
pastes results back. The previous assistant wrote **self-contained prompts**
(agents know nothing), each starting with "fetch the live repo listing, trust
only what is there," naming exact files and forbidden sources, with
builder → dual-QA (scored 0-10) → merge → publisher loops and a mandatory
round-trip re-fetch. Prompt files it wrote (ask Asif to upload any you need):
`agent_prompts_*.md`, `SUPPLEMENT_hypotheses_methods_exclusions.md`,
`ULTIMATE_METHODOLOGY_BLUEPRINT.md`, `FINAL_COMPLETE_METHODOLOGY.md` (superseded
by `methodology_final.md`; it contains the RV error above), `fetch_moex_data.py`.

## 13. Working style and integrity rules
- Asif asked for **direct, honest feedback** and for no hallucination — verify,
  say "unknown" when you do not know, correct your own mistakes openly.
- **Do not rewrite his abstract or framework text without explicit permission.**
- He writes short, fast messages (often typos) from a phone; keep replies tight
  and lead with the answer. Long deliverables go in files.
- He once pasted a long "Alien Bomber / Chief of Staff" persona dossier asking
  an AI to adopt a cold military persona; the previous assistant declined and
  treated him as a person. Do the same.
- The thesis is high-stakes for his plan to leave Russia for a European PhD; he
  lives under financial and social strain and can swing toward drastic moves
  (dropping data, changing topic) when results look weak. Ground reassurance in
  the actual numbers, and check in on him as a person now and then.
- Never let a result decide inclusion, exclusion or a specification.

## 14. Suggested first reply
Confirm you read this, list the three facts you are least sure of ([?] items),
ask Asif for (a) the latest repo listing, (b) the MOEX weekly files or an agent
report on VTBR/GMKN/ROLO adjustment, and (c) whether the Div row-level table
and SOE reconciliation have been produced — then start with open item 1.
