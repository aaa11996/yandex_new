# FINAL REPORT — Investor Attention (ASVI) and the Russian Equity Market, 2018-08-27 → 2026-09-06

Assembled, estimated, audited pipeline. Panel: `/home/user/work/panel/panel.csv` — **31,425 rows = 75 companies × 419 weeks, Mondays 2018-08-27 through 2026-08-31** (price bars labeled 2018-08-19 → 2026-09-06 independently re-verified from raw files, audit A1). The prior run's 2026-02-23 truncation is corrected: **W4 crisis (2022-02-21…03-28) and the April-2026 EU sanction rounds are inside the sample** (A1b).

## Results by hypothesis

### H1 — attention → realized volatility (M1, M3, M4, M6)
- **M1** (per-company, NW-HAC bw=4, 73 fits): 12/73 nominally significant. **After block-level BH within H1: 3 survivors (MFGS, RTKM, SNGS; 10-of-12 raw effects negative). Holm: 2 (MFGS, RTKM).**
- **M3** Granger: 30/219 raw significant; **8 BH / 4 Holm survivors** (JNOS L1,L4; MFGS L1,2,4; RTKM L1,2,4).
- **M4** (two-way FE, n=29,453, Driscoll–Kraay bw=4, with the **mandated lagged-volume correction β3**): pooled asvi_lag1 = +0.00128 (p=0.355) — null.
- **M6**: 15/73 permutation-significant; post-hoc power: **all 61 M1 nulls have power <0.80 → every null here is "inconclusive due to insufficient power," never "no effect"** (MDE80 ≈ 0.02–0.04 rv units).
- **Verdict H1: weak, sign-mixed, company-specific evidence (3 robust names concentrated in telecom/retail/power-defensive); pooled effect null; majority of per-company nulls underpowered.** NOT a broad market effect.

### H2 — attention → returns (M2, M3)
- **M2**: 3/74 raw significant (FEES, GCHE, PLZL); **0 BH / 0 Holm survivors**. **M3-H2**: 17/222 raw; **0 BH survivors**.
- **Verdict H2: rejected at any multiplicity-corrected level. Attention has no detectable weekly return predictability.**

### H3 — structural break at 2022-02-24 (M5 Chow)
- Reduced form, q=3, k_pool=4, asymmetric crisis_chow: **nominal 35/73; bounds-survivors 32/73.** Giles–Lieberman exact tabulation absent from repo → disclosed two-bound substitute (WARNING).
- **Verdict H3: supported for ~44% of companies (robust bounds), concentrated in Regulated Defensive and banking names.**

### H4 — sector heterogeneity
- Joint Wald on ASVI×Sector (df=12): W=27.3, **p=0.0071**. Sector effects range **−0.020 (Industrial) … +0.013 (Energy), +0.012 (Tech)**.
- **Verdict H4: supported — economically large dispersion explains why the pooled H1 estimate is null (positive and negative sector effects offset).**

### H5 — dividend-period attenuation
- asx_div = +0.00895, **p=0.091** — fails 5%; Agent-5 variants A/B (drop 30 / 29 overlap companies): p=0.174 / 0.158.
- **Verdict H5: not supported at 5%; the documented "11 Div-overlap companies" definition is unrecoverable (WARNING), but H5 stays null under both reconstruction variants.**

### H6 — SOE amplification
- asx_soe = +0.00600, **p=0.0132**. Robust to federal-only list (p=0.048) and to VSMO reclassification (p=0.011).
- **Verdict H6: supported and stress-robust.**

## Robustness (Agent 5)
Checks 1–2 (News revisions, window width) qualitatively unchanged, quantitatively below documented values by the disclosed News-reconstruction shortfall (84 vs 89 cells); Check 3 strict-anchor attribution 58.2% explained (documented 50.8%); Checks 5–6 confirm H6 robustness. Full table: AGENT5_REPORT.md.

## Audit (Agent 4)
Independent re-derivation: **9 PASS, 0 FAIL, 3 WARNING — READY with disclosed warnings.** Raw-file date range, 24 independent M1/M2 refits, lag integrity, block-BH recomputation, Chow refits, M4 spec, and all flag/anchor spot checks passed.

## Integrity statement (mandatory)
1. **Study window untruncated**: 419 Mondays, 2018-08-27 → 2026-08-31; raw price labels 2018-08-19 → 2026-09-06, re-verified from source files (A1 PASS).
2. **News events reconstructed**: no ground-truth event file exists in the repo; the documented manual rule reproduces 84 of 89 documented cells with all documented overlap invariants preserved (shortfall AFLT, MTSS, MVID — disclosed, never force-matched). Attribution numbers in Checks 1–3 are correspondingly lower (≤4pp).
3. **Exclusion registry incomplete**: 19 of ~25 documented items recoverable from the live repo; the other 6 are disclosed as unrecoverable.
4. **YDEX search channel excluded by design** at the user's direction — ~2 years of real Yandex search volume is omitted by this constraint (limitation, disclosed).
5. **ROLO excluded from all RV-dependent tests** (R4; documented spike-attribution rationale ties ROLO's extreme RV to a known non-attention cause).
6. **Giles–Lieberman tabulation absent** from the repo: M5 uses disclosed nominal-F / robust-Wald bounds instead; counts reported for both bounds.
7. **Div-overlap "11 companies" list unrecoverable**: Check 4 run under two explicit reconstruction variants, both reported.
8. Every WARNING above is incorporated as an explicit limitation of this report.

## Artifacts
- Panel: `/home/user/work/panel/panel.csv`, construction: `panel/AGENT1_REPORT.md`, `panel/spot_check.py`
- Models: `stats/M1_M2_results.csv` (incl. block BH/Holm flags + power/MDE), `stats/M3_granger_results.csv`, `stats/M6_permutation_results.csv`, `stats/M4_results.json`, `stats/M5_chow_results.csv`
- Reports: `stats/AGENT2_REPORT.md`, `stats/AGENT3_REPORT.md`, `stats/AGENT4_REPORT.md`, `stats/AGENT5_REPORT.md`
- Code: `stats/statslib.py`, `stats/agent2.py`, `stats/agent3.py`, `stats/agent5.py`, `stats/agent4.py`; dividend build: `div_recovery/build_final_table.py`
