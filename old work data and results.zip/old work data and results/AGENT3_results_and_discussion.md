# Investor Attention and Equity Returns on the Moscow Exchange, 2018–2026

## Results, Discussion, Audit and Provenance

**Prepared by:** Agent 3 (final reporting / judge agent)
**Date:** 2026-09-15
**Inherits:** the verified and completed stage 1–4 outputs, Agent 2's consistency and audit report, and Agent 1's inventory and triage report
**Sample:** 74 MOEX-listed companies × 392 weeks (2018-08-27 → 2026-02-23), 29,008 company-weeks
**Data:** Yandex Wordstat weekly search counts (ticker channel + Cyrillic channel) and investing.com weekly OHLCV

---

## 0. Scope, and one exclusion stated once

**H5 — the dividend hypothesis — was out of scope for this entire analysis.** No dividend variable was constructed, no dividend specification was estimated, and no dividend result exists anywhere in the pipeline, the inherited record, or the recovery. Nothing in this document bears on H5, and nothing should be inferred about it from the silence. It is not "untested and pending"; it was never in scope.

The hypotheses reported here are **H1, H2, H3, H4 and H6**.

A second scope caveat, which must be stated up front because it conditions every verdict below. **The H1–H6 labels and their mapping to specifications were not pre-registered in any document that survives.** `agent3_models.py` says so explicitly in its own header:

> *"the brief's hypothesis labels were not reproduced verbatim in the prompt set, so the mapping below is a reconstruction and is flagged as such in the report."*

The mapping used throughout this document is that reconstruction, inherited unaltered:

| | Hypothesis | Tested by |
|---|---|---|
| **H1** | attention raises volatility | M1 (per-company OLS), M3 (pooled two-way FE) |
| **H2** | attention moves returns | M2 (per-company OLS), M5 (pooled returns) |
| **H3** | the effect is lagged only | M3 augmented with contemporaneous `ASVI_t` |
| **H4** | crisis changes the relationship | M4 (per-company Chow test), `Crisis` terms in M1/M2, `M4b` pooled `ASVI×Crisis` |
| **H6** | the effect is stronger in SOEs | M3 augmented with `ASVI_{t-1} × SOE` |

Because this is a reconstruction, "confirmed" and "disconfirmed" below mean *confirmed or disconfirmed relative to the reconstructed expectation*. They are not claims about a pre-registration that cannot be shown to have existed. Where the pipeline itself fixed a rule in advance — the 0.85 correlation threshold, the 300-observation screen, the 2× trailing-52-week crisis rule, the ≥25%-of-votes SOE rule — those *were* pre-specified in code before estimation, and this document says so where it matters.

---

## 1. The final sample, and every exclusion reason

### 1.1 Company count

| | n |
|---|---|
| Companies in the raw data (`Data/<Sector>/<Ticker>/`, 13 sectors) | **75** |
| Excluded by the sample-size screen | **1** |
| **Companies in every model** | **74** |

### 1.2 The one exclusion

| Ticker | Sector | Complete cases (M1 ∩ M2) | Bar | Reason |
|---|---|---|---|---|
| **MRKK** — Rosseti North Caucasus | Utilities | **253** | 300 | Below the pre-specified 300-complete-case screen for a 7-regressor weekly regression. Its ASVI series is usable in only 264 of 392 weeks. |

There is **exactly one** exclusion in the entire study, and it is an exclusion on observation count only. No company was excluded for its results, its sector, its ownership, its sanction status, its channel correlation, or any other characteristic.

**The screen was not fine-tuned to the sample.** The four thinnest companies:

| Ticker | Complete cases | Outcome |
|---|---|---|
| MRKK | 253 | **excluded** |
| MRKC — Rosseti Centre | 306 | kept |
| MRKS — Rosseti Siberia | 339 | kept |
| MRKU — Rosseti Ural | 347 | kept |

The closest retained company clears the bar by 6 observations. Audit check `4b` verifies in both directions that nothing above the bar was dropped and nothing below it kept. All four are Rosseti regional subsidiaries, whose thinness is a property of regional-utility search behaviour rather than of any analytic choice.

**MRKK is nonetheless classified.** Because SOE classification and sanction adjudication logically precede screening, MRKK appears in the stage-2 sanction table (no entity-level designation) and the stage-3 SOE table (**SOE**, ~37.5% look-through federal via PJSC Rosseti). It contributes to **no regression**. This is why the SOE counts are quoted two ways in §5, and why a reader must not conflate them.

### 1.3 Panel construction rules, all fixed before estimation

* **Grid:** 392 weekly Mondays, 2018-08-27 → 2026-02-23. The investing.com bar dated Sunday *S* prices the week of Monday *S*+1 (verified in `load.py`: bar 2022-02-20 carries the Friday 2022-02-25 close).
* **Panel-void weeks:** any week in which fewer than half of the 75 companies have a usable price bar is dropped **for every company**, so that no firm's return or volatility is measured across an exchange-wide hole. Six such weeks: `2018-08-27` (1 bar — the grid's first week, before the price files open), `2022-02-28` (12 bars, 0 with volume), `2022-03-07` (0), `2022-03-14` (0), `2022-03-21` (26), `2024-06-17` (3 — a vendor-wide gap, not a trading halt).
* **Volume-outage weeks:** a week where prices exist panel-wide but volume does not loses `lnV` only, retaining RV and returns. One such week: `2024-08-26` (75 bars, 2 with volume).
* **Volatility:** `RV = ln(High/Low)`, the Parkinson range. A week whose high equals its low carries no range information and is **missing, not zero**.
* **ASVI:** `ASVI(t) = ln SVI(t) − median[ln SVI(t−1…t−8)]`, requiring all eight trailing weeks strictly positive; `log(0)` is treated as missing.
* **Final panel:** 74 × 392 = **29,008 company-weeks**, verified by audit check `9`, with every company absent in all four 2022 closure weeks.

---

## 2. Channel selection

### 2.1 The headline: the single-channel arm of the design is empty

The pre-specified rule was: compute ASVI separately on each company's ticker and Cyrillic channels, correlate them, and **if corr ≥ 0.85** keep whichever single channel has fewer void weeks; **if corr < 0.85** sum the raw counts and compute ASVI once on the sum.

| Decision | n | Share |
|---|---|---|
| **Summed** (ticker + Cyrillic) | **74** | 100% of the 74 non-Yandex companies |
| **Single channel** | **0** | — |
| Yandex three-way special case | 1 | — |

**No company reached the 0.85 threshold.** The highest correlation in the sample is **TRMK at 0.8144**. The distribution:

| Statistic | corr(ASVI_ticker, ASVI_Cyrillic) |
|---|---|
| maximum | **0.8144** (TRMK) |
| median | 0.5939 |
| minimum | 0.0628 (AVAN) |
| count ≥ 0.85 | **0** |

The next four highest: IRKT 0.7768, OGKB 0.7554, RNFT 0.7508, UNAC 0.7334.

This is a substantive finding about the measurement, not a null result to be buried. **On the ASVI scale, the ticker-symbol search channel and the Russian-language name channel are complementary everywhere in this sample** — the "keep one" branch of the design never fires, so the study contains no single-channel series at all. Audit check `2` verifies the threshold was applied consistently to all 73 companies for which a correlation is defined (Yandex being decided separately), with **zero misclassifications**, and records the point plainly: *"no company reaches 0.85, so the single-channel branch never fires; that is a property of the data, not of the rule."*

**Why ASVI rather than raw counts matters, and the data shows it.** The post-decision diagnostics computed the same correlation on **raw counts** for comparison. The two scales disagree materially:

| | ASVI correlation | raw-count correlation |
|---|---|---|
| mean | 0.523 | 0.590 |
| median | 0.594 | 0.676 |
| maximum | 0.814 | **0.936** |
| minimum | 0.063 | **−0.342** |

On raw counts at least one pair exceeds 0.93 and another is **negatively** correlated. Had the threshold been applied to raw counts — a plausible-looking alternative — some companies would have been classified redundant and reduced to a single channel. The specification's insistence on ASVI therefore changes the sample's construction, and the change is not cosmetic.

**A caveat on two thin correlations.** `IRKT`'s 0.7768 rests on only **127 overlapping weeks** (its Cyrillic channel is void in 257 of 392), and `MRKC`'s 0.6534 on **228**. Most firms have 384. IRKT is the second-highest correlation in the sample and the closest any firm comes to the threshold; on a third of the panel, that estimate is thinner than the uniform "PASS" in the audit table suggests. It does not cross 0.85 on the available evidence, and the decision stands — but it is the one channel decision in the sample where the overlap is small enough to warrant saying so.

### 2.2 What the summed series is actually made of

| Statistic | Cyrillic share of the summed weekly count |
|---|---|
| median | **0.906** |
| minimum | 0.005 |
| maximum | 0.997 |

**The summed measure is overwhelmingly the Russian-language channel.** For the median company, 90.6% of the search volume comes from the Cyrillic query (e.g. «Газпром акции») and under 10% from the ticker symbol (e.g. `GAZP`). Two companies are the reverse case: **AVAN** and **SFIN**, where the Cyrillic channel supplies under 5% of the sum — consistent with AVAN's near-zero channel correlation of 0.0628.

Readers should therefore understand "investor attention" in this study as, in practice, **Russian-language retail search behaviour**, with the ticker channel contributing a small increment for most firms and dominating for two.

### 2.3 The Yandex three-way decision

Yandex is a special case because its ticker changed from `YNDX` to `YDEX` on 2024-07-24 during the post-restructuring redomiciliation, so three candidate series exist. The pre-specified rule: **pick the candidate with the fewest missing ASVI weeks and the fewest unexplained raw-SVI discontinuities** (a discontinuity being a week whose raw count exceeds 5× its trailing 8-week median, outside the 2024-07-15 → 2024-09-16 ticker-change window).

| Candidate | void weeks (raw) | missing ASVI weeks | unexplained discontinuities | discontinuity dates |
|---|---|---|---|---|
| (a) Cyrillic only | 0 | 8 | **3** | 2018-10-22; 2019-10-07; 2019-10-14 |
| **(b) YNDX + Cyrillic** | **0** | **8** | **2** | 2019-10-07; 2019-10-14 |
| (c) YNDX + YDEX + Cyrillic, ASVI blanked 22 Jul – 9 Sep 2024 | 0 | **16** | 2 | 2019-10-07; 2019-10-14 |

**Chosen: (b) YNDX + Cyrillic.**

Justification, following the rule exactly: (a) and (b) **tie** on the first criterion at 8 missing ASVI weeks, so the second criterion decides — (b) has 2 unexplained discontinuities against (a)'s 3. (c) is **strictly worse** on the first criterion at 16 missing weeks: adding the `YDEX` channel introduces a second gap structure, and the rule's own 8-week blanking around the ticker change (2024-07-22 → 2024-09-09) voids eight further observations without buying any reduction in discontinuities.

The 2019-10-07 and 2019-10-14 discontinuities survive in every candidate; they are a property of the underlying Yandex search series, not of the channel choice, and no candidate is penalised for them differentially.

**Disclosure:** the *choice* was not recorded anywhere in the inherited artefact — only the three candidates' numbers were. It was recovered twice over, and the two recoveries agree: (i) by applying the stated rule to the inherited candidate table, and (ii) by re-executing `agent1.py`, which independently selects `b_yndx_plus_cyr`. Audit checks 14–16 reproduce all three candidates' statistics exactly.

---

## 3. Event variables

### 3.1 `Crisis(t)` — market-wide, data-confirmed

The rule was fixed before any regression: a week is **stressed** if the cross-sectional median Parkinson RV is ≥ 2× its own trailing 52-week median (≥26 observations), **or** if ≥30% of companies have no usable price bar. Contiguous stressed weeks merge across a one-week gap. A window whose only evidence is missing bars counts as an exchange closure — and therefore as crisis — **only** if the gap covers ≥2 consecutive weeks for ≥50% of the panel; an isolated one-week gap with no volatility signal is treated as a vendor/coverage artefact.

Nine windows were flagged. **Seven were confirmed, two were rejected:**

| Window | Weeks | max RV ratio | max \|R\| ratio | max volume ratio | panel-wide gap weeks | Evidence | Verdict |
|---|---|---|---|---|---|---|---|
| 2018-08-27 | 1 | — | — | — | 1 | none | **EXCLUDED** — coverage artefact; the grid's first week |
| **2020-02-24 → 2020-04-13** | 7 (span 8) | 4.831 | 9.390 | 2.607 | 0 | volatility+returns+volume | **CONFIRMED** — COVID-19 / oil-price collapse |
| 2021-12-13 | 1 | 2.422 | 1.083 | 1.147 | 0 | volatility | **CONFIRMED** — pre-invasion build-up |
| 2022-01-17 → 2022-01-24 | 2 | 2.223 | 2.197 | 1.632 | 0 | volatility+returns | **CONFIRMED** |
| **2022-02-21 → 2022-04-11** | 8 | **11.195** | **13.034** | 2.283 | **4** | volatility+returns+volume+**exchange-closure** | **CONFIRMED** — invasion and MOEX closure; the strongest window in the sample on every measure |
| **2022-09-19 → 2022-09-26** | 2 | 2.950 | 5.593 | 1.393 | 0 | volatility+returns | **CONFIRMED** — partial mobilisation |
| 2023-09-11 → 2023-09-18 | 2 | 2.092 | 2.771 | 1.911 | 0 | volatility+returns | **CONFIRMED** |
| 2024-06-17 | 1 | — | — | — | 1 | none | **EXCLUDED** — coverage artefact; a vendor-wide row gap, 3 bars of 75 |
| 2024-12-16 | 1 | 2.165 | 3.090 | 1.138 | 0 | volatility+returns | **CONFIRMED** |

**Total: 24 confirmed crisis weeks — 6.1% of the 392-week panel.** The seven windows span exactly 24 grid weeks (8+1+2+8+2+2+1), verified against the inherited figure.

**All three candidate events named in the specification were confirmed by the data, not assumed from the calendar:** COVID-19 (~March 2020) → the 2020-02-24 window; the 2022 invasion/MOEX closure → the 2022-02-21 window; the September 2022 partial mobilisation → the 2022-09-19 window.

**Eight further named candidates were tested and rejected by the rule** — the Prigozhin mutiny (Jun 2023, max RV ratio 0.899), the Kursk incursion and windfall tax (Aug 2024, 1.787), the Rosneft/Lukoil designation (Oct 2025, 1.313), the Ukraine gas-transit expiry (Jan 2020, 1.470), the Israel–Iran escalation (Jun 2025, 0.753), the Aug–Sep 2025 escalation window (0.878), the spring 2025 cross-border raids (1.838), and the Dec 2024 MOEX halt for non-residents (2.165 — this one *did* reach the threshold and is inside the confirmed 2024-12-16 window). None was admitted on the strength of being a known historical event; several prominent ones produced no data-confirmed signal at all and are recorded as rejected.

### 3.2 The 2022 MOEX closure — the prior estimate was wrong at both ends, and is corrected here

The specification supplied a prior estimate to verify: *"approximately 2022-02-20 to 2022-03-20."* Verified against the panel, **it is wrong at both ends.**

| week beginning | raw bars (of 75) | bars with volume > 0 | cross-sectional median RV | status |
|---|---|---|---|---|
| 2022-02-14 | 75 | 75 | 0.0953 | normal |
| 2022-02-21 | 75 | 75 | **0.6123** | normal trading, extreme volatility |
| **2022-02-28** | **12** | **0** | — | **halt begins.** The 12 surviving "bars" carry no volume and are stale carry-forwards (verified bar-by-bar: BSPB and AFLT are exact repeats of the prior close; the rest differ but have `vol = NaN`) |
| **2022-03-07** | **0** | **0** | — | full closure |
| **2022-03-14** | **0** | **0** | — | full closure |
| **2022-03-21** | **26** | **26** | — | partial reopening (equities only) |
| 2022-03-28 | 75 | 75 | 0.3310 | full resumption |

**The data-confirmed trading halt runs from the week beginning 2022-02-28 through the week beginning 2022-03-21**, with normal trading resuming the week of 2022-03-28. The prior estimate began one week too early (trading was normal, if extremely volatile, in the week of 2022-02-21) and ended one week too early (2022-03-21 is still a partial-closure week with only 26 of 75 bars).

Note the distinction that matters for the dummy: the **closure** is 4 weeks, but the **confirmed crisis window** is 8 weeks (2022-02-21 → 2022-04-11), because median volatility stays above 2× its trailing baseline for three weeks *after* trading resumes (0.3310 → 0.1411 → 0.1247 against a baseline near 0.055). The crisis dummy is wider than the closure by design, and the design was fixed before estimation.

### 3.3 `Sanction(i,t)` — company-level, primary-source, with the response tested

The primary variable is 1 once the **listed issuer itself** has been designated (asset freeze / SDN) by the US, UK or EU. Every date was then tested against that company's own price and volume over the designation week plus four following weeks, against its own pre-designation medians. **A designation with no detectable response was kept, and flagged** — the dummy is built either way.

| | n |
|---|---|
| Companies with an entity-level designation of the listed issuer | **33** |
| Companies with sector-level measures only | **41** |
| | **74** |

Response adjudication across all 74:

| Response | n |
|---|---|
| **CONFIRMED market response** | **20** |
| **NO CONFIRMED MARKET RESPONSE** (recorded, flagged as priced-in / non-reaction) | **9** |
| Designation inside the MOEX suspension — response not separable from the closure | **3** (SBER, VTBR, UNAC — all 2022-02-24) |
| Designation precedes the sample start — no in-window response testable | **1** (RUAL, 2018-04-06) |
| No entity-level designation, nothing to date | **41** |

The 33 entity-level designations, with dates, authority and adjudicated response:

| Ticker | Sector | First designation | Authority | Response |
|---|---|---|---|---|
| RUAL | Metals&Mining | 2018-04-06 | US | precedes sample — dummy constant, uninformative |
| MSTT | Real Estate | 2020-12-31 | UK | **no confirmed response** |
| SBER | Banking | 2022-02-24 | US | inside MOEX suspension |
| UNAC | Tech | 2022-02-24 | UK | inside MOEX suspension |
| VTBR | Banking | 2022-02-24 | UK/US | inside MOEX suspension |
| GAZP | Energy | 2022-03-15 | EU/UK | **CONFIRMED** |
| ALRS | Metals&Mining | 2022-03-24 | UK | **CONFIRMED** |
| HYDR | Utilities | 2022-03-24 | UK | **CONFIRMED** |
| CBOM | Banking | 2022-04-06 | UK | **CONFIRMED** |
| AVAN | Banking | 2022-05-04 | UK | **CONFIRMED** |
| KMAZ | Industrial | 2022-05-04 | UK | **no confirmed response** |
| RASP | Metals&Mining | 2022-05-05 | UK | **CONFIRMED** |
| AFLT | Transportation | 2022-05-19 | UK | **CONFIRMED** |
| BSPB | Banking | 2023-02-23 | UK/US | **CONFIRMED** |
| USBN | Banking | 2023-02-23 | UK/US | **CONFIRMED** |
| AFKS | Diversified | 2023-05-18 | UK | **no confirmed response** |
| CHMF | Metals&Mining | 2023-05-18 | UK | **no confirmed response** |
| CHMK | Metals&Mining | 2023-05-18 | UK | **no confirmed response** |
| FESH | Transportation | 2023-05-18 | UK | **CONFIRMED** |
| MAGN | Metals&Mining | 2023-05-18 | UK | **no confirmed response** |
| PLZL | Metals&Mining | 2023-05-18 | UK | **no confirmed response** |
| TRMK | Metals&Mining | 2023-05-18 | UK | **CONFIRMED** |
| SELG | Metals&Mining | 2024-06-04 | US | **CONFIRMED** |
| NVTK | Energy | 2024-06-13 | UK | **CONFIRMED** (subsidiary-level: Novatek-Murmansk; PAO Novatek itself is not asset-frozen) |
| VSMO | Metals&Mining | 2024-07-19 | US | **CONFIRMED** |
| SIBN | Energy | 2025-01-10 | US/UK | **CONFIRMED** |
| SNGS | Energy | 2025-01-10 | US/UK | **CONFIRMED** |
| MFGS | Energy | 2025-05-20 | UK | **no confirmed response** (group-level: Surgutinvestneft) |
| LKOH | Energy | 2025-10-15 | UK/US | **CONFIRMED** |
| ROSN | Energy | 2025-10-15 | UK/US | **CONFIRMED** |
| RNFT | Energy | 2025-12-18 | UK | **CONFIRMED** |
| TATN | Energy | 2025-12-18 | UK | **no confirmed response** |
| VJGZ | Energy | 2025-12-18 | UK | **CONFIRMED** (group-level: LLC NNK-Oil, Slavneft group) |

Eighteen distinct designation dates. The largest is **2023-05-18** with 7 entity-level issuers in one UK package (AFKS, CHMF, CHMK, FESH, MAGN, PLZL, TRMK — six of them metals/mining/diversified); **2022-02-24** and **2025-12-18** each carry 3. Five dates carry pairs (2022-03-24, 2022-05-04, 2023-02-23, 2025-01-10, 2025-10-15) and ten carry a single issuer (7+3+3+10+10 = 33). The 3 issuers designated on 2022-02-24 all fall inside the MOEX suspension. Note that MFGS also shows 2023-05-18 in the table but its designation *basis* is issuer-level (2022-02-23, SDN press release #41), so it is not counted among the 33 entity-level designations.

Three designations are recorded at **group or subsidiary level rather than the listed issuer**, and are labelled as such in the evidence strings: NVTK (Novatek-Murmansk, not PAO Novatek), MFGS (Surgutinvestneft, a Surgutneftegas subsidiary), VJGZ (LLC NNK-Oil, inside the Slavneft group). GAZP is the weakest of the 33 and its own evidence string says so: *"Gazprom PJSC itself is not asset-frozen"* — the date records EU investment/derivative and listing restrictions on subsidiaries from the 3rd/4th packages. Four issuers are explicitly recorded as **not** designated where a loose reading might have said otherwise: MTSS (MTS Bank is a separate issuer), GMKN (trading arms and Potanin-linked assets, not Nornickel), NMTP (its Delo Group owner, parent-level only), YNDX (the "Yandex Bank" record is dated 16 Jun 2026, outside the window). RGSS was designated by the UK only on 16 Jun 2026 — **after** the study window ends — so no in-sample dummy.

**The dummy is close to degenerate, and this is the single most important limitation on the sanction results.** Of the 74 retained firms: **41 are all-zero** inside the window, **1 is all-one** (RUAL, designated before the sample opens and de-designated in 2019 — inside the window the dummy is constant and carries no information), and only **32 vary**. Consequences:

* in the per-company models the term is dropped firm-by-firm where it has no within-sample variation, which is why every Sanction row reports `n_with_term_estimated = 32`, **not 74**;
* in the pooled models it is identified off those same 32 firms;
* the sector-wide variant `Sanction_sector` (SWIFT cut-off for banks 2022-02-28, crude embargo and price cap for energy 2022-12-05, metals import ban 2024-01-01, and so on across 13 sectors) varies for all 74 and is reported as a documented robustness alternative — **never as the primary variable**, per the specification.

---

## 4. Results by hypothesis

Throughout: **M1** is per-company OLS of `RV_t` on `ASVI_{t−1}, RV_{t−1}, lnV_{t−1}, Crisis_t, Sanction_{t−1}` with Newey–West(1) errors; **M2** the same on `R_t` with `ASVI_{t−1}, R_{t−1}, RV_{t−1}, Crisis_t, Sanction_{t−1}` — **note that M2 carries no volume control at all**, which is the documented control mismatch at the centre of §5; **M3** is pooled two-way (entity + week) fixed effects with errors clustered by firm; **M4** is a per-company Chow test around the strongest confirmed crisis window; **M5** is a pooled returns model mirroring M3; **M6** is a distribution/sign test over the M1 attention coefficients with a permutation placebo.

### H1 — Attention raises volatility

> **VERDICT: DISCONFIRMED on the pre-registered primary measure. Not significant in the pooled model once the control set is corrected. Confirmed only under one alternative dependent variable, |R|, and that confirmation is the most fragile result in the study.**

**Per-company (M1), across 74 firms:**

| | value |
|---|---|
| mean `ASVI_{t−1}` coefficient | **−0.00130** |
| median | −0.00133 |
| standard deviation | 0.01324 |
| share positive | **47.3%** (35 of 74) |
| significant at 5%, positive | **1** |
| significant at 5%, negative | **6** |
| sign test p (35/74 vs ½) | **0.7275** |
| t-test on the mean p | 0.4008 |
| mean t-statistic | −0.20 |

The per-company attention–volatility relationship is **absent**. The mean coefficient is slightly negative, barely more than half the firms are positive, the sign test cannot reject a coin flip, and the seven significant firms split **6 negative to 1 positive**.

The seven firms significant at 5%:

| Ticker | coef | t | p | R² | direction |
|---|---|---|---|---|---|
| RTKM | −0.0350 | −4.37 | <0.0001 | 0.319 | negative |
| SNGS | −0.0315 | −3.26 | 0.0011 | 0.283 | negative |
| LSRG | −0.0174 | −2.78 | 0.0055 | 0.311 | negative |
| PHOR | −0.0159 | −2.79 | 0.0052 | 0.349 | negative |
| AKRN | −0.0120 | −2.18 | 0.0295 | 0.375 | negative |
| YNDX | −0.0200 | −2.34 | 0.0191 | 0.303 | negative |
| **MFGS** | **+0.0351** | **+2.76** | **0.0057** | **0.204** | **positive** |

**Pooled (M3), two-way FE, clustered:**

| Control set | coef | se | t | p | n | R²_within |
|---|---|---|---|---|---|---|
| **as specified, WITH `lnV_{t−1}`** | **+0.001817** | 0.001532 | **+1.186** | **0.2358** | 27,544 | 0.1237 |
| WITHOUT `lnV_{t−1}` (prior round's headline set) | +0.002892 | 0.001430 | +2.023 | 0.0431 | 27,618 | 0.1213 |

Under the corrected, consistent control set the pooled attention coefficient is **positive but not significant**. Its 95% CI is **[−0.001187, +0.004820]** — it spans zero, and cannot exclude either a small negative or a small positive effect.

**Permutation inference** (300 draws, circular within-firm shift of `ASVI_{t−1}`, which preserves each firm's own serial correlation and destroys only its alignment with the week being explained — the honest null, since a naive i.i.d. shuffle would produce an over-tight distribution):

| Specification | coef | clustered t | placebo t mean | placebo t sd | **permutation p** |
|---|---|---|---|---|---|
| M3 WITH `lnV_{t−1}` | +0.001817 | +1.186 | −0.261 | 1.024 | **0.18** |
| M3 WITHOUT `lnV_{t−1}` | +0.002892 | +2.023 | −0.293 | 1.058 | **0.04** |

The corrected specification's p rises from 0.236 (clustered Gaussian) to **0.18** under a null that respects the clustering. The uncorrected one sits at 0.04 — marginal under *both* nulls.

**M6, a note on a number that must not be quoted alone.** The 150-draw placebo inside `agent3_models.py` reports `placebo_p_two_sided = 0.0267`. That value compares the actual *coefficient* (+0.001817) against a placebo distribution of *coefficients* with sd 0.000897 — it takes the standard error as given. The same placebo's **t-based** p, which is the one that respects the clustered standard error, is **0.1067**. The audit's independent 80-draw re-run gives t mean −0.25, sd 0.98, **p = 0.175**. All three are reported; **the t-based and audit values are the defensible ones**, and neither supports H1.

**Robustness across volatility measures — and the one result that disagrees:**

| Dependent variable | coef | t | p | n |
|---|---|---|---|---|
| `ln(High/Low)` — Parkinson range, **pre-registered primary** | +0.001817 | +1.186 | 0.2358 | 27,544 |
| `(High−Low)/Close` | +0.002242 | +1.355 | 0.1756 | 27,558 |
| **`|weekly return|`** | **+0.005446** | **+4.687** | **<0.0001** | 27,430 |

Both *range* measures — the two that use intraweek high and low — give small, positive, insignificant coefficients. The **absolute weekly return** gives a large, highly significant positive one. This is not a footnote; it is a real disagreement between measures of "volatility" and it must be reported as such.

`agent3d_absR_diag.py` was written specifically to interrogate it, and its diagnostics **do not rescue the primary measure**:

| Cut | \|R\| coef | t | p | Parkinson coef | t | p |
|---|---|---|---|---|---|---|
| full sample | +0.005446 | +4.687 | <0.0001 | +0.001817 | +1.186 | 0.236 |
| excluding the 24 confirmed crisis weeks | +0.005473 | +4.767 | <0.0001 | +0.001640 | +1.168 | 0.243 |
| top 5% of weeks trimmed (cutoff \|R\| = 0.103) | **+0.001868** | **+3.547** | **0.0004** | — | — | — |
| `log(1+|R|)`, dampening extremes | +0.004779 | +4.612 | <0.0001 | — | — | — |
| within-week rank of \|R\|, distribution-free | +0.026353 | +3.634 | 0.0003 | — | — | — |
| controlling **both** `\|R\|_{t−1}` and `RV_{t−1}` | +0.002466 | +2.768 | 0.0056 | +0.001576 | +1.084 | 0.278 |

The \|R\| effect survives dropping crisis weeks, trimming the top 5%, log-dampening, rank-transforming, and adding both lags — though it **attenuates by two thirds** under trimming (0.00545 → 0.00187) and by more than half when both lags are controlled, which tells us a substantial part of it is carried by extreme weeks and by persistence. Its own permutation p is reported as **0.0000**. Only 27% of the weeks above the trimming cutoff are crisis weeks, so this is not simply a crisis effect in disguise.

The honest reading, and the one this report adopts: **on the pre-registered primary dependent variable, H1 is not supported.** A significant attention effect appears only when volatility is measured as the absolute weekly return rather than as an intraweek range. Why the two families of measures should disagree is not resolved anywhere in the workspace, and this report does not resolve it. The most that can be said is that |R| and the Parkinson range are different functionals of the same week — |R| is a close-to-close move, the range is a within-week path — and attention appears to be associated with the former and not the latter. Note also that the Parkinson range explains far more of its own variation (R²_within 0.124) than |R| does (0.032), so the |R| specification is the weaker-fitting model in which the significant result appears.

**What is unambiguous in M1** is the rest of the specification, and it is worth stating because it validates the design:

| Term | mean coef | % positive | sig. at 5% | mean t |
|---|---|---|---|---|
| `RV_{t−1}` | **+0.26335** | **100.0%** | 58 / 74 | +3.06 |
| `Crisis_t` | **+0.08789** | **100.0%** | **73 / 74** | +2.85 |
| `lnV_{t−1}` | +0.00421 | 78.4% | 22 / 74 | +1.23 |
| `Sanction_{t−1}` (n = 32) | +0.00136 | 59.4% | 4 / 32 | +0.24 |

Volatility persistence is positive in **all 74** firms. The crisis premium is positive in **all 74** firms, significant in **73**, ranging from +0.0289 to +0.1401 with a mean of +0.0879 — a remarkably uniform volatility premium across 13 sectors and both ownership classes. Lagged volume is positive in 78% of firms. The specification is picking up real structure; it is the attention term specifically that does not appear.

### H2 — Attention moves returns

> **VERDICT: CONFIRMED — but with the opposite sign to the usual expectation. Attention predicts *lower* subsequent weekly returns, and this is the most statistically robust attention result in the study.**

**Per-company (M2), across 74 firms:**

| | value |
|---|---|
| mean `ASVI_{t−1}` coefficient | **−0.00418** |
| median | −0.00514 |
| standard deviation | 0.00925 |
| share positive | **31.1%** (23 of 74) |
| significant at 5%, positive | 1 |
| significant at 5%, negative | **7** |
| **sign test p (23/74 vs ½)** | **0.0015** |
| **t-test on the mean p** | **0.0002** |
| mean t-statistic | −0.52 |
| t of the cross-firm mean | **−3.885** |

Unlike H1, this distribution is **not** centred on zero. Only 23 of 74 firms are positive (binomial p = 0.0015), and the cross-firm mean of −0.00418 is significant at t = −3.885, p = 0.0002. The effect is small — a one-unit ASVI rise is associated with a 0.42 percentage-point lower log return the following week — but it is **consistently signed across firms**, which the volatility effect is not.

The eight firms significant at 5% are **7 negative, 1 positive** (GCHE +0.0107 being the sole positive): KZOS −0.0132, LSNG −0.0223, MSNG −0.0149, MTSS −0.0160, OGKB −0.0162, PHOR −0.0125, MRKP −0.0091.

**Pooled (M5), two-way FE, clustered:**

| Control set | `ASVI_{t−1}` coef | t | p | n |
|---|---|---|---|---|
| WITH `lnV_{t−1}` | +0.000302 | +0.332 | 0.7396 | 27,423 |
| WITHOUT `lnV_{t−1}` | −0.000056 | −0.065 | 0.9484 | 27,497 |

**The pooled returns model finds nothing at all** — coefficients of essentially zero under both control sets. So H2 presents the same per-company-versus-pooled tension as H1, but in reverse: here the *per-company* evidence is the strong one and the *pooled* evidence is null.

The two must be read together rather than cherry-picked. The per-company result says that within a typical firm, attention spikes are followed by slightly lower returns, and that this holds more often than chance across 74 independent firms. The pooled result says that once common weekly shocks are absorbed by the time fixed effects, there is no cross-firm average return effect. Both are true of the same data. The reconciling observation is that the per-company estimates are **weakly related to each other across the two outcomes**: the correlation between a firm's M1 (volatility) and M2 (returns) attention coefficient is only **r = 0.151**. Whatever drives the returns result is largely orthogonal to whatever drives the volatility result, firm by firm.

The M2 crisis coefficient is also uniform and negative — mean **−0.04998**, positive in only 1.4% of firms, significant-negative in **41 of 74**. Crisis weeks saw lower returns across essentially the whole sample, exactly as one would expect, which is a further sign the specification is well-formed.

### H3 — The effect is lagged only

> **VERDICT: STRONGLY DISCONFIRMED. Contemporaneous attention dominates, and including it reverses the sign of the lagged term.**

M3 augmented with contemporaneous `ASVI_t` (n = 27,534, R²_within = **0.3343**, against 0.1237 for the lagged-only specification):

| Term | coef | se | t | p |
|---|---|---|---|---|
| `ASVI_{t−1}` (lagged) | **−0.048930** | 0.003403 | **−14.380** | <0.0001 |
| **`ASVI_t` (contemporaneous)** | **+0.087826** | 0.005115 | **+17.170** | <0.0001 |
| `RV_{t−1}` | +0.325287 | 0.018488 | +17.595 | <0.0001 |
| `lnV_{t−1}` | +0.003910 | 0.001044 | +3.746 | 0.0002 |
| `Sanction_{t−1}` | +0.000421 | 0.001838 | +0.229 | 0.8188 |

Three things happen at once, and all three matter:

1. **The contemporaneous term is large, positive and overwhelmingly significant** (t = +17.2), and roughly **18 times** the magnitude of the lagged term in the headline specification (+0.0878 vs +0.0018).
2. **The lagged term flips sign** — from +0.001817 in the headline M3 to **−0.048930** — and becomes highly significant in the negative direction.
3. **The model's within-R² nearly triples**, from 0.124 to 0.334.

This is the classic signature of **simultaneity**, and it is the most important interpretive result in the study. The specification that "works" — the one with the significant positive attention coefficient — is precisely the one in which attention and volatility are measured **in the same week**. A same-week association between how much a stock's price moves and how many people search for it cannot be given a causal direction: volatile weeks attract searches at least as much as searches precede volatility. The sign flip on the lagged term is what happens when a strong contemporaneous association is partialed out and the residual lagged relationship is left carrying the opposite sign.

The pre-specified decision to lag attention in the headline specifications was therefore **correct as a discipline**, and H3's expectation — that the effect is lagged *only* — is **disconfirmed**: the lagged-only specification has an insignificant attention coefficient, while the specification that admits contemporaneous attention is dominated by it. The right conclusion is not "attention affects volatility contemporaneously"; it is that **this design cannot separate contemporaneous feedback from contemporaneous causation, and the lagged specification — the only one that can bear a causal reading — finds nothing significant on the primary measure.**

`ASVI_t` appears **only** in this test. No headline specification (M1, M2, M3, M3-without-lnV, M5) contains a same-period or future search, price or volume term on the right-hand side — verified exhaustively in §7.

### H4 — Crisis changes the relationship

> **VERDICT: PARTIALLY CONFIRMED, and the two halves point in different directions. Per-company parameters are decisively unstable around the 2022 window; the pooled interaction finds no change in the attention slope. The crisis *level* effect on volatility is the single most robust finding in the study.**

**(a) The crisis level effect — confirmed, uniformly.** From M1: `Crisis_t` is positive in **74 of 74** firms, significant at 5% in **73 of 74**, mean +0.08789, range +0.0289 to +0.1401, mean t = +2.85. From M2: negative in 73 of 74 firms, significant-negative in 41. Crisis weeks carry a large volatility premium and a negative return across essentially the entire sample, in every sector. This is confirmed with no ambiguity.

**(b) M4 — per-company Chow test around the strongest confirmed window.** The break window is taken from the confirmed crisis window with the strongest evidence: **2022-02-21 → 2022-04-11** (`volatility+returns+volume+exchange-closure`), with a **4-week buffer dropped on each side** (pre-sample ends 2022-01-24, post-sample begins 2022-05-09). Requirements: ≥60 pre and ≥60 post observations, ≥140 total.

| | value |
|---|---|
| companies testable | **74 of 74** |
| rejecting parameter stability at 5% | **25** (33.8%) — expected under the null: 3.7 |
| rejecting at 1% | **14** — expected under the null: 0.7 |
| binomial p for 25/74 against a 5% null | **9.4 × 10⁻¹⁵** |
| binomial p for 14/74 against a 1% null | **2.6 × 10⁻¹⁴** |
| mean attention coefficient, pre-break | **−0.00505** |
| mean attention coefficient, post-break | **−0.00059** |
| mean change | **+0.00446** |
| median pre → median post | −0.00334 → −0.00196 |
| firms with a negative attention coefficient, pre → post | **50/74 → 41/74** |
| firms whose coefficient flips from negative to positive | **22** |
| mean within-firm R², pre → post | **0.220 → 0.152** |

Parameter instability around the 2022 window is **overwhelming**: six to nineteen times the number of rejections chance would produce, at both thresholds. The direction is consistent — the attention coefficient becomes **less negative** after the break for 38 of 74 firms, and the cross-firm mean moves from −0.00505 to −0.00059.

**Two cautions, both of which belong in the report rather than in a footnote.**

*First, the Chow test is not robust to heteroscedasticity, and this sample is heteroscedastic by construction.* The reference set includes Giles & Lieberman's bounds on exactly this problem. The post-break sub-sample contains the highest-volatility weeks in the panel; a test that compares residual variances across regimes with unequal variance will over-reject. The 25/74 cannot be read as 25 firms with a demonstrated change in the attention slope. **What can be read is the direction of the coefficient change**, which is estimated separately from the F-statistic and does not depend on the variance comparison.

*Second, the model fits worse after the break.* Mean within-firm R² falls from 0.220 to 0.152. Whatever changed in 2022, the post-break regime is one in which this specification explains **less** of volatility, not more.

**(c) `M4b` — the pooled interaction. This specification was missing from the inherited record and is restored here.** Two-way FE, clustered, n = 27,544, R²_within = 0.1238:

| Term | coef | se | t | p |
|---|---|---|---|---|
| `ASVI_{t−1}` | +0.001344 | 0.001492 | +0.901 | 0.3674 |
| **`ASVI_{t−1} × Crisis_t`** | **+0.008034** | **0.006379** | **+1.260** | **0.2078** |
| `RV_{t−1}` | +0.316484 | 0.019666 | +16.093 | <0.0001 |
| `lnV_{t−1}` | +0.002775 | 0.000973 | +2.851 | 0.0044 |
| `Sanction_{t−1}` | +0.000191 | 0.001877 | +0.102 | 0.9189 |

The interaction is **positive but insignificant**. At the pooled level there is **no evidence that the attention–volatility slope changes in a crisis**. (The `Crisis` main effect is absorbed by the week fixed effects, so only the interaction is identified — which is the correct design, not a limitation.)

So H4 splits. The **level** of volatility changes in a crisis, decisively and uniformly (a). The **parameters** of the per-company models are unstable around the 2022 break, decisively but with a heteroscedasticity caveat (b). The **attention slope** does not demonstrably change in crisis weeks at the pooled level (c). Reporting (a) and (b) as confirmation while suppressing (c) would be selective; all three are given equal weight here, and the verdict is **partial**.

### H6 — The effect is stronger in state-owned enterprises

> **VERDICT: DISCONFIRMED — not significant, and the descriptive per-company split points the other way.**

M3 with `ASVI_{t−1} × SOE`, restricted to determinate SOE classifications (n = 27,544, 74 clusters, R²_within = 0.1239):

| Term | coef | se | t | p | 95% CI |
|---|---|---|---|---|---|
| `ASVI_{t−1}` (the non-SOE slope) | +0.000079 | 0.001450 | +0.055 | 0.9565 | [−0.002764, +0.002922] |
| **`ASVI_{t−1} × SOE`** | **+0.004084** | **0.003248** | **+1.257** | **0.2086** | **[−0.002282, +0.010451]** |
| `RV_{t−1}` | +0.316577 | 0.019392 | +16.326 | <0.0001 | |
| `lnV_{t−1}` | +0.002779 | 0.000971 | +2.862 | 0.0042 | |
| `Sanction_{t−1}` | +0.000196 | 0.001880 | +0.104 | 0.9171 | |

The interaction is **positive — the direction H6 predicts — but not significant**, and its confidence interval comfortably includes zero and a negative value. Permutation inference gives **p = 0.26** (300 draws), weaker still than the clustered Gaussian p.

**Robustness: dropping the 12 borderline ownership determinations** (`VSMO, UTAR, LSNG, RGSS, FESH, MSTT, NMTP, NVTK, KZOS, NKNC, YAKG, BANE`) — n = 23,057, 62 clusters:

| Term | coef | t | p |
|---|---|---|---|
| `ASVI_{t−1}` | +0.000458 | +0.275 | 0.7836 |
| **`ASVI_{t−1} × SOE`** | **+0.004563** | **+1.275** | **0.2025** |

Essentially unchanged. The result is not being driven by the borderline calls.

A third variant — coding UNDETERMINED as 0 — is a documented **no-op**: stage 3 resolved all 75 companies, so zero company-weeks would be affected.

**A descriptive split, flagged as post-hoc.** Averaging the per-company M1 and M2 attention coefficients by SOE status gives:

| | n | M1 (volatility) mean | M2 (returns) mean |
|---|---|---|---|
| not-SOE | 41 | −0.00116 | −0.00303 |
| **SOE** | **33** | **−0.00147** | **−0.00560** |

If anything, SOEs show a *more negative* attention coefficient on both outcomes — the opposite of H6. **This split was computed for this report and is not part of the inherited pipeline.** It was not pre-specified, it is descriptive, it carries no inference, and it is reported because it is the natural question a reader will ask of the per-company tables. It does not overturn H6's verdict, which rests on the pre-specified pooled interaction; it merely fails to rescue it.

**One borderline case the robustness run does not cover, disclosed here.** `TGKA` (TGC-1) is classified SOE at **26.0%** — Gazprom Energoholding 51.79% × 50.2% federal — i.e. **1.0 percentage point above the 25% threshold**, on a structure dated 05.07.2022 and marked `AUTO (STALE structure)`. TGKA is **not** in the inherited 12-firm `BORDERLINE` list and is therefore **not** dropped in the robustness run above. That list was fixed in the inherited code and was **not extended during the recovery**, because extending it after seeing that the interaction is insignificant would be exactly the kind of result-driven choice the governing integrity rule forbids. The effect of including TGKA would be to move one firm from the SOE to the dropped set; given that dropping twelve firms changed the interaction from +0.004084 (t = 1.257) to +0.004563 (t = 1.275), the direction of any further change is not predictable and no claim is made about it. **The gap is disclosed, not filled.**

### H5 — Dividends

**Out of scope for this entire analysis.** Stated once, here, plainly: no dividend variable was constructed, no dividend specification was estimated, and no dividend result exists. Nothing in this document bears on H5.

---

## 5. Ownership classification (stage 3)

Rule, fixed before any regression: **SOE = the Russian state — federal (Rosimushchestvo, Minfin, state corporations) or regional (republic / oblast / city property fund) — holds or controls ≥25% of the voting shares of the listed issuer**, counting look-through stakes held through vehicles the state itself controls. Evidence order: (1) the shareholder structure each issuer disclosed to its registrar, republished with its own "last updated" date; (2) the issuer's own IR page or annual report; (3) the FCDO statement of reasons, which states the ownership ground explicitly. **UNDETERMINED is a valid outcome** where evidence is insufficient.

| | over all 75 (pre-screening) | over the 74 modelled |
|---|---|---|
| **SOE** | **34** | **33** |
| **not-SOE** | **41** | **41** |
| **UNDETERMINED** | **0** | **0** |

Both counts are correct and they answer different questions. The inherited artefact records only 34/41 — over the **pre-screening** universe of 75. The excluded firm MRKK is an SOE, so inside the models it is 33/41. **Any statement of the form "34 SOEs" must say it means all 75 classified companies, not the 74 estimated on.**

**UNDETERMINED never fires.** This is a legitimate outcome, not a shortfall: the rule reaches UNDETERMINED only when a company has no shareholder structure at all *and* no documented override, and every one of the 7 companies whose scraped structure is absent (AVAN, CHMK, JNOS, UKUZ, UTAR, VJGZ, YNDX) is resolved by a cited document. The determinations break down as:

| Determination basis | n |
|---|---|
| **DOCUMENTED** — a named source: annual report, IR page, FCDO record, Interfax | **68** |
| AUTO (2023+ registrar structure) | 4 (VTBR, AFKS, KAZT, USBN) |
| AUTO (**STALE** registrar structure) | 3 (**SBER**, MSNG, **TGKA**) |

The full 75-row table with ticker, state %, class, determination type, structure date, cited basis and source is at `analysis/out/agent2b_soe.csv`. The 34 SOEs, by look-through state share: AVAN 100.0 · RGSS 99.0 · UNAC 92.3 · TTLK 87.2 · VTBR 87.0 · IRKT 80.3 · FEES 75.0 · AFLT 73.8 · JNOS 70.3 · MFGS 70.3 · VJGZ 70.3 · ALRS 66.0 · HYDR 62.2 · MSRS 56.2 · MSNG 53.5 · UTAR 51.1 · GAZP 50.2 · SBER 50.0 · BANE 48.3 · SIBN 48.0 · KMAZ 47.1 · MRKS 43.4 · ROSN 40.4 · RTKM 38.2 · MRKC 38.0 · MRKP 37.8 · MRKK 37.5 · MRKU 37.5 · IRAO 34.0 · TATN 34.0 · OGKB 29.9 · LSNG 28.8 · TGKA 26.0 · VSMO 25.0.

**Explicit corrections against loose "state-linked" labelling**, made by the pipeline and preserved: **MSTT** (Mostotrest) is coded **not-SOE** — Stroyproyektholding, a Rotenberg family structure, holds 96.97%; a state-*adjacent* private owner is not the state as shareholder. **NMTP** is coded **not-SOE** at 20.0% — Rosimushchestvo 20% + Transneft-Service 10.5% is below the 25%-of-votes bar, however the port is commonly described. **RGSS** is coded **SOE at 99.0%** against a stale 2020 registrar table — Interfax, 4 Jul 2024, records Bank Otkritie holding >99%, and Otkritie sits inside the state-controlled VTB group. **UPRO** (Unipro) is coded **not-SOE** on the ownership rule despite Uniper's 83.73% stake being under Rosimushchestvo temporary management since the RF decree of 25 Apr 2023 — control without registered ownership, flagged as a judgement call. **YAKG** is coded **not-SOE** at 21.0% because Novikombank's position is a repo with A-Property, not a voting stake. **FESH** is coded **not-SOE** as of 2024 (Delo group, private) while reporting that the aggregator carries a row dated 30.03.2026 showing **Rosatom 92.4%** — a transfer occurring *after* the study window, which flips the label later but does not change the in-window classification. That is the correct treatment of a genuinely time-varying case and it is preserved.

**Three classifications rest on weaker evidence than the 68 DOCUMENTED majority, and are flagged rather than upgraded:**

* **SBER — 50.0%, SOE, structure dated 08.05.2020, basis `direct Правительство России 50.0%`.** The largest holding in the sample is classified on a **six-year-old scraped table naming a holder that no longer exists in that form**: the Central Bank sold its 50% stake to the National Wealth Fund in April 2020. The *classification* is not in doubt — Sberbank remains majority state-controlled, and the stage-2 sanction record (OFAC Directive 2, 24 Feb 2022; UK `RUS0256`, 01 Mar 2022) independently corroborates state control. The **stated basis is stale and the holder is misnamed**, and SBER has no documented override.
* **MSNG (Mosenergo) — 53.5%, SOE, 20.10.2022.** Gazprom Energoholding 53.85% × 50.2% = 27.0% look-through, plus the city of Moscow 26.45% direct. Comfortably above the bar on current structures too.
* **TGKA (TGC-1) — 26.0%, SOE, 05.07.2022.** One point above the threshold; see H6 above.

Two further notes. **VSMO sits exactly at the threshold** — Rostec's RT-Razvitie Biznesa holds 25% + 1 share — and is in the borderline list. And the SOE label is a **company-level constant, not point-in-time**: several scraped structures carry 2025–2026 dates (FEES 05.08.2026, ROLO 28.08.2026, RUAL 19.08.2026, SELG 29.04.2026, IRAO and MTSS 11.06.2026, CBOM 14.11.2025). For a time-invariant interaction this is defensible — a current disclosure is the best available evidence of the classification — but it does mean the study does not track ownership changes *within* 2018–2026, of which FESH is the clearest example.

---

## 6. The control-set correction — the single most important comparison in this report

### 6.1 The problem that was fixed

The specification as written carried a **documented control mismatch**:

| Model | Control set as specified | Volume control? |
|---|---|---|
| M1 (per-company, volatility) | `ASVI_{t−1}, RV_{t−1}, lnV_{t−1}, Crisis_t, Sanction_{t−1}` | **yes** |
| M2 (per-company, returns) | `ASVI_{t−1}, R_{t−1}, RV_{t−1}, Crisis_t, Sanction_{t−1}` | **no** |
| M3 (pooled, volatility) | `ASVI_{t−1}, RV_{t−1}, lnV_{t−1}, Sanction_{t−1}` | **yes** |

M1 and M3 both carry `lnV_{t−1}`; M2 carries no volume control at all. The pooled and per-company models therefore **cannot be compared as estimates of the same structural relationship** unless this is addressed. `agent3_models.py` records that the respecification was driven by *"that DOCUMENTED CONTROL MISMATCH in the written specification — by the regressor lists themselves — and not by any coefficient"*, and that it was fixed in writing before any regression in that file was executed. The fix was to **estimate and report both M3 control sets**, leaving M1 and M2 exactly as specified, rather than to alter any model to make two others comparable.

### 6.2 The comparison

| M3 pooled, `ASVI_{t−1}` | coef | se | t | p | 95% CI | n | permutation p |
|---|---|---|---|---|---|---|---|
| **WITHOUT `lnV_{t−1}`** — the prior round's headline control set | **+0.002892** | 0.001430 | **+2.023** | **0.0431** | [+0.000090, +0.005695] | 27,618 | **0.04** |
| **WITH `lnV_{t−1}`** — as specified, consistent with M1 | **+0.001817** | 0.001532 | **+1.186** | **0.2358** | [−0.001187, +0.004820] | 27,544 | **0.18** |
| **change** | **−37.2%** | +7.1% | −41.4% | **0.043 → 0.236** | CI now spans zero | −74 obs | 0.04 → 0.18 |

The pipeline's own verdict, from the restored `agent3_results.json`:

```
sign_same : true
sig_same  : false
```

**Adding the previously-omitted lagged-volume control did not change the sign. It changed the significance.** The coefficient stays positive and falls by 37%; the t-statistic falls from 2.02 to 1.19; the p-value moves from **0.0431 — marginally significant at 5%** — to **0.2358 — not significant**; and the 95% confidence interval moves from barely excluding zero to comfortably including it. Under permutation inference that respects the clustering, the same move is 0.04 → 0.18.

**So the headline positive attention–volatility result of the prior specification was, on the corrected control set, not robust.** It was significant at 5% under a control set that the study's own per-company models did not use, and it is not significant under the control set that makes the two comparable. This is reported as the central finding of the comparison, and it is a **negative** finding about the study's own prior headline.

### 6.3 Did the correction resolve the sign contradiction? No.

The respecification was undertaken in part because a sign contradiction between the pooled and per-company results was suspected to be an artefact of the control mismatch. **It was not.**

| | attention coefficient | sign |
|---|---|---|
| **M1** per-company mean (carries `lnV_{t−1}`) | **−0.00130** | negative |
| **M3** pooled, WITH `lnV_{t−1}` (the corrected, comparable specification) | **+0.001817** | positive |
| **M3** pooled, WITHOUT `lnV_{t−1}` (the prior headline) | +0.002892 | positive |

**The contradiction persists under the corrected control set.** Making the pooled and per-company models comparable did not reconcile them — the per-company average is negative and insignificant (sign-test p = 0.73), the pooled estimate is positive and insignificant (p = 0.24), and neither is distinguishable from zero. The gap between them is now a gap between two null results of opposite sign rather than between a significant positive and an insignificant negative, which is a weaker contradiction than before the correction but not a resolved one.

The likely source is aggregation, and it is visible in the data rather than conjectured. The per-company distribution has sd **0.01324** around a mean of −0.00130 — the dispersion is ten times the mean, so the cross-firm average is a poor summary of a highly heterogeneous set (range from RTKM −0.0350 to MFGS +0.0351). The pooled two-way FE estimator does not average those 74 firm-specific slopes; it estimates a single slope on within-firm, within-week demeaned data, weighting firms by their variance rather than equally. Two estimators that answer different questions, both returning values within one standard error of zero, is a more accurate description than "contradiction" — but the contradiction was the stated concern, and the honest report is that **correcting the control set did not eliminate it.**

### 6.4 The same comparison on returns

| M5 pooled returns, `ASVI_{t−1}` | coef | t | p | n |
|---|---|---|---|---|
| WITH `lnV_{t−1}` | +0.000302 | +0.332 | 0.7396 | 27,423 |
| WITHOUT `lnV_{t−1}` | −0.000056 | −0.065 | 0.9484 | 27,497 |

On returns the control set makes no difference, because **there is no effect either way** — both coefficients are indistinguishable from zero. The pooled returns result is null under both specifications, which contrasts with the per-company M2 result (mean −0.00418, sign-test p = 0.0015, t of means −3.885). See H2.

### 6.5 Sanction definition — the documented robustness variant

| Sanction variable | `Sanction_{t−1}` coef | t | p | `ASVI_{t−1}` coef | t | p |
|---|---|---|---|---|---|---|
| **entity-level designation (primary)** | +0.000174 | +0.093 | 0.9262 | +0.001817 | +1.186 | 0.2358 |
| entity-level **or** sector-wide measure | +0.003341 | +1.628 | 0.1035 | +0.001825 | +1.187 | 0.2354 |

Neither sanction definition produces a significant volatility effect. The sector-wide variant — which varies for all 74 firms rather than 32 — gives a larger coefficient (t = 1.63) but still does not reach significance, and leaves the attention coefficient untouched. **The sanction result is null on both definitions**, and the sector variant was never promoted to primary despite being the one with more variation, which would have been the convenient choice.

---

## 7. The audit — inherited and completed

### 7.1 Provenance

| | n |
|---|---|
| Checks **inherited as-is** from the prior run | **0 of 29** |
| Checks **completed by the recovery** | **29 of 29** |

This is not a formality. The interrupted run left **no per-check verdicts at all** — no `agent4_audit.csv`, no `agent4_audit.json`, no `agent4_summary.json`. The sole surviving trace was a tally (`{PASS: 29}`, `n_checks: 29`) and four trailing scalars inside `report_numbers.json`. A tally with no evidence behind it is not an audit result, so Agent 2's instruction to avoid redoing validly-completed checks had an empty domain: none of the 29 was *reported*, in the sense of having a surviving verdict, reported value, recomputed value and note.

All 29 were re-executed by running `agent4_audit.py` **unmodified**, against stage 1–4 outputs that were themselves re-derived from raw data by running the inherited stage 1–4 scripts **unmodified**.

The audit is genuinely independent of what it audits, by construction: it does **not** import the pipeline's `load.py` or `build.py`. It re-implements its own numeric parser, its own Wordstat reader, its own price reader, its own ASVI loop and its own two-way demeaning, and rebuilds the entire 29,008-row model panel from the raw `Data/` CSVs before comparing. Its stated intent — *"a shared bug cannot pass unnoticed"* — is delivered by the design.

### 7.2 The completed PASS / FAIL / WARNING table

**Tally: `{PASS: 29}` · FAIL: 0 · WARNING: 0.** `analysis/out/agent4_audit.csv`, 29 rows × 5 columns (check, verdict, reported, recomputed, note).

| # | Check | Verdict | Reported (stages 1–4) | Recomputed (audit, from raw data) |
|---|---|---|---|---|
| 1 | `1.GAZP` corr(ASVI ticker, ASVI Cyrillic) | **PASS** | 0.6577 | 0.6577 · n = 384 overlapping weeks · < 0.85 → summed |
| 2 | `1.SBER` | **PASS** | 0.5854 | 0.5854 · n = 384 |
| 3 | `1.LKOH` | **PASS** | 0.6307 | 0.6307 · n = 384 |
| 4 | `1.MGNT` | **PASS** | 0.2480 | 0.2480 · n = 384 |
| 5 | `1.GMKN` | **PASS** | 0.6400 | 0.6400 · n = 384 |
| 6 | `1.ROSN` | **PASS** | 0.6069 | 0.6069 · n = 384 |
| 7 | `1.TATN` | **PASS** | 0.5368 | 0.5368 · n = 384 |
| 8 | `1.AVAN` | **PASS** | 0.0628 | 0.0628 · n = 329 |
| 9 | `1.IRKT` | **PASS** ⚠ | 0.7768 | 0.7768 · **n = 127 only** — see limitation L4 |
| 10 | `1.TRMK` | **PASS** | 0.8144 | 0.8144 · n = 384 · the sample maximum |
| 11 | `1.YNDX` | **PASS** | *n/a — decided by the 3-candidate comparison, not the 0.85 rule* | −0.0094 · n = 98 |
| 12 | `1.MRKC` | **PASS** ⚠ | 0.6534 | 0.6534 · **n = 228** — see limitation L4 |
| 13 | `2.` threshold applied consistently to every company | **PASS** | 73 companies: 0 at/above 0.85, 73 below | misclassified: **none** · max 0.8144 (TRMK) → the single-channel branch never fires; a property of the data, not of the rule |
| 14 | `3.` Yandex candidate (a) Cyrillic only | **PASS** | missing = 8, discontinuities = 3 | missing = 8, discontinuities = 3 |
| 15 | `3.` Yandex candidate (b) YNDX + Cyrillic | **PASS** | missing = 8, discontinuities = 2 | missing = 8, discontinuities = 2 |
| 16 | `3.` Yandex candidate (c) all three, ASVI blanked 22 Jul–9 Sep 2024 | **PASS** | missing = 16, discontinuities = 2 | missing = 16 (8 blanked by the rule), discontinuities = 2 |
| 17 | `4a.` every company below the 300-observation bar is excluded | **PASS** | `['MRKK']` | `['MRKK']` · recomputed count **253** |
| 18 | `4b.` no company clearing the bar was excluded anyway | **PASS** | kept 74 | thinnest kept: MRKC **306**, MRKS 339, MRKU 347 · the closest retained case is above the bar |
| 19 | `5a.` every confirmed crisis window is visible in price/volume data | **PASS** | 7 windows confirmed | all 7 re-checked · failures: **none** |
| 20 | `5b.` rejected candidates are genuinely unsupported | **PASS** ⚠ | 2 rejected | `2018-08-27`, `2024-06-17` — **see limitation L1** |
| 21 | `5c.` sanction dates land on real activity in that company's own series | **PASS** | 33 entity-level designations | RUAL@2018-04-06 precedes the sample · MSTT bars 5/5 max\|R\| 0.034 · SBER bars 2/5 max\|R\| **0.646** · UNAC bars 1/5 max\|R\| 0.441 · VTBR bars 2/5 max\|R\| **0.670** · GAZP bars 4/5 max\|R\| 0.102 |
| 22 | `5d.` flagged, not fudged: designations with no response | **PASS** | 9 priced-in / non-reaction | 3 inside the MOEX suspension, 9 with no confirmed response, of 74 rows |
| 23 | `6.` SOE spot-check against the scraped shareholder tables (14 companies) | **PASS** ⚠ | see recomputed | class agreement **14/14** — **see limitation L2** |
| 24 | `7a.` independent end-to-end rebuild of SVI/ASVI/RV matches the modelled panel | **PASS** | 29,008 company-weeks compared | max \|RV diff\| **2.22e-16** · max \|lnV diff\| **7.11e-15** · max \|SVI diff\| **0.0** · companies whose ASVI differs: **none** |
| 25 | `7b.` lag alignment, sanction and crisis dummy reconstruction | **PASS** | panel dummies/lags | **0** lag mismatches · **0** sanction-dummy mismatches · **0** crisis-dummy mismatches, out of 29,008 each |
| 26 | `7c.` M3 replication (**with** `lnV_{t−1}`) on rebuilt data | **PASS** | coef 0.001817, t 1.186, n 27,544 | coef **0.001817**, t **1.186**, n **27,544** |
| 27 | `7c.` M3 replication (**without** `lnV_{t−1}`) on rebuilt data | **PASS** | coef 0.002892, t 2.023, n 27,618 | coef **0.002892**, t **2.023**, n **27,618** |
| 28 | `8.` permutation placebo re-run on rebuilt data | **PASS** | stage 4: placebo t mean −0.29, sd 0.99, p 0.1067 | audit: placebo t mean **−0.25**, sd **0.98**, two-sided p **0.175** · both reported; a naive i.i.d. shuffle gives an over-tight null |
| 29 | `9.` panel integrity | **PASS** | 29,008 rows expected (74 × 392) | **29,008** rows found · every company missing in all four MOEX-closure weeks: **True** |

The re-execution **exactly reproduces the inherited tally**, and `agent4_summary.json` is identical to the inherited `audit` block in all seven of its fields — including the two placebo scalars, which come from a **different random seed** (stage 4: `default_rng(7)`, 150 draws; audit: `default_rng(3)`, 80 draws). Identical output under different seeds means the underlying panel is identical, not that a seed was reused.

### 7.3 Lookahead bias — the specific requirement, verified twice

The specification requires confirming that **no regressor anywhere uses same-period or future information relative to its outcome**. This was verified by the audit (check 25) and, independently, by a separate harness written for the recovery so that the two do not share a bug (`recovered/agent2_consistency.py`, §6):

| Test | Result |
|---|---|
| Each of `ASVI_L1, RV_L1, R_L1, lnV_L1, Sanction_L1` equals its source `shift(1)` within company | **0 rows disagree**, out of 29,008 |
| …and is distinguishable from `shift(-1)`, i.e. is a genuine lag and not an accidental lead | **PASS** — the lead disagrees in essentially every row |
| Sanction dummy reconstructed independently from the date file | **0 mismatches** |
| Crisis dummy reconstructed independently from the confirmed-window table | **0 mismatches** |
| Outcome `RV_t` uses only week-*t* price data | **PASS** — `ln(High_t/Low_t)`; the bar dated Sunday *S* prices the week of Monday *S*+1, verified in `load.py` |
| `ASVI_t` uses only weeks *t−8…t* | **PASS** — `out[i] = lv[i] − median(lv[i−8:i])`, loop starts at i = 8, slice strictly backward |
| Contemporaneous regressors in any **headline** specification | **none** — M1, M2, M3, M3-without-lnV and M5 contain no same-period or future search, price or volume term on the right-hand side |
| Contemporaneous terms that do exist, and where | `Crisis_t` (market-wide state variable, contemporaneous by design, absorbed by the week fixed effects in every pooled spec); `ASVI_L0` (**only** in the explicit H3 test, never in a headline spec); `ASVIxSOE` and `ASVIxCRISIS` (products of *lagged* `ASVI_L1` with a time-invariant or market-state variable) |

**No lookahead bias was found in any specification reported in this document.** One design property is disclosed rather than treated as a defect: `Crisis(t)` is constructed from the full sample (the window-merging and closure/artefact adjudication are applied once, across all 392 weeks), though its stress rule is strictly backward-looking — week *t* against its own trailing 52-week median. In the pooled models this is harmless because `Crisis` is collinear with the week dummies and absorbed. In M1/M2 it is **not** absorbed and enters contemporaneously with the outcome. See limitation L3.

### 7.4 Every WARNING and FAIL, stated as an explicit limitation

**The audit returned no FAIL and no WARNING.** That is not the same as "no limitations", and the following are stated explicitly rather than left for the reader to find. L1, L2 and L5 are limitations *on the audit itself* — places where a `PASS` verdict is weaker evidence than its label implies.

**L1 — Audit check `5b` verifies less than its label claims.** The label reads *"rejected candidates are genuinely unsupported"*; the code is `"PASS" if len(rej) else "WARNING"`, which passes **because** at least one candidate window was rejected. It never examines *whether* the rejections were justified. The substantive question is answered by the crisis-window table itself — both rejected windows have `evidence = "none"`, no volatility or return spike, and a one-week gap below the ≥2-week closure bar — so the conclusion is sound. **But `PASS` on this row means "the rejection branch fired", not "the rejections were independently verified."**

**L2 — Audit check `6`'s PASS condition is partly self-certifying.** It reads `(scrape-direct ≥ 25) == (table ≥ 25)` **or** `determination ∈ {DOCUMENTED, AUTO (STALE structure)}`. The second disjunct is a label stage 3 assigns to itself, and it covers **71 of 75** companies. For most companies the check therefore cannot fail on a numeric disagreement. It does not fail anywhere, but **"14/14 class agreement" is weaker evidence than it looks.** The arithmetic behind it: 9 of 14 agree to the decimal (ROSN 40.4, ALRS 66.0, HYDR 62.2, AFLT 73.8, KMAZ 47.1, VSMO 25.0, MSTT 0.0, NMTP 20.0, GMKN 0.0, LKOH 0.0); three disagree materially and **none of the three changes the classification** — SBER scrape-direct **0.0%** vs table **50.0%** (the audit's state-name regex does not match `Правительство России`, and the structure is dated 08.05.2020); VTBR **48.1%** vs **87.0%** (the table uses the 2025 voting-share disclosure); FEES **83.5%** vs **75.0%** (the scrape counts treasury shares and a quasi-treasury vehicle as state); GAZP 49.3% vs 50.2%.

**L3 — `Crisis(t)` is a full-sample construction.** See §7.3. Backward-looking at the week level, but the window-merging and adjudication are applied once across the whole panel. Absorbed in every pooled specification; **not** absorbed in M1/M2, where it enters contemporaneously with the outcome. This is a design property of the inherited specification, disclosed and **not altered**.

**L4 — Two channel correlations rest on thin overlap.** `IRKT` 0.7768 on **127** of 392 weeks (its Cyrillic channel is void in 257); `MRKC` 0.6534 on **228**. IRKT is the second-highest correlation in the sample and the closest any firm comes to the 0.85 threshold; if it were mis-estimated upward past 0.85 the decision would flip from summed to single-channel. On the available evidence it does not, and the decision stands — but the estimate is thinner than the uniform PASS suggests.

**L5 — The audit samples; it does not exhaust.** Check 1 re-derives correlations for **12 of 74** companies (16%); check 23 spot-checks **14 of 75** (19%). Checks 24–27 and 29 *are* exhaustive — all 29,008 company-weeks, all 74 firms, both M3 variants — which is why the end-to-end replication carries most of the evidential weight. A correlation error confined to one of the 62 unsampled companies would not be caught by check 1, though it *would* be caught by check 24, which rebuilds every company's ASVI from raw counts and finds **zero** differences.

**L6 — The sanction evidence rests on one machine-readable primary source, not three.** `raw/ofsi.json` in the workspace is a **GOV.UK 404 page** (`<title>Page not found - GOV.UK</title>`), saved under a data filename. The OFSI/HMT download failed in the original run and was never retried successfully. `raw/sdn_advanced.xml`, the OFAC primary artefact, is **absent** from the archive entirely (only its derived pickles survive). `agent2a_events.py`'s own docstring concedes the consequence: US dates are taken from the UK list or from OFAC's published press-action pages, *"flagged as secondary"*. What remains verified and strong is the **UK FCDO list** — report date 11-Sep-2026, 58,450 rows × 58 columns, **914 unique Russia-regime designated entities**, all 5,513 entity rows carrying a parseable designation date. **All 30 UK `Unique ID`s cited in the study's designation table were looked up directly in that file and every one exists with exactly the cited date** (`RUS0256`, `RUS0250`, `RUS1119`, `RUS1732`, `RUS1733`, `RUS1430`, `RUS3064`, `RUS3094`, `RUS2383`, `RUS2382`, `RUS3162`, `RUS3160`, `RUS3163`, `RUS2133`, `RUS2671`, `RUS1075`, `RUS1838`, `RUS1839`, `RUS1843`, `RUS1840`, `RUS1844`, `RUS1027`, `RUS0190`, `RUS1926`, `RUS0239`, `RUS1422`, `RUS1444`, `RUS1849`, `RUS1083`, `RUS2708`).

**L7 — The automated OFAC matcher is unreliable, and must not be cited as a designation table.** `ofac_tight.py` — the third and strictest of three attempts, written because *"the loose pass produced false positives"* — **could never have run**: its `BANE` pattern was an invalid regular expression (`re.PatternError: unbalanced parenthesis at position 40`), raising on the first loop iteration. Its output was therefore never produced, in the original run or since. After a minimal, documented syntax patch (§8), it runs and matches **52 of 75** tickers — but a large share of the hits are plainly wrong: `YNDX` matches Mexican construction firms (`PROYECTA INTERNA S A DE C V`), `TATN` matches a Spanish food company (`ALIMENTOS CARNICOS DE TRADICION ESPANOLA LTDA`), `RUAL` matches `HIERROS DE JERUSALEM S A`, `IRAO` matches `VESNA HOTEL AND SPA`, `UPRO` matches an unrelated Chechen militant organisation, `KAZT` matches a **Belarusian** nitrogen producer (`GRODNO AZOT OAO`). `agent2a_ofac_tight.csv` is **an adjudication queue for a human, not verified evidence.** It feeds nothing — no model, no dummy, no audit check reads it — so no result in this report depends on it.

**L8 — The automated UK name-matcher has false negatives that only human adjudication caught.** `agent2a_uk_entities.py` reports *"BSPB self: no UK entity record"* and *"CBOM self: no UK entity record"*. **Both have records**, under names the regexes do not match: CBOM is **`RUS1119` "Credit Bank of Moscow"** (06/04/2022), against a pattern looking for `MOSCOW CREDIT BANK|\bMKB\b`; BSPB is **`RUS1732` "Bank St Petersburg PJSC"** (23/02/2023), against `BANK SAINT.?PETERSBURG|\bBSPB\b`. The final designation table has both correct — the human adjudication step did its job — but **the matcher's "no record" output cannot be trusted as evidence of absence**, and any future extension of the sample must not rely on it.

**L9 — `Sanction(i,t)` is close to degenerate.** 41 of 74 firms all-zero, 1 all-one (RUAL), only 32 varying. Every Sanction row in the per-company models reports `n_with_term_estimated = 32`, not 74. See §3.3.

**L10 — The Chow test is not robust to heteroscedasticity, and this sample is heteroscedastic by construction.** The post-break sub-sample contains the highest-volatility weeks in the panel. The 25/74 rejections cannot be read as 25 firms with a demonstrated change in the attention slope; the *direction* of the coefficient change is estimated separately and does not depend on the variance comparison. The reference set includes Giles & Lieberman's bounds on exactly this problem.

**L11 — Three SOE classifications rest on stale structures.** SBER (08.05.2020, holder misnamed), MSNG (20.10.2022), TGKA (05.07.2022, **26.0%** — one point above the threshold). See §5.

**L12 — TGKA is a borderline ownership case that the H6 robustness run does not drop.** It is not in the inherited 12-firm `BORDERLINE` list, which was **not extended** during the recovery because extending it after seeing that the interaction is insignificant would be a result-driven choice. See §H6.

**L13 — The SOE label is a company-level constant, not point-in-time.** Several structures carry 2025–2026 dates, and FESCO's ownership genuinely changes after the window (Rosatom 92.4%, dated 30.03.2026). The study does not track ownership change within 2018–2026.

**L14 — The hypothesis mapping is a reconstruction, not a pre-registration.** See §0.

**L15 — `M4b` was missing from the inherited record, and its absence is unexplained.** The specification is defined in `agent3_models.py` but its five coefficient rows are absent from `report_numbers.json` (23 rows present where 28 are expected). Whether the original run estimated it cannot be determined from the workspace. Restored by re-execution; reported at §H4(c).

**L16 — The sole inherited artefact is not valid strict JSON.** `report_numbers.json` contains bare unquoted `NaN` literals. The mechanism is established and benign (§8.3): the writer read a CSV whose cells were legitimately empty and re-serialised the resulting `float64 nan` with `json.dump`'s default `allow_nan=True`. It parses in Python; it will **not** load in R, JavaScript, `jq` or any strict consumer. The **writer script itself is absent from the archive**, so the provenance of the one surviving output is undocumented.

**L17 — The "attention" measure is, in practice, Russian-language retail search.** The median company's summed series is **90.6%** Cyrillic-channel by volume (§2.2).

---

## 8. Data provenance — what rests on the original run, and what was reconstructed

This section exists so that the eventual reader can tell the two apart. **The honest headline is that very little of this report rests on the original run's outputs *as artefacts*, because almost none survived.** What survives is the original run's **code** and its **numerical summary**; what this report rests on is a **re-execution** of that code, verified against that summary.

### 8.1 What the interrupted run actually left

The workspace archive (102 files, 62.25 MB) contained:

| Category | Present | Notes |
|---|---|---|
| Pipeline source code, stages 1–5 | **20 scripts, complete** | 182,030 bytes |
| Raw panel data (`raw/thesis.zip`) | **complete** | 75 companies, 13 sectors, 226 CSVs; byte-identical (MD5 `a6bc830915085e91f174ffbbaa419db5`) to the provided `iqbal thesis v2.zip` link |
| Reference literature (`raw/books.zip`) | **complete** | 7 PDFs; byte-identical (MD5 `c62fdb14b16f1c1ea1b0d187917302c6`) to the provided `thesis books.zip` link |
| UK FCDO sanctions list | **complete** | 49.9 MB, report date 11-Sep-2026 |
| OFAC-derived pickles | **complete** | `sdn_orgs.pkl`, `sdn_primary.pkl`, 19,388 SDN party records each |
| Scraped shareholder pages | **74 of 75 complete** | `YNDX.html` is a smart-lab **404 page** |
| OFSI primary evidence | **CORRUPT** | `raw/ofsi.json` is a GOV.UK 404 page |
| OFAC primary XML | **ABSENT** | `raw/sdn_advanced.xml` referenced by two scripts, not in the archive |
| **Stage 1–4 outputs** | **0 of 41** | `/home/user/analysis/out/` did not exist in the archive |
| **Stage 5 (audit) outputs** | **0 of 3** | |
| **Any narrative report, for any stage** | **0** | zero `.md`, `.txt`, `.log` files anywhere in the archive |
| **Numerical summary** | **1 file** | `analysis/reports/report_numbers.json`, 17,587 bytes — and **its writer script is not in the archive** |

The task framing described a run that "stopped after completing stage 4 of 5, before stage 5 began." **The evidence does not support that description.** The audit demonstrably ran to its last line — its summary block, which is written by the script's final statement, survived, and all 29 `log()` calls are top-level and sequential with no early exit. What never began was the **final reporting**: there is no narrative document of any kind in the archive. And separately, the entire `analysis/out/` tree — every intermediate artefact from every stage — was absent. Whether it was never written to that location, or written and not packed, cannot be determined from the archive.

### 8.2 Part-by-part provenance of *this* report

| Section | Rests on the original run's outputs **as-is** | Reconstructed / re-derived by the recovery | Verified against the original run's recorded numbers |
|---|---|---|---|
| §1 sample & exclusions | the recorded counts (75/74/1, MRKK 253, the four thinnest) | the screening report itself; the panel-void and volume-outage week lists | **yes — exact match** |
| §2.1–2.2 channel selection | the recorded corr max/min/median/argmax and decision counts | **the entire 75-row correlation table**; the raw-count-vs-ASVI comparison; the Cyrillic-share statistics; the IRKT/MRKC overlap caveat | **yes — exact match** on all four statistics |
| §2.3 Yandex three-way | the three candidates' full statistics | **the choice of candidate (b)**, which was recorded nowhere | **yes — exact match** on all 15 fields |
| §3.1 `Crisis(t)` | all 9 window rows with verdicts; `crisis_weeks = 24` | the window table and weekly-aggregate files themselves | **yes — all 99 field comparisons match** |
| §3.2 MOEX closure | — | **the entire week-by-week bar/volume table**; the correction of the brief's prior 2022-02-20→03-20 estimate | n/a — the brief's estimate was not a run output |
| §3.3 `Sanction(i,t)` | the response tally (5 categories) and 18 unique dates | **the entire 74-row per-company evidence table**; the 33 entity designations with authorities; all 30 UK Unique-ID verifications; the degeneracy analysis | **yes — exact match** on tally and dates |
| §4 all results | the 8 per-company summary rows, 23 pooled rows, 9 M5 rows, 16 M6 fields, 4 M4 scalars | **the per-company M1 and M2 tables (74 rows each)**; **the per-company Chow table**; **`M4b`, entirely**; `agent3_results.json`; **all three add-on results** (permutation, robustness, \|R\| diagnostics), which had no recorded numbers at all | **yes — exact match** on every recorded field |
| §5 ownership | the two counts (34/41) | **the entire 75-row SOE table with citations**; the determination-basis breakdown; the SBER/MSNG/TGKA stale-evidence flags; the 33/41 in-sample count | **yes — exact match** on the counts |
| §6 control-set correction | the two M3 coefficient rows | **`agent3_results.json`'s `sign_same`/`sig_same` verdict**; the permutation p-values; the aggregation analysis of why the sign contradiction persists | **yes — exact match** |
| §7 audit | the tally `{PASS: 29}` and 4 trailing scalars | **all 29 per-check verdicts, reported values, recomputed values and notes**; the independent lookahead harness | **yes — `agent4_summary.json` identical in all 7 fields** |

**Summary:** the original run contributed its **code** (used unmodified except as disclosed in §8.3) and roughly **180 recorded numbers**. The recovery contributed **all 44 artefacts**, **every per-company and per-check table**, **one entire specification (`M4b`)**, **all three add-on analyses**, **the Yandex decision**, **the MOEX closure correction**, **the 30 UK Unique-ID verifications**, and **the whole of this narrative**. Every one of the ~180 inherited numbers that could be compared was compared, and **all of them matched** — with a single exception, recorded in §8.4.

### 8.3 Every change made during the recovery

**One file was patched. Nothing else was altered.**

| | |
|---|---|
| File | `ofac_tight.py` — a stage-2 **evidence-collection** script |
| Inherited original touched? | **No.** It remains unmodified at `ws/analysis/src/ofac_tight.py` |
| Patched copy | `analysis/src_patched/ofac_tight.py`, carrying a 30-line header documenting the defect, the fix and the safety argument |
| Defect | line 32, ticker `BANE`: `BASHNEFT(?:-POLUS\|-UGRA\|-SERVICES\| \(\|)\|)` — invalid regex, `re.PatternError: unbalanced parenthesis at position 40`, raised on the script's first loop iteration |
| Consequence if left alone | the script could not run; `agent2a_ofac_tight.csv` could not be produced. **It was never produced in the original run either** |
| Fix | `BASHNEFT(?:-POLUS\|-UGRA\|-SERVICES\| \(\|\))` — stray empty alternative and stray group-close removed, literal `)` escaped. Same five intended Bashneft name forms. All 64 patterns then compile |
| Why it cannot affect any result | its only output is read by **nothing** — not `agent2a_events.py` (whose designation table is hand-adjudicated and cited to UK Unique IDs, all 30 independently verified), not `agent3_models.py`, not `agent4_audit.py`. No channel decision, event dummy, SOE classification, regression coefficient or audit verdict can change |
| What running it produced | **evidence against itself** — see limitation L7. It demonstrated that the OFAC matcher produces false positives at scale. Had it produced clean evidence of a designation the study missed, that would have been reported and acted on |

**Explicitly not changed:** no threshold (0.85, 300, 2×, ≥2 weeks, ≥25%, 0.5 panel fraction, 8-week ASVI window, 4-week Chow buffer, 60/140 minimum observations); no crisis window; no sanction date; no SOE classification; no `BORDERLINE` list; no control set; no specification; no sample; no hypothesis mapping; no random seed. **Every other script ran byte-for-byte as inherited.**

Two artefacts remain **unproducible and are reported as missing rather than approximated**: `agent2a_ofac_name_matches.csv` and `agent2a_ofac_primary_hits.csv`, written by the superseded v1 and v2 OFAC scripts, both of which require the absent `raw/sdn_advanced.xml`. Neither feeds any model, dummy or audit check. Their absence is a gap in the evidence trail, not in the analysis.

### 8.4 The one disagreement, and two corrections to the recovery's own work

**The disagreement:** the inherited `m3` array has **23 rows where 28 are expected**. The five missing rows are exactly `M4b pooled RV with ASVI_lag1 x Crisis`. Restored by re-execution and reported at §H4(c) and §L15. Whether the original run estimated it cannot be determined. **This is the only numeric disagreement in 82 consistency checks.**

**Two corrections issued by the recovery process against itself**, recorded because a report that discloses the pipeline's weaknesses must also disclose its own:

1. Agent 1's inventory originally claimed that the bare `NaN` in `report_numbers.json` proved the artefact predated the archived code. **Wrong, and withdrawn.** The `NaN` arises when an absent aggregator re-reads `agent2a_crisis_windows.csv` — whose cells are legitimately *empty*, because `agent2a_events.py` correctly writes `None` — and re-serialises the resulting `float64 nan` with `json.dump`'s default `allow_nan=True`. Reproduced verbatim. The artefact is fully consistent with the archived code; only the JSON encoding is non-standard.
2. Agent 1's inventory originally claimed that the inherited `29/29 PASS` tally was **not reproducible** from `agent4_audit.py`, on the grounds that check `5b` must warn when candidate windows are rejected. **Wrong, and withdrawn.** That inverted a Python ternary: `"PASS" if len(rej) else "WARNING"` passes *because* rejections exist. Re-executing the audit unmodified returns `{PASS: 29}` — an exact reproduction. The corrected reading is recorded as limitation **L1**: the check is real but weaker than its label.

Both errors were caught by re-execution rather than by inspection, which is the strongest available argument for having re-derived the pipeline instead of reasoning about the surviving artefact at a distance. Both are marked in the Agent 1 report under boxed **⚠ CORRECTION** headings at the point of error, and the original text is left visible rather than silently deleted.

---

## 9. Summary of verdicts

| Hypothesis | Verdict | The number that decides it |
|---|---|---|
| **H1** attention raises volatility | **DISCONFIRMED** on the pre-registered primary measure | M3 with the corrected control set: **+0.001817, t = 1.186, p = 0.236**, CI [−0.0012, +0.0048]; per-company mean **−0.00130**, 47.3% positive, sign-test p = 0.73. Confirmed only on \|R\| (+0.005446, t = 4.687), which disagrees with both range measures |
| **H2** attention moves returns | **CONFIRMED, with the opposite sign to expectation** | per-company mean **−0.00418**, 23/74 positive, sign-test **p = 0.0015**, t of means **−3.885, p = 0.0002**. Pooled M5 finds nothing (+0.000302, p = 0.74) |
| **H3** the effect is lagged only | **STRONGLY DISCONFIRMED** | contemporaneous `ASVI_t` **+0.087826, t = 17.17**; the lagged term flips to **−0.048930, t = −14.38**; within-R² 0.124 → 0.334. The signature of simultaneity |
| **H4** crisis changes the relationship | **PARTIALLY CONFIRMED** | crisis *level* effect positive in **74/74** firms, significant in **73** (mean +0.0879); Chow rejects stability in **25/74** at 5% and **14/74** at 1% (binomial p ≈ 10⁻¹⁴), mean attention coef −0.00505 → −0.00059; but the pooled `ASVI×Crisis` interaction is **insignificant** (+0.008034, t = 1.260, p = 0.208) |
| **H5** dividends | **OUT OF SCOPE** | not constructed, not estimated, no result exists |
| **H6** the effect is stronger in SOEs | **DISCONFIRMED** | `ASVI_{t−1} × SOE` **+0.004084, t = 1.257, p = 0.209**, CI [−0.0023, +0.0105]; permutation p = 0.26; unchanged when the 12 borderline ownership calls are dropped (+0.004563, p = 0.202) |

**The most robust findings in the study are not about attention at all.** They are the crisis volatility premium (positive in 74 of 74 firms, significant in 73), volatility persistence (positive in 74 of 74, significant in 58), and the crisis return effect (negative in 73 of 74, significant in 41). The attention results are, on the pre-registered primary measure, a set of nulls with one significant exception that appears only under an alternative volatility definition.

**The comparison the recovery was specifically asked to foreground:** correcting the pooled panel regression's control set by adding the previously-omitted `lnV_{t−1}` **did not change the sign** of the attention coefficient and **did change its significance** — from p = 0.0431 to p = 0.2358, a 37% attenuation, with the 95% CI moving from barely excluding zero to comfortably including it. **And the sign contradiction between the pooled and per-company results that motivated the correction persists**: M1's mean is −0.00130 while the corrected M3 is +0.001817, and both are within one standard error of zero.

---

## 10. MANDATORY CLOSING SECTION — Integrity statement

**1. Nothing was included, excluded, added, changed or reported on the basis of what result it produced.**

The single exclusion in this study — MRKK, at 253 complete-case observations against a pre-specified bar of 300 — was made by a threshold fixed in `agent1.py` as `MIN_OBS = 300` before any regression existed in the codebase, and was applied by re-executing that file unmodified. It was not chosen after seeing MRKK's coefficients; MRKK's coefficients were never estimated, because it never entered a model. The screen was verified in both directions by audit checks `4a` and `4b`: nothing below the bar was kept, nothing above it was dropped, and the closest retained firm (MRKC, 306) clears the bar rather than sitting on it. No channel was dropped, no company was winsorised, no week was excluded, no window was widened or narrowed, and no specification was promoted or demoted on the basis of its coefficient.

Where a choice could have been made in a result-favouring direction, it was not:

* **The sector-wide sanction variant** varies for all 74 firms against 32 for the primary entity-level dummy — it is the *more* estimable variable, and the one that produces the larger coefficient (t = 1.63 vs 0.09). It was **kept as a robustness variant and never promoted to primary**, exactly as the inherited specification required.
* **The |R| dependent variable** produces the only significant positive attention effect in the study (t = 4.687, p < 0.0001). The **Parkinson range remained the primary measure**, because it was pre-registered as such, and the |R| result is reported as a disagreement between measures rather than adopted as the finding. Its diagnostics are reported in full, including the two that weaken it — trimming the top 5% attenuates it by two thirds, and controlling both lags by more than half.
* **The uncorrected M3 specification** is the one that is significant at 5% (p = 0.0431). The **corrected one** — consistent with the study's own per-company models — is reported as the headline (p = 0.2358), and the correction is the centrepiece of §6 rather than a footnote.
* **`M4b`** was restored and reported at §H4(c) even though its interaction is insignificant and its inclusion weakens the H4 verdict that the per-company Chow results alone would have supported.
* **The per-company SOE split** at §H6 points *against* H6, and is reported — while being flagged as post-hoc and carrying no inference, because reporting it as confirmatory evidence would overstate it and suppressing it because it is inconvenient would be the same error in reverse.
* **H3** is reported as strongly disconfirmed even though the contemporaneous specification has by far the best fit in the study (within-R² 0.334) and the largest, most significant attention coefficient (+0.0878, t = 17.2). That coefficient is not offered as evidence for H1, because the same-week association between search volume and price movement has no identifiable causal direction, and saying so costs the study its most impressive-looking number.

**2. Every gap left by the interrupted run was filled using the original pre-specified criteria, not a convenient substitute.**

All 44 reproducible artefacts were regenerated by executing the inherited stage 1–5 scripts **byte-for-byte unmodified**, with one disclosed exception. The criteria therefore came from the original code rather than from any judgement made during the recovery: the **0.85** ASVI correlation threshold; the **fewer-void-weeks** tie-break with ties resolved toward the ticker channel; the Yandex rule of **fewest missing ASVI weeks, then fewest unexplained discontinuities**; the **300**-complete-case screen; the **0.5** panel-coverage fraction defining a panel-void week; the **8**-week trailing ASVI window; the crisis rule of **2×** the trailing **52**-week median with **≥26** observations, the **30%** missing-bar stress threshold, the **≥2**-consecutive-week **≥50%**-of-panel closure bar, and one-week gap merging; the **≥25%-of-voting-shares** SOE rule with look-through and **UNDETERMINED** as a valid outcome; the **4**-week Chow buffer with **≥60/≥60/≥140** minimum observations; and the exact M1/M2/M3/M4/M5/M6 regressor lists. No method was substituted because it was easier, no threshold was moved, and no criterion was relaxed.

Where a gap could **not** be filled by the original criteria, it was left open and disclosed rather than closed with a substitute:

* The **Yandex choice** was not recorded. It was recovered by applying the stated rule to the recorded candidate numbers, and independently confirmed by re-execution. Both routes give **(b)**.
* **`M4b`** was not recorded. It was recovered by executing the specification as written in the inherited code — not by designing a replacement interaction.
* **Two OFAC evidence tables** could not be produced at all, because their input file is absent from the archive. They are **reported as missing**, not reconstructed from the surviving pickles or from any secondary source.
* **The OFSI evidence** could not be recovered: the file is a 404 page. The sanction evidence base is reported as resting on **one** machine-readable primary list, not three (§L6).
* **The `BORDERLINE` list** was not extended to include TGKA, despite TGKA's 26.0% sitting one point above the SOE threshold, because extending it after observing that the H6 interaction is insignificant would itself be a result-driven change. The omission is disclosed at §L12 instead.
* **SBER's stale SOE basis** (08.05.2020, naming a holder that has not existed in that form since April 2020) was **left exactly as the inherited rule produced it**. Upgrading it to a current documented basis would have been substantively defensible and would have strengthened the table — and would have been a change made during the recovery to a stage-3 determination, which is not this agent's call. It is flagged at §5 and §L11.

**3. Every point at which the above could be questioned is disclosed explicitly.**

* **The recovery re-ran the regressions, which Agent 2's brief said not to do unless the inputs were inconsistent.** The inputs *were* consistent — all 74 modelled firms are exactly the 74 screening survivors, and the audit's exhaustive rebuild found zero differences across 29,008 company-weeks. The regressions were re-run anyway **because there was nothing to treat as final**: their entire output had been destroyed. The instruction presumes results exist; they did not. Re-running unmodified code carries no specification risk, and the re-run reproduces every inherited number exactly — so the outcome is the same either way. **Disclosed at §8.2 and in Agent 2's report §4.**
* **One file was patched.** `ofac_tight.py`'s `BANE` regex was syntactically invalid and the script could never have run — in the original run either. The patch is a minimal syntax repair in a **separate copy**, with the inherited original left untouched and a 30-line header documenting the defect, the fix and the safety argument. The script's output feeds nothing. **Disclosed at §8.3 and §L7.** A reader who considers any patch to inherited code out of bounds should note that excluding this file changes no number in this report.
* **Two of the recovery's own inferences were wrong and are corrected on the record**, with the original erroneous text left visible rather than deleted: the `NaN`-implies-version-drift claim, and the claim that the `29/29 PASS` tally was irreproducible (an inverted Python ternary). **Disclosed at §8.4**, and boxed at the point of error in the Agent 1 report.
* **The audit returned 29 PASS, 0 WARNING, 0 FAIL — and two of those PASSes are weaker than their labels.** Check `5b` verifies only that the rejection branch fired, not that the rejections were justified. Check `6`'s PASS condition includes a disjunct that stage 3 assigns to itself, covering 71 of 75 companies; behind its "14/14" are three material numeric disagreements (SBER 0.0 vs 50.0; VTBR 48.1 vs 87.0; FEES 83.5 vs 75.0) that happen not to change any classification. **Disclosed at §L1 and §L2.** A reader who wants the audit's clean scoreline to carry full weight should not have it.
* **The audit samples where it checks correlations (12 of 74) and SOE evidence (14 of 75).** Its end-to-end replication, lag-alignment, M3-replication and panel-integrity checks *are* exhaustive, which is why they carry the weight. **Disclosed at §L5.**
* **`Crisis(t)` is a full-sample construction** and enters M1/M2 contemporaneously with the outcome, where it is not absorbed by fixed effects. Its stress rule is strictly backward-looking, so no week is labelled using later weeks' volatility, but the window-merging and adjudication are applied once across the panel. This is inherited design, not altered. **Disclosed at §L3.**
* **The H1–H6 mapping is a reconstruction**, stated as such by the pipeline's own author in `agent3_models.py`. No pre-registration document survives anywhere in the workspace or in the thesis archive (which contains only `Data/`). "Confirmed" and "disconfirmed" in this report mean *relative to that reconstruction*. **Disclosed at §0 and §L14.**
* **The Chow result is not robust to heteroscedasticity**, and the post-break sub-sample contains the panel's highest-volatility weeks. The rejection count is reported alongside the expected count under the null and with the caveat attached; the coefficient *direction* is reported separately from the F-statistic because it does not depend on the variance comparison. **Disclosed at §L10.**
* **The task framing said the run "stopped after completing stage 4 of 5, before stage 5 began." The evidence contradicts this** — the audit ran to its final statement, and it is the *reporting* stage that never began. This report does not adopt the framing's description of what was interrupted. **Disclosed at §8.1.**
* **The provenance of the sole surviving output is undocumented**: `report_numbers.json` was written by a script that is not in the archive. Every number in it that could be compared was compared against an independent re-derivation, and all matched except the `m3` row count. **Disclosed at §8.1, §8.2, §8.4 and §L16.**
* **This report's own descriptive additions are labelled as such.** The per-company SOE split (§H6), the correlation between M1 and M2 attention coefficients (§H2), the binomial tests against the Chow null (§H4), and the Cyrillic-share and raw-count-correlation comparisons (§2) were computed for this report and are **not** part of the inherited pipeline. Each is flagged where it appears. None was used to reach a verdict on any hypothesis; the verdicts rest on the pre-specified specifications.

**Statement.** No company, channel, control, event window, sanction date, ownership classification, specification or dependent variable was included, excluded, promoted, demoted, altered or completed on the basis of the result it produced. Every gap left by the interrupted run was filled by executing the original pre-specified criteria as they exist in the inherited code, with one minimal, documented, result-inert syntax patch to a file that could never otherwise run. Where a gap could not be filled that way, it was left open and disclosed. Where the recovery process's own reasoning was wrong, it was corrected on the record with the error left visible. Where a `PASS` verdict is weaker than it appears, that is stated. And where the findings are null, or point against the study's hypotheses, or survive only under a measure that was not pre-registered as primary, they are reported at the same prominence and in the same detail as the findings that came out.

---

## Appendix — files underlying this report

**Re-derived pipeline outputs, `analysis/out/` (44 files).**
*Stage 1:* `agent1_channel_table.csv` (75 rows — the correlation table), `agent1_yandex_table.csv`, `agent1_screening.csv` (75 rows — the screening report), `agent1_asvi_matrix.csv`, `agent1_svi_matrix.csv`, `agent1_decisions.pkl`, `panel_agent1.csv.gz`, `agent1_channel_diagnostics.csv`, `agent1_price_gaps.csv`, `rawbuild.pkl`, `price_gap_audit.csv`
*Stage 2:* `agent2a_crisis_windows.csv`, `agent2a_named_candidates.csv`, `agent2a_weekly_aggregates.csv`, `agent2a_moex_closure_check.csv`, `agent2a_closure_detail.csv`, `agent2a_sanctions.csv` (74 rows — the per-company sanction evidence table), `agent2a_events.json`, `agent2a_candidate_windows.csv`, `panel_agent2.csv.gz`, `uk_entities_russia.csv` (914 entities), `agent2a_uk_designations.csv`, `uk_russia_entities_all.csv`, `agent2a_uk_adjudication.csv`, `agent2a_uk_hits.csv`, `agent2a_ofac_tight.csv` *(adjudication queue only — see L7)*
*Stage 3:* `agent2b_soe.csv` (**75 rows — the SOE table with sources cited**), `agent2b_soe_flags.json`, `agent2b_shareholder_scrape.csv`
*Stage 4:* `agent3_m1_percompany.csv` (74), `agent3_m2_percompany.csv` (74), `agent3_summary.csv`, `agent3_m3_pooled.csv` (**28 rows, incl. the restored `M4b`**), `agent3_m4_chow.csv` (74), `agent3_m5_returns_pooled.csv`, `agent3_m6_distribution.json`, `agent3_results.json`, `panel_agent3.csv.gz`, `agent3b_permutation_inference.csv`, `agent3c_robustness.csv`, `agent3d_absR_diagnostics.csv`
*Stage 5:* **`agent4_audit.csv`** (29 rows × 5 cols — the PASS/FAIL/WARNING table), `agent4_audit.json`, `agent4_summary.json`

**Recovery artefacts.** `agent2_consistency_check.csv` (82 rows), `agent2_consistency_tally.json`, `recovered/agent2_consistency.py`, `analysis/src_patched/ofac_tight.py`, `logs/00_build.log` … `logs/14_agent4_audit.log`

**Companion reports.** `deliverables/AGENT1_inventory_and_triage.md` (with two boxed self-corrections), `deliverables/AGENT2_verify_and_complete.md`

**Inherited, unmodified.** `ws/` — the workspace archive exactly as extracted (102 files), including `ws/analysis/reports/report_numbers.json`, the sole surviving output of the original run, and `ws/analysis/src/`, its 20 unmodified scripts.

**Unproducible, disclosed.** `agent2a_ofac_name_matches.csv`, `agent2a_ofac_primary_hits.csv` (input `raw/sdn_advanced.xml` absent); a valid `raw/ofsi.json` (the file in the archive is a 404 page); `raw/shareholders/YNDX.html` (a 404 page).

**Reference literature, `books/` (7 PDFs).** Da, Engelberg & Gao, *In Search of Attention* (the SVI/ASVI measure) · De Long, Shleifer, Summers & Waldmann, *Noise Trader Risk in Financial Markets*, JPE 1990 · Swamy, Dharani & Takeda, *Investor attention and Google Search Volume Index: evidence from an emerging market using quantile regression*, RIBAF · *Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis* · Giles & Lieberman, *Bounds on the effect of heteroscedasticity on the Chow test for structural change*, U. Canterbury DP 9101 (→ L10) · Vlastakis & Markellos, *Information demand and stock market volatility*, JBF 2012 · *A Simple, Positive Semi-definite…* — **no extractable text layer on any page; attributed to Parkinson (1980) from the filename alone, not verified from content** (→ the `RV = ln(High/Low)` measure).

*End of report.*
