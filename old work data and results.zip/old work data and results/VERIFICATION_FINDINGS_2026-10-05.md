# Independent Verification of the Known Issues Register

**Date:** 5 October 2026 · **Verified against:** the two data zips (`yandex_final.zip`, `combined_panel.zip`) plus the three supplied documents (`FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md`, `AGENT_3_FINDINGS.md`).
**Method:** every item that can be tested on the files was recomputed from the raw panel and the control matrices. Models were re-implemented from the written specification in `FINAL_REPORT.md` (the `analysis/` scripts are not in the repo), so this is an independent replication, not a re-run of the original code.
**Integrity:** sha256 of every input file used is in `verify/out/input_manifest.json` (115 files). Every number below is regenerable from `verify/scripts/`.

---

## 1. Headline

**The register is accurate. Nothing in it is materially wrong, and the report's headline numbers are real.** I reproduced, to the decimal places printed in the report:

| Reproduced exactly | Report | My recomputation |
|---|---|---|
| M4 pooled ASVI coefficient | .001014 | **.001014** |
| M4 sample size | 29,642 | **29,642** |
| M4 within-R² | .1331 | **.1331** |
| M1 survivors' coefficients (RTKM, SNGS, LSRG, PHOR, MFGS) | −.039908 / −.033895 / −.021268 / −.016384 / +.046297 | **identical to 6 dp** |
| H5 interaction (ASVI×Div) | .007527 | **.007527** |
| H6 interaction (ASVI×SOE) | .006575 | **.006575** |
| B4 table, 9 tickers × 2 volume controls | — | **all 18 values identical to 4 dp** |
| C3 channel correlations (max .8066 TRMK; 0 firms ≥ .85) | — | **.8066; 0 firms** |
| E6 overlaps (204 / 85 / 217 / 3) | — | **204 / 85 / 217 / 3** |
| W1 ASVI definition in the founding paper | unresolved | **resolved — see §2** |

**Six things you should know:**

1. **W1 is answered, and it does not threaten the results.** The founding paper really does use `log of the median` (raw), not `median of logs`. I built the canonical series: it correlates **0.999764** with the shipped one, flips the sign of **37 of 30,532** values (0.12%), and leaves the H1 survivor set **unchanged**. This is now a one-line disclosure plus one robustness row, not a problem.
2. **"5 BH survivors" is knife-edge.** I get **6** (AFKS joins). The difference is entirely the HAC implementation: the report's calendar-gap-aware HAC4 gives AFKS p = .00519 (just outside BH), my gap-agnostic HAC4 gives p = .00223 (just inside). The report already flags AFKS as the marginal case under HAC8; it should be flagged for HAC4 too.
3. **The M4 row says "419 weeks"; the estimation sample spans 406 weeks.** The 13 empty weeks are structural: 9 ASVI warm-up weeks (2018-08-27 → 2018-10-22, ASVI_l1 impossible) and 4 weeks around the MOEX halt (2022-02-28 → 2022-03-21). Worth fixing the row, because 419 is the *grid*.
4. **The ROLO exclusion rationale holds — but it implies a wider screen than was run.** ROLO does have the coarsest price grid relative to its price level of all 75 firms (median step 1 kopeck = 0.49% of price). However **11 other firms sit within ~25% of that** (UKUZ, BLNG, MVID, BSPB, AVAN, CHMK, VTBR, FESH, MRKU, USBN, RNFT at 0.32–0.44%). Either state that the rule is a judgement about ROLO specifically, or apply it as a stated screen to all firms.
5. **Two documentation inconsistencies, neither fatal.** (a) MRKK runs with n = 277 complete weeks, below the documented "≥300 or excluded" rule — dropping it changes nothing (BH set identical), but the report should say why it stays. (b) C3's "all 74 non-Yandex firms in the sum branch" is really **73 computed + SFIN**, whose channel correlation is *undefined* (its Cyrillic channel is positive in only 30 of 419 weeks). The doc's own table already says 73 — the prose should match.
6. **Everything in the M1/M2/M4/H5/H6 core is real.** The models I rebuilt from the written spec land on the report's numbers. That is strong indirect evidence that the missing `analysis/` scripts did what the report says they did.

---

## 2. W1 / A1 / C2 — the founding-paper ASVI definition (RESOLVED)

The corpus PDF is the working-paper draft: **"In Search of Attention", Da, Engelberg & Gao, this draft June 3, 2010** (first draft March 1, 2009), 50 pp.

Page 13, equation (1), verbatim:

> `ASVI_t = log(SVI_t) − log[Med(SVI_{t−1},…,SVI_{t−8})]`
> "…where `log(SVI_t)` is the logarithm of SVI during week t, and `log[Med(SVI_{t−1},…,SVI_{t−8})]` is **the logarithm of the median value of SVI** during the prior eight weeks."

Table 7 (p.44) repeats the same form for the IPO tests: "…minus the log of the median SVI (w−9, w−2)."

So **Agent 3's L3-004 is correct and A1 is correct**: the founding paper takes the log of the median of raw counts; v2.0 takes the median of logs. For an 8-week (even) window these differ unless the two middle counts are equal.

**Empirical consequence, measured on your panel (new result).** I built `ASVI_canon = ln SVI_t − ln[median(SVI_{t−1..t−8})]` on `SVI_RAW` and compared:

| | value |
|---|---|
| rows with both forms defined | 30,532 |
| correlation | **0.999764** |
| mean difference (canonical − v2.0) | −0.00173 (sd 0.00807); mean absolute 0.0017 |
| sign flips | **37 rows (0.12%)** |
| range | identical [−2.00, 3.42] |
| M1 BH survivors under canonical form | **same 6** (RTKM, SNGS, LSRG, AFKS, PHOR, MFGS) |
| median \|Δβ\| across 74 firms | 0.00008; β correlation 0.9999 |

**Verdict:** the mismatch is real and must be disclosed, but it is empirically immaterial. The two forms differ only when the 4th and 5th ordered counts in the window are far apart; Wordstat counts in this panel are rarely that far apart. Files: `verify/out/canonical_asvi.txt`, `out/m1_canonical.csv`.

---

## 3. Verdict table by register item

| Item | Verdict | Evidence |
|---|---|---|
| **A1** median/log | **CONFIRMED** (and quantified, §2) | PDF p.13; panel recomputation |
| **A2** `RETURN_RAW` keeps the CA jump | **CONFIRMED** | 4 CA rows: RAW = VTBR +8.483, GMKN −4.514, PLZL −2.314, ROLO −2.219; SAFE = NaN on exactly those 4 rows; 495 vs 499 NaNs overall, so they differ nowhere else |
| **A3** definitional differences | **CONFIRMED** | 587 record dates / 63 payers in `data1/dividend_record_dates.csv`; Crisis∩Sanction = 204 (step) and 3 (reaction union) both reproduce; `FINAL_COMPLETE_METHODOLOGY.md` absent |
| **A4** what is / is not in the repo | **CONFIRMED** | control matrices present in `yan 2/data1/`; `FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md` supplied separately; `analysis/`, `gl_bounds_published.csv`, `agent2b_soe.csv`, `news_i_t.csv` absent from both zips (directory walk) |
| **A5** "nearly identical slopes" overstated | **CONFIRMED** | B4 reproduced exactly, including PHOR −.0171 → −.0131 |
| **B1** prices not split-adjusted | **CONFIRMED** | VTBR 0.041 → 96.33 at the 5000:1 week |
| **B2** four `CA_FLAG` rows | **CONFIRMED** | exactly 4, notes as stated; 17 `CA_CANDIDATE_FLAG` rows (ABRD, BLNG, IRKT, PIKK, RNFT, ROLO, ROSN, SBER, SFIN, UKUZ, UNAC, VJGZ×2, VTBR, YAKG×2, YNDX) |
| **B3** volume vs value break | **CONFIRMED to 3 dp** | VTBR −8.066/+0.172; GMKN +4.823/−0.016; PLZL +1.699/−0.393; ROLO +3.821/+1.747 |
| **B4** simplified rerun table | **CONFIRMED exactly** | all 9 tickers × 2 controls to 4 dp (`out/B4_table.csv`) |
| **B5** split-signature scan | **CONFIRMED** | 3 weeks above ln 10 (VTBR 8.456, GMKN 4.543, PLZL 2.324); ROLO max 2.169 = 8.75× |
| **B6** SFIN 2025-12-22 | **CONFIRMED as data** | prior RV .136 → event week RV .678, next .055; flagged candidate only, not masked |
| **B7** partial-week flag | **CONFIRMED** | exactly 75 rows, all week 2026-08-31, all `N_TRADING_DAYS = 5` |
| **B8** daily→weekly round trip | **NOT TESTABLE** | daily source files (`moex_panel_data.zip`) are not in either zip |
| **B9** Sunday-label shift | **CONFIRMED, and sharper than stated** | panel `MOEX_WEEK_END_SUNDAY = SEARCH_MONDAY + 6`; every control matrix uses `week_sunday = week_monday − 1`. Join on Monday, never on the Sunday field |
| **B10** dividends ignored in returns | **CONFIRMED (by construction)** | `RETURN_SAFE` is a pure price return; no dividend adjustment anywhere in the panel |
| **B11** tick-size quantization / ROLO | **SUBSTANCE CONFIRMED, RATIONALE NEEDS RESTATING** | see §5 |
| **B12** trading-calendar claims | **PARTLY CONFIRMED** | on the panel: 328 no-trade ticker-weeks ✓, 7 H==L bars ✓, 6 Saturday sessions ✓, 3 full-market closure weeks ✓. SBER "416 weekly rows" and the official-announcement check: **not testable** without the MOEX weekly files |
| **B13** two runs | **CONFIRMED as recorded** | `EXECUTION_AND_BLOCKER_REPORT.md` carries n = 29,445, 404 weeks, within-R² = .161; the MOEX run gives 29,642 / .1331 (both now verified separately) |
| **B14** volume break contaminating spike tests | **STILL A HYPOTHESIS** | the spike tests live in the missing control-builder code; not testable from the panel alone |
| **C1** SVI/ASVI definition | **CONFIRMED** | `SVI_RAW = LATIN + CYRILLIC` on all 31,425 rows (0 exceptions); ASVI = LN_SVI − median(ln SVI t−1..t−8) on all 30,532 non-null cells, 0 mismatches; 56 zero-SVI cells = NaN (MRKC 26, MRKK 18, MRKS 4, MRKU 4, SFIN 2, UKUZ 2) |
| **C3** channel-combination rule | **CONFIRMED exactly, with one correction** | §4 |
| **C4** no issuer-level Wordstat validation in literature | **NOT TESTABLE here** (literature-search claim) | — |
| **C5** YNDX/YDEX | **CONFIRMED** | Latin `YNDX.csv` + Cyrillic `Яндекс акции.csv`; the string "YDEX" appears in no source path in the panel |
| **C6** 17-item registry | **CONFIRMED present** | §3.5 / Appendix C of the unified paper |
| **D5** M2 omits lagged volume | **CONFIRMED, and it matters at the margin** | report's M2 (no volume control) gives exactly 3 nominal: GCHE, FEES, PLZL ✓. Adding lagged lnV (as M1/M4 do) makes **LSNG** nominal at p ≈ .047 |
| **D6** MDE arithmetic | **CONFIRMED** | 2.802 × .001833 = .005135 vs reported .005132 |
| **D10** Chow / GL bounds | **CONFIRMED, with the correct reading in §6** | 5.206 / 3.372 / 18.127 all located in Table A3 (k = 4) |
| **E1** crisis windows | **CONFIRMED exactly** | four runs with the documented boundaries (8w / 6w / 3w / 6w), 23 weeks, all 75 firms = 1 in every window week |
| **E2** sanction step | **CONFIRMED** | 24 step companies, 11 distinct onset weeks, 2 onset weeks inside crisis windows (NMTP and VTBR, 2022-02-21) |
| **E3** SOE | **CONFIRMED (map), still PROVISIONAL (H6)** | §5 table parses to 35 SOE=1 / 40 SOE=0 / 0 UNDETERMINED; tiers A 72 / B 3 (LKOH, SNGS, CBOM) |
| **E4** dividends | **CONFIRMED** | 587 rows, 63 payers, all `confirmed-paid`, sources = aggregator URLs (SL/DH/TB/ZR); 18-row exclusion audit present |
| **E5** news | **CONFIRMED absent** | `news_i_t.csv` not in either zip |
| **E6** overlaps | **CONFIRMED exactly** | 204 / 85 (55 in the 2026 window, 29 tickers) / 217 / 3 |
| **F** literature corpus | **ALL 7 FACTS CONFIRMED** | §6 |

---

## 4. C3 — the channel rule, verified and corrected

Computed exactly as §3.2 defines it — Pearson correlation of the **ticker-channel ASVI against the Cyrillic-channel ASVI** on overlapping valid weeks:

- **MAX = 0.8066 (TRMK)** — matches the documented 0.8066 to 4 dp.
- **0 of 74 firms reach 0.85** → the all-SUM-RAW branch is correctly applied.
- The documented low end also verifies: AVAN .0598, BANE .0818, RASP .0949, FEES .1290, MGTS .1590, UTAR .1619.
- **Correction:** **SFIN's correlation is undefined** (its Cyrillic channel is positive in only 30 of 419 weeks, so it never has a valid 8-week baseline). The sweep is therefore **73 computed + SFIN not computable**, which is what the doc's own summary table says (73) even though the headline prose says "all 74".
- **Trap to keep documented:** correlations of raw channel *levels* are much higher (max 0.935 TRMK, 5 firms > 0.85). Anyone recomputing this test on levels or logs instead of ASVI would move several firms across the threshold. The rule must always be stated as ASVI-vs-ASVI.

---

## 5. B11 — the ROLO rule, and what it implies

I tested the stated rationale ("one-kopeck price grid mechanically quantizes RV") two ways.

**The rationale is substantively right.** Ranking all 75 firms by relative grid coarseness (median gap between distinct weekly closes ÷ median price), **ROLO is 1st of 75** (median step 0.01 = **0.49% of its median price of 2.03**). ROLO's typical step is indeed one kopeck.

**But ROLO is not alone.** Eleven firms sit within ~25% of ROLO's relative grid:

| Firm | median price | median step | step as % of price |
|---|---|---|---|
| ROLO | 2.03 | 0.0100 | 0.494% |
| UKUZ | 912 | 4.00 | 0.439% |
| BLNG | 10.18 | 0.040 | 0.393% |
| MVID | 205.5 | 0.80 | 0.389% |
| BSPB | 90.85 | 0.345 | 0.380% |
| AVAN | 812 | 3.00 | 0.370% |
| CHMK | 4085 | 15.00 | 0.367% |
| **VTBR** | 0.038 | 0.0001 | **0.340%** |
| FESH / MRKU / USBN / RNFT | — | — | 0.32–0.33% |

In the 2018–2021 subperiod AVAN's relative grid (0.66%) is *coarser* than ROLO's (0.50%). And the [HYP] in B11 about **VTBR before consolidation is confirmed in relative terms** — its 5-decimal quotes at ~0.038 RUB give it a relative grid comparable to ROLO's.

**What I could not find:** any visible *outcome* signature. ROLO has 0% identical consecutive RV pairs and no RV == 0 weeks — its RV series (median 0.084, the highest of the firms I checked) does not look quantized. **Verdict:** the exclusion is defensible as a judgement about the coarsest grid in the panel, but as written ("ROLO because of its grid") it reads as if ROLO were uniquely coarse. Either say that explicitly, or screen all 75 firms on this statistic and show the results.

---

## 6. D10 — the Giles–Lieberman numbers, verified against the published table

All three values are in `canterbury-nz-034.pdf`, **Table A3 (k = 4, nominal 5%)**, θ = 0.1 column:

| Value | Table A3 row | θ = 0.1 column | CL |
|---|---|---|---|
| **5.206** | T1 = T2 = 40 | Cu = 5.206 | 2.499 |
| **3.372** | T1 = 40, T2 = 10 | Cu = 3.372 | 2.594 |
| **18.127** | T1 = T2 = 10 | Cu = 18.127 | 3.259 |

Also verified: the paper's own worked example (pp. 12–13) shows the intended procedure — compute θ̂ (= 0.297 there), read the **θ = 0.1** column, and state the conclusion over the interval ("…we can reject when 0.1 < θ < 1"). That is what the register's "Cu(0.1,10]" notation is doing, and it is a faithful reading.

Three residual points, all of which support the report's decision **not** to threshold the HAC-Wald against these numbers:

1. The paper's Conclusions state these bounds apply **only to the form of the test that allows a structural shift in the full coefficient vector** — a subset-restriction test (your q = 3) is a different statistic.
2. The tabulation is indexed by **k = the number of coefficients in the full-vector test** (numerator df). A 3-restriction test would read **Table A2 (k = 3)**, where T1 = T2 = 40, θ = 0.1 gives **Cu = 5.501**, not 5.206. That is the concrete content of the disclosed q = 3 vs k = 4 mismatch.
3. The tabulation stops at T1 = T2 = 40, while the actual regime split is roughly 183 / 236 weeks — so no published row matches the sample.

---

## 7. What this changes for the thesis (recommendations)

1. **Add the canonical-form robustness row.** It is pre-computed in `verify/out/m1_canonical.csv`; the sentence is: "replacing the v2.0 ASVI with the founding-paper form `ln SVI_t − ln[median(SVI_{t−1…t−8})]` changes the survivor set by zero firms and the median coefficient by 0.00008."
2. **State the HAC convention and the AFKS knife-edge.** Report that AFKS sits at q = .064 under the gap-aware HAC4 and q = .028 under a compressed-date HAC4, so the headline is "five survivors, with AFKS marginal". Better: report *6 of 74* under the gap-aware HAC if that is the primary implementation.
3. **Fix the M4 row:** 406 weeks in the estimation sample (9 ASVI warm-up + 4 halt weeks), not 419.
4. **Note MRKK:** n = 277 complete weeks, below the stated ≥300 screen; the BH set is identical with and without it, so keep it and say so in one line.
5. **Restate C3 as 73 computed + SFIN undefined**, and keep the "ASVI-vs-ASVI, never levels" note attached to the rule.
6. **Decide on the grid screen (B11):** either add the relative-grid statistic as a documented screen, or add one sentence that the ROLO exclusion is a specific judgement.
7. **Ask for `moex_panel_data.zip`** if you want B8 (the 282,825-cell round trip) and B12 (SBER 416 rows) closed. Those are the only large items still open, and both are cheap to check once the daily files exist.
8. **Nothing here requires changing the abstract or framework text.**

---

## 8. What I could not verify, and why

| Item | Reason |
|---|---|
| B8 round trip, B12 SBER row count / official calendar | daily MOEX files absent from both zips |
| Which column the missing scripts read (A2) | `analysis/` absent |
| Control-layer price provenance (B13) | builder code absent |
| B14 contamination of spike tests | spike-test code absent |
| C4 literature absence claims, D3/D4 | literature-search claims, not file facts (Agent 3's Round-2 work covers these) |
| CA ratios vs issuer/exchange sources (B2), dividends vs issuer filings (E4) | external-source verification; I did not fetch issuer or exchange documents |
| M3 / M5 / M6 numbers | not re-run in this pass (M1, M2, M4, H4–H6, and every panel-side quantity were) |

---

## 9. Reproducing this verification

| Script | Produces |
|---|---|
| `verify/scripts/load_panel.py` | `out/panel.pkl` (31,425 rows), `out/panel_hashes.json` |
| `check_B.py` | `out/check_B.txt` — all panel-side B items |
| `build_est.py` | `out/est.pkl` — panel + Crisis/Sanction/Div, gap-aware lags, join-trap check |
| `run_M1_M4.py` | `out/run_M1_M4.txt`, `out/m1_replication.csv`, `out/m2_replication.csv` |
| `probe_M4.py`, `probe_r2.py` | covariance variants; the two within-R² definitions |
| `canonical_asvi.py` | `out/canonical_asvi.txt`, `out/m1_public.csv`, `out/m1_canonical.csv` |
| `B4_repro.py` | `out/B4_table.csv`, `out/B4_repro.txt` |
| `check_C3_E6.py` | `out/check_C3_E6.txt`, `out/channel_corr.csv` |
| `run_H456.py` | `out/run_H456.txt` — H4 joint Wald, H5, H6 |
| `final_checks.py` | `out/final_checks.txt` — crisis windows, ROLO grid, file-absence audit |

Input hashes: `verify/out/input_manifest.json`.
