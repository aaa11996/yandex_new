# Stage 1 - QA loop controller report

**Score: 10.00/10** · loops: 1 · rubric 12.0/12 normalised to 10

The rubric weights given in the brief sum to 12 while the mandated scale is 0-10. The score is therefore `10 x points / 12`, which preserves the brief's relative emphasis exactly and yields 10.00 only when every item is fully satisfied. No item is ever part-paid for a partial pass: a failing test forfeits its whole weight.

| item | requirement | weight | earned | test | evidence |
|---|---|---|---|---|---|
| QA1 | IMOEX downloaded successfully, complete, no gaps, validated | 2 | 2.0 | T1 | 2206 sessions (2018-01-03 .. 2026-10-05); gaps > 5 calendar days: 2 (suspension 1, holiday 1, unexplained 0) |
| QA2 | weekly aggregation matches the provided *_weekly.csv (100 %) | 2 | 2.0 | T3 | 75/75 tickers cross-checked; 31097 bars / 186582 values compared at 1e-9; mismatches: 0; missing reference files: 0 |
| QA3 | date alignment perfect (-6 day rule, Mon-Sun, zero orphans) | 2 | 2.0 | T4 | 75 tickers / 31425 rows; violations: 0 |
| QA4 | search data intact (SVI, canonical ASVI, zero counts -> NaN) | 2 | 2.0 | T5 | grid = 419 weeks 2018-08-27 .. 2026-08-31; 75 combined + 75 search frames checked; problems: 0; canonical ASVI cells 30532, delivered ASVI cells 30532, zero-SVI cells 56 (expected 56) |
| QA5 | combined files correct column order, encoding, structure | 2 | 2.0 | T8 | 75 files round-tripped; 1225575 values compared; mismatches: 0; column order == the 39-column mandate for all 75 files; encoding utf-8-sig; missing cells empty |
| QA6 | raw data folder complete (300 files, hashes match) | 1 | 1.0 | T9 | raw files: 300 (expected 300), 300 sha256 verified, 0 mismatched, 0 structural problem(s); combined manifest: 75 entries, 0 problem(s) |
| QA7 | all automated integrity tests pass (Tests 1-9) | 1 | 1.0 | * | 11/11 integrity tests passed |

## Defects

None. Every rubric item is fully satisfied; the build proceeded to the Stage-2 Judge without a loop-back.

## Integrity tests as seen by Stage 1

| test | name | result | evidence |
|---|---|---|---|
| T1 | IMOEX completeness (rows + no unexplained gaps) | PASS | 2206 sessions (2018-01-03 .. 2026-10-05); gaps > 5 calendar days: 2 (suspension 1, holiday 1, unexplained 0) |
| T2 | IMOEX vs known event levels (report only) | PASS | 6 reference date(s): 3 inside the stated band, 3 outside but within the 30% escalation threshold, 0 SUSPICIOUS |
| T3 | weekly aggregation vs provided *_weekly.csv reference | PASS | 75/75 tickers cross-checked; 31097 bars / 186582 values compared at 1e-9; mismatches: 0; missing reference files: 0 |
| T4 | date alignment (Mon label, Sun end, +6 days) | PASS | 75 tickers / 31425 rows; violations: 0 |
| T5 | search grid consistency (419 weeks, identical everywhere) | PASS | grid = 419 weeks 2018-08-27 .. 2026-08-31; 75 combined + 75 search frames checked; problems: 0 |
| T6 | IMOEX weekly grid vs company grid (suspension alignment) | PASS | I MOEX grid identical to all 75 company grids; zero-trading weeks ['2022-02-28', '2022-03-07', '2022-03-14'] vs documented ['2022-02-28', '2022-03-07', '2022-03-14']; problems: 0 |
| T7 | no fabrication (NaN signature of the panel) | PASS | NaN cells in OPEN/HIGH/LOW/CLOSE/VOLUME/VALUE = 1968 (expected 1968, delta +0); no-trade weeks 328 (expected 328); RV NaN 335 = 328 + 7 H==L weeks; zero-SVI 56 (expected 56); CA rows 4 (expected 4); IMOEX NaN OHLCV 18 (expected 18); rows with RV == 0: 0 |
| T8 | round-trip (written CSV == in-memory panel) | PASS | 75 files round-tripped; 1225575 values compared; mismatches: 0 |
| T9 | file hash verification (raw data + combined manifest) | PASS | raw files: 300 (expected 300), 300 sha256 verified, 0 mismatched, 0 structural problem(s); combined manifest: 75 entries, 0 problem(s) |
| T10 | EXTENSION - independent reconstruction (bars + both ASVI forms) | PASS | 314250 values recomputed by an independent plain-Python path; weekly-bar mismatches: 0; ASVI canonical mismatches: 0; ASVI delivered mismatches: 0 |
| T11 | EXTENSION - weekend-session omission quantified & disclosed | PASS | ISS weekend sessions missing from the delivered daily files: 354 across 3 sampled ticker(s) (first missing 2025-03-01; per-ticker arithmetic 124 ISS weekend session(s) in 2018-08-27..2026-09-06 - 6 already present in the delivered file = 118 missing); panel left UNMODIFIED; disclosure written to weekend_session_audit.csv |
