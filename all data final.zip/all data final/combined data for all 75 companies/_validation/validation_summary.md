# Validation summary - IMOEX + combined panel

Generated: 2026-10-06T05:56:51 · script v2.0.0 · pandas 2.2.3 · Python 3.13.14

## Verdict

- **Stage 1 QA: 10.00/10** (rubric 12.0/12 normalised to 10, 1 loop(s))
- **Stage 2 Judge: 10/10 - READY FOR USE**
- Integrity tests: **11/11 passed**
- Publication: **YES**

## Panel

| item | value |
|---|---|
| companies | 75 |
| sectors | 13 |
| weeks per company | 419 |
| total rows | 31,425 |
| grid | 2018-08-27 .. 2026-08-31 (SEARCH_MONDAY) |
| columns | 39 (mandated order) |
| NaN cells in OHLCV | 1,968 (expected 1,968) |
| no-trade weeks | 328 |
| H == L weeks (RV = NaN) | 7 |
| zero-SVI weeks | 56 |
| corporate-action rows | 4 |
| ASVI canonical cells | 30,532 |
| ASVI delivered cells | 30,532 |
| cells where the two ASVI forms differ | 29,903 |

## IMOEX

| item | value |
|---|---|
| source | iss-api |
| API pages | 5 |
| rows saved | 2,206 |
| range | 2018-01-03 .. 2026-10-05 |
| in-progress session(s) excluded | 1 (2026-10-06 (session end 08:56:02 - still trading)) |
| sha256 | `d62c2215d92b50e8916396b5abff89dd0eccca967393020fabba06d7aaf40df9` |
| weekly weeks | 419 |
| zero-trading weeks | 3 (2022-02-28, 2022-03-07, 2022-03-14) |
| Saturday sessions inside the panel | 6 |

## Integrity tests

| test | name | result | evidence |
|---|---|---|---|
| T1 | IMOEX completeness (rows + no unexplained gaps) | PASS | 2206 sessions (2018-01-03 .. 2026-10-05); gaps > 5 calendar days: 2 (suspension 1, holiday 1, unexplained 0) |
| T2 | IMOEX vs known event levels (report only) | PASS | 6 reference date(s): 3 inside the stated band, 3 outside but within the 30% escalation threshold, 0 SUSPICIOUS |
| T3 | weekly aggregation vs provided *_weekly.csv reference | PASS | 75/75 tickers cross-checked; 31097 bars / 186582 values compared at 1e-9; mismatches: 0; missing reference files: 0 |
| T4 | date alignment (Mon label, Sun end, +6 days) | PASS | 75 tickers / 31425 rows; violations: 0 |
| T5 | search grid consistency (419 weeks, identical everywhere) | PASS | grid = 419 weeks 2018-08-27 .. 2026-08-31; 75 combined + 75 search frames checked; problems: 0 |
| T6 | IMOEX weekly grid vs company grid (suspension alignment) | PASS | I MOEX grid identical to all 75 company grids; zero-trading weeks ['2022-02-28', '2022-03-07', '2022-03-14'] vs documented ['2022-02-28', '2022-03-07', '2022-03-14']; problems: 0 |
| T7 | no fabrication (NaN signature of the panel) | PASS | NaN cells in OPEN/HIGH/LOW/CLOSE/VOLUME/VALUE = 1968 (expected 1968, delta +0); no-trade weeks 328 (expected 328); RV NaN 335 = 328 + 7 H==L weeks; zero-SVI 56 (expected 56); CA rows 4 (expected 4); IMOEX NaN OHLCV 18 (expected 18); rows with RV == 0: 0 |
| T8 | round-trip (written CSV == in-memory panel) | PASS | 75 files round-tripped; 1225575 values compared; mismatches: 0 |
| T9 | file hash verification (raw data + combined manifest) | PASS | raw files: 300 (expected 300), 300 sha256 verified, 0 mismatched, 0 structural problem(s); combined manifest: 75 entries, 0 problem(s) |
| T10 | EXTENSION - independent reconstruction (bars + both ASVI forms) | PASS | 314250 values recomputed by an independent plain-Python path; weekly-bar mismatches: 0; ASVI canonical mismatches: 0; ASVI delivered mismatches: 0 |
| T11 | EXTENSION - weekend-session omission quantified & disclosed | PASS | ISS weekend sessions missing from the delivered daily files: 354 across 3 sampled ticker(s) (first missing 2025-03-01; per-ticker arithmetic 124 ISS weekend session(s) in 2018-08-27..2026-09-06 - 6 already present in the delivered file = 118 missing); panel left UNMODIFIED; disclosure written to weekend_session_audit.csv |

## Findings & disclosures (data vs brief, reported - never modified)

### F1 - IMOEX Saturday sessions

- Brief asserted: IMOEX has no Saturday sessions; N_SAT_DAYS will always be 0 and that is correct.
- Measured: **6 Saturday session(s) inside the panel window; the actual session dates are 2018-12-29, 2021-02-20, 2024-04-27, 2024-11-02, 2024-12-28, 2025-11-01 and they sit in the weeks labelled 2018-12-24, 2021-02-15, 2024-04-22, 2024-10-28, 2024-12-23, 2025-10-27**
- Resolution: The truth is counted, not asserted: the IMOEX ISS feed really does print those bars, and the SAME six session dates appear in the company daily files. Making IMOEX_N_SAT_DAYS 0 would have meant discarding real exchange data.

### F2 - reference bands that the real data does not sit inside

| level | stated date | used date | IMOEX close | band | deviation vs midpoint |
|---|---|---|---|---|---|
| weekly | 2020-03-16 | 2020-03-16 | 2331.61 | [2500, 2700] | -10.32% |
| weekly | 2022-02-21 | 2022-02-21 | 2470.48 | [2000, 2100] | +20.51% |
| weekly | 2024-07-15 | 2024-07-15 | 3008.24 | [3100, 3300] | -5.99% |
| daily | 2020-03-18 | 2020-03-18 | 2112.64 | [2400, 2600] | -15.49% |
| daily | 2024-07-12 | 2024-07-12 | 2973.21 | [3100, 3300] | -7.09% |
| daily | 2026-08-29 | 2026-08-28 | 2114.93 | [2300, 2700] | -15.40% |

- Resolution: Reported, never modified. No value reaches the 30 % escalation threshold, so none is flagged SUSPICIOUS. The stated bands, not the ISS feed, are the suspect: the 2022-02-21 week really did close at 2,470 after the intraweek crash and partial recovery.

### F3 - weekend sessions missing from the delivered daily files

| ticker | ISS weekend sessions in window | of those, present in the delivered file | missing from the delivered file | first missing | last missing |
|---|---|---|---|---|---|
| SBER | 124 | 6 | **118** | 2025-03-01 | 2026-09-06 |
| GAZP | 124 | 6 | **118** | 2025-03-01 | 2026-09-06 |
| LKOH | 124 | 6 | **118** | 2025-03-01 | 2026-09-06 |

- `SBER`: 124 ISS weekend session(s) in 2018-08-27..2026-09-06 - 6 already present in the delivered file = 118 missing; the delivered file carries 8 weekend session(s) in total, 6 of them inside the panel window.
- `GAZP`: 124 ISS weekend session(s) in 2018-08-27..2026-09-06 - 6 already present in the delivered file = 118 missing; the delivered file carries 8 weekend session(s) in total, 6 of them inside the panel window.
- `LKOH`: 124 ISS weekend session(s) in 2018-08-27..2026-09-06 - 6 already present in the delivered file = 118 missing; the delivered file carries 8 weekend session(s) in total, 6 of them inside the panel window.

The panel is built **exactly as specified from the delivered daily files** and no value was altered. Company `VOLUME`, `VALUE`, `HIGH` and `LOW` are therefore understated in the affected weeks, which biases `RV = ln(H/L)` and `ln(V)` downward. This is a property of the delivered input, measured against the primary source, disclosed here so it cannot be mistaken for a processing error.

## Reproduction

```
python download_imoex_and_build.py            # download + build + QA + Judge
python download_imoex_and_build.py --offline  # identical, no network
python download_imoex_and_build.py --selftest # synthetic edge-case suite
```
