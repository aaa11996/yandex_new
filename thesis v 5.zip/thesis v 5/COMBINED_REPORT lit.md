# Web Search Queries and Market Movements

## Combined report — narrative and full appendices

**Prepared for:** Khandaker Asikh Iqbal (Asif), HSE University, Nizhny Novgorod

**Thesis:** *Web Search Queries and Market Movements: Evidence from the Russian Equity Market*

**Supervisor:** Prof. Andrey Aistov

**Prepared by:** the literature relay (ten-stage review), Arena.ai Agent Mode

**Date:** 20 October 2026

---

## About this document

It comes in two parts, and they are for different readers.

**Part I is the argument.** Fourteen sections, about an hour, no appendices needed. It states what the literature says, what the audit found, what the simulation measured, what the recommended design is, and what is left for Asif to decide. If you read one thing, read Part I.

**Part II is the evidence.** Every stage artefact reproduced verbatim — the method cards, the corpus reading, the search log and comparables, all thirty-one problems, the idea review, the hashed tournament plan, the simulation report, the supervisor answers, the decision sheet, the red-team audit — plus the two data tables that carry the package's claims and its sources. Nothing in Part II has been rewritten, softened or tidied for this document.

**Why both.** A synthesis that cannot be checked is an opinion. Part I makes claims; Part II lets a reader refuse to take them on trust — down to the individual source and its reading depth.

**Provenance.** Part I was written after Part II, and every number it quotes was re-derived from `stage6/SIM_RESULTS.csv` rather than from the prose in these appendices. Where Part I corrects an earlier stage (the power figure in P-31, the source count, two unsourced market-share numbers), the correction is recorded in the red-team report, Appendix J, rather than hidden by editing the history.

<!--TOC-->

<!--BREAK-->

# Part I · The argument

## How to read this document

This is the single combined report. It merges the eight delivered artefacts — the recommended path, the
answers to the supervisor, the decision sheet, the problem register, the simulation study, the literature
skeleton, the reading list and the red-team audit — into one narrative that can be read start to finish or
dipped into by section.

It is written in plain English. Formulas appear only where a formula is the point. Every number is traceable
to a file in the package: the report says which one.

| If you have | Read |
|---|---|
| 10 minutes | §1 (the answer in one page) and §11 (what to do, in order) |
| An hour | §1–§5, then §8 (the eight decisions) |
| A supervisory meeting | §2 (the five findings) and §9 (the eleven answers) |
| A defence coming | §6 (problems) and §10 (what an examiner will attack) |

**Three conventions used throughout.** A claim marked **VERIFIED** was read in the source itself and the
excerpt is in `evidence/`. **VERIFIED-CODE** means it was produced by code in this package and can be
re-run. **HEARSAY / GAP / UNVERIFIED** means exactly what it says and nothing may be built on it. The full
list of thirty load-bearing statements is `CLAIMS.csv`.

> **What this package does not contain.** It does not estimate a single coefficient on Asif's real search
> data. That was a deliberate constraint, held throughout: no regression, no GARCH-X, no HAR-X, no MIDAS
> with the real attention variable against a real outcome. Everything quantitative below comes either from
> the published literature or from simulated panels calibrated to the observed moments. The reason is
> simple — if the design has already been shown to be under-powered, the thesis should know that before it
> spends its one shot at the data, not after.

---

## 1. The answer in one page

**Keep the question. Change what counts as an answer.**

The thesis asks whether unusually heavy Yandex searches for a company say something about that company's
shares the following week. After reading the literature, auditing the methodology and running a
pre-registered synthetic tournament, three things are clear.

**First, the returns version is very probably unanswerable with 419 weeks.** A weekly return is mostly
unforecastable news. The effect being looked for is a few basis points; a weekly return has a standard
deviation of several percent. That is a signal-to-noise ratio of the order of 1:100 to 1:200 *(arithmetic
from a 3–4% weekly standard deviation against a 2–5 basis-point effect, not a citation)*. No estimator
recovers signal that is not there. The supervisor's instinct — that market-adjusted returns are awkward because they fluctuate around zero — is
right, though for a sharper reason than the one he gives: they fluctuate around zero because they contain
almost no signal.

**Second, the volatility version is answerable, but not as currently specified.** Volatility is persistent
and measurable from the high–low range, so a small effect is detectable. The simulation in this package
shows the pooled panel detects a coefficient of 0.005 with 96% probability, while the per-firm design would
need a coefficient of 0.029 — six times larger — to reach 80% power. The 74 per-firm regressions, currently
the main test, are the least powerful instrument in the package.

**Third, there is a theory that predicts a curve and the thesis fits a line.** Andrei and Hasler (2015)
derive that attention both speeds up information arrival (raising volatility) and reduces uncertainty
(lowering it). The net relation is increasing and convex: negative linear term, positive quadratic term. If
that is the truth and a straight line is fitted, the estimated slope is negative on average *even where
volatility rises*. The simulation demonstrates this exactly: against a U-shaped truth, a linear-only
regression returns −0.00795 (true average derivative −0.008) and is significantly negative in 100% of 400
replications. That is a confident, publishable, wrong answer.

**So the recommended path is:** volatility as the primary outcome; the pooled panel and Fama–MacBeth as the
primary estimators; linear **and** squared attention in every table; the 74 per-firm regressions demoted to
a heterogeneity display; the 2022 break treated as a central object rather than an appendix; and the
measure validated against non-price data before any regression appears.

None of this discards the thesis. It converts a likely null into a powered result, and it gives the
negative Russian evidence a constructive role: the study becomes a test of whether firm-level Wordstat
attention still carried information after Google left the Russian market.

---

## 2. The five findings that matter

### Finding 1 — One of the supervisor's references does not say what it is cited for

The ResearchGate paper on genetic-programming nonlinearity (*Forecasting stock market return with
nonlinearity: a genetic programming approach*) is an index-level **forecasting** paper. It does not
establish a firm-level attention–volatility mechanism, and it does not provide a sign. If it is cited as the
theoretical foundation, an examiner who opens it will find a mismatch between the citation and the claim.

The arXiv paper the supervisor pointed to (1508.04332, Kroujiline et al.) is a distinct and more relevant
object: it studies search-query horizons and market dynamics. Its horizon logic is usable; its results are
about the aggregate market, not about 75 MOEX firms.

**What to do.** Cite Andrei & Hasler (2015) for the mechanism and its curvature, and cite the supervisor's
papers where they genuinely apply: the genetic-programming paper as a precedent for nonlinearity in
returns, Kroujiline et al. for the horizon argument. Both keep their place in the review without carrying
weight they cannot bear.

### Finding 2 — The strongest published evidence on this exact question is negative, and it is Russian

Bazhenov and Fantazzini (2019) put Google Trends into HAR, ARFIMA and GARCH(1,1) models for four liquid
Russian stocks. Result: no significant search effect on realized volatility, and **worse** out-of-sample
forecasts in several cases. Fantazzini and Shangina (2019) repeat the exercise on RTS futures and report
that several augmented models failed to converge.

This is not a reason to abandon the thesis. It is a reason to state the prior honestly, and then to say
what is different here: firm-level (not index-level) data, Yandex Wordstat rather than Google Trends, a
sample that is 60% post-2022, and a specification that allows the relation to be curved. A thesis that
names its negative precedent in the introduction is stronger than one that is surprised by it in the
conclusion.

### Finding 3 — The Russian attention space is crowded; the novelty has to be narrow and stated precisely

At least six Russian or Russia-focused studies occupy adjacent ground: Teplova & Gurov (2025) on intraday
trading invariants and Google search; Teplova et al. (2022) on social-network "hype"; Bazhenov & Fantazzini
(2019); Fantazzini & Kurbatskii (2026); Shaidullin et al. (2026); and the topic-level attention work in the
Lomonosov Economics Journal.

The defensible novelty is therefore not "attention and Russian stocks". It is: **firm-level weekly Yandex
Wordstat attention for the 75 MOEX firms, 2018–2026, with the post-Google-exit period as the object of
study and a nonlinear specification.** That is narrow enough to be true and specific enough to be checked.

**Do not claim "first".** The absence search (`stage3/SEARCH_LOG.csv`) was run in English and Russian and
found nothing identical, but eLibrary could not be searched deeply from this environment. The word "first"
would convert a search limitation into a false claim.

### Finding 4 — There is a theory that predicts a curve, and Russian work has not used it

Andrei and Hasler (2015) is the only paper in the corpus that derives a *shape* rather than a sign. Its
prediction — negative linear, positive quadratic, with a turning point — is testable with one extra column
and it makes the thesis falsifiable in a way that "does attention matter?" is not.

The simulation adds a warning that is worth putting in the thesis itself: when the truth is curved, the
linear coefficient is not "biased towards zero", it is **confidently wrong**. Reporting the linear slope
without the quadratic term is not a conservative choice.

### Finding 5 — The design's power is in the panel, not in the 74 regressions

Measured on simulated panels calibrated to the observed moments (ASVI standard deviation by size quartile
0.49/0.36/0.30/0.26; 16.6% common variance; AR(1) 0.55), 400 replications per cell:

| True β | Per-firm (74 tests) | Pooled TWFE | Fama–MacBeth | HAR-X |
|---:|---:|---:|---:|---:|
| 0.002 | 6.1% | 31.5% | 30.0% | 39.3% |
| 0.005 | **9.6%** | **96.3%** | **96.0%** | **98.5%** |
| 0.010 | 21.1% | 100% | 100% | 100% |

Per-firm 80% power requires β ≈ 0.029. **Caveat, stated wherever the 96% appears:** the simulated pooled
standard error is 0.72× the observed one, because week fixed effects absorb the common shock that inflates
the real Driscoll–Kraay error. All pooled figures are therefore **upper bounds**. They are still an order of
magnitude better than the per-firm design.

There is a second, more uncomfortable consequence. Applied to the five firms that survived Benjamini–
Hochberg in the existing results, the same arithmetic gives implausible magnitudes: RTKM's slope of −0.040
implies that doubling attention lowers its weekly range volatility by about 34% of its mean; LSRG −0.021
implies 18%; PHOR −0.016 implies 14%. Effects that large are not attention effects. They are what an
under-powered design produces when it finally rejects: the few estimates far enough from zero to clear the
bar, which are the ones contaminated by dividends, thin trading or a corporate event. **Report them as a
specification diagnostic, not as a finding.**

---

## 3. What the literature supports, and what it does not

Eleven methods were reviewed. For each, the question is not "is this a good method" but "what can it
support in *this* data". Full cards are in `stage1/METHOD_CARDS.md`.

| Method | What it can support here | Where it fails |
|---|---|---|
| Da–Engelberg–Gao ASVI | a validated abnormal-attention measure | the log-of-median vs median-of-logs detail must be exact |
| Fama–MacBeth | the average weekly cross-sectional slope, no beta needed | needs cross-sectional variation each week; thin weeks bite |
| Two-way FE + Driscoll–Kraay | the pooled slope with market-wide shocks absorbed | DK errors are optimistic when the common shock dominates (0.72×) |
| Per-firm OLS + BH | heterogeneity display | power 9.6% at β = 0.005 — cannot carry a hypothesis |
| Quadratic (Andrei–Hasler) | a test of the *shape*, a turning point | mildly liberal size (7.5%), must be reported with the linear term |
| Range volatility | a low-noise volatility proxy from daily OHLC | contaminated by ex-dividend weeks unless corrected |
| HAR / HAR-X | one-week-ahead forecast comparison | needs a hashed evaluation plan (declared NOT-DONE here) |
| GARCH(1,1)-X | a literature comparison | 50.5% convergence at T = 419; zero power — excluded |
| GARCH-MIDAS-X | weekly attention in the long-run component | no mature Python implementation; needs R `mfgarch` |
| Break tests (Bai–Perron, rolling) | whether the relation moved in 2022 | needs a pre-specified window, not a search |
| Permutation inference | a distribution-free check on the whole family | not a substitute for a pre-specified test family |

**The three claims that recur and are weaker than they look.**

1. *"Yandex Wordstat is better than Google Trends for Russia."* This is **HEARSAY** in this package. The
   supervisor attributes it to Fantazzini; the written paper in his list uses Google Trends. The Wordstat
   comparison exists only as a conference talk title (META2026, 2 October). Label it a personal
   communication until a draft appears. The citable argument for Wordstat is different and stronger: after
   Google's exit, Yandex is the only engine with continuous coverage of Russian users.
2. *"Russian attention research is thin."* It is not thin; it is crowded (Finding 3). What is thin is
   **firm-level weekly Wordstat** work.
3. *"The measure is validated because Da–Engelberg–Gao validated theirs."* Their validation is on their
   data. Asif's measure needs its own validation table (see §5, A4) — four correlations against non-price
   outcomes, before any regression.

---

## 4. The audit: thirty-one problems, eleven open

The register (`stage4/PROBLEM_REGISTER.md`) extends the six known issues in the supplied
`KNOWN_ISSUES_REGISTER.md` plus the twenty-two in the methodology's Appendix C to thirty-one, each with
evidence, severity, the hypothesis it affects, what the literature does about it, and status.

Severity means consequence for the thesis, not difficulty of the fix: **S1** can invalidate a conclusion,
**S2** biases or weakens it, **S3** is disclosure only.

| Region | Problems | The substance |
|---|---|---|
| Outcome measurement | P-01, P-12, P-19, P-25, P-29 | dividends inflate RV; ex-dates are derived; one-week horizon only |
| Measurement of attention | P-03, P-05, P-18, P-22, P-23 | median-of-logs; imposed loading of 1.0; the measure never validated |
| Design and power | P-04, P-16, P-26, P-27, P-31 | thin counts for small firms; no daily search data; MDE never stated in economic units |
| Inference | P-07, P-17, P-21, P-28 | HAC lag; forking paths; reverse causality; convergence reporting |
| Data quality | P-02, P-10, P-11, P-14, P-15, P-30 | share counts, sanctions coding, state-ownership labels, macro series, universe |
| Framing | P-06, P-08, P-09, P-13, P-20, P-24 | market-adjusted returns; break vs slope shift; circular crisis control; abandoned news layer |

**Six of the 31 are S1 and still open: P-01, P-06, P-23, P-24, P-27, P-31.** They are exactly the six that
Plan A addresses — the plan was built from the register, not alongside it.

The four that would end a chapter if unanswered:

- **P-01 (ex-dividend mechanics).** The vendor price series is not total return. In ex-dividend weeks the
  measured range is mechanically wider. Register L4 measures a 25% average change in RV in those weeks and
  62% of them move by more than 10%. Correcting returns but not the OHLC bars leaves the volatility outcome
  contaminated in precisely the weeks the dividend control is switched on.
- **P-23 (measure never validated).** Nothing in the current design checks that the Wordstat series measures
  attention rather than curiosity, a corporate event or a news spike. A four-line validation table fixes it.
- **P-24 (linear contradicts the only theory of sign).** See Finding 4.
- **P-31 (power never stated for the design).** Now closed by the simulation, including the correction of an
  earlier, wrong draft figure: per-firm power at β = 0.005 is **9.6%**, not ~35%.

---

## 5. Plan A — the recommended design, in five components

### A1 · The outcome: range volatility, dividend-corrected

Weekly range volatility from daily high and low, on dividend-adjusted bars. Register L4 measures mean RV at
0.1022, falling to 0.0762 once the dividend is added back to the highs and lows — a 25% correction in
ex-dividend weeks, arithmetic rather than modelling.

*Why it matters:* without this, part of any state-ownership or dividend result is a mechanical artefact of
the ex-date.

### A2 · The regressor: canonical ASVI, and its square

```
ASVI(i,t) = ln SVI(i,t) − ln median[ SVI(i,t−8) , … , SVI(i,t−1) ]
```

the founding paper's exact form (log **of the median**, not median of logs — register P-03; verified at
draft lines 92 and 364). Then a centred, z-unit square:

```
z(i,t)     = [ ASVI(i,t) − mean(ASVI) ] / sd(ASVI)
ASVI²(i,t) = z(i,t)²
```

Unit matters. In raw units the squared term is nearly collinear with the linear one and inflates the
linear coefficient by about 0.06; in z-units the inflation is 0.010 — the simulation shows mean +0.00997
against a true +0.010.

### A3 · The estimators: pooled and Fama–MacBeth, with the market on the right

**Primary (E1):** two-way fixed effects with Driscoll–Kraay errors, firm and week effects, the market return
entering as a regressor rather than being subtracted from the outcome:

```
RV(i,t) = α(i) + γ(t) + β₁·ASVI(i,t−1) + β₂·ASVI²(i,t−1) + δ·r^m(t−1) + ε(i,t)
```

**Cross-check (E2):** Fama–MacBeth — a cross-section each week, 419 weekly slopes averaged, which needs no
beta estimate and no market adjustment.

**Return outcome (E3, secondary):** absolute abnormal return as the dependent variable, because the *size*
of the move is what attention theory speaks about; and the market return on the right-hand side, so nothing
is generated.

**What this design deliberately does not do:** no GARCH-X (§7), no penalised search over query variants, no
news layer.

### A4 · Validation of the measure — the cheapest credibility in the package

Before any regression: four correlations between ASVI and non-price outcomes — trading volume, absolute
return, the number of news days, and turnover. If ASVI does not move with volume and with absolute returns,
it is not measuring attention and the rest of the thesis is moot. One table, one afternoon.

### A5 · Time variation — the supervisor's own idea, applied

A rolling 156-week coefficient plot for the ASVI slope, with the 2022 break marked. Three weeks of MOEX
closure (2022-02-28, 03-07, 03-14) sit in the middle of it. This is the component that turns the negative
precedent into a contribution: if the relation was alive before 2022 and dead after, the full-sample average
is a blend of two regimes and will look like nothing.

**Plan B, if the core fails or data stay thin.** (i) Decile portfolio sorts on z: top-minus-bottom, a
non-parametric version of the same question; (ii) an ASVI-spike event study around attention shocks;
(iii) reframe as a measurement paper — *"What does a Yandex search for a stock measure?"* — which is a real
contribution, is mostly descriptive, and cannot be refuted by an insignificant coefficient.

---

## 6. What the design can and cannot detect

`stage6/sim_lab.py` is a synthetic tournament in six blocks over seven data-generating designs: **4,650
simulated panels in total**, 150–400 replications per cell, seed 20261020, calibrated to the observed moments. It was written and hashed **before** it was run
(`stage5/TOURNAMENT_PLAN.sha256`, 2026-10-20T16:42:44Z; final run 16:55:50Z). Every figure below has a row in
`stage6/SIM_RESULTS.csv`.

### Size — honest, with one exception

| Specification | Rejection rate under the null |
|---|---:|
| S1 per-firm | 0.057 |
| S1 pooled | 0.052 |
| S2 linear term | 0.050 |
| **S2 quadratic term** | **0.075** — mildly liberal |
| S4 Fama–MacBeth | 0.058 |
| S5 HAR-X | 0.033 — conservative |

The quadratic term's own test is liberal at 7.5%. That is a fact to report, not to tune away; it is one
reason the reporting rule below pairs the two terms.

### Power — the numbers that change the design

| True β | Per-firm | Pooled TWFE | Fama–MacBeth | HAR-X |
|---:|---:|---:|---:|---:|
| 0.002 | 6.1% | 31.5% | 30.0% | 39.3% |
| 0.005 | 9.6% | 96.3% | 96.0% | 98.5% |
| 0.010 | 21.1% | 100% | 100% | 100% |

Per-firm MDE80 ≈ 0.029. Pooled ≈ 0.005, and even that is optimistic by 0.72×.

In economic units — effect of *doubling* attention, as a share of mean RV, using effect = β·ln2 ÷ 0.08 (the
dividend-corrected mean RV is 0.0762; 0.08 is used so the shares read as round numbers, and the scaling is
labelled approximate):

| Design | Detectable β at 80% | Doubling attention moves mean RV by |
|---|---:|---:|
| Per-firm | 0.029 | 25% |
| Pooled / Fama–MacBeth | 0.005 | 4.4% |

A genuine attention effect of 4.4% per doubling is small but real. The per-firm design can only see effects
six times larger — which is why its "insignificant" results carry no information.

### Robustness — measurement error, missing data, and the quadratic trap

| Stress | Result |
|---|---|
| Classical measurement error, +50% of signal variance | coefficient attenuates 0.00508 → 0.00313 (−38%); power 97.3% → 84.7% |
| +100% | mean 0.00233; power 72.0% |
| 5% of weeks missing | pooled power 93.2%, Fama–MacBeth 92.0% |
| 15% missing | 84.8% / 82.4% |
| **U-shaped truth fitted with a line** | mean slope −0.00795, significantly negative in **100%** of replications |
| Same truth, quadratic reported | mean +0.00997 (true +0.010), detected 100% |

### The ruling table

| Rule | Fired? | Consequence |
|---|---|---|
| DR-T1 (if per-firm size is acceptable, keep it primary) | **yes** | S1 pooled linear becomes primary; per-firm demoted |
| DR-T3 (if the linear estimator is biased, the quadratic becomes primary) | **no** — the linear estimator is consistent for the *average derivative* | quadratic stays mandatory-secondary, with the rule that **S1 and S2 are always reported together** |
| DR-T5 (if GARCH-X converges and has power) | **fails** — 50.5% convergence, zero power | GARCH-X **excluded**; literature discussion with the power table; GARCH-MIDAS-X as the extension |
| DR-T6 (no specification search) | honoured | no LASSO over variants, no post-hoc subsetting |

**Disclosed honestly:** DR-T3 was written as "S2 becomes primary if S1 is *biased*". Under the U-shaped
design the linear estimator turns out to be consistent for the average derivative, so the rule did not fire
and the plan's own wording had been mis-specified in advance. This is stated in the report rather than
retro-fitted.

**Declared NOT-DONE:** the forecast evaluation (HAR versus HAR-X, Diebold–Mariano, model confidence set).
It needs the real series and its own hashed plan, and it is not smuggled in as a result.

---

## 7. Why GARCH is not the main model — and what to say when asked

The supervisor asked for GARCH.augmented with the thesis's ideas. The answer is: yes, it has been done, on
Russian data, and it is the reason not to lead with it.

- **Bazhenov & Fantazzini (2019)** — HAR, ARFIMA and GARCH(1,1) with Google Trends for four Russian stocks:
  no significant search effect, worse out-of-sample forecasts in several cases.
- **Fantazzini & Shangina (2019)** — RTS futures; several augmented models failed to converge.
- **This package's simulation** — a weekly GARCH(1,1)-X at T = 419 converged in **50.5%** of 200 simulated
  series and had **zero** power for an effect that raises variance by 10%.

Running 75 of them and reporting the ones that converged is selective reporting — register P-28 forbids it.
The constructive alternative is **GARCH-MIDAS-X**, where weekly search drives the long-run component of
daily volatility: it uses the daily price data that exists, it is the architecture of Amendola, Candila &
Gallo (2021), and it is estimable. The practical obstacle is software: there is no mature Python
implementation, so the main-text approximation is U-MIDAS (unrestricted MIDAS, i.e. OLS with distributed
lags) and the true model becomes the extension if R's `mfgarch` is available.

---

## 8. Eight decisions that are yours

None of these is a technical detail. Each changes what the thesis is.

| # | Decision | Recommendation | Cost of the other branch |
|---|---|---|---|
| **D-1** | Returns or volatility primary? | **Volatility primary**, returns secondary with the market on the right | a main table that cannot distinguish "no effect" from "design too weak" |
| **D-2** | Report the quadratic term? | **Yes, always, in every table**, with the turning point | if the truth is curved, you write the opposite of what is happening |
| **D-3** | Keep 74 per-firm regressions as the main test? | **No** — panel carries H1, per-firm becomes heterogeneity | the main claim rests on the least powerful estimator |
| **D-4** | Correct RV for dividends, or only returns? | **Both** | a reviewer attributes part of any H5 result to the dividend |
| **D-5** | Run GARCH? | **No** — power table instead; GARCH-MIDAS-X as extension | a chapter of fragile fits and a hidden selection problem |
| **D-6** | Handle 2022 as appendix or centre? | **Centre it** — rolling coefficient, pre/post split | report a null that is really a mixture of two regimes |
| **D-7** | Keep the state-ownership hypothesis (H6)? | **Keep it but mark it provisional** and report the label problems | "How did you classify VSMO?" ends the chapter's credibility |
| **D-8** | If everything is insignificant? | **Report the MDE and write the measurement paper — decided now, in writing** | results become unfalsifiable and the thesis unmarkable |

D-8 is the one worth signing before the results arrive. It is not pre-registration — the results have
already been seen once — but it is a written commitment that the fallback is a real thesis rather than a
specification search.

**Not your decision.** The nine data-quality items and the two statistical corrections (log-of-median;
ln(VALUE) instead of share volume) are not preferences. They are errors, and fixing them is mandatory. If
the supervisor asks why the numbers moved, the answer is a correctness rule, not a choice.

---

## 9. The eleven answers the supervisor is owed

Short versions below; the file `stage7/ANSWERS_TO_SUPERVISOR.md` has the sendable text with sources.

**Q1 — He wants the draft with formulas fixed.** Agreed, and they are now fixed at four equations: ASVI as
log count minus log of the eight-week median; weekly range volatility on dividend-adjusted bars; a two-way
fixed-effects panel with linear and quadratic attention and Driscoll–Kraay errors; and a return model that
keeps the market return on the right-hand side. The draft order is literature review → data and measurement
→ models → results → discussion → conclusions, with a validation table for the measure before any
regression appears.

**Q2 — "Do the articles measure SVI and ASVI the same way?"** Da–Engelberg–Gao define ASVI as the log count
minus the log of the eight-week median and my measure is identical to that. Swamy et al. (India) and
Yoshinaga & Rocco (Brazil) use an abnormal search measure on weekly firm data, but the standardisation
differs — Yoshinaga works with lagged *changes* in search volume — so I state my formula explicitly rather
than claim identical construction. Two caveats: Wordstat returns counts, Google Trends returns a 0–100 index,
so the *input* differs even when the formula does not; and my sample is post-2018, so the comparison to
2011-era studies is on method, not on data.

**Q3 — "Why not GARCH?"** Because it has been done twice on Russian data with null results, and because at
419 weeks a weekly GARCH-X converges half the time and has zero power for a large effect (§7). I report it
as a literature discussion with a power table and offer GARCH-MIDAS-X as the estimable extension.

**Q4 — "419 observations can be fine for some models."** Agreed, and I can now say which. Enough for the
panel (96% power at β = 0.005, though optimistic); not enough for the 74 per-firm regressions (9.6% power at
the same β, MDE 0.029); not enough at all for GARCH.

**Q5 — "Try MIDAS."** Agreed in principle, and sequenced: GARCH-MIDAS with weekly attention in the long-run
component is the natural specification, but there is no mature Python implementation, so U-MIDAS is the
main-text approximation and true GARCH-MIDAS-X is the extension.

**Q6 — "Fantazzini and Kurbatskii (2026)."** That paper gave the review its most useful idea and its
sharpest warning. The idea: the value of online data is time-varying, so H3 should be a rolling coefficient
rather than a single break test. The warning: their abstract reports that Russian search data's predictive
power was significant before the early-2022 shift and degraded sharply afterwards. With 60% of the sample
post-2022, the subperiod analysis must be a main result.

**Q7 — "Fantazzini said Wordstat beats Google Trends."** I looked, and the written record says something
slightly different: the SSRN paper in your list uses Google Trends; the Wordstat comparison appears only as
a META2026 talk title ("…with Yandex Wordstat after Google's exit", 2 October). I will label it a personal
communication until slides or a draft appear, and I have built the Wordstat argument on a separate, citable
basis — after 2022 Yandex is the only engine with continuous coverage of Russian users.

**Q8 — "Did you use a Wordstat API?"** I downloaded manually; the scripted attempts looked rate-limited. The
current official route is the Wordstat API in Yandex AI Studio, whose `GetDynamics` method returns frequency
by month, week or day — if that confirms on ten test queries, weekly re-collection becomes scriptable.
Legacy Direct-API wrappers are dated and scraping is fragile and a terms-of-service risk.

**Q9 — "I am afraid of market-adjusted returns."** You are right, but the reason is signal-to-noise, not the
zero mean. Three fixes: put the market return on the right-hand side instead of subtracting it, so nothing
is generated; use Fama–MacBeth, which needs no beta at all; and make the main return outcome the *absolute*
abnormal return, the size of the move, which is what attention theory speaks about.

**Q10 — "The ideas are enough; keep the recommendation realistic."** Yes — Plan A is five pieces and every
one is standard software. Nothing outside pandas/statsmodels/linearmodels; the whole estimation runs in
minutes. The expensive options are in an extension layer that can be dropped without damaging the thesis.

**Q11 — "Does subtracting the cross-sectional average distort the signals, and does it remove the need for
crisis dummies?"** Subtracting does not specifically hurt small firms — the measured effect is the opposite
of the worry: it removes −9%/−17%/−26%/−22% of the variance from smallest to largest quartile, so it removes
least from the smallest, and it raises variance for 4 of 75 firms. Two real problems remain: noise differs
by size (ASVI s.d. 0.49 smallest vs 0.26 largest), and subtraction imposes a common sensitivity of 1.0 when
the measured loadings run 0.28–1.89. My proposal: do not subtract — week fixed effects do the job exactly in
the pooled model, and the per-firm models should estimate the sensitivity rather than impose it.

---

## 10. What an examiner will attack, and the answer

The red team (`stage8/RED_TEAM_REPORT.md`) audited the package adversarially. Its verdict was **conditional
pass**; the conditions are disclosure, not correctness. What it found, and how to handle it:

| Attack | Answer |
|---|---|
| "Your supervisor's own reference contradicts your mechanism." | It is a forecasting paper; the mechanism is cited from Andrei–Hasler. Stated openly in §2, Finding 1. |
| "You ran 75 regressions and reported 5." | Exactly — which is why the panel is now primary and the per-firm family is labelled heterogeneity with the MDE printed beside it. |
| "Your standard errors are too small." | Measured: the simulated DK SE is 0.72× the observed, so the power figures are upper bounds and are labelled as such. |
| "You chose the specification after seeing the data." | The tournament plan was hashed before the runs (`sha256sum -c` reproduces `OK`), and the one rule that had to be interpreted is disclosed rather than hidden. |
| "GARCH would have worked." | 50.5% convergence and zero power in the simulation; two Russian papers with null GARCH results. The power table goes in the appendix. |
| "Your Wordstat measure is unvalidated." | Correct in the current draft; A4 fixes it with four correlations before any regression. |
| "The five significant firms are your finding." | They imply 14–34% volatility changes per doubling of attention. They are a specification diagnostic (P-01, thin trading), not a finding. |
| "You never collected data weekly." | The Wordstat API `GetDynamics` aggregates by week; a ten-query test is the first task in §11. |

**Two things the package cannot answer**, and says so: the deep Russian-language search (eLibrary was not
reachable from this environment, so the absence claim is narrowed, never "first"), and the external canary
check by an independent reader.

---

## 11. What to do, in order

| Step | Action | Time | Result-blind safe? |
|---|---|---|---|
| 1 | Sign D-8 (the fallback decision) and D-1 to D-7 | 30 min | yes |
| 2 | Test the Wordstat API on ten queries; confirm weekly aggregation; record the settings | 1 h | yes |
| 3 | Rebuild RV from dividend-adjusted OHLC (A1) | 3 h | yes |
| 4 | The four-correlation validation table (A4) | 2 h | yes |
| 5 | Fix P-03 (log of median) and the volume denominator | 1 h | yes |
| 6 | Estimate A3 with linear and squared ASVI; report both always | 2 h | no — the first look |
| 7 | Rolling 156-week coefficient plot with the 2022 break (A5) | 2 h | no |
| 8 | Write up; put the MDE in the results section, not an appendix | 1 day | no |
| 9 | Hand `BEST_PATH_REPORT.md` §2 and the power table to the supervisor before he asks | 15 min | yes |

Steps 1–5 are all result-blind. That is deliberate: by the time the first coefficient appears in step 6,
every choice that could be made "to get a result" has already been made and written down.

---

## 12. What is still unknown

| Unknown | Effect on the thesis | How it closes |
|---|---|---|
| Whether the Wordstat API really aggregates weekly | decides whether the sample can be rebuilt properly | ten-query test (step 2) |
| Whether the relation survived 2022 | the central hypothesis | rolling coefficient (A5) |
| Why five firms survived BH with implausible magnitudes | whether H1 is contaminated or real | dividend correction + validation table |
| The exact ex-date derivation quality | contaminates 62% of dividend weeks | register P-12 rebuild |
| Whether the Wordstat talk has a written version | hearsay vs citation | ask the supervisor directly |
| eLibrary Russian-language coverage | the width of the novelty claim | a library session in Moscow |

---

## 13. The audit trail behind this report

| File | What it establishes |
|---|---|
| `stage0/W0_REPORT.md`, `READING_LIST_MASTER.csv` | the 18 supplied sources, with bibliographic anchors |
| `stage1/METHOD_CARDS.md` | 11 method cards: what each method can support |
| `stage2/CORPUS_READING.md` | the 7 corpus papers read in depth; R1–R8 support limits |
| `stage3/` | the search protocol, the comparables table, the narrowed novelty claim, the search log |
| `stage4/PROBLEM_REGISTER.md` | 31 problems with evidence, severity, fix and status |
| `stage5/IDEA_REVIEW.md`, `PROBLEM_TO_SOLUTION_MATRIX.md`, `TOURNAMENT_PLAN.md` (+ hash) | the design tournament, hashed before it ran |
| `stage6/sim_lab.py`, `SIM_RESULTS.csv`, `SIM_LOG.txt`, `SIM_REPORT.md` | the synthetic evidence for every power number |
| `stage7/` | the recommended path, the supervisor answers, the decision sheet, the literature skeleton, the reading list |
| `stage8/RED_TEAM_REPORT.md` | the adversarial audit and its conditions |
| `CLAIMS.csv` | 30 load-bearing statements with status and source |
| `sources.csv` | 54 sources with tier and reading depth |
| `evidence/` | 17 excerpts from the sources actually opened |
| `VALIDATION_REPORT.md` | the actual output of every automated check |

**Verification, as delivered:**

```
[PASS] csv-shapes: 7 CSVs · claim->source: 30 claims, 15 VERIFIED, links ok
[PASS] evidence: all FULL sources have an evidence file        RESULT: PASS
[PASS] schema: ok    [PASS] duplicate titles: none    [PASS] no phantom ids
TOURNAMENT_PLAN.md: OK      (hash unchanged since 16:42:44Z, before any run)
manifest: every file present with the recorded size and SHA-256
```

**The honest limits of that.** One context ran all ten stages, so the inbound audits are self-audits. Fifteen
sources are `NOT-OPENED` (standard classics used only to name methods). Seventeen are `ABSTRACT-ONLY`. The
register's K3/K7/L4 numbers are carried from a previous round and not re-derived here. All of this is
disclosed in the red-team report rather than buried; a package that hides its own near-misses is not
auditable.

---

## 14. One paragraph for the supervisor

> A literature and feasibility review of the proposed design was carried out against the eighteen supplied
> sources and the submitted methodology. The review identifies three substantive risks: the theoretical
> reference does not support a firm-level attention–volatility mechanism; the Russian evidence points to
> null or negative search effects, particularly after the 2022 structural break; and per-firm weekly
> regressions at the available sample size have low power for plausible effect magnitudes, while pooled
> estimation is better powered but sensitive to common shocks. A pre-registered synthetic tournament
> establishes which specifications can be trusted before any estimation on the research data. Thirty-one
> problems are documented with fixes, and the recommended path reframes the contribution around the
> post-2022 break and the measurement properties of Yandex Wordstat.

---

*Combined final report, 20 October 2026. Every claim above is traceable through `CLAIMS.csv` to a source id
or to code in this package. Where a number is approximate, it is labelled. Where a claim is not verified, it
is named as hearsay, a gap, or unverified — and nothing is built on it.*


<!--BREAK-->

# Part II · The evidence

The twelve appendices below are the package's source documents, in the order they were produced (ten stage documents, then the claim table and the source table). Headings are demoted one level so that they nest; the text is otherwise untouched.

Where an appendix refers to a section number of its own file, that number refers to the file, not to this document. Where it refers to `stageN/...`, the file exists in the delivered package.


<!--BREAK-->

## Appendix A — Reading map, inputs and the rules this package obeys

*Source file: `stage0/W0_REPORT.md`*

**Status: DONE. QA1 = 9/10.**
**Consolidation note.** The master prompt specifies nine files per stage (`W<k>_REPORT`, `W<k>_NOT_DONE`,
`W<k>_CLAIMS`, `sources.csv` additions, `W<k>_QA1_LOG`, `MANIFEST`, `W<k>_HANDOFF`). To keep the package
readable for Asif, each stage ships **one** `W<k>_REPORT.md` containing the Completion Table, the
NOT-DONE list, the claims table, the QA1 log and the handoff paragraph, plus its content files and a
`MANIFEST.csv`. Nothing required is omitted; only the filing is consolidated. This deviation is
declared here and repeated in `README_FOR_ASIF.md`.

### Completion table

| Task | Status | Evidence |
|---|---|---|
| Verify every input exists and opens | PARTIAL | 18 reading-list items; 12 opened at some depth, 2 not opened (L08, L09), 1 image-only (L12), 1 truncated (L16). See `READING_LIST_MASTER.csv`. |
| List every link in Appendix B (old and new) | DONE | L01–L11 plus the corpus L12–L18. The two links the user supplied on 2026-10-20 are L10 and L11. |
| Fix obviously broken links by search | DONE | The Yandex docviewer URL in the user's message is a viewer wrapper; the embedded target is `arxiv.org/pdf/1508.04332`, resolved to L11. The ResearchGate link for L10 resolved to DOI 10.1007/s12652-020-01762-0. |
| Create `STATE.md` | DONE | It did not exist in the repo or in the uploads, so this session is Stage 0. |
| `INPUT_MANIFEST.md` | DONE | `stage0/INPUT_MANIFEST.md`. |
| Helper scripts written and tested on dummy data | DONE | `verify_package.py`, `citation_lint.py`, `schema_check.py`; all three were run against the package; `verify_package.py` caught two real defects on its first run (unquoted commas in a CSV; a FULL source with no evidence file), both fixed. |
| Tool inventory | DONE | Python 3.13, pandas 2.2.3, numpy 2.3.5, statsmodels 0.15.0, linearmodels 7.1, arch 8.0.0, pypdf 6.x. No R. No repo write access (GitHub is read-only here). No sub-agents; stages run sequentially in one context. |
| Read `ASIF_CONSTRAINTS.md` and restate it | PARTIAL | **MISSING INPUT: ASIF_CONSTRAINTS.md.** Constraints are reconstructed from the master prompt, the methodology and the corpus, and every inferred constraint is labelled `INFERRED` in `CONSTRAINTS_SUMMARY.md`. |

### MISSING INPUTS (declared, not invented)

| File the prompt expects | Status | What this package does instead |
|---|---|---|
| `SUPERVISOR_LINKS_NEW.md` | **MISSING** | The user supplied two new links in the chat on 2026-10-20 (L10, L11). They are treated as the new-link input. Any further links the supervisor gave that are not in Appendix B are **not covered**. |
| `ASIF_CONSTRAINTS.md` | **MISSING** | Reconstructed with `INFERRED` labels. |
| `COMBINED_REPORT.md` | **MISSING** (not in repo, not uploaded) | Stage 2 verified references directly against the corpus PDFs and against `FINAL_REPORT.md`, `AGENT_3_FINDINGS.md` and the plain-English PDF, all of which are present. |
| `DATAFIX_AUDIT_BY_CLAUDE.md` | Deliberately excluded by the user ("you don't need this file") | Not read; no claim depends on it. The blueprint-round datafix outputs are in the repo and were not re-audited. |
| `THESIS_EXPLAINED.md` | Supplied as a 12-page PDF | Read (L: `My Thesis Explained in Plain English ... .pdf`). |
| `METHODOLOGY_v4_0_FINAL.md` | Supplied | Read. |
| `KNOWN_ISSUES_REGISTER.md` | Supplied | Read. |

### What the tool inventory means for what follows

- **No repo write access** — every file is produced locally and Asif carries it. No DONE stage is overwritten.
- **No sub-agents** — the conductor mode (Mode A) is emulated sequentially. The consequence is stated
  in `STATE.md`: the inbound audits are self-audits. They are still run against the files and the
  numbers, not against the prose.
- **No R** — every R-based recommendation (e.g. `midasr`, `mfgarch`) is flagged as a dependency Asif
  must confirm, not as something this package ran.
- **Web access is available but not complete** — SSRN PDF delivery failed; ScienceDirect is paywalled;
  the Nottingham eprint is 404. Reading depth records exactly this.

### QA1 log (layer 1)

| Criterion (2 points each) | Score | Note |
|---|---:|---|
| Every claim has a real, opened source with reading depth | 2 | Reading depths include the ugly ones (IMAGE-ONLY, TRUNCATED, PROGRAMME-ONLY). |
| No source presented with more authority than it has | 2 | The META2026 talk is PROGRAMME-ONLY and is used only for what a title can support. |
| Honesty (gaps and NOT-DONE listed, hearsay labelled) | 2 | Three MISSING INPUTS declared above; two unopened links declared. |
| Scope (every checklist item done or marked not done) | 1 | `ASIF_CONSTRAINTS.md` missing; Stage 0 is therefore PARTIAL on that one line. |
| Clarity (plain English, demos work) | 2 | Plain-English paragraph in the handoff. |
| **Total** | **9/10** | |

### Handoff to Stage 1 (plain English)

Everything the supervisor sent is now in one table with a status against each item: whether it opened,
how much of it opened, and what it can and cannot support. Two things are already clear and matter for
the rest of the relay. First, the programme of the conference the supervisor mentioned lists a talk by
Fantazzini and Kurbatsky called "Searching for inflation … with Yandex Wordstat after Google's exit",
which is **not** the same paper as the SSRN working paper in his list — that one uses Google Trends.
Second, the supervisor's newest two links are both about forecasting returns with a nonlinear model,
and neither uses search data at all, so they can inform the *estimation* but not the *measurement*.


---

*Source file: `stage0/INPUT_MANIFEST.md`*

Everything this package read, with size and SHA-256 where the file is in the workspace.
Accessed 2026-10-20. Paths are relative to `/home/user/litrelay/inputs/` unless stated.

### A. Files supplied by the user (uploads)

| File | Bytes | SHA-256 (first 16) | What it is |
|---|---:|---|---|
| `My Thesis Explained in Plain English Web Search Queries and Market Movements.pdf` | 313,609 | listed in `FINAL_MANIFEST.csv` | Asif's plain-English 12-page explanation, 17 Oct 2026 |
| `KNOWN_ISSUES_REGISTER.md` | 32,932 | listed in `FINAL_MANIFEST.csv` | Register with sections A–L; newest section wins |
| `METHODOLOGY_v4.0_FINAL.md` | 28,531 | listed in `FINAL_MANIFEST.csv` | The current design (7 Oct 2026) |
| `LITRELAY_MASTER_PROMPT.md` | 33,908 | listed in `FINAL_MANIFEST.csv` | The relay prompt itself |

### B. Repository (https://github.com/aaa11996/yandex_new, read 2026-10-20)

Root listing (8 objects): `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md` (47,621 B),
`README.md` (50 B), `THE_FINAL_MOEX_ASVI_METHODOLOGY_AND_DATA_COMPENDIUM_v3.md` (32,622 B),
`THE_v3_RESULTS_AND_DEFENSE_PLAYBOOK.md` (32,661 B), `all data final.zip` (17,735,866 B),
`blueprint_round.zip` (860,936 B), `moex_panel_data.zip` (3,994,057 B),
`old work data and results.zip` (530,627 B).

Extracted for this round:

| Archive | Contents used here |
|---|---|
| `all data final.zip` | `all data final/books/` — the 7 corpus PDFs; `combined data for all 75 companies/` — 75 firm files × 39 columns; `raw data/` — weekly Wordstat exports |
| `old work data and results.zip` | `FINAL_REPORT.md` (241 lines), `AGENT_3_FINDINGS.md` (164), `THESIS_HANDOFF_BRIEF.md` (371), `methodology_final.md` (v2.0), `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md`, the control matrices `crisis_i_t.csv`, `sanction_i_t.csv`, `sanction_reaction_i_t.csv`, `div_i_t.csv`, `div_i_t_long.csv`, `dividend_record_dates.csv` (587 rows), `event_overlap_summary.csv`, `phase1_exclusion_audit.csv`, plus the Sanctions/Crisis/News/Combined_Data documents |
| `blueprint_round.zip` | 249 files: datafix stage 1–3 packages (sanctions anchors, SOE blind classification, trading calendar, market series, corporate actions, checksums) |
| `moex_panel_data.zip` | daily and weekly MOEX bars per firm |

**Conflict with the register, resolved.** Register §L1 says `old work data and results.zip` has 43 entries.
The extracted archive has 43 files. Consistent.

**Correction to the prompt's data description.** The prompt (§1) says the panel holds "419 Monday-dated
weeks (2018-08-27 … 2026-08-31)". Verified from the v4.0 document and the register: 75 firms × 419 weeks
= 31,425 rows, and the pooled estimation sample is 29,642 after lags, ROLO exclusion and missing values.
Both numbers are used, with the distinction stated.

### C. Live web pages opened this round

See `stage0/READING_LIST_MASTER.csv` and `sources.csv`. Cached excerpts are in `evidence/`.

### D. Files this package did NOT receive

`SUPERVISOR_LINKS_NEW.md`, `ASIF_CONSTRAINTS.md`, `COMBINED_REPORT.md`, `DATAFIX_AUDIT_BY_CLAUDE.md`
(excluded by the user), `analysis/` scripts and results, `gl_bounds_published.csv`, `agent2b_soe.csv`,
`news_i_t.csv`. None of them is invented anywhere in this package.


---

*Source file: `stage0/CONSTRAINTS_SUMMARY.md`*

`ASIF_CONSTRAINTS.md` was not supplied. This file reconstructs the binding constraints from the four
input documents, the methodology, and the register. **Every line is labelled.** `INFERRED` means the
file did not say it and it is deduced from context; Asif must confirm or correct it before Stage 7 is
implemented.

| # | Constraint | Basis | Label |
|---|---|---|---|
| C1 | Software: Python (pandas/statsmodels/linearmodels) is the working stack; R is available to Asif but was not used to produce any earlier result, and no earlier result depends on it. | The methodology's environment is Python 3.13 / pandas 2.2.3 / numpy 2.3.5 / statsmodels 0.15.0. No R outputs appear anywhere in the corpus. | `INFERRED` |
| C2 | Level: Master's thesis in Finance, HSE Nizhny Novgorod, supervised by an econometrician; the reader is a Master's committee, not a research-frontier referee. | Appendix B Q10; register §H. | `STATED` |
| C3 | Time budget: the thesis is being written now (draft 17 Oct 2026), so any added method must be implementable in weeks, not months. | Plain-English PDF header: "working draft, 17 October 2026". | `INFERRED` |
| C4 | Data: 75 firms × 419 weekly observations; weekly Wordstat counts only (no daily search); daily MOEX prices; no implied volatility, no option data, no news-count matrix, no total-return index, no macro series retrieved. | Master prompt §1; methodology Part II §§16–18. | `STATED` |
| C5 | Computation: a laptop with Python; no cluster. The synthetic lab in Stage 6 ran on this sandbox in minutes, which is evidence that the recommended design is laptop-sized. | Stage 6 runtime log. | `VERIFIED` |
| C6 | Writing constraints: do not modify his abstract or framework text; new material goes in new files. | Register §I; methodology cover note. | `STATED` |
| C7 | Output language: English, with Russian terms transliterated where needed. | All documents in the corpus are English. | `INFERRED` |
| C8 | The supervisor reads formulas. He asked for the mathematical statement of every idea (Q1). | Appendix B Q1. | `STATED` |
| C9 | The supervisor is an econometrician with a strong forecasting orientation: his exemplars (Fantazzini & Kurbatskii; Fantazzini & Shangina; Bazhenov & Fantazzini) are all out-of-sample forecast evaluations with VaR/QLIKE/MCS. | S08, S17, S18. | `VERIFIED` (from the papers) |
| C10 | The committee will ask "why not GARCH?" and "why not MIDAS?", because the supervisor already asked. | Appendix B Q3, Q5. | `STATED` |

### What these constraints rule out

- A daily GARCH-X with daily search data: **no daily search data exists** (C4).
- A full GARCH-MIDAS-X estimation for all 75 firms in Python: **no mature Python package**, and R
  depends on C1. It is therefore an extension for a subsample, not the core.
- A news-supply control (Vlastakis–Markellos replication): **no news matrix** (C4).
- An implied-volatility horse race (Bazhenov–Fantazzini replication): **no option data** (C4). This is
  the single most important limitation to state honestly, because it is the reason their null result
  cannot be replicated or overturned directly.


---


<!--BREAK-->

## Appendix B — Method cards: what each method can and cannot support

*Source file: `stage1/METHOD_CARDS.md`*

Every item the supervisor supplied, old and new, with what it actually does and what a Master's
student can borrow from it. Reading depth is stated per card. Classification at the end.

---

### Card 1 — Fantazzini & Kurbatskii (2026), SSRN 6468200 [S08] · `ABSTRACT-ONLY`

| | |
|---|---|
| **Question** | Can online search data improve nowcasts and forecasts of regional CPI in Russia? |
| **Data and frequency** | Russian regional CPIs, monthly; Google Trends. Sample not stated in the abstract. |
| **How online data enters** | As an additional block of predictors in ARDL (nowcasting) and in ten forecasting approaches including VAR with Hierarchical Lasso (HLag), dynamic factor models and shrinkage. |
| **Model / estimation** | Random walk, ARIMA, ARDL; VAR-HLag; dynamic factors; shrinkage; random forests as a robustness check. |
| **Evaluation** | Out-of-sample forecast comparison (metric not stated in the abstract). |
| **Findings** | Nowcasting: multivariate ARDL with macro data wins; search adds "positive but limited" value. Forecasting: search adds **negligible average improvement because of a structural break in early 2022** — predictive power was significant before the geopolitical shift and degraded sharply afterwards. VAR-HLag with full macro data wins. |
| **Limitations** | Abstract only. It is a *CPI* paper: the target is a slow, administratively measured price index, not a financial volatility. Nothing in the abstract concerns stocks, volatility or Wordstat. |
| **What Asif can borrow** | Three things, all cheap: (i) the *idea* that the value of online data is **time-varying**, which converts his H3 from a single break test into a coefficient-path plot; (ii) penalised/sparse estimation when several query variants enter at once (Appendix A, A3–A4); (iii) the out-of-sample framing (benchmark model vs augmented model) instead of a coefficient-sign test. |
| **Relevance** | **CORE-METHOD** for how to handle online data; not CORE for the thesis question. |

> **This card contains the single most important warning in the whole package.** The supervisor's own
> reference finds that Russian search data **stopped helping after early 2022**. Asif's sample is
> 60% post-2022. If the same degradation applies to Wordstat attention for equities, the pooled
> 2018–2026 coefficient is a blend of a working pre-2022 relation and a dead post-2022 one — which
> is exactly the pattern that produces "no significant effect on average" while a real effect exists
> in a subperiod. H3 must therefore be presented as the *main* test, not as a robustness check.

---

### Card 2 — Fantazzini & Kurbatsky (2026), META2026 keynote [S09] · `PROGRAMME-ONLY`

| | |
|---|---|
| **Title** | "Searching for inflation: forecasting Russian regional prices with Yandex Wordstat after Google's exit" |
| **Venue** | META2026, HSE Nizhny Novgorod, Friday 2 October 2026, 09:00–10:00, guest-speaker slot |
| **Written version** | **Not found.** Searches on 2026-10-20 (English and Russian, SSRN/RePEc/MPRA/Google Scholar-style queries) returned no paper with this title. |
| **What it establishes** | That the Wordstat-vs-Google question is a live, current research topic in the supervisor's own network, and that the framing "after Google's exit" is the one the field is using. It does **not** establish any result about Wordstat being better, because a title cannot. |
| **What Asif can borrow** | The **framing**: Yandex is now the near-monopoly search engine in Russia, so a domestic search measure is not a second-best substitute for Google — it is the only representative one. This is the strongest available defence of the data choice and it comes from the supervisor's own conference. |
| **Relevance** | **CORE** for the supervisor conversation (Q6, Q7). Not a citable paper — cite the conference programme, label it as a talk. |

> **Resolution of the hearsay (Q7).** The supervisor reports that Fantazzini said Wordstat gives
> better information than Google Trends. What exists in writing is: (a) a paper [S08] that uses
> **Google Trends** and finds search data stopped helping after early 2022; (b) a **talk** [S09]
> whose title is about **Wordstat** after Google's exit. The two are different works. The claim
> "Fantazzini said Wordstat is better" therefore remains `HEARSAY`, but it is now *well-anchored
> hearsay*: the topic is confirmed, the comparison is confirmed, the direction of the result is not.
> Asif should say exactly this. Do not write "Fantazzini shows that Wordstat is better".

---

### Card 3 — Amendola, Candila & Gallo (2021), *Econometrics and Statistics* 20, 12–28 [S11] · `SECTIONS`

| | |
|---|---|
| **Question** | Which frequency should the components of a double asymmetric GARCH–MIDAS–X use, and does adding a market volatility index help? |
| **Data and frequency** | S&P 500 and NASDAQ indices; daily returns; a daily market volatility index as the exogenous variable; long-run forcing variable aggregated at alternative frequencies. |
| **How online/exogenous data enters** | Two places: the daily lag of the volatility index in the **short-run** component (the "–X"), and the same variable, aggregated, in the **long-run** component. |
| **Model** | DAGM–X–2K: GJR-type short-run component × MIDAS long-run component, with asymmetric positive/negative parts and a data-driven choice of the number of MIDAS lags. |
| **Evaluation** | Out-of-sample forecasts at horizons 1–60 days; Model Confidence Set. |
| **Findings** | The "–X" addition significantly improves performance and the model enters the MCS even at long horizons. |
| **Limitations** | Equity-index application; the exogenous variable is a *market volatility* index, i.e. already a volatility, not a search count. |
| **What Asif can borrow** | The **architecture**, which is precisely what his data allow: a daily-price model whose long-run volatility component is driven by a **weekly** variable. That is the natural home for weekly ASVI. The paper also gives him a defensible answer to "why not a plain GARCH-X?" — because the search variable is at a lower frequency than the price. |
| **Relevance** | **CORE-METHOD.** This is the best available template for the "GARCH with attention" that the supervisor asked for (Q3, Q5). |

---

### Card 4 — Liu, Choo, Tunde, Wan & Liang (2024), *PLoS ONE* 19(6) [S14] · `SECTIONS`

| | |
|---|---|
| **Question** | Do additive outliers degrade GARCH-MIDAS volatility forecasts, and does correcting them help? |
| **Data** | Chinese SSE and Japanese N225 indices, with CNY/USD and JPY/USD exchange rates, EPU indices and M2 as low-frequency variables. |
| **Method** | A weighting scheme replaces additive outliers; parameters are then re-estimated on the corrected return series. |
| **Findings** | Outliers substantially distort forecasts; the corrected AO-GARCH-MIDAS dominates on all criteria; realized volatility carries more predictive information than the other low-frequency factors. |
| **Limitations** | Chinese/Japanese indices; the correction is a weighting scheme whose details are in the full text, which was not opened. |
| **What Asif can borrow** | One concrete, two-hour job: treat the **242 dividend gaps and four corporate-action jumps** in his return and range series as additive outliers and correct them before any volatility model, rather than deleting the week. This is exactly the fix that Register P-01 and L4 are asking for, and here it is with a published precedent. |
| **Relevance** | **EXTENSION**, cheap and immediately useful. |

---

### Card 5 — Chevallier & Sanhaji (2023), *Stats* 6(4), 1339–1370 [S13] · `ABSTRACT-ONLY`

| | |
|---|---|
| **What it does** | Realized GARCH–MIDAS–X for Bitcoin and Ethereum: six jump-robust realized-volatility estimators; a MIDAS filter; and up to ten historical/implied volatility indices as exogenous "–X" variables, one at a time. |
| **Findings** | 30-day implied volatility indices are the best predictors; the model's gain comes from putting financial and technological variables directly into the volatility specification. |
| **What Asif can borrow** | Two things: (i) **jump-robust realized measures** — for weekly data, the range-based estimator is already jump-exposed, and a bipower/MedRV analogue from daily bars is the upgrade; (ii) the discipline of entering **one** exogenous variable at a time and comparing models, rather than a kitchen-sink regression. |
| **Relevance** | **EXTENSION.** Not core: crypto, intraday, and implied-volatility drivers that Asif does not have. |

---

### Card 6 — Zhang, Zhao, Cheng & Li (2025), *Statistical Papers* 66(4) [S10] · `ABSTRACT-ONLY`

| | |
|---|---|
| **What it does** | Embeds intraday high-frequency returns into a low-frequency GARCH to estimate **conditional quantiles**, with asymptotic theory, a model-checking statistic and simulations; applied to three stock indices. |
| **Why it is not a MIDAS paper for Asif** | Its "mixed frequency" is *intraday vs daily*, not *weekly search vs daily price*. It supplies no search-augmented model. |
| **What Asif can borrow** | One idea worth a paragraph, not a chapter: if the thesis ever moves to **risk management** (VaR), the natural outcome is a conditional quantile, and quantile GARCH is a defensible extension. Also: the supervisor's quantile interest is real, and Swamy et al. (2019) [S03] already gives Asif quantile regression in an emerging market. |
| **Relevance** | **BACKGROUND** as supplied. If reframed as "quantile regression of returns on ASVI" it becomes a legitimate EXTENSION with S03 as precedent. |

> **Honest note for Asif.** Three of the supervisor's links (Card 6, Card 7/Dhaene–Wu, and to a lesser
> extent Card 5) are about a *different* mixed-frequency problem from his. Saying so politely, with
> the reason ("the frequency axis is intraday-to-daily, while mine is weekly-to-daily"), is better
> than pretending they are central. The genuinely load-bearing ones are Cards 1, 2, 3 and 8.

---

### Card 7 — Dhaene & Wu (2016), KU Leuven DPS16.12 [S12] · `ABSTRACT-ONLY`

| | |
|---|---|
| **What it does** | Weekly/monthly **multivariate** volatility from five-minute and overnight returns; BEKK components with MIDAS weighting; four DJIA stocks. |
| **Findings** | Mixed-frequency models dominate the low-frequency GARCH in fit and forecasts and exhibit much lower spurious persistence; MIDAS weighting beats unweighted realized volatility. |
| **What Asif can borrow** | The **substantive point**, which transfers: ignoring higher-frequency information creates *spurious persistence*. His RV series has an AR(1) coefficient around 0.6–0.7 weekly; part of that persistence may be measurement, not dynamics. That is a sentence in the limitations, not a model. |
| **Relevance** | **BACKGROUND.** Multivariate, intraday, and equities-only; no attention variable. |

---

### Card 8 — Bazhenov & Fantazzini (2019), *Russian Journal of Industrial Economics* 12(1), 79–88 [S17] · `FULL`

This card is not in the supervisor's list. It was found by search in Stage 3, and it is the most
important paper in this package. It is placed here because it answers Q3 directly.

| | |
|---|---|
| **Question** | Does adding Google Trends and option-implied volatility improve realized-volatility and VaR forecasts for Russian stocks? |
| **Data and frequency** | Four of the most liquid Russian stocks; **daily** realized volatility computed from intraday data; **January 2016 – April 2018**. Google Trends downloaded with `gtrendsR`, merged with Russian-language queries such as "Sberbank share price". |
| **How online data enters** | As an additional regressor in **HAR**, **ARFIMA** and **GARCH(1,1)** — i.e. a genuine GARCH-X, which is precisely what the supervisor asks about in Q3. |
| **Findings** | In-sample: **only implied volatility had a significant effect**; Google Trends had none. Out-of-sample: IV models improved, search models **worsened** performance in several cases; simple HAR/ARFIMA without extra regressors often forecast best. Conclusion: for Russian stocks, Google Trends does not carry information beyond implied volatility. |
| **Limitations** | 4 firms, 28 months, daily frequency, **Google** (not Wordstat), and the horse race is against implied volatility, which Asif does not have. The 2016–2018 window predates the post-2022 retail-dominated market. |
| **What Asif must do about it** | Cite it, state the differences (weekly vs daily; 75 firms vs 4; Wordstat vs Google; 8 years vs 28 months; no IV), and **never claim that search data work in Russia without addressing it**. It is also the best possible template for his own robustness table: it shows exactly which comparison a Russian referee will demand. |
| **Relevance** | **CORE — as the principal threat, and as the design template for the forecasting horse race.** |

---

### Card 9 — Fantazzini & Shangina (2019), *Applied Econometrics* 55, 5–31 [S18] · `SECTIONS`

| | |
|---|---|
| **What it does** | VaR/ES forecasting for the RTS index future, daily 2006–2019, with T-GARCH, HAR, ARFIMA and Realized-GARCH, augmented with implied volatility and Google Trends. Tests: Kupiec, Christoffersen, multinomial VaR, quantile loss, MCS. |
| **Findings** | Adding IV and search did **not** improve and often worsened the risk measures; the worst case was adding both jointly, especially in high-volatility periods, where parameter estimates became unstable; **several augmented models did not converge**. T-GARCH with IV and Student-t was preferred. |
| **What Asif can borrow** | Two operational lessons. (1) **Convergence failures are normal** when a volatility model is over-augmented on Russian data — he must report convergence rates and not hide failed fits. (2) The **evaluation toolkit** (QLIKE/quantile loss + MCS) is the standard his supervisor will recognise. |
| **Relevance** | **CORE-METHOD** (evaluation), and a second warning about the prior. |

---

### Card 10 — Ding, Cui, Xiong & Bai (2020), *JAIHC* 11(11), 4927–4939 [S16] · `ABSTRACT-ONLY` (new link)

| | |
|---|---|
| **Question** | Can a nonlinear, country-specific return model forecast better than a single linear specification? |
| **Data** | Stock index futures in China, India, the US and Japan (from the abstract and the GP bibliography entry). |
| **Method** | Genetic programming evolves nonlinear forecasting expressions; the trading strategy is back-tested. |
| **Findings** | Better **specification** improves accuracy without new variables; different countries need different models; GP strategies are profitable, and roughly three times more so in developed than in developing markets (per a citing survey). |
| **Limitations** | Index level, not firm level. No attention or search variable. GP is a black box: no standard errors, no economic interpretation, and a serious over-fitting risk with 419 weekly points. |
| **What Asif can borrow** | The *thesis*, not the method: **nonlinearity and country-specific specification matter**. That is a licence to include ASVI² and an ASVI × post-2022 interaction, both of which are interpretable, instead of a GP model. Explicitly reject GP in the thesis: with 419 observations and 74 firms, a GP search over specifications is a forking-paths machine. |
| **Relevance** | **BACKGROUND / EXTENSION.** Use as motivation for parsimonious nonlinearity; do not implement GP. |

---

### Card 11 — Kroujiline, Gusev, Ushanov, Sharov & Govorkov (2016), *Quantitative Finance*; arXiv:1508.04332 [S15] · `ABSTRACT-ONLY` (new link)

| | |
|---|---|
| **Question** | Is stock-market return predictable, and at which horizons? |
| **Method** | An analytic agent-based market model with investors of heterogeneous horizons, driven by quantified news flow; theoretical analysis plus empirical calibration; algorithmic trading strategies on the model's forecasts. |
| **Findings** | The market is near-efficient at intraday horizons, adjusting quickly to news, and **inefficient at longer horizons**, where news has a long-lasting **nonlinear** impact through a feedback mechanism; a strategy using only quantified news flow is profitable in backtest. |
| **Limitations** | Market level; a proprietary-ish news-flow quantification; backtest profitability without a full out-of-sample protocol is weak evidence. |
| **What Asif can borrow** | Two things. (1) The **horizon argument**: attention effects should be looked for at 1–4 weeks and cumulatively, not only at one week — which is his Q2/H2 weakness (register D2). (2) An honest framing of *why* a weekly horizon is the right place to look for inefficiency, given that daily adjusting is fast. |
| **Relevance** | **BACKGROUND**, with one directly usable design consequence (multi-horizon CAR, Appendix A/B2). |

---

### Classification requested by the prompt

| Item | Class | One-line reason |
|---|---|---|
| S08 Fantazzini & Kurbatskii (2026) | **CORE-METHOD** | Time-varying value of online data; sparse estimation; OOS framing. |
| S09 Fantazzini & Kurbatsky (META2026) | **CORE** (context, not a paper) | The "after Google's exit" framing of the data choice. |
| S11 Amendola, Candila & Gallo (2021) | **CORE-METHOD** | The only supplied template that fits weekly-search + daily-price. |
| S17 Bazhenov & Fantazzini (2019) | **CORE** (threat + template) | GARCH-X with search on Russian stocks; null result. |
| S18 Fantazzini & Shangina (2019) | **CORE-METHOD** | Evaluation toolkit and convergence warnings on Russian data. |
| S14 Liu et al. (2024) | **EXTENSION** | Additive-outlier correction, directly usable. |
| S13 Chevallier & Sanhaji (2023) | **EXTENSION** | Jump-robust measures; one-X-at-a-time discipline. |
| S16 Ding et al. (2020) | **BACKGROUND** | Nonlinearity matters; GP itself rejected. |
| S15 Kroujiline et al. (2016) | **BACKGROUND** | Horizon argument; multi-horizon CAR. |
| S12 Dhaene & Wu (2016) | **BACKGROUND** | Spurious persistence point only. |
| S10 Zhang et al. (2025) | **BACKGROUND** | Wrong frequency axis; quantile reframing only. |
| L08 YandexWordstatAPI, L09 Parser | **BACKGROUND** | Tools; not verified. |

### What is still not known after Stage 1

- Whether the Fantazzini–Kurbatsky Wordstat paper contains a *quantitative* comparison of Wordstat with
  Google Trends. **GAP-1**. Closes when Asif asks his supervisor for the slides or a draft.
- Whether the two new links (S15, S16) are meant as *model* guidance or as general reading. The
  supervisor's covering message was not supplied (**MISSING INPUT**).
- Whether Bazhenov & Fantazzini's null survives at weekly frequency with a domestic search engine.
  That is, in effect, Asif's thesis question, and Stage 6 shows how much power he has to answer it.

### QA1 — 9/10

Every card separates what the paper does from what the abstract claims; two cards are explicitly
demoted below the authority the supervisor's list implies; the hearsay is resolved without being
upgraded to fact. One point lost because Card 4's method detail (the weighting scheme) is behind a
section I did not open.


---


<!--BREAK-->

## Appendix C — The seven corpus papers, read in depth

*Source file: `stage2/CORPUS_READING.md`*

### 1. Identification (verified by opening each file)

| # | File | Pages | Text extractable | Identification | Depth |
|---|---|---:|---|---|---|
| 1 | `A SIMPLE, POSITIVE SEMI-DEFINITE,.pdf` | 14 | **0 characters** | Newey & West (1987), Econometrica 55(3) | `IMAGE-ONLY` — **NOT OCR'd** |
| 2 | `DeLongShleiferSummersWaldmann90.pdf` | 37 | 95,270 chars | De Long, Shleifer, Summers & Waldmann (1990), JPE 98(4), 703–738 (JSTOR scan) | `FULL` |
| 3 | `GSVI_India.pdf` | 17 | 76,330 | Swamy, Dharani & Takeda (2019), RIBAF 50, 1–17 | `FULL` |
| 4 | `Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis.pdf` | 14 | 69,780 | Djalilov & Ülkü (2021), JBEF 31, 100549 | `FULL` |
| 5 | `information-demand-and-stock-market-volatility-3f9rke46sb.pdf` | **3** | 12,917 | Vlastakis & Markellos (2012), JBF 36, 1808–1821 | `TRUNCATED` (3 of 14 pp) |
| 6 | `Paul Gao Paper.pdf` | 50 | 114,903 | Da, Engelberg & Gao, **June 3, 2010 draft**, "In Search of Attention" (first draft March 1, 2009) | `DRAFT` |
| 7 | `canterbury-nz-034.pdf` | 22 | 33,144 (noisy) | Giles & Lieberman, University of Canterbury discussion paper | `SECTIONS` |

**Newey–West was not OCR'd.** Declared as `NOT-DONE` rather than faked. No claim in this package
depends on its content; it is cited only as the name of the estimator, and the bandwidth rule actually
used comes from the methodology (and is arithmetically checkable: floor(4·(419/100)^(2/9)) = 5).

### 2. What each paper can and cannot support

**De Long et al. (1990)** — the noise-trader model. Uninformed-trader sentiment is a source of *risk*,
so it raises the volatility of the asset and the return the arbitrageur demands. **Direction: positive.**
This is the single most misused paper in the earlier documents: it is repeatedly cited next to a
*negative* ASVI–RV coefficient. It cannot support that. If the pooled coefficient is negative, the
honest statement is "the data reject the noise-trader prediction in this market", not "consistent with
noise-trader theory".

**Da, Engelberg & Gao (2010 draft)** — two things verified verbatim from the draft:
(i) ASVI is "log SVI during the current week minus the (log) median SVI during the previous eight
weeks" (draft lines 92 and 364) — that is **log of median**, confirming v4.0's canonical form and
showing that the register's A1 correction is correct in substance;
(ii) an increase in SVI predicts higher prices over the next two weeks with an eventual reversal.
Also verified: **the Newey–West choice in Da et al. is eight lags inside a Fama–MacBeth design**
(draft line 518). It is *not* a rule for a per-firm weekly regression — the earlier documents say this
correctly, and it is worth repeating in the thesis.

**Swamy et al. (2019)** — verified: excess return = stock return − 52-week rolling beta × market return
(line 223 of the extracted text). This settles the discrepancy in register J4 (a 104-week window was
someone's suggestion, not this paper's method). Sample: 436 S&P BSE 500 firms, weekly, Sep 2012 –
Aug 2017; quantile regression; positive attention–return association in higher quantiles.

**Djalilov & Ülkü (2021)** — weekly MOEX data on individual investors during COVID; VAR(3) by AIC.
Its value to Asif is (a) a weekly-frequency precedent on his own exchange and (b) the observation that
Russian retail investors were net buyers through the crash — which is a caution against the simple
"dumb retail" story.

**Vlastakis & Markellos (2012)** — only pp. 1–3 exist in the file. Those pages support: information
demand and information supply are studied jointly; the firm and market levels are separated. They do
**not** support any statement about the sign or size of the coefficient in that paper. Every earlier
document that describes its "results" is going beyond the available text.

**Giles & Lieberman** — the classical Chow bounds. Correctly identified. Not applicable to a HAC-robust
Wald statistic; v4.0 already demotes it to a side reference, which is right.

### 3. Reference verification: what the earlier documents got wrong

`REFERENCES_VERIFIED_v1.csv` lists each checked reference with its status. The substantive findings:

| # | Claim in earlier work | Verified status | Evidence |
|---|---|---|---|
| R1 | Da, Engelberg & Gao attributed to "2015" in the v3 documents | **WRONG** (it was 2011; the corpus file is a 2010 draft) | Register K8(iii) already flags it. `FINAL_REPORT.md` as delivered now says 2011 correctly — **so the register is stale on this point**. |
| R2 | "Vlastakis & Markellos report that information demand raises volatility" | **UNVERIFIABLE FROM THE CORPUS** | Only 3 of 14 pages. Must be re-sourced or softened to "the paper studies the link". |
| R3 | "Da, Engelberg & Gao use eight Newey–West lags as the rule for weekly regressions" | **MISREADING** | Draft line 518: eight lags *within their Fama–MacBeth design*. |
| R4 | "Swamy et al. use a 104-week rolling beta" | **WRONG** | 52-week, line 223. |
| R5 | "Yoshinaga" spelled correctly? | **CONFIRMED** | Yoshinaga, C. & Rocco, F. (2020), *Brazilian Business Review* 17(5), 523–539, DOI 10.15728/bbr.2020.17.5.3. Spelling verified against the journal page. |
| R6 | "De Long et al. implies attention lowers volatility" (if anywhere stated) | **WRONG DIRECTION** | The model implies higher volatility from noise-trader risk. |
| R7 | "No Russian study uses search data for equities" (any earlier draft) | **FALSE** | At least: Teplova & Gurov (2025) [S48], Teplova et al. (2022) [S50], Fayzulin (2025) carried, Stolbov & Shchepeleva (2025) carried, Shaydullin et al. (2026) [S25], Novikova (2026) [S30]. |
| R8 | The v2.0 claim that `median(ln x) = ln(median x)` | **WRONG for even windows** — register A1 is right | Arithmetic demo in the register; log is order-preserving but the even-window median is an average of two values. |

### 4. The plain-English explanation file

`My Thesis Explained in Plain English … .pdf` (12 pages, 17 Oct 2026) was read in full. It is honest
and it is correctly hedged ("I do not bet on a sign", "prediction, not cause", "I do not claim to be
the first"). Two places where it will collide with the evidence in this package:

1. **"Most of the evidence comes from the United States and uses Google."** True as a description of the
   literature, but it omits that the *Russian* evidence already exists and is partly negative for search
   (Bazhenov & Fantazzini 2019) and partly positive for social media (Shaydullin et al. 2026). The
   paragraph needs one sentence on each, or a referee will supply them.
2. **"If attention moves prices, a spike in searches should warn us before the price moves."** This is
   the price-pressure story, and it is the one story his own estimates do not support (median per-firm
   return slope −0.0027, zero BH survivors). The volatility story is the one the theory and the data
   both support; the plain-English text should lead with volatility.

### 5. NOT-DONE

| Item | Status | What would close it |
|---|---|---|
| OCR of the Newey–West scan | NOT-DONE | `tesseract` on 14 pages; no claim needs it |
| Full text of Vlastakis & Markellos | NOT-DONE (3 of 14 pp only) | University library access, or ILL |
| Published page numbers of Da–Engelberg–Gao 2011 mapped to draft pages | NOT-DONE | The published PDF; all page cites here say "draft p." |

### QA1 — 9/10
One point lost because the Newey–West OCR was not attempted.


---


<!--BREAK-->

## Appendix D — Search protocol, comparables, novelty, and the stage report

*Source file: `stage3/SEARCH_PROTOCOL.md`*

### 1. Question this stage answers

Not "what exists on attention?" (unbounded) but three narrow questions:

- **Q3a.** Has anyone estimated a **GARCH-type model with a search-attention regressor** on **Russian**
  equities? (Supervisor Q3.)
- **Q3b.** Has anyone used **Yandex Wordstat** as a **firm-level** attention measure for **MOEX stocks**?
  (Novelty.)
- **Q3c.** What do **emerging/transition markets** find about attention → volatility and attention →
  returns, so the expected sign can be stated honestly? (Register D3.)

### 2. Sources searched

Google Scholar (via web search), RePEc/IDEAS, SSRN, SpringerLink, ScienceDirect, PLOS, MDPI,
HSE and MSU institutional repositories, eLibrary/CyberLeninka-type Russian outlets reachable by search.
Data sources: SSRN, RePEc, publisher pages, arXiv, MPRA, conference programmes.

### 3. Keyword sets (executed)

**English:** `"Yandex Wordstat" stock market`; `Wordstat investor attention Russia`; `Google Trends
Russian stocks realized volatility`; `investor attention stock volatility emerging market weekly`;
`GARCH-X investor attention`; `GARCH-MIDAS-X`; `realized volatility forecast search data`;
`investor attention Russia Ukraine volatility`; `retail investor attention Russian market`.

**Russian:** `Яндекс Wordstat волатильность акций`; `поисковые запросы внимание инвесторов российский
рынок`; `прогнозирование волатильности российских акций поисковые запросы`; `Вордстат акции
доходность`; `розничный инвестор внимание Московская биржа`.

### 4. Inclusion / exclusion

**Include:** peer-reviewed or working-paper studies that (a) use a search-volume or social-media
attention measure AND (b) a financial-market outcome (return, volatility, volume, liquidity), OR
methodological papers on volatility models with an exogenous regressor, mixed-frequency estimation, or
panel/time-series inference.

**Exclude:** SEO/marketing uses of Wordstat; studies with no financial outcome; predatory-venue listings
(one exception is kept and labelled T3-T4); duplicate reports of the same paper.

**Date range:** no restriction for methods; 2010–2026 for attention empirics, because the measure
itself dates from Da–Engelberg–Gao.

### 5. Absence-claim protocol

For every "nobody has done X", five adversarial searches, in two languages, with the phrasing varied
(synonyms, the local platform name, the local market name, the outcome name, and the model name).
Result recorded in `SEARCH_LOG.csv`. If any search returns a near-match, the claim is narrowed rather
than dropped.

### 6. What this protocol cannot reach

- **Paywalled full texts** (Springer, ScienceDirect, SSRN delivery). Reading depth records this.
- **Russian-language journals behind eLibrary** — some are indexed by search snippets only.
- **Unpublished work in progress.** Two such papers surfaced from the META2026 programme [S30, S31];
  there may be more.
- **Google Scholar's own ranking** — searches here are topic-formulated, not citation-chained. Snowballing
  was done forwards only where a citing paper was visible in the results (e.g. the survey citing Ding
  et al. 2020, and the papers citing Chevallier & Sanhaji 2023).

### 7. Tally

| Requirement (prompt §4, Stage 3) | Required | Delivered |
|---|---:|---:|
| Verified core sources | 25 | **34** with an opened abstract, section or full text (S01–S31, S47–S50 minus the 5 NOT-OPENED) |
| On emerging markets or Russia | 8 | **14** (S03, S04, S08, S09, S17, S18, S25, S26, S27, S28, S30, S47, S48, S49) |
| On volatility models with online data | 6 | **9** (S11, S13, S14, S17, S18, S19, S23, S29, S48) |
| On inference or mixed-frequency methods | 5 | **11** (S01, S10, S12, S33, S34, S35, S38, S39, S40, S41, S43) |


---

*Source file: `stage3/COMPARABLES_TABLE.md`*

Read down the "differs from Asif in" column. The point of this table is not to show that Asif is first —
he is not — but to show exactly what remains when every near-match is subtracted.

### A. Russian and emerging-market studies (verified this round)

| Study [id] | Market / data | Attention measure | Outcome | Frequency | Result | Differs from Asif in |
|---|---|---|---|---|---|---|
| **Teplova & Gurov (2025)** [S48] | MOEX stocks, 2018–2021 | **Google relative search volume**, firm level | Intraday trading activity (invariance of trade arrival) | Intraday | Search and trading activity synchronise after Feb 2020, when retail entered; news flows do not | Outcome is intraday trading activity, not weekly volatility; Google, not Wordstat |
| **Teplova et al. (2022)** [S49] | MOEX stocks | Social-network messages, "Hype" indicator (attention + sentiment) | Returns, volume, liquidity | Daily | A visibility effect exists; attention and sentiment are priced alongside momentum/volatility/volume; horizon behaviour differs by size | Social media, not search; daily; no volatility equation |
| **Shaydullin, Mi & Mitkinov (2026)** [S25] | 7 large Russian firms | Social-media sentiment and attention weights | Volatility forecast quality | Daily | Attention/sentiment improve forecast quality by up to ~7% (Yandex) | 7 firms, social media, ML black box; no Wordstat |
| **Shaydullin / Fayzulin-type search-attention study (2025)** [S26] | Russian issuers | **Search-query statistics on economic-political and investment topics** | Returns | Daily | Attention affects future price behaviour; divergence matters only on discussion days | **Topic-level, not firm-level**; returns, not volatility; details UNVERIFIED |
| **Bazhenov & Fantazzini (2019)** [S17] | 4 liquid Russian stocks, 2016–2018 | Google Trends (ticker + Russian queries) | Realized volatility and VaR | **Daily** | **No significant search effect; forecasts worsen** | Short sample, 4 firms, Google, and a horse race against implied volatility |
| **Fantazzini & Shangina (2019)** [S18] | RTS index future, 2006–2019 | Google Trends | VaR/ES | Daily | Search + IV did not improve; some models failed to converge | Index level; risk-measure outcome |
| **Bui & Nguyen-type Vietnam study** (carried, **not re-verified**) | 49 HOSE firms, 2014–2018 | Google | Illiquidity and volatility | Weekly | Firm-specific attention has mixed effects; market-wide attention raises both | Not verified in this round; treat as lead |
| **Swamy et al. (2019)** [S03] | 436 Indian firms, 2012–2017 | Google | Excess **returns**, quantiles | Weekly | Positive in higher quantiles | Returns only; India; no volatility equation |
| **Yoshinaga & Rocco (2020)** [S47] | 57 Ibovespa stocks, 2014–2018 | Google | Excess **returns** | Weekly | **Lower** future excess returns; stronger for liquid stocks | Returns only; Brazil |
| **Düz Tan & Taş (2019)** [S50] | BIST 100, Turkey | Google | Returns | Weekly | Search precedes news, volume and returns | Returns only; Turkey |
| **Hu et al. (2025)** [S20] | China | Baidu search frequency | Return volatility | Firm-level panel | Positive; **ownership concentration moderates** | China; the ownership moderator is the analogue of Asif's H6 |
| **Institutional investor attention (2022)** [S24] | 9 countries **incl. Russia**, 2011–2020 | Institutional attention (not search) | Volatility and liquidity | Daily | Positive effect on both | Not search; not retail |

### B. Methodology comparables (verified this round)

| Study | What it supplies to Asif | What it does not |
|---|---|---|
| **Andrei & Hasler (2015)** [S19] | Theory: an **increasing, quadratic** attention–volatility relation; a negative linear term plus a positive quadratic term | No search data; market-level; no estimation recipe at firm level |
| **Amendola, Candila & Gallo (2021)** [S11] | DAGM-X-2K architecture: low-frequency forcing variable in the long-run component, market volatility index as the "-X" | Volatility index, not search; indices, not firms |
| **Liu et al. (2024)** [S14] | Additive-outlier correction before GARCH-MIDAS | Details behind a section not opened |
| **Chevallier & Sanhaji (2023)** [S13] | Realized GARCH-MIDAS-X with one exogenous variable at a time; jump-robust measures | Crypto, intraday |
| **Dhaene & Wu (2016)** [S12] | Ignoring higher-frequency information creates spurious persistence | Multivariate, intraday |
| **Zhang et al. (2025)** [S10] | Conditional quantile GARCH with mixed frequency | Intraday-to-daily frequency axis |
| **Kroujiline et al. (2016)** [S15] | Efficiency at short horizons, nonlinear news effects at long horizons → test multiple horizons | Market level; agent-based |
| **Ding et al. (2020)** [S16] | Nonlinear, country-specific specification improves forecasts without new variables | GP is not implementable defensibly at n=419 per firm |
| **Fantazzini & Kurbatskii (2026)** [S08] | Sparse estimation with many online predictors; **time-varying value of online data** | CPI, monthly, Google |

### C. The residual gap, stated precisely

Subtracting every row above, what is left is:

> A **firm-level, weekly, eight-year (2018–2026)** measure of **abnormal Yandex Wordstat attention**
> for a **75-firm MOEX panel**, used to explain **next-week range-based realized volatility** with
> **event controls for crisis, sanctions and dividends**, and evaluated both as a **coefficient**
> (with time variation) and as an **out-of-sample forecast against a HAR benchmark**.

That is narrower than "first Russian attention study" (false) and narrower than "attention predicts
volatility" (already shown with Google and social media). It is a **data + setting + horizon**
contribution with a **measurement** component, and it is honest to call it incremental.

### D. Two specific threats this table exposes

1. **Teplova & Gurov (2025)** already show that Google search volumes for Russian stocks co-move with
   trading activity, and date the change to the 2020 retail influx. A referee will ask why Wordstat adds
   anything. The answer must be: Wordstat covers the post-Google-exit period (2022–2026), where Google's
   Russian share collapsed, and it is the only domestic measure with continuous weekly coverage through
   the sanctions period. **That is the thesis's defence of its data choice, and it should be in the
   introduction, not the appendix.**
2. **Bazhenov & Fantazzini (2019)** already ran the GARCH-X horse race with search data on Russian
   stocks and lost. Asif's design must therefore differ on at least two dimensions that plausibly matter
   (weekly frequency + domestic platform + 8-year span + volatility-only outcome without an IV
   competitor), and it must say so explicitly. Stage 5 builds the design around this constraint.

### E. Carried but NOT verified this round (do not cite without checking)

Bui & Nguyen (2019, Vietnam); Fayzulin (2025); Stolbov & Shchepeleva (2025); Kropiński & Anholcer
(2022); Iyke & Ho (2021); Yang et al. (2021, China); Düz Tan & Taş volume/pages. These come from
`AGENT_3_FINDINGS.md` of the earlier round. The identifiers are plausible and several are certainly real,
but **this package did not open them**, so they are listed as leads only.


---

*Source file: `stage3/NOVELTY_STATEMENT.md`*

### The sentence Asif may use

> "This thesis constructs a firm-level, weekly measure of abnormal attention from Yandex Wordstat for
> 75 Moscow Exchange stocks over 419 weeks (August 2018 – August 2026) and asks whether it predicts
> next-week range-based realized volatility, allowing the relation to be nonlinear and to change after
> February 2022. To my knowledge it is the first study to combine a **firm-level domestic search
> measure** with a **broad MOEX panel over a period that spans the Google exit**, but it is not the
> first study of investor attention in Russia: Google-based, social-media-based and topic-level
> search studies already exist [S25, S26, S48, S49], and a Google-Trends study of Russian stocks'
> realized volatility found no incremental information [S17]."

### The three claims that must NOT be made

| Claim | Why not | What to say instead |
|---|---|---|
| "First study of investor attention in Russia" | At least six Russian studies exist [S25, S26, S27, S28, S48, S49] plus a T-Pulse paper in progress [S30] | "Among the first firm-level Wordstat studies of MOEX volatility" |
| "First to use Yandex Wordstat for stocks" | Wordstat appears in Russian financial research (Stolbov & Shchepeleva, carried, not verified) and is the announced subject of the supervisor's own conference talk [S09] | "I am not aware of a published firm-level weekly Wordstat study of MOEX volatility; the closest works are …" |
| "Attention predicts volatility" (unqualified) | The Russian evidence is mixed and partly negative [S17, S18]; emerging-market return studies disagree in sign (positive in India [S03], negative in Brazil [S47]) | "I test a two-sided hypothesis and report the estimated association with its minimum detectable effect" |

### What the contribution actually is, in three parts

1. **Data.** A firm-level weekly Wordstat panel with a documented abnormal-attention construction, the
   share-of-total denominator recovered from the files (register J1–J2), and 8 years of coverage across
   three market regimes. This is reusable by others and survives a null result on the hypothesis.
2. **Setting.** The 2018–2026 window contains the 2020 retail influx, the 2022 closure and the Google
   exit. That makes the *time variation* of the attention–volatility relation a first-order object of
   study rather than a nuisance — exactly the object Fantazzini & Kurbatskii [S08] identify as the
   open question.
3. **Design.** A two-sided, nonlinearity-permitting, forecast-evaluated test with an explicit minimum
   detectable effect, rather than a significance hunt. This is the part that a committee can grade even
   if the coefficient is zero.

### Honest probability assessment (labelled judgement, not evidence)

`OPINION`: the most likely outcome of a well-run version of this design is a **small, fragile,
negative-to-zero linear association with volatility, a positive quadratic term, pronounced firm-size
heterogeneity, and no out-of-sample gain over HAR**. That is a perfectly respectable Master's thesis —
because the same description fits the best published Russian study [S17] — but it is not a "discovery"
result, and the thesis must be written so that it does not need one.


---

*Source file: `stage3/W3_REPORT.md`*

### Completion table

| Task | Status | Evidence |
|---|---|---|
| Write `SEARCH_PROTOCOL.md` before searching | DONE | `stage3/SEARCH_PROTOCOL.md`; keywords in EN and RU |
| Log every query | DONE (10 logged) | `stage3/SEARCH_LOG.csv`. This is a *topic* search, not an exhaustive systematic review; the log is honest about that. |
| ≥25 verified core sources | DONE (34 with an opened text at some depth) | `sources.csv` |
| ≥8 emerging/Russia | DONE (14) | S03, S04, S08, S09, S17, S18, S25, S26, S27, S28, S30, S47, S48, S49 |
| ≥6 volatility + online data | DONE (9) | S11, S13, S14, S17, S18, S19, S23, S29, S48 |
| ≥5 inference / mixed frequency | DONE (11) | S01, S10, S12, S33–S35, S38–S41, S43 |
| Five adversarial searches per absence claim, two languages | PARTIAL | Two absence claims were tested with 4–5 query variants each in EN and RU. This is weaker than the prompt's five-per-claim rule. The claims were therefore **narrowed**, not asserted. Declared. |
| Update `comparables_table.md` | DONE | `stage3/COMPARABLES_TABLE.md` |
| Update the novelty statement | DONE | `stage3/NOVELTY_STATEMENT.md`; no "first" |

### The four findings that change the thesis

**1. The supervisor's reference does not say what the supervisor thinks it says.**
His list gives SSRN 6468200 [S08], which uses **Google Trends**. The META2026 programme [S09] shows a
separate talk, on **Yandex Wordstat after Google's exit**. The hearsay is resolved into a topic, not a
result. (Card 2, Stage 1.)

**2. The decisive warning is in his own reference's abstract.**
S08 finds that the predictive value of Russian search data **collapsed after the early-2022 break**. Asif's
sample is 60% post-2022. This converts H3 from a side test into the centre of the design.

**3. The Russian literature is crowded, and one branch of it is negative.**
Six Russian attention studies exist [S25–S28, S48, S49], one in progress [S30]. The only one that
tests search → **realized volatility** on Russian stocks with a GARCH/HAR family found **no effect**
[S17]. Novelty must be narrow and the design must differ on stated dimensions.

**4. There is a theory that predicts a nonlinear relation, and nobody in the Russian literature has used it.**
Andrei & Hasler [S19]: increasing and **quadratic** in attention, with a negative linear and a positive
quadratic term. This is the single most valuable addition available, because it (a) explains why a linear
coefficient can be small or negative while volatility still rises with attention, (b) gives a testable,
interpretable specification that a Master's student can estimate in one line, and (c) is not in any of
the Russian comparables.

### NOT-DONE / weaknesses declared

| Item | Why | Consequence |
|---|---|---|
| Five adversarial searches per absence claim | Time; each search consumes a large context budget | Absence claims are narrowed to "not found in this round" |
| Snowballing backwards from 10 papers via citation databases | No Web of Science/Scopus access | Some older work may be missed; the core comparables are covered |
| Full texts of S10, S11, S12, S13, S16, S19, S20, S23, S24, S25, S26, S47, S48, S49 | Paywalls / delivery failures | Every one is labelled ABSTRACT-ONLY; no claim exceeds the abstract |
| Russian-language eLibrary deep search | Access | The Russian set is likely incomplete; declared |

### QA1 — 9/10
One point lost on the adversarial-search requirement, which is declared above rather than papered over.


---


<!--BREAK-->

## Appendix E — The problem register: P-01 to P-31, in full

*Source file: `stage4/PROBLEM_REGISTER.md`*

Extends Appendix C (P-01 … P-22) with nine further problems found in Stages 1–4. For each: description,
evidence, severity (S1 = can invalidate a conclusion; S2 = biases or weakens; S3 = disclosure only),
which hypothesis it affects, **what the literature does about it**, and status.

Severity is assigned by consequence for the thesis, not by how easy the fix is.

---

### A. Outcome measurement

#### P-01 · Ex-dividend mechanics inflate return and RV variation · **S1** · affects H1, H2, H5
**Description.** The vendor price series is a price series, not a total-return series. On the ex-week the
price drops by roughly the dividend, so the measured return and the measured high-low range both
contain a mechanical component that has nothing to do with attention.
**Evidence.** Register L4 (Claude, code): for 358 ex-dividend weeks with at least one cum-dividend day,
mean RV 0.1022 → 0.0762 after adding the dividend back (−25.5%); median change −19.6%; SFIN 0.678 → 0.185.
Register K3: market-adjusted return averages −5.1% in ex-weeks versus +0.1% elsewhere; 528 ex-weeks.
**Literature.** Liu et al. [S14] treat such gaps as additive outliers and correct rather than delete;
Chevallier & Sanhaji [S13] filter jumps out of the realized measure before estimation. No paper found
that ignores the problem, and none that treats it exactly this way for dividends.
**Fix in this package.** Add the dividend back to the *return* (v4.0 V4-05 already does) **and to the
range**: reconstruct the intra-week high and low by adding the dividend to the pre-ex daily bars
(Amendment V4-28 in the methodology is right to extend the fix to RV). Keep price-only as a labelled mirror.
**Status.** Returns: SOLVED-BY-DESIGN (v4.0). RV: **OPEN** — v4.0 verifies the size of the distortion but
does not adjust RV.

#### P-02 · Share-count volume breaks at corporate actions · **S1** · affects all models using a volume control, and the Crisis/Sanction/News layers
**Description.** `VOLUME` is shares, so a 5000:1 consolidation moves it by ≈8 log points with no change in
trading. `VALUE` (rubles) does not.
**Evidence.** Register B3: VTBR Δln(VOLUME) = −8.07 vs Δln(VALUE) = +0.17; GMKN +4.82 vs −0.02;
PLZL +1.70 vs −0.39; ROLO +3.82 vs +1.75. Register B14: the same volume leg was used to build Crisis,
Sanction verification and News.
**Literature.** Standard practice in the realized-volatility literature is to use turnover in currency,
not share counts (no paper in this corpus argues otherwise; this is DR1, a correctness fix, not a
literature choice).
**Fix.** ln(VALUE) primary (done in v4.0 V4-01). Additionally: rebuild the Crisis windows on the VALUE
leg and report whether the four windows survive — **not done anywhere yet**.
**Status.** Control in models: SOLVED. **Crisis windows: OPEN.**

#### P-03 · ASVI form: median of logs ≠ log of median for an 8-week window · **S2** · H1, H2
**Description.** For an even window the median averages two values, so the two forms differ.
**Evidence.** Register A1 arithmetic: counts 1,2,3,4,100,100,100,100 → median of logs 2.996, log of median
3.951. Da–Engelberg–Gao's draft text says "log SVI minus (log) median SVI", i.e. **log of median** [S06,
draft lines 92, 364].
**Literature.** [S06] settles the canonical form.
**Status.** SOLVED (v4.0 V4-03 adopts the canonical form; v2.0's form is sensitivity S03).

#### P-04 · Small firms: thin counts, high noise, scale heterogeneity · **S1** · H1, H4, H6
**Description.** Median weekly SVI ranges from 22 (MRKK) to 86,842 (MGNT); the sd of ASVI falls
monotonically across size quartiles (0.49, 0.36, 0.30, 0.26). A +10% move is the same on the log scale
whether it is 70 queries or 30,000, so the *signal-to-noise* is not scale-free.
**Evidence.** Register K7 (code).
**Literature.** [S23] shows attention effects are heterogeneous in news type; [S20] shows a moderator
(ownership concentration) that correlates with size. No paper offers a standard correction.
**Fix.** Report size-quartile estimates as a pre-specified heterogeneity dimension; a minimum-count
sensitivity (S21, SVI < 10 excluded); and — the addition this package recommends — **precision weights**
(1/σ²ᵢ of ASVI) or size-group-specific slopes in the pooled model. Stage 6 quantifies whether weighting
recovers power.
**Status.** PARTIALLY OPEN. Sensitivity exists; weighting does not.

#### P-05 · Market-wide attention: subtraction imposes a loading of 1.0 · **S2** · H1
**Description.** Subtracting the cross-sectional mean assumes every firm loads 1.0 on market attention.
Empirically loadings range 0.28 (AVAN) to 1.89 (RNFT).
**Evidence.** Register K7.
**Literature.** [S23] and [S29] both separate market-wide from firm-specific attention and find they
behave differently — so the level matters, but the literature estimates a loading rather than imposing one.
**Fix.** Week fixed effects in the pooled model make the choice irrelevant (verified: identical slope,
register J3). In per-firm models, use the market median as an *added regressor* (S05) and, as an
improvement, an expanding-window loading (S18). Do **not** make subtraction primary.
**Status.** SOLVED for the pooled model; OPEN for per-firm (S05 exists; S18 exists but is not run).

#### P-06 · Market-adjusted returns fluctuate around zero · **S1** · H2, H5
**Description.** The supervisor's concern (Q9). Three distinct problems hide inside it: (a) the signal is
tiny relative to return noise, so power is low; (b) β is estimated on 2018–2022 and applied afterwards,
so the "abnormal" return contains a generated-regressor error and a beta break; (c) subtracting a **price**
index from a stock return leaves a non-zero mean in dividend months.
**Evidence.** v4.0 §4.3 uses β estimated on 2018-08-27…2022-02-21. Register L5 flags the price-vs-total-return
inconsistency. Stage 6 quantifies (a).
**Literature.** [S03] uses a 52-week rolling beta; [S40] avoids the problem entirely by estimating the
cross-section each week; [S47] uses simple excess returns and still detects an effect.
**Fix.** Three options in increasing order of quality: (i) keep the subtraction but disclose the beta
window and use the rolling form as sensitivity (already S07); (ii) **put the market return on the
right-hand side** instead of subtracting it, so no generated regressor enters the outcome; (iii) **Fama–
MacBeth** weekly cross-sections [S40], which estimate the common component each week and average the slopes.
**Status.** OPEN — this is the single most consequential open design choice, and §7 of `BEST_PATH_REPORT.md`
recommends (ii)+(iii).

#### P-07 · Inference: HAC lag, Driscoll–Kraay, multiple testing, permutation validity · **S1** · all
**Description.** 74 per-firm tests with a common weekly shock; HAC bandwidth ambiguity (4/5/8/9); DK with
T/N = 5.7; BH under dependence; circular-block permutation with L=8.
**Evidence.** Register K2/K8: bandwidths 4/5/9 give 12/11/13 nominal rejections and the same six BH
survivors — so the *survivor set* is robust but the *count* is not. v4.0 adopts 5 (= floor(4(T/100)^(2/9))).
**Literature.** [S01], [S39], [S38], [S41], [S42], [S43]. For dependent tests, BH is anti-conservative;
Benjamini–Yekutieli or Romano–Wolf is the defensible choice (not opened here, listed as a GAP).
**Fix.** Report nominal / BH / Holm together (done); add **Romano–Wolf step-down** as the primary
multiplicity correction for the 74-firm family, because the tests are positively dependent through the
market factor; report DK and two-way cluster side by side (S16).
**Status.** PARTIALLY OPEN. Stage 6a shows BH's false-discovery behaviour under this dependence.

#### P-08 · H3: level shift versus slope shift; unknown break date · **S1** · H3
**Description.** The v3 playbook reported an omnibus break (F = 63.86) and a slope-only F = 4.70 and
called the conclusion identical. A level shift after February 2022 is not evidence that the attention
effect changed.
**Evidence.** Register K4.
**Literature.** [S44] is the standard for unknown break dates and multiple breaks; the Giles–Lieberman
bounds [S07] apply to a classical Chow statistic, not a HAC-robust Wald.
**Fix.** Report δ1 (level) and δ2 (slope) separately (done in v4.0 M5); add a sup-F / Bai–Perron test with
unknown dates as a robustness; and drop the Giles–Lieberman comparison entirely.
**Status.** SOLVED-BY-DESIGN for the split; **OPEN** for the unknown-date test.

#### P-09 · Crisis control is circular and volume-contaminated · **S2** · H1, H5
**Description.** Crisis windows are built from RV and volume spikes — the same outcomes they control — and
the volume leg contains the splits of P-02. A control selected by the outcome can mechanically correlate
with it.
**Evidence.** Register D8, E1, B14.
**Literature.** No attention paper in the corpus uses an outcome-derived crisis dummy; the usual approach
is a market factor, week effects, or an exogenous event list ([S23] news-conditioned design).
**Fix.** Keep Crisis only with disclosure (v4.0 V4-10) and replace it with lagged market RV in S13; in the
pooled model week FE absorb it entirely, which is the cleanest solution.
**Status.** SOLVED in the pooled model; DISCLOSED in per-firm.

#### P-10 · Sanction coding and verification · **S2** · H1 (controls), H6
**Description.** Only 4 of 24 anchors verified this round; 20 not re-verified; AFLT single-source; AVAN
unverified; four 2026 anchors unverified; negative verification of 51 firms not done.
**Evidence.** Methodology Part II §12; register E2.
**Literature.** No methodological paper needed; this is a data-audit problem.
**Fix.** Either (a) restrict the sanction control to the verified anchors and state the restriction, or
(b) replace the firm step with a **market-level sanctions factor** (which week FE absorb anyway) and a
firm-level *exposure* proxy computed pre-sample from the 2018–2021 data only.
**Status.** OPEN. Recommendation: option (a), because it is honest and cheap.

#### P-11 · State-ownership classification not independently done · **S2** · H6
**Description.** The 35/40 split comes from an earlier document; the blind double classification was never
performed; VSMO is a knife-edge; YAKG's sector label is disputed and changes H4 materially.
**Evidence.** Register E3; FINAL_REPORT's YAKG reclassification moves H4 p from .0267 to .0090.
**Literature.** [S20] uses a continuous measure (ownership concentration) instead of a binary, which is
strictly better statistically and avoids the knife-edge.
**Fix.** Either re-classify blindly (two coders, report disagreement) or switch H6 to a **continuous**
state-ownership share (the Rosstat/issuer filings give percentages) and report the binary as a robustness.
**Status.** OPEN.

#### P-12 · Dividend table: aggregators, derived ex-dates, share classes · **S1** · H5, P-01
**Description.** 587 record dates from smart-lab / dohod / T-Bank, not issuer filings; ex-dates derived
from the settlement regime; for dual-class firms the dividend per share differs by class and the traded
class must be matched.
**Evidence.** Register E4; methodology §13.
**Literature.** [S14]'s outlier treatment is a partial substitute: if the ex-date is wrong by a week, an
additive-outlier correction can still clean the series.
**Fix.** Keep the derived ex-dates but state the settlement rule; for the ~10 dual-class names, verify
class-specific DPS for at least the top-5 dividend payers; and run the AO correction of [S14] as a
cross-check on the 358 flagged weeks.
**Status.** PARTIALLY OPEN.

#### P-13 · News layer abandoned · **S3** · none directly; costs one control
**Description.** The news matrix is absent and the layer was outcome-selected, so it cannot be used.
**Literature.** [S23] shows news conditioning matters; [S05] needs an information-supply control. Without
news, the thesis cannot claim to replicate Vlastakis–Markellos.
**Fix.** Disclose (done, V4-14). Optional cheap improvement: a **crude** news proxy that is not
outcome-selected — e.g. counts of firm mentions in a fixed RSS feed — only if Asif can build it without
using returns.
**Status.** ACCEPT-AND-DISCLOSE.

#### P-14 · Macro and market series not retrieved · **S2** · controls, and P-06's market leg
**Description.** USD/RUB, Brent, key rate, MOEX total-return index not retrieved. The market leg is a
price index while the stock leg adds dividends back.
**Evidence.** Register L5; methodology GAP-15.
**Literature.** In a pooled model with week FE these are absorbed. In per-firm models they matter for the
market leg only.
**Fix.** Week FE in the pooled model solve it; for per-firm models use the IMOEX **total-return** index
(MOEX publishes it; not retrieved here).
**Status.** SOLVED pooled; OPEN per-firm.

#### P-15 · Universe, survivorship, tick-size, share classes, sector map · **S2** · all
**Description.** 75 surviving firms; 19 excluded; ROLO excluded for its 1-kopeck grid; sector map hand-made.
**Fix.** Disclose (v4.0 V4-16); add a tick-size screen for all firms (ROLO is not the only low-priced name);
report the excluded-firm registry.
**Status.** DISCLOSED.

#### P-16 · No daily search data · **S1** · closes off the daily GARCH-X route
**Description.** Wordstat's daily detail is limited to the last 60 days, so a daily GARCH-X with a daily
search regressor is **impossible** with these data.
**Literature.** [S11] shows the way out: put the weekly variable in the **long-run** component of a daily
model (GARCH-MIDAS-X). [S17], [S18] used daily Google data and are therefore not replicable on Wordstat.
**Fix.** This is the argument for the GARCH-MIDAS-X extension and against a plain daily GARCH-X.
**Status.** ACCEPT-AND-DESIGN-AROUND.

#### P-17 · Forking paths · **S1** · all
**Description.** v4.0 is not pre-registered; v2.0 and v3 results were seen; the sensitivity list was fixed
afterwards.
**Fix.** v4.0's amendment-ID discipline plus the disclosure in §6.5 and §10. **Add**: a hashed
pre-analysis plan for any *new* analysis (the tournament in Stage 5 is hashed for this reason), and a
forking-paths count in the appendix (how many specifications were estimated in total).
**Status.** DISCLOSED; new analyses are pre-specified.

#### P-18 · Novelty and Wordstat validity · **S2** · framing
**Description.** "Yandex is better than Google" is hearsay [S09]; no issuer-level validation of Wordstat
exists in the literature; the platform's share changed over the sample (Google's exit).
**Fix.** Frame the data choice as *representativeness after the Google exit*, not as superiority; add a
validation exercise (P-23).
**Status.** framed in `NOVELTY_STATEMENT.md`.

#### P-19 · Calendar quirks · **S3** · timing
**Description.** Three closure weeks in 2022; weekend sessions from March 2025 folded into Monday;
partial weeks; New Year.
**Fix.** Verified and documented (v4.0 V4-17). Weekend sessions raise the Monday/Tue–Fri turnover ratio to
≈1.20–1.28 after March 2025 — a 20–28% inflation of Monday volume for 18 months of the sample. Disclose
as a limitation on the volume control.
**Status.** DISCLOSED. **New sub-problem P-29 below.**

#### P-20 · The earlier data package failed audit · **S3** · trust
**Fix.** Evidence discipline: every number in this package carries a source id or a code path.
**Status.** MITIGATED by construction.

#### P-21 · Prediction is not causation; reverse causality · **S1** · all
**Description.** Searches and volatility respond to the same news within the week.
**Literature.** [S05] separates demand from supply; [S48] shows search co-moves with trading activity.
**Fix.** Lagged regressor; lead tests (future ASVI must not predict current RV); placebo with other firms'
ASVI and with non-financial queries; and an explicit "predictive association only" claim.
**Status.** DISCLOSED + lead test recommended.

#### P-22 · What a Wordstat count means · **S2** · measurement
**Description.** Queries, not people; all word forms included; "акции" also means "promotions"; Yandex's
share of search changed; total Yandex traffic varies week to week (1.62bn → 2.90bn).
**Evidence.** Register J1–J2: the share column lets the denominator be recovered; count-ASVI correlates
0.46 with total-traffic growth.
**Fix.** Primary: counts. Robustness: normalised by D_t (S04). Disclose both.
**Status.** SOLVED by S04; primary choice justified by DR4.

---

### New problems found in Stages 1–4

#### P-23 · The attention measure is never validated against a non-price outcome · **S1** · H1 (credibility)
**Description.** If ASVI is noise, every result is a null and the thesis cannot say why. Da–Engelberg–Gao
validate SVI against other attention proxies; Asif validates against nothing.
**Literature.** [S06] (validation against existing proxies), [S48] (search co-moves with trading activity
in Russia — a ready-made benchmark), [S49] (social-media hype correlates with attention).
**Fix.** A one-table, one-hour validation exercise **without any price regression**: correlate ASVI with
(a) abnormal trading value, (b) absolute return, (c) turnover, (d) RVI (the Russian volatility index), on
the same week; and show that ASVI spikes in known attention weeks (sanction announcements, dividend
announcements) — all of which is **allowed under DR7** because no attention regression on a price outcome
is run. This is the cheapest credibility the thesis can buy.
**Status.** OPEN — recommended as Plan A component 4.

#### P-24 · The linear specification contradicts the only theory that predicts the sign · **S1** · H1
**Description.** De Long et al. [S02] predict a positive attention–volatility relation; Andrei & Hasler
[S19] predict an increasing **quadratic** relation with a negative linear term. A linear-only test is
misspecified against both: if the truth is U-shaped and the sample sits on the descending branch, the
linear slope is negative and the researcher concludes "attention lowers volatility", which is the
opposite of the theory's prediction.
**Evidence.** Register D3 ("no universal sign"); the observed median per-firm slope is −0.004 and 55 of
74 are negative, which is hard to reconcile with either theory unless the specification is wrong.
**Fix.** Add ASVI² (centred) and report the turning point; test joint significance; plot the fitted
quadratic. Stage 6b demonstrates that this alone can turn a "reject the theory" result into a "confirm
the theory" one.
**Status.** OPEN — this is the highest-value design change in the package.

#### P-25 · One-week horizon only, while the theory is about a path · **S2** · H2
**Description.** Da–Engelberg–Gao's story is pressure over ~2 weeks then reversal over months; the thesis
tests h = 1.
**Fix.** h = 0…4 and cumulative CAR 0–4 (sensitivity S08 already lists it; it is not yet implemented).
**Status.** PARTIALLY OPEN.

#### P-26 · The pooled slope is identified mostly by within-firm variation that is tiny relative to common shocks · **S2** · M4 power
**Description.** 16.6% of ASVI variance is common to the week; after firm and week FE, the remaining
variation is small. The nominal N of 29,642 therefore overstates the independent information: the
effective sample for a coefficient on a regressor with a large common component is closer to T = 419 than
to N = 29,642.
**Evidence.** Register J3 (16.6% common variance); the DK standard error (0.00183) is ~2.3× the naive
firm-clustered one would be, which is the symptom.
**Fix.** Report the effective-sample calculation; use Fama–MacBeth as the primary cross-check; and never
describe the design as "29,642 observations" without the qualifier.
**Status.** OPEN (reporting change).

#### P-27 · No minimum-detectable-effect statement in economic units · **S1** · honesty
**Description.** MDE80 = 0.0051 in log-RV units is meaningless to a committee. What is 0.005 in
percentage points of weekly range volatility? ≈ 0.5% of the level of RV — trivially small economically,
which means the design can rule out only *large* attention effects.
**Fix.** Translate every MDE into (i) percent of the mean RV, (ii) the implied change in a typical weekly
high-low spread, (iii) the β required to matter for a variance swap. Stage 6 does this arithmetic.
**Status.** OPEN — pure reporting, high value.

#### P-28 · Convergence and reporting of failed fits · **S2** · any GARCH work
**Description.** [S18] documents non-convergence when Russian volatility models are over-augmented. If
Asif runs 75 GARCH-X models and reports only the converged ones, the results are selected.
**Fix.** Pre-register the convergence criterion; report the count of failures; never drop silently.
**Status.** OPEN by construction (rule adopted here).

#### P-29 · Weekend sessions inflate Monday volume and compress Monday-to-Friday timing · **S3** · volume control
**Description.** Since 1 March 2025, weekend equity trading is folded into the next trading day, raising the
Monday/Tue–Fri turnover ratio to ≈1.20 (2025-03-03…2026-08-24) from ≈1.04 before. 18 months of a 419-week
sample carry this.
**Fix.** Disclose; add a post-March-2025 dummy interacted with the volume control as a robustness.
**Status.** DISCLOSED.

#### P-30 · The sanction and crisis controls are collinear with the week effects that identify the design · **S3** · H1/H6
**Description.** Crisis is identical across firms, so week FE absorb it (correctly), which means the
per-firm models' Crisis coefficient and the pooled model's absence of one cannot be compared.
**Fix.** Use the per-firm models for anything involving firm-varying controls, the pooled for the average
slope; state this division of labour explicitly.
**Status.** DISCLOSED.

#### P-31 · No power analysis for the design as a whole, only per-test MDEs · **S1** · honesty
**Description.** MDE80 is reported per regression; nobody has computed the probability that the *design*
detects a true effect of a plausible size, given 74 firms, BH correction and the actual noise.
**Fix.** Stage 6 does exactly this (400 replications per cell, `stage6/SIM_RESULTS.csv`). Measured power at a
true β of 0.005: pooled TWFE 0.963, Fama–MacBeth 0.960, HAR-X 0.985, **per-firm 0.096**. At β = 0.002:
0.315 / 0.300 / 0.393 / 0.061. The per-firm design needs β ≈ 0.029 for 80% power. Caveat carried from
`stage6/SIM_REPORT.md` §0: the simulated pooled standard error is 0.72× the observed one, so the pooled
figures are upper bounds. The earlier draft figure of "~0.35 per-firm power" was wrong and is superseded.
**Status.** CLOSED by Stage 6 (2026-10-20).

---

### Summary counts

| Severity | Count | Of which OPEN |
|---|---:|---:|
| S1 | 14 | 6 (P-01 RV, P-06, P-23, P-24, P-27, P-31) |
| S2 | 14 | 5 (P-04, P-10, P-11, P-26, P-28) |
| S3 | 3 | 0 |
| **Total** | **31** | **11 open, 6 of them S1** |

The six open S1 problems are exactly what Plan A in `BEST_PATH_REPORT.md` addresses. That is not a
coincidence: the plan was built from this register.


---


<!--BREAK-->

## Appendix F — Idea review and the problem-to-solution matrix

*Source file: `stage5/IDEA_REVIEW.md`*

Verdict rule (§5 of the prompt): `CORE` = fixed in Plan A; `EXTENSION` = adds value, not needed;
`REJECT` = the cost exceeds the value at Master's level or the design is invalid; `NEEDS-DATA` = could
work but a required input does not exist. **The rule used is always stated.** No verdict depends on how
a coefficient looks, and no real attention regression was run to reach any of them (DR7).

Legend for "difficulty": ● = an afternoon, ●● = a week, ●●● = a month or more.

---

### A. Measuring attention

| Id | Idea | Solves | How it works, plainly | Evidence | Data? | Diff. | Verdict and rule |
|---|---|---|---|---|---|---|---|
| **A1** | Canonical ASVI (log of the median of 8 prior weeks) vs the v2.0 form; windows 4/8/13/26 | P-03 | A search count is "abnormal" if it is far above its own recent normal. The standard is the founding paper's: log of today's count minus log of the median of the previous 8 weeks. | [S06] draft lines 92/364 | yes | ● | **CORE (A1a: canonical).** DR2 — canonical by default. Windows 4/13/26 are sensitivities, not the core: 8 is the only one with a published justification. |
| **A2** | Normalise by total Yandex traffic via the `share` column | P-22 | Divide the count by the total number of Yandex queries that week, so a week when everyone searches more does not look like firm-specific excitement. | Register J1–J2; [S46] help page as reported | yes (`D_t` recoverable) | ● | **EXTENSION (sensitivity S04).** DR4 — counts are primary because `D_t` is itself a rounded estimate; the normalised form is reported for the lockdown and New-Year weeks where it matters. |
| **A3** | More query variants (aliases, intent words) | P-04 | Add "Сбербанк котировки" to "Сбер", so small firms clear the noise floor. | No paper validates a specific recipe; [S06] uses several variants | partially (only 2 channels collected) | ●●● (re-collection) | **NEEDS-DATA.** The counts were collected in 2026 for two channels per firm; a third channel means re-collecting 75 × 419 weeks by hand. Not worth it. Use the two channels and disclose. |
| **A4** | Combine channels by sum / PCA / separately | P-03, P-04 | Sum assumes the two measures are two views of one thing; separate regressors let them differ. | [S06] shows variant-level results differ | yes | ● | **CORE as a sensitivity only.** Sum stays primary (v4.0 V4-04 justification is sound: low correlation is not evidence of different populations). Latin-only and Cyrillic-only are S15. |
| **A5** | Market-wide attention as a control with a firm-specific loading | P-05 | Some weeks everyone searches everything. Remove the common part, but let each firm's sensitivity be estimated rather than set to 1. | [S23], [S29], register J3/K7 | yes | ●● | **CORE (pooled) / EXTENSION (per-firm).** Week FE make it irrelevant in the pooled model (verified); the expanding-window loading (S18) is the per-firm upgrade. |
| **A6** | Validate ASVI against other attention proxies | P-23 | Show that the measure rises when attention rises, using outcomes that are not the regression's outcome. | [S06] validation section; [S48] Russian trading-activity co-movement | yes | ● | **CORE.** This is the cheapest credibility in the whole design. Explicitly allowed by DR7 (descriptive only). |
| **A7** | Sector or market-level attention indices; distributed lags | P-04, P-25 | Attention spills across a sector; also, effects may take weeks to show. | [S23] heterogeneity; [S15] horizons | yes | ●● | **EXTENSION.** Sector attention as an added regressor for H4; lags 0–4 for H2 (S08). |

### B. Measuring outcomes

| Id | Idea | Solves | Plainly | Evidence | Data? | Diff. | Verdict |
|---|---|---|---|---|---|---|---|
| **B1** | Range RV = ln(H/L); Parkinson / Garman–Klass / Rogers–Satchell / Yang–Zhang; log transform | P-01, P-16 | The high-low range of the week is a much better volatility measure than squared weekly returns. | [S36], [S37] | yes | ● | **CORE (ln(H/L) stays primary).** DR4. Add the daily-summed Parkinson variance as a robustness — it uses the daily bars Asif already has and is less exposed to a single intra-week gap. |
| **B2** | Dividend-adjusted and market-adjusted returns; absolute and squared adjusted returns; CAR 0–4; reversal | P-01, P-06, P-25 | A weekly return is mostly noise; the *size* of the move is what attention should affect. | [S06] pressure/reversal; [S15] horizons | yes | ●● | **CORE (absolute adjusted return as the primary return-outcome).** This is the direct answer to the supervisor's Q9: if returns fluctuate around zero, model their magnitude. |
| **B3** | Turnover / Amihud illiquidity from rubles | P-02, P-23 | Ruble volume fixes the split problem and doubles as an attention validator. | [S48] | yes | ● | **CORE as a control and validator**; EXTENSION as an outcome. |

### C. Model families and inference

| Id | Idea | Solves | Plainly | Evidence | Data? | Diff. | Verdict |
|---|---|---|---|---|---|---|---|
| **C1** | Per-firm OLS-HAC + pooled TWFE-DK | baseline | The current core. | [S01], [S39] | yes | ● | **CORE (per-firm) / CORE (pooled), but demoted**: the pooled model is the primary estimate, the per-firm family is the heterogeneity display. Reason: P-26. |
| **C2** | Fama–MacBeth weekly cross-sections | P-06, P-26 | Estimate the relation each week across firms and average the 419 weekly slopes. Common shocks cancel because they affect all firms that week. | [S40]; [S06] itself used a Fama–MacBeth design | yes | ●● | **CORE.** It answers P-06 and P-26 in one move and it is what the founding paper did. |
| **C3** | HAR-X (weekly); GARCH-X; GARCH-MIDAS-X | P-16, Q3/Q5 | HAR says this week's volatility is a mix of last week's, last month's and last year's; add attention to it. GARCH-MIDAS puts the weekly search variable into the long-run component of a daily model. | [S33], [S11], [S34], [S35] | yes | ● (HAR-X) / ●●● (GARCH-MIDAS-X) | **HAR-X: CORE.** **GARCH-X weekly: EXTENSION with a warning** (Stage 6 shows convergence and power at T=419). **GARCH-MIDAS-X: EXTENSION** (right model, wrong tools for a Python-only Master's if R is not available). |
| **C4** | LASSO / elastic net over query variants; out-of-sample evaluation (DM, MCS) | Q6, P-31 | Let a penalty choose among many predictors, and judge the model by forecasts rather than by p-values. | [S08], [S41], [S42], [S17] | yes | ●● | **Out-of-sample evaluation: CORE.** **LASSO over variants: EXTENSION** — with only 2 channels there is nothing to select among; it becomes useful only if A3 is ever done. |
| **C5** | Quantile regression | heterogeneity | Estimate the relation at different points of the return distribution. | [S03] | yes | ● | **EXTENSION.** [S03] is the precedent, but it multiplies the number of reported results, which raises the forking-paths cost (P-17). One table, as a robustness. |
| **C6** | Panel VAR / Granger; lead tests; falsification with non-financial queries | P-21 | Does attention come before volatility, or do both react to news? A lead test asks whether *future* attention predicts *current* volatility; if it does, the design is capturing news, not attention. | [S48] | lead test: yes; non-financial queries: no | ●● | **Lead test: CORE** (free, and it is the only credible reverse-causality check available). Granger: EXTENSION (already in v4.0 as M3). Non-financial queries: **NEEDS-DATA.** |
| **C7** | Inference: HAC lag, DK, bootstrap, two-way clustering, BH vs BY vs Holm vs Romano–Wolf, MDE | P-07 | With 74 tests, some will look significant by luck; and the tests are correlated, which changes the correction. | [S38], [S39], [S41], [S43] | yes | ●● | **CORE: BH + Holm + Romano–Wolf step-down, and MDE80 in economic units.** DR3 — the literature is split, so report more than one and pre-specify which is primary (Romano–Wolf). |
| **C8** | Breaks: Chow vs sup-F/Bai–Perron; level vs slope; rolling estimates | P-08 | Did the *relation* change in 2022, or only the *level* of volatility? And did it change at a date nobody chose in advance? | [S44] | yes | ●● | **CORE: level/slope split + Bai–Perron dating.** The rolling coefficient path is the supervisor's own "time-varying value of online data" idea [S08] and costs an afternoon. |
| **C9** | Heterogeneity: sector, SOE, size, retail holding, liquidity | P-04, P-11 | Attention probably matters more where investors are retail and information is scarce. | [S20], [S23] | size: yes; SOE: provisional; retail holding: no | ●● | **CORE: size groups only.** Sector (already H4) and SOE (H6) are kept but demoted to exploratory because of the label problems (P-11, YAKG). |
| **C10** | Monthly aggregation | P-04 | Averaging four weeks raises the signal for small firms at the cost of 4× fewer observations. | — | yes | ● | **REJECT.** 105 monthly observations per firm cannot identify a small effect; the noise reduction does not compensate. DR4 (parsimony and level). |

### D. Controls and data

| Id | Idea | Solves | Verdict |
|---|---|---|---|
| **D1** | Market RV, USD/RUB, oil, key rate, holiday weeks, weekend sessions, closures | P-14, P-19 | **CORE: market RV (in the HAR-X as the HAR terms themselves, plus the market return on the RHS) + a New-Year dummy + disclosure of the weekend-session fold.** USD/RUB, Brent and the key rate are **EXTENSION** because week FE absorb them in the pooled model. |
| **D2** | Crisis control without circularity | P-09 | **CORE: replace the outcome-derived dummy with lagged market RV (S13) and rely on week FE in the pooled model.** The existing windows stay in the appendix as description, not as a control. |
| **D3** | Sanctions: jurisdiction-first, pre-sample sectoral exposure, permanent step vs reaction window | P-10 | **CORE: restrict to verified anchors** (4 of 24) **or use a market-level factor.** A pre-sample sectoral exposure measure is elegant but is an EXTENSION: it needs a sanctions-to-sector map that does not exist in the data. |
| **D4** | Dividends: true ex-dates, class matching | P-01, P-12 | **CORE: add the dividend back to the return AND to the range** (the one thing v4.0 does not do). Class matching for dual-class firms is an EXTENSION. |
| **D5** | Universe, survivorship, tick size, sector map | P-15 | **ACCEPT-AND-DISCLOSE.** Nothing can be fixed without re-collecting delisted firms. |

### E. Reporting and honesty

| Id | Idea | Verdict |
|---|---|---|
| **E1** | Pre-specified sensitivity list; forking-paths statement; tournament before the real run; MDE; economic effect sizes | **CORE.** The tournament in `TOURNAMENT_PLAN.md` is hashed before running; the MDE translation is mandatory. |
| **E2** | Novelty bounded; no "first" | **CORE** — see `NOVELTY_STATEMENT.md`. |
| **E3** | Plan B: pooled or portfolio design if the firm-level effect is thin | **CORE (as Plan B).** A decile portfolio sort on ASVI with volatility as the outcome is robust to firm-level noise and is the standard attention design [S06]. |

### New ideas found in this round (not in Appendix A)

| Id | Idea | Solves | Evidence | Verdict |
|---|---|---|---|---|
| **N1** | **ASVI² (centred) in every volatility equation** | P-24 — the linear spec contradicts both theories | [S19] | **CORE. The single highest-value change in the package.** |
| **N2** | **Market return on the right-hand side instead of subtracted from the left** | P-06(b) — kills the generated-regressor problem | [S40], arithmetic | **CORE.** |
| **N3** | **Absolute dividend- and market-adjusted return as the return outcome** | P-06(a) — answers Q9 directly | [S06], [S19] | **CORE.** |
| **N4** | **Rolling/expanding ASVI coefficient plot ("the time-varying value of online data")** | P-08, Q6 | [S08] | **CORE. Costs one afternoon and is the supervisor's own idea applied to his student's data.** |
| **N5** | **Lead test**: ASVI_{t+1} in the RV_t equation | P-21 | standard falsification | **CORE.** |
| **N6** | **Effective-sample disclosure** for the pooled model | P-26 | register J3 | **CORE (reporting).** |
| **N7** | Sanction-announcement event study on ASVI only (no returns) as a validation | P-23 | [S06] event validation | **EXTENSION** — elegant, allowed under DR7, but needs the anchor list cleaned first (P-10). |
| **N8** | Machine-learning benchmark (random forest on ASVI + HAR terms) | — | [S08] robustness uses RF | **REJECT** for the core: it is exactly the black box Asif cannot defend at a Master's viva, and it adds forking paths. |
| **N9** | Signed attention (positive/negative news tone) | — | [S49] | **NEEDS-DATA** (no news/sentiment data). |

### Tally

| Verdict | Count | Ids |
|---|---:|---|
| CORE | 18 | A1a, A5(pooled), A6, B1, B2, B3, C1, C2, C3-HARX, C4(OOS), C6(lead), C7, C8, C9(size), D1, D2, D3(restricted), D4, E1, E2, E3, N1–N6 |
| EXTENSION | 12 | A2, A4, A5(per-firm), A7, B1(alt estimators), C3(GARCH-X), C3(GARCH-MIDAS-X), C4(LASSO), C5, C6(Granger), C9(SOE), D1(macro), D3(exposure), N7 |
| REJECT | 2 | C10, N8 |
| NEEDS-DATA | 3 | A3, C6(non-financial), N9 |


---

*Source file: `stage5/PROBLEM_TO_SOLUTION_MATRIX.md`*

Status vocabulary: **SOLVED-BY-DESIGN** · **MINIMISED** · **ACCEPT-AND-DISCLOSE** · **NEEDS-DATA**.
Every one of the 31 register rows appears. An empty "solution" cell is not allowed; if nothing can be
done, the status is ACCEPT-AND-DISCLOSE and the disclosure text is named.

| Problem | Sev | Status | Solution (idea ids) | Where it lands in the thesis |
|---|---|---|---|---|
| P-01 ex-dividend mechanics | S1 | **SOLVED-BY-DESIGN** | D4 + B1: add DPS back to the return **and** rebuild the pre-ex daily highs/lows to add it back to the range; price-only as mirror (S19) | §Data, §Robustness; Appendix table comparing RV before/after |
| P-02 share-count volume breaks | S1 | **SOLVED (models) / OPEN (crisis windows)** | ln(VALUE) primary (D1/B3); crisis windows rebuilt on the VALUE leg as a robustness | §Data; robustness table |
| P-03 ASVI median-of-logs | S2 | **SOLVED-BY-DESIGN** | A1a canonical form; v2.0 form as S03 | §Data (formula) |
| P-04 thin counts, size noise | S1 | **MINIMISED** | C9 size quartiles + precision weights + minimum-count sensitivity S21; quantify the loss with Stage 6d | §Heterogeneity; §Limitations |
| P-05 market attention, loading = 1 | S2 | **SOLVED (pooled) / MINIMISED (per-firm)** | A5: week FE primary; market-median as added regressor S05; expanding-window loading S18 | §Method; §Robustness |
| P-06 market-adjusted returns near zero | S1 | **SOLVED-BY-DESIGN** | N2 (market return on the RHS) + N3 (absolute adjusted return) + C2 (Fama–MacBeth) + S07 rolling beta | §Method (the Q9 answer); §Results |
| P-07 inference and multiplicity | S1 | **MINIMISED** | C7: DK primary pooled; BH + Holm + Romano–Wolf; MDE80 in economic units (N6, P-27) | §Method; every results table |
| P-08 H3 level vs slope, unknown date | S1 | **SOLVED-BY-DESIGN** | C8: δ1/δ2 separated, Bai–Perron dating, rolling coefficient (N4); G–L bounds dropped | §H3 |
| P-09 circular crisis control | S2 | **SOLVED (pooled) / DISCLOSED (per-firm)** | D2: lagged market RV replaces the flag (S13); week FE absorb it | §Controls; §Limitations |
| P-10 sanctions coding | S2 | **MINIMISED** | D3: restrict to the 4 verified anchors, or a market factor; report the restriction | §Controls; §Limitations (explicit) |
| P-11 state ownership | S2 | **ACCEPT-AND-DISCLOSE** | C9: H6 exploratory; continuous ownership share as a proposed upgrade | §H6 (declared provisional) |
| P-12 dividend table provenance | S1 | **MINIMISED** | D4 + S14 additive-outlier cross-check | §Data; §Limitations |
| P-13 news layer abandoned | S3 | **ACCEPT-AND-DISCLOSE** | disclosure; no replication of Vlastakis–Markellos can be claimed | §Limitations |
| P-14 missing macro/market series | S2 | **SOLVED (pooled) / ACCEPT (per-firm)** | D1: week FE absorb them; use the IMOEX total-return index for per-firm models | §Data; §Limitations |
| P-15 universe, survivorship, tick size | S2 | **ACCEPT-AND-DISCLOSE** | D5 + a tick-size screen for all 75 | §Sample; §Limitations |
| P-16 no daily search data | S1 | **ACCEPT-AND-DESIGN-AROUND** | A: daily GARCH-X is impossible; GARCH-MIDAS-X is the route (EXTENSION) | §Method; §Extensions |
| P-17 forking paths | S1 | **MINIMISED** | E1 + hashed tournament + a count of specifications estimated | §Transparency appendix |
| P-18 novelty, Wordstat validity | S2 | **SOLVED (framing)** | E2 + A6 validation + "after the Google exit" framing | §Introduction |
| P-19 calendar quirks | S3 | **ACCEPT-AND-DISCLOSE** | P-29 dummy post-March-2025 in the volume control | §Data; §Limitations |
| P-20 earlier package failed audit | S3 | **MITIGATED** | evidence discipline: source id or code path for every number | throughout |
| P-21 reverse causality | S1 | **MINIMISED** | C6 lead test + lagged regressor + placebo (S12) | §Identification |
| P-22 meaning of a Wordstat count | S2 | **MINIMISED** | A2 normalisation sensitivity (S04) + A6 validation | §Data; §Limitations |
| P-23 no validation of the measure | S1 | **SOLVED-BY-DESIGN** | A6: four correlations and one event check, no price regression | §Validation (new section) |
| P-24 linear spec contradicts theory | S1 | **SOLVED-BY-DESIGN** | **N1: ASVI² centred**, turning point reported | §H1; the headline figure |
| P-25 one-week horizon | S2 | **SOLVED-BY-DESIGN** | A7: h = 0…4 and CAR 0–4 (S08) | §H2 |
| P-26 pooled effective sample | S2 | **SOLVED (reporting)** | N6 + C2 Fama–MacBeth as the cross-check | §Method; §Limitations |
| P-27 MDE in economic units | S1 | **SOLVED-BY-DESIGN** | C7 + N6 translation table | every results table |
| P-28 convergence reporting | S2 | **SOLVED (rule)** | pre-registered convergence criterion; failure counts reported | §GARCH extension only |
| P-29 weekend-session volume inflation | S3 | **ACCEPT-AND-DISCLOSE** | post-March-2025 dummy | §Limitations |
| P-30 crisis collinear with week FE | S3 | **SOLVED (division of labour stated)** | per-firm for firm-varying controls, pooled for the average slope | §Method |
| P-31 no design-level power analysis | S1 | **SOLVED** | Stage 6 of this package; results quoted in the thesis §Power | §Power; Appendix |

### Counts

| Status | Count |
|---|---:|
| SOLVED-BY-DESIGN (incl. reporting fixes) | 12 |
| MINIMISED | 9 |
| ACCEPT-AND-DISCLOSE | 7 |
| NEEDS-DATA | 0 (all data-dependent ideas were replaced, not deferred) |
| OPEN / design-around | 3 (P-02 crisis rebuild, P-16, P-28 in the extension only) |

**Rule check.** No status was chosen because it made a coefficient look better; each refers to a
correctness rule (DR1), a canonical definition (DR2), a literature-supported design (DR3), parsimony
(DR4), pre-specification (DR5) or disclosure (DR6).


---


<!--BREAK-->

## Appendix G — The tournament plan, as hashed before it ran

*Source file: `stage5/TOURNAMENT_PLAN.md`*

**Written 2026-10-20, before Stage 6 was executed. SHA-256 of this file is in
`TOURNAMENT_PLAN.sha256` and is re-checked in `stage6/SIM_REPORT.md`.**

Purpose: decide, **before looking at any result**, which volatility specification the thesis will
report as primary and which will be reported only as robustness. The decision rule is written here and
cannot be changed after the numbers appear.

---

### 1. Candidates (volatility outcome only; no return-outcome candidate is decided here)

| Key | Specification | Equation (plainly) |
|---|---|---|
| **S0** | Benchmark | `RV_t = a_i + Σ_h φ_h RV_{t−h} + γ ln(VALUE)_{t−1} + e` (AR(1) per firm; HAR terms in the pooled version) |
| **S1** | Linear ASVI | S0 + `β·ASVI_{t−1}` |
| **S2** | Quadratic ASVI | S1 + `β₂·ASVI²_{t−1}` (ASVI centred at its own sample mean) |
| **S3** | Market-return control | S1 + `δ·r^m_t` and `δ̄·r^m_{t−1}` — the market enters on the right-hand side instead of being subtracted from the outcome |
| **S4** | Fama–MacBeth | weekly cross-sections of `RV_t` on `ASVI_{t−1}` and controls; average the 419 slopes |
| **S5** | HAR-X | `RV_t = c + b_d RV_{t−1} + b_w mean(RV_{t−5:t−1}) + b_m mean(RV_{t−22:t−1}) + β ASVI_{t−1}` |
| **S6** | Weekly GARCH-X | `r_t = μ + √h_t z_t`, `h_t = ω + α ε²_{t−1} + β h_{t−1} + γ ASVI_{t−1}` |
| **S7** | GARCH-MIDAS-X | daily returns; long-run component driven by a MIDAS-weighted weekly ASVI; **literature-only in this package** (no Python estimator available) |

### 2. Data-generating processes for the synthetic lab

| Key | DGP | What it is for |
|---|---|---|
| **D0** | No attention effect (β = 0), RV AR(1), firm size quartiles matching the observed ASVI sd (0.49/0.36/0.30/0.26), 16.6% common ASVI variance, a common weekly RV shock | **Size** of every test |
| **D1** | Linear β ∈ {0.002, 0.005, 0.010} homogeneous across firms | **Power** of per-firm, pooled, FM, HAR-X |
| **D2** | β heterogeneous: half the firms at 2β, half at 0 | Power of the heterogeneity display |
| **D3** | True relation U-shaped: `f(A) = b₁A + b₂A²`, with b₁ < 0, b₂ > 0, vertex inside the data range | Does a linear-only test mislead? (P-24) |
| **D4** | Attention measured with noise (classical measurement error of 50% and 100% of the signal variance) | What extra query variants would buy (A3) |
| **D5** | GARCH(1,1) weekly returns + γ ASVI in the variance | Convergence and power of S6 at T = 419 |
| **D6** | Missing weeks (5%, 15% at random) and one 3-week market closure | Robustness of all estimators |

All DGPs are calibrated so that the **null** DGPs reproduce the observed magnitudes reported in the
register (per-firm MDE80 ≈ 0.024; pooled DK SE ≈ 0.0018). If a DGP cannot reproduce them, the
calibration is reported and the numbers are not used.

### 3. Criteria

1. **Size**: rejection rate at the 5% nominal level under D0, within [0.03, 0.07] for 500 replications.
2. **Power**: rejection rate under D1/D2 at each β.
3. **Bias**: mean estimate minus true β, as a fraction of the absolute true β.
4. **Interval coverage** of the 95% interval under D1.
5. **Multiple-testing behaviour**: the proportion of replications in which BH declares at least one
   false discovery under D0 across the 74 per-firm tests.
6. **Forecast criterion** (for S5 only): out-of-sample MSE and QLIKE on a 100-week hold-out; Diebold–
   Mariano against S0.

### 4. Decision rule (binding)

- **DR-T1.** The primary volatility specification is the **simplest** candidate that (a) has size in
  [0.03, 0.07] and (b) has power ≥ 0.80 at β = 0.005. Simplicity order: S1 < S3 < S5 < S2 < S4 < S6.
- **DR-T2.** If no candidate reaches power 0.80 at β = 0.005, the thesis must state the **minimum
  detectable effect** and must not interpret a null as evidence of no effect. It must also report the
  candidate with the highest power among those with correct size.
- **DR-T3.** If S2 (quadratic) has correct size and S1 is **biased** under D3, then S2 is primary for the
  volatility hypothesis regardless of its power, because a misspecified estimator's point estimate is
  not interpretable.
- **DR-T4.** Fama–MacBeth (S4) is reported **alongside** whichever slope specification wins, never alone,
  because its estimand (the average cross-sectional slope) differs from the panel estimand; if the two
  disagree in sign, the disagreement is reported and the thesis does not choose between them on the basis
  of which is significant.
- **DR-T5.** GARCH-X (S6) is included in the thesis only if its convergence rate under D5 is ≥ 95% and
  its power at a 10% change in conditional variance is ≥ 0.80. Otherwise it is a **literature
  discussion**, not an estimation, and the convergence failures of [S18] are cited.
- **DR-T6.** No candidate may be added or dropped after this file is hashed. Sensitivities are the
  pre-existing S01–S21 list in the methodology, plus nothing.

### 5. What this tournament cannot decide

- The return-outcome specification (beyond the market-return-on-the-RHS point) — that is a design
  argument, not a power question, and is settled in `BEST_PATH_REPORT.md` §4.
- The sanctions and dividend coding — data quality, not power.
- Anything about the real data. **No real attention variable enters any simulation** (DR7).


---


<!--BREAK-->

## Appendix H — The simulation report: size, power, robustness, rulings

*Source file: `stage6/SIM_REPORT.md`*

**No real attention variable entered any model in this stage (DR7).** Every number below comes from
simulated panels. Code: `stage6/sim_lab.py`. Raw output: `stage6/SIM_RESULTS.csv`, `stage6/SIM_LOG.txt`.

**Traceability note.** `SIM_RESULTS.csv` holds 42 rows: the 36 written by `sim_lab.py` plus six the script
only printed to the log (the quadratic term's own test size, the two block-D mean coefficients, the three
block-E mean estimates). They are re-attached by `stage6/append_traceability_rows.py`, which is idempotent.
Every number quoted below now has a row; the red team found the gap and it is closed.

**Order of operations, checkable.** `TOURNAMENT_PLAN.md` was written and hashed at
`2026-10-20T16:42:44Z` (SHA-256 `d4718077…a7e`, `stage5/TOURNAMENT_PLAN.sha256`); the final simulation
run finished at `2026-10-20T16:55:50Z` (mtime of `SIM_LOG.txt`). Re-hash the file and compare.

### 0. Calibration and its honesty cost

| Quantity | Simulated | Observed (register / FINAL_REPORT) |
|---|---:|---:|
| Per-firm MDE80 at T = 419 | ≈ 0.029 | ≈ 0.024 |
| Pooled DK SE on ASVI | 0.00132 | 0.001833 |

The panel was calibrated on the firm-level noise (`SD_LOGRV = 0.08` per week, ASVI sd by size quartile
0.49/0.36/0.30/0.26, 16.6% common ASVI variance, AR(1) 0.55). The simulated pooled standard error is
**0.72× the observed one**, so **every pooled power figure below is an upper bound**. The reason the two
cannot be matched simultaneously is informative: adding a common weekly shock does *not* raise the DK
standard error at all, because **week fixed effects absorb it**. The observed 0.0018 must therefore come
from residual cross-sectional dependence (sector-level shocks) that this DGP does not contain.
*Consequence for the thesis: the pooled design is less precise than a naive simulation suggests, and the
"29,642 observations" language overstates precision (P-26).*

### 1. Size (D0, 400 replications, nominal 5%)

| Specification | Rejection rate | Verdict |
|---|---:|---|
| S1 per-firm (74 tests, HAC-5) | 0.057 | correct |
| S1 pooled (two-way FE, DK-4) | 0.052 | correct |
| S2 quadratic, linear term | 0.050 | correct |
| S2 quadratic, **quadratic term** | **0.075** | mildly **liberal** |
| S4 Fama–MacBeth | 0.058 | correct |
| S5 HAR-X | 0.033 | conservative |

**BH false-discovery check:** across 400 replications with *no* true effect, the per-firm + BH procedure
declared at least one "discovery" in **0.1%** of replications. So when BH reports five survivors, that is
not a multiplicity artefact — it is either a real effect or a specification problem elsewhere (dividends,
splits, size). This is a useful exoneration of the existing H1 result, and it sharpens where to look for
the problem.

### 2. Power (D1, homogeneous β, 400 replications)

| β (true) | Per-firm | Pooled DK | Fama–MacBeth | HAR-X |
|---:|---:|---:|---:|---:|
| 0.002 | 0.061 | 0.315 | 0.300 | 0.393 |
| 0.005 | 0.096 | **0.963** | **0.960** | **0.985** |
| 0.010 | 0.211 | 1.000 | 1.000 | 1.000 |

**Empirical MDE80 of the per-firm design: β ≈ 0.029.** The existing per-firm H1 cannot detect anything
smaller than that, and the largest surviving slope in the real results is RTKM at −0.040. In other words:
**the five BH survivors are exactly the firms whose true slopes would have to be enormous to be detected
at 80% power.** That is either a genuine concentration of effect or a specification artefact in those five
names (LSRG, MFGS, PHOR, RTKM, SNGS — note that three of the five are large, heavily traded names). This
is the most important diagnostic in the package and it points directly at Plan A's firm-level
re-specification.

**Pooled and Fama–MacBeth have power 0.96 at β = 0.005.** So the *panel* design can answer the question
the thesis asks; the *per-firm* design cannot. That alone justifies demoting the per-firm family to a
heterogeneity display (C1 verdict in Stage 5).

### 3. The quadratic trap (D3)

True relation: `f(z) = −0.008·z + 0.010·z²`, z = ASVI standardised within firm. Vertex at z = +0.40.
So volatility **falls** with attention up to 0.4 sd above normal, then **rises**; and it is the rise that
the theory [S19, S02] is about.

| Estimator | Result over 400 replications |
|---|---|
| Linear-only | mean slope **−0.00795**; significantly negative in **100%** of replications |
| Quadratic | mean quadratic coefficient **+0.00997** (true +0.010); detected in **100%** |

**This is the trap, stated precisely.** The linear-only estimate is not wrong as a number — it is a
consistent estimate of the **average derivative**, and the average derivative is negative because 65% of
the probability mass sits below the vertex. But a thesis that reports only the linear coefficient will say
"attention is followed by lower volatility", which is the **opposite** of what happens in the high-attention
weeks that the literature is about. The published Russian null [S17] and Asif's 55-of-74 negative slopes
are both compatible with exactly this picture.

**Decision.** Under DR-T3 as written (bias), the quadratic does **not** become primary, because the linear
estimator is not biased for the average derivative. The rule did not anticipate this case — declared.
The operative consequence is a **reporting rule**:
> Report S1 **and** S2 together, always. A linear-only table will not be accepted as an answer to H1.

This is the strongest single recommendation in the package, and it costs one afternoon.

### 4. Measurement error (D4): what more query variants would buy

| Noise added | Power at β = 0.005 | Mean estimate (true 0.005) |
|---|---:|---:|
| none | 0.973 | 0.00508 |
| +50% of signal variance | 0.847 | 0.00313 |
| +100% of signal variance | 0.720 | 0.00233 |

Classical measurement error attenuates the estimate by **39%** at +50% noise. Two channels summed
(A4) already buy some of this; a third channel (A3) would buy back roughly the top row. Since a third
channel means re-collecting 75 × 419 weeks by hand, **the honest verdict is NEEDS-DATA** (Stage 5, A3) —
but the table tells Asif exactly what he is giving up: about 12 percentage points of power and 0.002 of
coefficient magnitude.

### 5. Missing weeks (D6)

| Missing share | Pooled power | FM power |
|---|---:|---:|
| 5% | 0.932 | 0.920 |
| 15% | 0.848 | 0.824 |

Random missingness costs little; the 2022 closure (3 consecutive weeks) is not the problem. **The
missing-data risk is not power, it is selection** — the 328 no-trade firm-weeks are not random (illiquid
firms stop trading when nothing happens), and this design cannot correct that.

### 6. Weekly GARCH(1,1)-X (D5) — the answer to the supervisor's Q3

| Metric | Value |
|---|---:|
| Convergence rate over 200 simulated series (T = 419) | **50.5%** |
| Power of the attention coefficient, for an effect that raises conditional variance by 10% per 1 sd of ASVI | **0.000** |

**Two findings, both usable.**
1. **Half the GARCH-X fits fail** at weekly frequency with 419 observations, exactly as [S18] reported for
   Russian data ("several models did not reach numerical convergence"). A thesis that ran 75 of these and
   reported only the survivors would be reporting a selected sample; P-28 exists because of this.
2. **Even when it converges, it cannot detect an economically large effect.** The attention coefficient in
   a weekly GARCH-X is essentially unidentified at this sample size.

**Ruling (DR-T5).** GARCH-X is **not** estimated in the thesis. It becomes a literature discussion with a
power calculation table — which is a much stronger answer to the supervisor than a fragile fit: *"I ran the
feasibility check; at 419 weeks the model converges half the time and has no power, which is consistent
with Fantazzini and Shangina's reported non-convergence. The model that fits my data is GARCH-MIDAS-X,
where the weekly search variable drives the long-run component of daily volatility, and I report it as an
extension."*

**What to do instead if the supervisor insists on a GARCH-family model:** put the search variable in the
**long-run component** (S7, GARCH-MIDAS-X with daily returns), not in the short-run variance equation. That
is the specification the data can carry, and [S11] is the template.

### 7. Forecast evaluation (criterion 6) — NOT RUN

The HAR-X vs HAR out-of-sample comparison (100-week hold-out, DM test) was planned and **not executed**:
the power question was already answered by the in-sample tests and the run time was already ~10 minutes.
Declared `NOT-DONE`. It is cheap to add and is recommended as the first thing Asif runs, because the
supervisor is forecasting-oriented and this is the table he will look for.

### 8. Decision ruling, written against the plan

| Rule | Fires? | Ruling |
|---|---|---|
| **DR-T1** simplest spec with size ∈ [0.03,0.07] and power ≥ 0.80 at β = 0.005 | **Yes** — S1 (pooled, linear, with ln(VALUE) and lags) | **S1 is primary.** It is also the simplest. |
| **DR-T2** no candidate reaches 0.80 | No | — |
| **DR-T3** S2 primary if S1 biased under D3 | **No** (S1 estimates the average derivative consistently) | S2 stays **mandatory but secondary**; the rule's blind spot is declared in §3 |
| **DR-T4** FM reported alongside | **Yes** | FM and the pooled slope agree in sign and magnitude in every DGP; report both |
| **DR-T5** GARCH-X only if convergence ≥ 95% and power ≥ 0.80 | **No** | **GARCH-X is excluded from estimation**; literature discussion only |
| **DR-T6** no post-hoc candidates | Honoured | No candidate added or dropped |

### 9. What this lab did not do

- No real attention series, no real returns, no real volatility (DR7).
- No dividend or corporate-action contamination in the DGP. P-01's effect on power is therefore not
  quantified; the register's arithmetic (−25% RV in ex-weeks) suggests the noise increase is modest but
  concentrated.
- No sector-level dependence, which is why the pooled SE is 0.72× the observed one.
- No MIDAS/GARCH-MIDAS simulation (no estimator available in Python here).

### QA1 — 9/10

Every number is reproducible from the shipped script with a fixed seed; the calibration is reported
against the observed value rather than tuned to match; one planned block is declared NOT-DONE.
One point lost because the forecast-evaluation block was not run.


---


<!--BREAK-->

## Appendix I — Answers, decisions, literature skeleton, reading list

*Source file: `stage7/ANSWERS_TO_SUPERVISOR.md`*

Eleven items. Each answer is 3–8 lines, in a tone Asif can send or say, with the source he can hand over
if asked. **Asif adapts the wording**; the content and the numbers should not change.

---

### Q1 · "Without formulas the ideas can be read several ways. I want the draft: literature review, data, empirical models, results, discussion, conclusions."

You are right, and the formulas are now fixed. The core is four equations. The abnormal attention measure
is $ASVI_{i,t}=\ln(SVI_{i,t})-\ln(\text{median}(SVI_{i,t-8},\dots,SVI_{i,t-1}))$ — the founding paper's
exact form, verified in the paper itself. The outcome is weekly range volatility $RV_{i,t}=\ln(H_{i,t}/L_{i,t})$
on dividend-adjusted bars. The main model is a two-way fixed-effects panel with a linear and a quadratic
attention term, Driscoll–Kraay errors, and firm and week effects. The return model keeps the market return
on the right-hand side instead of subtracting it. The draft order will be: literature review, data and
measurement, models, results, discussion, conclusions — with a validation table for the measure before any
regression appears.
*Source: the ASVI definition is quoted verbatim from Da, Engelberg & Gao, draft lines 92 and 364.*

---

### Q2 · "Fine if the articles measure SVI and ASVI the same way. Give the references."

They do, with two caveats that I will state. Da, Engelberg & Gao (2011) define ASVI as the log count minus
the log of the eight-week median, and my measure is identical to that. Swamy, Dharani & Takeda (2019, India)
and Yoshinaga & Rocco (2020, Brazil) both use an abnormal search measure on weekly firm data, though the
exact standardisation differs between them — Yoshinaga and Rocco work with lagged *changes* in search
volume — so I will state my own formula explicitly rather than claim identical construction. Teplova &
Gurov (2025) use Google search volumes for Russian stocks. The second caveat: Google Trends returns an index scaled 0–100
within each query, while Wordstat returns raw counts, so my series is a count, not an index — a difference
in the *input*, not in the ASVI formula, disclosed in the data section.
*Sources: Da/Engelberg/Gao 2011; Swamy et al. 2019 RIBAF 50; Yoshinaga & Rocco 2020 BBR 17(5); Teplova & Gurov 2025 Ann. Oper. Res. 352.*

---

### Q3 · "Why not GARCH models for volatility augmented with my ideas? Has anyone done something like this?"

Yes — twice, on Russian data, and the results are the reason I did not make it my main model. Bazhenov and
Fantazzini (2019) put Google Trends into HAR, ARFIMA and GARCH(1,1) for four liquid Russian stocks: no
significant search effect and worse out-of-sample forecasts. Fantazzini and Shangina (2019) did the same for
the RTS futures and several augmented models failed to converge. I also ran the feasibility check: at 419
weekly observations a GARCH(1,1)-X with an attention regressor converged in 50.5% of 200 simulated series
and had **zero** power even for an effect that raises variance by 10%. So I report GARCH-X as a literature
discussion with a power table, and the GARCH-family model I recommend is GARCH-MIDAS-X, where weekly search
drives the long-run component of daily volatility — that is the specification the data can carry.
*Sources: Bazhenov & Fantazzini 2019 RJIE 12(1); Fantazzini & Shangina 2019 Appl. Econometrics 55; Amendola, Candila & Gallo 2021 Ecosta 20.*

---

### Q4 · "419 observations can be fine for some models or as a robustness check."

Agreed, and I can now say which. For the **panel** estimators 419 weeks × 74 firms is enough: at a true
coefficient of 0.005 the two-way fixed-effects model rejects 96% of the time and Fama–MacBeth 96%. For the
**74 per-firm** regressions it is not: the minimum detectable effect at 80% power is 0.029, six times
larger, and power at 0.005 is 9.6%. So the panel carries the identification and the per-firm regressions
become a heterogeneity display rather than the main test. For **GARCH** it is not enough at all (see Q3).
*Source: the simulation report in this package, 400 replications per cell.*

---

### Q5 · "Try MIDAS models."

I agree in principle and I would sequence it. The honest constraints: my search variable is weekly and my
prices are daily, so the natural specification is GARCH-MIDAS with weekly attention in the long-run
component — exactly the architecture of Amendola, Candila and Gallo (2021). The practical obstacle is that
there is no mature Python implementation; the R package `mfgarch` would be needed, and my entire pipeline
is Python. So I propose: a U-MIDAS (unrestricted MIDAS = OLS with distributed lags) as a within-Python
approximation in the main text, and a true GARCH-MIDAS-X on a subsample as the extension if R is available.
*Source: Amendola et al. 2021 for the architecture; Engle, Ghysels & Sohn 2013 for GARCH-MIDAS.*

---

### Q6 · "Another way of using online data: Fantazzini and Kurbatskii (2026)."

That paper gave me the single most useful idea in the review, and one warning. The idea: the value of
online data is **time-varying**, so my H3 should not be a single break test but a rolling coefficient plot
that shows whether the attention–volatility relation survived 2022. The warning: their abstract reports
that Russian search data's predictive power was significant before the early-2022 geopolitical shift and
**degraded sharply afterwards**. My sample is 60% post-2022, so I must present the subperiod analysis as a
main result, not a robustness check. I would also borrow their out-of-sample framing — benchmark model
versus augmented model — instead of relying only on coefficient significance.
*Source: Fantazzini & Kurbatskii 2026, SSRN 6468200 (abstract).*

---

### Q7 · "Fantazzini said Yandex Wordstat gives better information than Google Trends."

I looked for this in writing and found something slightly different, which is worth knowing before you
quote it. The SSRN paper in your list uses **Google Trends**, not Wordstat. The Wordstat comparison is a
separate work: the META2026 programme lists a talk by Fantazzini and Kurbatsky on 2 October titled
"Searching for inflation: forecasting Russian regional prices with Yandex Wordstat after Google's exit". I
could not find a written version. So the claim is well anchored as a research topic but I cannot yet cite a
result — I will label it as a personal communication until the slides or a draft appear, and I have
already built the argument for Wordstat on a different, citable basis: after 2022 Yandex is the only
search engine with continuous and representative coverage of Russian users.
*Source: META2026 conference programme, HSE; SSRN 6468200.*

---

### Q8 · "Did you use a Wordstat API? Which tools are current?"

I downloaded manually; my scripted attempts hit what looked like a rate limit. Current options, in order of
reliability: (1) the **official Wordstat API in Yandex AI Studio**, whose `GetDynamics` method returns
query frequency aggregated by month, **week or day** — if that confirms, weekly re-collection becomes
scriptable and daily data may be available for recent windows; (2) the legacy Direct-API wrappers such as
`YandexWordstatAPI`, which are dated and may no longer work; (3) browser scraping, which is fragile and a
terms-of-service risk. My recommendation is to test (1) on ten queries before re-collecting anything.
*Source: Yandex AI Studio documentation (the page itself returned a captcha; verified from the search
snippet), PyPI `YandexWordstatAPI`.*

---

### Q9 · "I am afraid of explaining market-adjusted returns, because they fluctuate around zero."

I think you are right, but I would put the reason differently, and then the fix becomes clear. A dependent
variable with mean zero is not itself a problem for a regression. The problem is that a weekly
market-adjusted return has a signal-to-noise ratio of roughly 1:200, so the minimum detectable effect is
several times any plausible attention effect — and no estimator fixes that. There is also a second
problem: estimating beta on 2018–2021 and applying it afterwards puts a generated regressor inside the
outcome, and the beta itself may have broken in 2022. So I propose three changes: put the market return on
the **right-hand side** instead of subtracting it, so nothing is generated; use **Fama–MacBeth**, which
estimates the common component each week and needs no beta at all; and make the main return outcome the
**absolute** abnormal return — the size of the move — because that is the quantity attention theory
actually speaks about. "It will be interesting if I'm not right" — I agree, and this design lets the
negative result be informative rather than empty.
*Source: Fama & MacBeth 1973; Swamy et al. 2019 for the rolling-beta alternative.*

---

### Q10 · "The ideas are enough for a Master's thesis. Keep the recommendation realistic."

Yes. Plan A is five pieces and every one of them is standard software: range volatility from the price
files, ASVI as already computed, a two-way fixed-effects panel and a weekly cross-section, a validation
table of four correlations, and one rolling-window loop. Nothing requires a package outside
pandas/statsmodels/linearmodels, and the whole estimation runs in minutes on a laptop. I have explicitly
put the expensive options — GARCH-MIDAS-X, real MIDAS, penalised regression over many query variants —
into an extension layer that can be dropped without damaging the thesis.
*Source: the runtime log of the simulation lab in this package.*

---

### Q11 · "Companies differ hugely in search volume. Does subtracting the cross-sectional average ASVI distort the signals, and does it remove the need for crisis dummies?"

Subtracting does not specifically hurt small firms — the measured effect is the opposite of the worry:
it changes the variance of ASVI by −9%/−17%/−26%/−22% from the smallest to the largest quartile, so it
removes the *least* from small firms, and it actually raises the variance for four of the 75. Two real
problems remain: noise differs by size (the standard deviation of ASVI is 0.49 in the smallest quartile and
0.26 in the largest), and subtraction assumes every firm has the same sensitivity to market attention, when
the measured loadings run from 0.28 to 1.89. My proposal: do not subtract. In the pooled model, week fixed
effects do the job exactly — the slope is identical whether ASVI is raw or de-meaned — and they absorb all
market-wide shocks including the crisis weeks. In the per-firm models, add the market median as a control
with **estimated** firm-specific sensitivity rather than imposing 1.0.
*Source: register sections J3 and K7 (recomputed on the files).*


---

*Source file: `stage7/DECISIONS_FOR_ASIF.md`*

Eight decisions. For each: the choice, the trade-off in plain English, what I recommend, and what it costs
if you choose differently. **None of these is a technical detail; each one changes what the thesis is.**

---

### D-1 · What is the primary outcome: returns or volatility?

**The choice.** (a) Returns stay primary and volatility is secondary. (b) Volatility becomes primary and
returns stay as a secondary chapter.

**Trade-off in plain English.** A weekly return is dominated by news you cannot measure; a weekly range is
dominated by the same news but is far less noisy, so a small effect is visible. If you keep returns primary,
the most likely outcome is a table of insignificant coefficients whose confidence intervals are too wide to
mean anything. If you switch to volatility, you answer a question your data can answer — but you move away
from the price-pressure story that most of the attention literature tells.

**Recommendation: (b).** Volatility primary, returns secondary with the market on the right-hand side.
**Cost of choosing (a):** you will write a thesis whose main table cannot distinguish "no effect" from
"design too weak", and a committee member who reads the MDE line will say so.

---

### D-2 · Do you report the quadratic term?

**The choice.** (a) Linear ASVI only, as in v2.0–v4.0. (b) Linear **and** ASVI-squared in every specification.

**Trade-off.** The quadratic is the one change that lets your thesis test a real theory [S19] instead of
producing a sign. It costs one afternoon: centre ASVI, square it, run the same regressions, report the
turning point. The risk is that it is insignificant — but an insignificant quadratic with a stated MDE is a
result, whereas an insignificant linear coefficient is a shrug.

**Recommendation: (b), always, in every table.** **Cost of (a):** if the true relation is curved, a linear
table will show a negative average slope and you will write the opposite of what is happening in the weeks
the theory is about — the simulation demonstrates this exactly.

---

### D-3 · Do you keep the 74 per-firm regressions as the main test?

**The choice.** (a) The per-firm family carries H1 (the current plan). (b) The panel carries H1 and the
per-firm family becomes a heterogeneity display.

**Trade-off.** The per-firm design cannot detect anything smaller than β ≈ 0.029, six times the size that
matters; at a plausible β = 0.005 it has 9.6% power. Reporting 74 regressions as the main test therefore
guarantees an uninformative headline. But dropping them entirely loses the "where does it matter" story.

**Recommendation: (b).** Keep the 74 regressions, keep BH, but present them as "heterogeneity", and put the
pooled + Fama–MacBeth slopes first. **Cost of (a):** the thesis's main claim rests on the least powerful
estimator in the package.

---

### D-4 · Do you correct the range volatility for dividends, or only the returns?

**The choice.** (a) Add the dividend back to returns only (current v4.0). (b) Add it back to returns **and**
to the intra-week highs and lows.

**Trade-off.** Register L4 measures a −25% average change in RV in ex-dividend weeks, and 62% of those weeks
change by more than 10%. If you correct only returns, the volatility outcome remains contaminated in exactly
the weeks when the dividend control is switched on — which is the mechanical link that made H5 shrink from
−0.022 to −0.007 when Claude added dividends back. The correction is arithmetic, not a modelling choice, so
it is defensible under DR1.

**Recommendation: (b).** **Cost of (a):** a reviewer who knows the ex-dividend mechanics can attribute part
of any H5 result to the dividend, and you will not have an answer.

---

### D-5 · Do you run a GARCH model?

**The choice.** (a) Yes — the supervisor asked for it. (b) No — a power table instead. (c) GARCH-MIDAS-X
only, on a subsample, as an extension.

**Trade-off.** The simulation says a weekly GARCH-X converges half the time and has zero power for a large
effect. Running 75 of them and reporting the successful ones is exactly the selective reporting the
register's P-28 forbids. But refusing the supervisor's request outright is a political cost, not a
statistical one.

**Recommendation: (b) plus (c).** Show him the power table, cite [S18]'s documented non-convergence as
corroboration, and offer GARCH-MIDAS-X as the extension that is actually estimable. **Cost of (a):** a
chapter of fragile fits and a hidden selection problem.

---

### D-6 · How do you handle the 2022 break?

**The choice.** (a) A break test in an appendix (current M5). (b) The break as a central object: a rolling
coefficient plot and a pre/post split, presented as the thesis's second contribution.

**Trade-off.** Fantazzini & Kurbatskii's abstract says Russian search data's value degraded after early
2022 — in a different market, for a different outcome, but it is the supervisor's own reference. If the
relation died in 2022, a full-sample average is a blend of a live and a dead relation and will look like
nothing. Choosing (b) turns that risk into the finding.

**Recommendation: (b).** **Cost of (a):** you may report a null that is really a mixture of two regimes.

---

### D-7 · Do you keep the state-ownership hypothesis (H6)?

**The choice.** (a) Keep it with the current 35/40 classification. (b) Keep it but make it exploratory and
report the label problems. (c) Replace the binary with a continuous state-ownership share.

**Trade-off.** The classification was never independently done, VSMO is 25%+1 share, and YAKG's sector
label alone moves the sector result from p = .027 to p = .009. A binary built this way cannot carry a
hypothesis. A continuous share is better statistically but needs data you do not have collected.

**Recommendation: (b).** Say plainly that H6 is provisional. **Cost of (a):** one determined committee
member asking "how did you classify VSMO?" ends the credibility of the chapter.

---

### D-8 · What do you do if everything is insignificant?

**The choice.** (a) Keep searching specifications until something is significant. (b) Report the MDE and
write the measurement paper.

**Trade-off.** (a) is the forking-paths failure the register already warns about (P-17), and it is
detectable: the number of specifications you estimated is knowable from your scripts. (b) is a real thesis:
the Wordstat series, its validation, the dividend contamination result, the size-heterogeneity result, and
a properly powered null are a contribution — and it is the version of your work that other people will
actually cite.

**Recommendation: (b), decided now, in writing, before the results are in.** **Cost of (a):** the results
become unfalsifiable and the thesis becomes unmarkable.

---

### What is not your decision

The nine data-quality items in the register and the two statistical corrections (log-of-median; ln(VALUE)
instead of share volume) are not choices — they are errors to fix, and fixing them is not optional. If the
supervisor asks why the results changed, the answer is a correctness rule (DR1), not a preference.


---

*Source file: `stage7/LIT_REVIEW_SKELETON.md`*

Each entry says **what the paragraph does** and **which verified source it uses**, with reading depth.
Sources marked ⚠ are abstract-only and may support only what an abstract supports.

### 1. Introduction (2 pages)

| Paragraph | Content | Sources |
|---|---|---|
| 1.1 Hook | Investors cannot watch 200 stocks; attention is scarce and search is its trace | S06 |
| 1.2 Why Russia | Yandex is the dominant Russian search engine and Google's withdrawal after 2022 removed the alternative; retail investors are a large and rising share of MOEX turnover; the market was closed for three weeks in 2022 [methodology Part I §2 for the closure; S09 for the Google-exit framing]. **Do not quote a market-share or retail-share number until a dated, citable source is found — none is in this package.** | S09 (programme, for the Wordstat framing), S04, methodology Part I §2 |
| 1.3 Research question and the two-sided hypothesis | \(H_1\): ASVI → next-week RV, sign not imposed | S06, S19, S05 ⚠ |
| 1.4 Contribution, bounded | Data + setting + horizon; **not** "first" | `NOVELTY_STATEMENT.md`; S25, S48 |
| 1.5 Roadmap | — | — |

### 2. Theory (2–3 pages)

| Paragraph | Content | Sources |
|---|---|---|
| 2.1 Limited attention | Attention is a scarce resource; price formation depends on who is watching | S06 |
| 2.2 Noise-trader risk | Uninformed trading **raises** volatility → predicts a positive coefficient | S02 (FULL) |
| 2.3 Attention, learning and uncertainty | Attention speeds up information arrival (raises variance) but lowers uncertainty (lowers variance) → **increasing, convex** relation | S19 ⚠ |
| 2.4 Price pressure and reversal | Short-run positive returns then reversal — the hypothesis this thesis will *not* be able to confirm or reject firmly | S06 (FULL draft) |
| 2.5 What the theories jointly predict | A positive, possibly convex relation between abnormal attention and volatility; no prediction about the sign of a *linear* slope | synthesis — a table with three theories × predicted sign × what would falsify each |

**Do not cite S02 next to a negative coefficient.** If the result is negative, write "the data do not
support the noise-trader prediction in this market", not "consistent with noise-trader theory".

### 3. Evidence (4–5 pages)

| Paragraph | Content | Sources |
|---|---|---|
| 3.1 The measure: Google SVI/ASVI | Founding construction, validation against other proxies, weekly firm panels | S06 (FULL draft); S03 (FULL); S47 ⚠; S50 ⚠ |
| 3.2 Developed markets | Attention → returns, attention → volatility, news conditioning | S23 ⚠, S24 ⚠, S29 ⚠ |
| 3.3 Emerging markets | India positive, Brazil negative, China moderated by ownership concentration, Turkey | S03 (FULL), S47 ⚠, S20 ⚠, S50 ⚠ |
| 3.4 **Russia** — the honest survey | (a) GARCH/HAR + Google Trends → no effect [S17 FULL]; (b) RTS futures VaR + Google + IV → no gain, non-convergence [S18 SECTIONS]; (c) Google search and intraday trading invariance [S48 ⚠]; (d) social-media attention and sentiment [S49 ⚠, S25 ⚠, S27 ⚠, S28 ⚠]; (e) topic-level search attention and returns [S26 ⚠]; (f) T-Pulse retail attention, in progress [S30 programme] | as listed |
| 3.5 Volatility modelling with online data | HAR, GARCH-X, GARCH-MIDAS, realized GARCH, jump-robust measures | S33, S34, S35 (definitional); S11 (SECTIONS); S13 ⚠; S14 (SECTIONS); S17 (FULL) |
| 3.6 Mixed frequency | Why a weekly regressor and daily prices need a MIDAS structure; and why the supervisor's other mixed-frequency links use a different frequency axis | S11, S12 ⚠, S10 ⚠ |
| 3.7 What is missing | The table in `COMPARABLES_TABLE.md` §C, stated as the gap | — |

### 4. Data and measurement (4 pages)

| Paragraph | Content |
|---|---|
| 4.1 Sample and grid | 75 firms × 419 weeks; Monday keys; closures; survivorship disclosure |
| 4.2 Wordstat | What a count is; the share column and the implied denominator (register J1–J2); collection settings; the two channels and the sum rule |
| 4.3 ASVI | Formula, canonical form, the eight-week window, why log-of-median is not median-of-logs |
| 4.4 Prices and RV | MOEX bars, the Sunday-label rule, the four corporate actions, the dividend correction to returns **and** to the range |
| 4.5 **Validation of the measure** | The table of correlations (turnover, absolute return, turnover ratio, RVI) and the dated-event check — **before any regression** |
| 4.6 Control variables | Crisis (and why it is absorbed), sanctions (restricted to verified anchors), dividends, ln(VALUE), market return |

### 5. Models (3 pages)

| Paragraph | Content | Source |
|---|---|---|
| 5.1 The pooled model and why week effects solve three problems at once | equation; FE; DK | S39 |
| 5.2 Fama–MacBeth | equation; what it does about the market | S40 |
| 5.3 The nonlinear term | ASVI² and the turning point; the theory | S19 |
| 5.4 The return models | market return on the RHS; absolute abnormal return; horizons 0–4 | S06, S15 ⚠ |
| 5.5 Inference and multiplicity | HAC lag 5; BH, Holm, Romano–Wolf; MDE in economic units | S01, S38, S41, S43 |
| 5.6 Power | the simulation table | this package, Stage 6 |

### 6. Results (5–6 pages)

6.1 Descriptive statistics of the search measure and of volatility **separately**.
6.2 Validation table (no regression).
6.3 Linear ASVI: pooled + Fama–MacBeth + per-firm heterogeneity.
6.4 Quadratic ASVI: coefficients, turning point, fitted curve. **This is the headline.**
6.5 Rolling coefficient: pre/post 2022.
6.6 Return outcomes: market on the RHS, absolute abnormal return, horizons.
6.7 Forecast comparison: HAR vs HAR-X (DM, MCS).
6.8 Robustness: the pre-specified S-list only.
6.9 What the design can rule out: the MDE table in economic units.

### 7. Discussion (2–3 pages)

7.1 Reconcile with S17 (why the answer may differ: weekly, Wordstat, 8 years, no IV competitor).
7.2 Reconcile with S19 (curve vs line).
7.3 Reconcile with S08 (time-varying value of online data; the 2022 break).
7.4 Mechanism: cannot separate Google exit from retail influx (U6).
7.5 Limitations: the register's ACCEPT-AND-DISCLOSE rows, verbatim.

### 8. Conclusion (1 page)

What was asked, what was found, what can and cannot be concluded, what the measure is good for.

---

### What must NOT appear anywhere

- "First study of attention in Russia."
- "Attention predicts volatility" without the minimum detectable effect.
- "Consistent with noise-trader theory" attached to a negative coefficient.
- Vlastakis & Markellos's "findings" beyond pages 1–3 (the corpus file has three pages).
- Any page number for Da–Engelberg–Gao taken from the 2010 draft as if it were the 2011 article.


---

*Source file: `stage7/PRIORITY_READING_LIST.md`*

Time budget assumed: about 15 hours total. Each entry says what to extract and what to skip.

#### 1. Bazhenov & Fantazzini (2019), *Russian Journal of Industrial Economics* 12(1), 79–88 — **read fully, twice**
**Why first:** it is the paper that will be used against you, and it is by your supervisor's co-author on
Russian data. You must be able to say, without notes, exactly how your design differs.
**Extract:** (i) the four stocks and the 28-month window; (ii) that Google Trends is a regressor in HAR,
ARFIMA and GARCH; (iii) the in-sample null and the out-of-sample worsening; (iv) the statement that Google
Trends carries nothing beyond implied volatility.
**Skip:** the ARFIMA algebra on first reading. Open access: MPRA 93544.

#### 2. Da, Engelberg & Gao (2011), *Journal of Finance* 66(5), 1461–1499 — **read the measure and the validation**
**Why:** your ASVI is copied from it; and its validation strategy is the template for the table that will
save your thesis.
**Extract:** the ASVI definition verbatim; the list of alternative attention proxies they compare against;
the two-week pressure and later reversal.
**Warning:** your PDF is the June 2010 draft. Page numbers will not match the published article. Get the
published version from the HSE library before you cite a page.

#### 3. Andrei & Hasler (2015), *Review of Financial Studies* 28(1), 33–72 — **read the model intuition and the empirical test**
**Why:** it is the only theory that predicts a **curve**, and the curve is your best chance of a real result.
**Extract:** the two opposing forces; the claim that the relation is increasing and quadratic; the sentence
conceding that the quadratic evidence is mixed.
**Skip:** the full dynamic model derivations.

#### 4. Swamy, Dharani & Takeda (2019), *Research in International Business and Finance* 50, 1–17 — **read the design**
**Why:** the closest emerging-market weekly firm-level template, and the source of the rolling-beta idea.
**Extract:** the 52-week rolling beta construction (p. 4); the quantile-regression idea; the sample size and
the frequency.
**Skip:** the quantile algebra unless you decide to run quantile regressions.

#### 5. Fantazzini & Kurbatskii (2026), SSRN 6468200 — **read the abstract and the results section only**
**Why:** your supervisor's newest reference, and the source of the "value of online data changed after
2022" argument.
**Extract:** the ARDL vs sparse VAR comparison; the finding that search data's value collapsed after the
2022 break; the words "time-varying value of online data" in the title.
**Note:** the full text may be obtainable from the authors directly; ask your supervisor for a copy.

#### 6. Amendola, Candila & Gallo (2021), *Econometrics and Statistics* 20, 12–28 — **read the model description**
**Why:** the correct architecture for weekly search and daily prices (GARCH-MIDAS-X). This is the answer
to "why not a plain GARCH-X?".
**Extract:** the two components; where the "-X" variable enters; how the number of MIDAS lags is chosen.
**Skip:** the MCS implementation details.

#### 7. Teplova & Gurov (2025), *Annals of Operations Research* 352(3), 441–469 — **read the results**
**Why:** it is the closest Russian study to your data question, and it shows that search volumes and Russian
trading activity are linked — which is exactly what your validation table must demonstrate.
**Extract:** the 2018–2021 window; the February 2020 break; the finding that the effect is absent for news
flows but present for Google searches.

#### 8. Fantazzini & Shangina (2019), *Applied Econometrics* 55, 5–31 — **read the evaluation section**
**Why:** it tells you how a Russian econometrician will judge a volatility model — Kupiec, Christoffersen,
quantile loss, model confidence set — and it documents the convergence failures you must report.
**Extract:** the model set; the non-convergence statement; the evaluation battery.

#### 9. Liu, Choo, Tunde, Wan & Liang (2024), *PLoS ONE* 19(6) — **read the outlier correction**
**Why:** it is the published licence for treating dividend gaps and corporate-action jumps as additive
outliers rather than deleting the week. Two hours of work that removes a reviewer's easiest objection.
**Extract:** how outliers are identified and replaced; the forecast improvement.

#### 10. De Long, Shleifer, Summers & Waldmann (1990), *JPE* 98(4), 703–738 — **read the introduction and the model intuition**
**Why:** the theoretical sign that your thesis must confront. It is also the paper most often misquoted
next to a negative coefficient — do not be the next person to do that.
**Extract:** why noise-trader risk raises the equilibrium volatility and the risk premium.

---

### Also read (not in the ten, but before the defence)

- **Yoshinaga & Rocco (2020)**, *BBR* 17(5) — a *negative* weekly firm-level result in an emerging market,
  which is the closest analogue to what your data may be telling you.
- **Shaydullin, Mi & Mitkinov (2026)**, *Lomonosov Economics Journal* 61(1) — what a Russian attention
  study looks like when it succeeds with social-media data, and therefore what your measurement
  contribution has to beat.
- **Kroujiline et al. (2016)**, arXiv 1508.04332 — the newest link from your supervisor; read the horizon
  argument, skip the agent-based model.

### Do not read yet (and why)

Chevallier & Sanhaji (2023), Dhaene & Wu (2016), Zhang et al. (2025), Ding et al. (2020): each is a
*possible extension*, none is needed for the core design. Reading them now costs days and changes nothing.


---


<!--BREAK-->

## Appendix J — The red-team audit and its conditions

*Source file: `stage8/RED_TEAM_REPORT.md`*

**Verdict: CONDITIONAL PASS.** Nothing in the package is fabricated, no forbidden regression was run, and
every headline number re-derives. Six conditions must be disclosed or fixed by Asif before defence; all are
listed in §6 and none requires new analysis.

**Audit method.** Every check below was executed against the files, not read from the narrative. Commands
are quoted so they can be re-run. Where I could not check something, it says so.

---

### 1. Hash and integrity

| Check | Command | Result |
|---|---|---|
| `TOURNAMENT_PLAN.md` unchanged since hashing | `cd stage5 && sha256sum -c TOURNAMENT_PLAN.sha256` | **OK** |
| Every CSV re-readable with field counts = header | `verify_package.py` | **PASS** (6 CSVs) |
| Every `source_id` in `CLAIMS.csv` exists in `sources.csv` | `verify_package.py` | **PASS** (30 claims, 15 VERIFIED) |
| No VERIFIED claim without a source | `verify_package.py` | **PASS** |
| Every FULL source has an evidence file | `verify_package.py` | **PASS** |
| Duplicate titles / inline ids / surname-year mismatches | `citation_lint.py` | **PASS** (54 sources, 47 ids used) |
| Schema of every CSV type | `schema_check.py` | **PASS** |

**Finding RT-01 (fixed, low).** The `.sha256` file stores a bare filename, so the check fails if run from
the package root. A reader following the README would see "FAILED open or read" and conclude the
pre-registration was broken. *Fix:* the command must be run from `stage5/`; this is now stated in
`README_FOR_ASIF.md`. *Not fixed:* re-writing the checksum file with a relative path, because that would
change the hashed artefact's companion file after the fact.

### 2. Re-derivation of the numbers

| Claim in `BEST_PATH_REPORT.md` / `SIM_REPORT.md` | Re-derived from | Match |
|---|---|---|
| Per-firm power at β = 0.005 is 9.6% | `SIM_RESULTS.csv` C_power S1_perfirm 0.0955 | yes |
| Pooled power 0.963, FM 0.960, HAR-X 0.985 | `SIM_RESULTS.csv` | yes |
| Per-firm MDE80 ≈ 0.029 | `SIM_RESULTS.csv` G_mde: power 0.776 at β = 0.028 | yes |
| Quadratic recovered at +0.00997 (true +0.010) | `SIM_RESULTS.csv` + `SIM_LOG.txt` | yes |
| Linear-only slope −0.00795, 100% significantly negative | `SIM_LOG.txt` block D | yes |
| GARCH-X convergence 50.5%, power 0.000 | `SIM_RESULTS.csv` H_garch | yes |
| Measurement error attenuation 39% | `SIM_LOG.txt` block E: 0.00508 → 0.00313 | yes (38.4%) |
| Simulated DK SE 0.00132 vs observed 0.001833 → 0.72× | `SIM_RESULTS.csv` A_calibration | yes |
| 4,650 replications | 400 + 1,200 + 400 + 900 + 500 + 1,050 + 200 | yes |

**Finding RT-02 (fixed, low).** `BEST_PATH_REPORT.md` said "50 sources"; `sources.csv` has **54 rows**
(51 external + 3 internal evidence objects). *Fix applied:* the basis line now reads "51 sources" and the
internal objects are labelled `INTERNAL-EVIDENCE`.

**Finding RT-03 (fixed, medium).** `BEST_PATH_REPORT.md` quoted the 96% pooled power in the one-page
summary **without** the caveat that the simulated standard error is 0.72× the observed one, i.e. that the
figure is an upper bound. *Fix applied:* the caveat now appears in the executive summary and in §5.

### 3. Source-by-source attack

**Re-opened and re-checked, three most important findings:**

1. **Bazhenov & Fantazzini (2019) null** [S17]. *Checked:* the evidence file quotes "only implied
   volatility had a significant effect … Google Trends did not … models including internet search activity
   worsened their performances in several cases". *Verdict:* claim supported. The sample statement
   (4 stocks, Jan 2016 – Apr 2018) is in the same text. **No overstatement found.**
2. **Fantazzini & Kurbatskii (2026) 2022 degradation** [S08]. *Checked:* the abstract says search data's
   benefit was "negligible … due to a structural break in early 2022: its predictive power was significant
   before the geopolitical shift but degraded sharply afterward". *Verdict:* supported, and the package
   consistently labels it ABSTRACT-ONLY and about **CPI**, not stocks.
3. **The META2026 Wordstat talk** [S09]. *Checked against the fetched programme:* Friday 2 October,
   09:00–10:00, "SEARCHING FOR INFLATION: FORECASTING RUSSIAN REGIONAL PRICES WITH YANDEX WORDSTAT AFTER
   GOOGLE'S EXIT". *Verdict:* the title and venue are exact. The package calls it `PROGRAMME-ONLY` and never
   attributes a result to it. **The hearsay is correctly refused.**

**Seeded 20% sample (seed 20261020, 11 of 54):** S50, S30, S48, S42, S21, S14, S31, S04, S51, S32, S06.
All eleven exist in `sources.csv` with a tier and a reading depth consistent with how they are used.
*Observation, not a defect:* the sample contains four items whose depth is below ABSTRACT-ONLY
(S30/S31 programme-only, S32/S42 not-opened). They are used only for positioning and method naming, never
for an empirical claim. Spot-checked: S30 and S31 appear only in `COMPARABLES_TABLE.md` and the novelty
statement; S32 and S42 appear only as definitional references.

**Finding RT-04 (open, disclosure).** **15 of 54 sources are `NOT-OPENED`** — the standard classics
(Bollerslev, Corsi, Engle–Ghysels–Sohn, Hansen–Huang–Shek, Parkinson, Alizadeh–Brandt–Diebold, Benjamini–
Hochberg, Driscoll–Kraay, Fama–MacBeth, Diebold–Mariano, Hansen–Lunde–Nason, Andrews, Bai–Perron,
Hansen-SPA, and the Wordstat help page). None carries an empirical claim; all are used to *name* a method.
Still: a reader who counts "54 sources" and assumes 54 opened texts would be misled. *Condition C-1:*
the thesis must cite these as standard references and no result may rest on them.

**Finding RT-05 (open, disclosure).** **17 sources are `ABSTRACT-ONLY`.** The heaviest use is S08 (the
2022-break warning) and S19 (the quadratic theory). Both uses are within what an abstract supports. The one
borderline case is **C-13** (Liu et al.'s outlier correction), which is cited to justify the dividend
correction to RV — but that correction is independently justified by arithmetic in register L4, so the
citation is corroborative, not load-bearing. *Condition C-2:* if the supervisor asks for the Liu et al.
method, the section must be obtained first.

**Finding RT-06 (fixed, high).** `ANSWERS_TO_SUPERVISOR.md` Q2 originally claimed that Swamy et al. and
Yoshinaga & Rocco use "the same construction" as Da–Engelberg–Gao. Yoshinaga & Rocco work with lagged
*changes* in search volume, not levels of ASVI, so the claim was false in detail. *Fix applied:* Q2 now
says the standardisation differs across papers and that Asif states his own formula explicitly.

**Finding RT-07 (fixed, medium).** `LIT_REVIEW_SKELETON.md` originally contained "Yandex ≈70% of Russian
search" and "retail share above 60%". Neither number is in `sources.csv`. *Fix applied:* both were removed
and replaced with an explicit instruction not to quote a market share until a dated source is found.

### 4. Fabrication-pattern tests

| Test | Result |
|---|---|
| Identical notes across source rows | none (0 duplicate support-notes) |
| Statuses assigned in bulk | no; every VERIFIED claim has its own evidence file or code path |
| Claims without a source id | 0 (checked by script) |
| Suspiciously complete tables | the comparables table has a "carried, NOT verified" section (§E) and a partially unverified citation (S49 volume/pages) — the opposite of the pattern |
| Round numbers | 4,650 replications, 400/300/250/200/150 per cell, seed 20261020 — all in the log |
| Papers that do not exist | none found; 5 of the supervisor's links were resolved to a real DOI/URL, 1 (L08) and 1 (L09) were left NOT-OPENED rather than described |

### 5. Result-blindness and process

| Check | Result |
|---|---|
| Any regression with real ASVI and a real outcome | **none** — `stage6/sim_lab.py` never opens a data file; grep for `combined data`, `all data final`, `moex_panel` returns nothing |
| Real attention data used as a simulation parameter | yes: the observed ASVI standard deviation by size quartile (0.49/0.36/0.30/0.26) and the observed DK standard error are used to **calibrate the simulation**, which Stage 6 explicitly asks for. This is not a regression and not a selection decision. |
| Plans hashed before runs | yes — `TOURNAMENT_PLAN.md` hashed at 16:42:44Z, first run after; re-verified OK |
| A plan rule that had to be bent | **yes, declared**: DR-T3 was written as "S2 becomes primary if S1 is *biased*". Under D3 the linear estimator turned out to be *consistent for the average derivative*, so the rule did not fire. The rule was mis-specified before the run. It is disclosed in `SIM_REPORT.md` §3 and in §8 of the same file rather than retro-fitted. |
| Hearsay labelled | yes (C-23 in `CLAIMS.csv`; `HEARSAY` tag in Card 2 and Q7) |
| sci-hub or similar | none (grep across all .md and .csv) |
| Asif's files edited | no; `inputs/` are byte-identical copies, all new material is in new files |
| Every Appendix B item answered | 11 of 11 (`grep -c "^## Q" stage7/ANSWERS_TO_SUPERVISOR.md` = 11) |
| Every Appendix C problem in the matrix | 31 of 31 (`grep -o "^| P-[0-9]*" | sort -u | wc -l` = 31) |

**Finding RT-08 (open, medium).** The independence claim in `STATE.md` is weaker than a true relay: one
context ran every stage, so the inbound audits are self-audits. This is disclosed there and repeated here.
*Condition C-3:* Asif must run the external canary check (the master prompt's Stage 9 instruction) before
submitting, and should ask a second reader to attack §2 of `BEST_PATH_REPORT.md` specifically.

**Finding RT-09 (open, low).** The package says "4,650 replications" in some places and "2,300+" in the
`BEST_PATH_REPORT.md` header. *Action:* use 4,650. *(Applied in the final copy.)*

**Finding RT-10 (fixed, cosmetic).** `PRIORITY_READING_LIST.md` contained a drafting artefact — a stray
"Yanagihashi? No —" before item 9. It was removed before delivery but is recorded here because a red team
that hides its own near-misses is not a red team. No such artefact survives in any delivered file.

### 5b. Package hygiene (found by opening every file, not by reading the prose)

**Finding RT-11 (fixed, medium).** `STATE.md` listed per-stage manifest files that **do not exist**
(`stage0/MANIFEST.md`, `stage5/MANIFEST.md`, `final/FINAL_MANIFEST.md`, `stage1/INBOUND_AUDIT_0.md`, …). The
ledger described a package shape that was never built. This is exactly the kind of trace a careful examiner
follows and then stops trusting the rest. *Fix applied:* every row now points to a file that exists and is
in `FINAL_MANIFEST.csv`, and the inbound-audit column says `self-audit (Mode A)` instead of naming files.

**Finding RT-12 (fixed, medium).** `evidence/evidence_index.csv` had 16 rows while `evidence/` held 17
excerpt files — `S04` was missing from the index. *Fix applied:* the index was regenerated from the files
(17 rows, with sizes and SHA-256 prefixes). One excerpt file that no index row claimed would have been an
orphan; an index row that claims a file nobody has would have been a phantom. Neither survives.

**Finding RT-14 (fixed, medium).** Six numbers quoted in `SIM_REPORT.md` and `BEST_PATH_REPORT.md` were
printed to `SIM_LOG.txt` but had **no row** in `SIM_RESULTS.csv`: the quadratic term's own test size
(0.075), the two block-D mean coefficients (−0.00795, +0.00997), and the three block-E mean estimates
(0.00508, 0.00313, 0.00233). A reader checking the CSV against the report would have found six unsupported
numbers — precisely the failure mode this package exists to prevent. *Fix applied:* the six rows are now in
the CSV (42 rows) and are re-attached idempotently by `stage6/append_traceability_rows.py`, so a re-run of
`sim_lab.py` cannot lose them.

**Finding RT-13 (fixed, low).** `README_FOR_ASIF.md` contained the typo `SM_REPORT.md` in §5, i.e. a path
that resolves to nothing. *Fix applied.*

### 6. Conditions of the CONDITIONAL PASS

| # | Condition | Who | Effort |
|---|---|---|---|
| C-1 | Cite the 15 NOT-OPENED classics as standard references only; no result may rest on them | Asif | none |
| C-2 | Obtain the Liu et al. method section before describing the outlier-correction algorithm in the thesis | Asif | 1 hour |
| C-3 | External canary check by a second reader / separate Claude instance; attack `BEST_PATH_REPORT.md` §2 | Asif | 2 hours |
| C-4 | Run the six helper-script checks before submitting the thesis; paste the output into the appendix | Asif | 10 minutes |
| C-5 | Fill the Wordstat collection-settings questionnaire (GAP-19b) before the final estimation run | Asif | 1 hour |
| C-6 | Re-run the register's K3/K7/L4 numbers before quoting them (this package carries them as `CARRIED-DOC`) | Asif | 2 hours |

### 7. What the red team could not check

- The real data: no panel file was opened in this package beyond extracting the corpus PDFs, so the
  register's numbers are carried, not re-derived.
- The 15 NOT-OPENED classics' exact page numbers (used for citation style only).
- Whether the Fantazzini–Kurbatsky Wordstat paper exists in writing today (searched, not found; may be
  circulating privately).
- Russian-language coverage: eLibrary deep search was not possible, so the Russian literature set is
  probably incomplete.

### 8. Verdict

**CONDITIONAL PASS.** The package's factual claims are traceable, its two strongest and most uncomfortable
findings (the supervisor's reference mismatch; the negative Russian prior) are stated plainly rather than
softened, its simulation is reproducible from a hashed plan, and its weaknesses are named in the file where
a reader will trip over them. It is fit to be handed to Asif with the six conditions above.


---


<!--BREAK-->

## Appendix K — The thirty load-bearing claims

*Source files: `CLAIMS.csv`, `evidence/`*

Thirty statements carry the package's argument. Statuses: VERIFIED 15; VERIFIED-CODE 6; DERIVED 1; CARRIED-DOC 3; UNVERIFIED-SNIPPET 1; UNVERIFIED-ABSENCE 1; HEARSAY 1; REJECTED-ON-RECHECK 1; GAP 1. Only the first three groups may be quoted as established; the rest are labelled so that nothing can be built on them by accident.

| id | statement | status | source |
|---|---|---|---|
| C-01 | Da, Engelberg & Gao define ASVI as the log search count minus the log of the median count over the previous eight weeks (log of median, not median of logs). | VERIFIED | S06 |
| C-02 | Da, Engelberg & Gao report an increase in SVI predicting higher prices over the next two weeks with an eventual reversal. | VERIFIED | S06 |
| C-03 | The Newey-West lag choice in Da, Engelberg & Gao (eight lags) belongs to their Fama-MacBeth design and is not a rule for per-firm weekly regressions. | VERIFIED | S06 |
| C-04 | De Long, Shleifer, Summers & Waldmann (1990) predict that noise-trader risk RAISES the volatility of the asset; the model cannot support a negative attention-volatility coefficient. | VERIFIED | S02 |
| C-05 | Swamy, Dharani & Takeda (2019) build excess returns with a 52-week rolling beta (not 104 weeks). | VERIFIED | S03 |
| C-06 | The corpus file of Vlastakis & Markellos (2012) contains 3 of 14 pages only; no claim about its results can be verified from the corpus. | VERIFIED | S05 |
| C-07 | Fantazzini & Kurbatskii (2026) use Google Trends (not Yandex Wordstat) and report negligible average forecasting improvement from search data because of a structural break in early 2022. | VERIFIED | S08 |
| C-08 | The META2026 programme lists a separate Fantazzini & Kurbatsky talk on Yandex Wordstat after Google's exit; no written version of it was found on 2026-10-20. | VERIFIED | S09 |
| C-09 | Bazhenov & Fantazzini (2019) find no significant Google Trends effect on realized volatility for four Russian stocks and worse out-of-sample forecasts in several cases. | VERIFIED | S17 |
| C-10 | Fantazzini & Shangina (2019) report that several search-augmented volatility models failed to converge on RTS futures data. | VERIFIED | S18 |
| C-11 | Andrei & Hasler (2015) derive an increasing, quadratic attention-volatility relation with a negative linear and a positive quadratic term. | VERIFIED | S19 |
| C-12 | Amendola, Candila & Gallo (2021) put a market volatility index into both the short-run ('-X') and the long-run (MIDAS) components and find an out-of-sample improvement. | VERIFIED | S11 |
| C-13 | Liu et al. (2024) show that additive-outlier correction before GARCH-MIDAS estimation improves forecast accuracy. | VERIFIED | S14 |
| C-14 | Yoshinaga & Rocco (2020) find that increases in Google search volume are followed by LOWER excess returns for Brazilian stocks. | VERIFIED | S47 |
| C-15 | Teplova & Gurov (2025) find that Russian trading activity becomes more synchronized with Google search volumes after February 2020, and not with news-article flows. | VERIFIED | S48 |
| C-17 | Per-firm regression at T=419 has 9.6% power at a true coefficient of 0.005 and an MDE80 of 0.029. | VERIFIED-CODE | S90 |
| C-18 | The pooled two-way FE estimator at T=419 has 96% power at a true coefficient of 0.005 in the simulation; the simulated SE is 0.72x the observed one, so this is an upper bound. | VERIFIED-CODE | S90 |
| C-19 | Weekly GARCH(1,1)-X converges in 50.5% of 200 simulated series at T=419 and has zero power for a 10% variance effect. | VERIFIED-CODE | S90 |
| C-20 | A linear-only regression on a U-shaped truth recovers the average derivative (-0.00795 vs true -0.008) and is significantly negative in 100% of replications, while the quadratic term is recovered at +0.00997 (true +0.010). | VERIFIED-CODE | S90 |
| C-21 | Classical measurement error of 50% of signal variance attenuates the coefficient by 39% and costs about 12 percentage points of power. | VERIFIED-CODE | S90 |
| C-22 | The pooled DK standard error is invariant to a common weekly shock because week fixed effects absorb it. | VERIFIED-CODE | S90 |
| C-28 | The five per-firm BH survivors imply implausibly large effects: RTKM's slope of -0.040 implies a 34% change in mean weekly range volatility per doubling of attention. | DERIVED | S90 |
| C-26 | Adding the dividend back to the range reduces mean RV in ex-weeks from 0.1022 to 0.0762. | CARRIED-DOC | S92 |
| C-27 | Market-adjusted returns average -5.1% in ex-dividend weeks versus +0.1% elsewhere. | CARRIED-DOC | S92 |
| C-29 | Subtracting the cross-sectional mean ASVI changes its variance by -9%, -17%, -26%, -22% from the smallest to the largest size quartile and raises it for 4 of 75 firms. | CARRIED-DOC | S92 |
| C-30 | A Wordstat API aggregating by week or day exists in Yandex AI Studio (GetDynamics). | UNVERIFIED-SNIPPET | S51 |
| C-24 | There is no firm-level weekly Wordstat-to-volatility study of MOEX stocks. | UNVERIFIED-ABSENCE | S91 |
| C-23 | Yandex Wordstat is the better source than Google Trends for Russian stock attention. | HEARSAY | S09 |
| C-16 | Da, Engelberg & Gao attributed to 2015 rather than 2011 anywhere in the delivered documents. | REJECTED-ON-RECHECK | S06 |
| C-25 | The 2018-2026 relation between ASVI and RV changed after February 2022. | GAP | — |

<!--BREAK-->

## Appendix L — The source table

*Source file: `sources.csv`, `evidence/evidence_index.csv`*

54 sources: 51 external, 3 internal evidence objects. Reading depth — ABSTRACT-ONLY 17, NOT-OPENED 15, SECTIONS 5, FULL 4, PROGRAMME-ONLY 3, ABSTRACT 3, IMAGE-ONLY 1, TRUNCATED 1, DRAFT 1, SNIPPET-ONLY 1, CODE-OUTPUT 1, LOG 1, CARRIED-DOC 1. The depth column is the point of the table: it says what was actually opened before the source was used. Citations and support notes are shortened here for width; the full text, the URL or DOI, and the access time are in `sources.csv`.

| id | citation | tier | depth | what it supports |
|---|---|---|---|---|
| S01 | Newey, W.K. and West, K.D. (1987). A Simple, Positive Semi-Definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix. Econometrica | T1 | IMAGE-ONLY (14 pp, pypdf returns 0 chars;  | Names the HAC estimator used throughout. No numeric claim in this package rests on the file; the bandwidth rule used is stated in the methodology, not |
| S02 | De Long, J.B., Shleifer, A., Summers, L.H. and Waldmann, R.J. (1990). Noise Trader Risk in Financial Markets. Journal of Political Economy 98(4), 703- | T1 | FULL (37 pp) | Uninformed-trader risk raises volatility; this predicts a POSITIVE attention-volatility relation and must not be cited to explain a negative coefficie |
| S03 | Swamy, V., Dharani, M. and Takeda, F. (2019). Investor attention and Google Search Volume Index: evidence from an emerging market using quantile regre | T1 | FULL (17 pp) | Emerging-market (India) attention-return link with quantile regression; builds excess returns with a 52-week rolling beta (p. 4). |
| S04 | Djalilov, A. and Ulku, N. (2021). Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis. Journal of Behavioral and Experim | T1 | FULL (14 pp) | Weekly MOEX data with retail investors; precedent for weekly frequency and for lag selection (VAR(3) by AIC) in this market. |
| S05 | Vlastakis, N. and Markellos, R.N. (2012). Information demand and stock market volatility. Journal of Banking and Finance 36, 1808-1821. | T1 | TRUNCATED (3 of 14 pp in the file) | Motivates ASVI -> RV and the separation of idiosyncratic from market-wide information demand. Only pp. 1-3 verified; the design cannot be replicated f |
| S06 | Da, Z., Engelberg, J. and Gao, P. (2011). In Search of Attention. Journal of Finance 66(5), 1461-1499. | T1 (draft in corpus) | DRAFT (50 pp) | The ASVI construction (log count minus log of the prior 8-week median) and the price-pressure-then-reversal result. Page numbers cited here are draft  |
| S07 | Giles, D.E.A. and Lieberman, O. (1992). Bounds on the effect of heteroscedasticity on the Chow test for structural change. University of Canterbury Ec | T2 | SECTIONS (noisy text layer, tabulation ide | The classical Chow bounds used by v2.0/M5. Not applicable to a HAC-robust Wald statistic. |
| S08 | Fantazzini, D. and Kurbatskii, A. (2026). Nowcasting and Forecasting Russian Regional CPI: Sparse Models and the Time-Varying Value of Online Data. SS | T2 | ABSTRACT-ONLY (49 pp; PDF delivery did not | Uses **Google Trends** (not Wordstat) for Russian regional CPI. Search data adds positive but limited nowcasting value; in forecasting its value is ne |
| S09 | Fantazzini, D. and Kurbatsky, A. (2026). Searching for inflation: forecasting Russian regional prices with Yandex Wordstat after Google's exit. Keynot | T3 | PROGRAMME-ONLY (title, authors, slot; no w | **Resolves the supervisor's hearsay**: the 'Wordstat beats Google Trends' claim is a conference presentation about Wordstat after Google's exit - a di |
| S10 | Zhang, Z., Zhao, S., Cheng, J. and Li, J. (2025). Conditional quantile estimation for GARCH model based on mixed-frequency data. Statistical Papers 66 | T1 | ABSTRACT-ONLY | Embeds INTRADAY high-frequency data into a GARCH model to estimate conditional quantiles. Mixed frequency here is intraday-vs-daily, not weekly-search |
| S11 | Amendola, A., Candila, V. and Gallo, G.M. (2021). Choosing the frequency of volatility components within the Double Asymmetric GARCH-MIDAS-X model. Ec | T1 | SECTIONS: abstract + introduction | Template for a two-component volatility model in which a low-frequency forcing variable drives the long-run component and a daily market volatility in |
| S12 | Dhaene, G. and Wu, J. (2016). Mixed-Frequency Multivariate GARCH. KU Leuven Department of Economics, DPS16.12; SSRN 2799569. | T2 | ABSTRACT-ONLY | Weekly multivariate volatility from five-minute and overnight returns; mixed-frequency GARCH beats low-frequency GARCH and reduces spurious persistenc |
| S13 | Chevallier, J. and Sanhaji, B. (2023). Jump-Robust Realized-GARCH-MIDAS-X Estimators for Bitcoin and Ethereum Volatility Indices. Stats 6(4), 1339-137 | T1 | ABSTRACT-ONLY | Shows how to put an exogenous variable into a realized GARCH-MIDAS long-run component and how to filter jumps out of the realized measure before estim |
| S14 | Liu, T., Choo, W., Tunde, M.B., Wan, C. and Liang, Y. (2024). Enhancing stock volatility prediction with the AO-GARCH-MIDAS model. PLoS ONE 19(6), e03 | T1 | SECTIONS: abstract + introduction + data | Additive-outlier correction before GARCH-MIDAS estimation improves forecasts; the corrected return series replaces the outliers. Directly transferable |
| S15 | Kroujiline, D., Gusev, M., Ushanov, D., Sharov, S.V. and Govorkov, B. (2016). Forecasting stock market returns over multiple time horizons. Quantitati | T1 | ABSTRACT-ONLY | News-flow-driven analytic agent-based model with heterogeneous horizons; markets are near-efficient at intraday horizons and inefficient at longer hor |
| S16 | Ding, S., Cui, T., Xiong, X. and Bai, R. (2020). Forecasting stock market return with nonlinearity: a genetic programming approach. Journal of Ambient | T1 | ABSTRACT-ONLY | Country-specific nonlinear return models found by genetic programming; better specification without new variables improves accuracy. Index-level, not  |
| S17 | Bazhenov, T. and Fantazzini, D. (2019). Forecasting realized volatility of Russian stocks using Google Trends and implied volatility. Russian Journal  | T1 | FULL (MPRA version) | Four liquid Russian stocks, daily RV, Jan 2016-Apr 2018, GARCH/ARFIMA/HAR + implied volatility + Google Trends. **Google Trends had no significant eff |
| S18 | Fantazzini, D. and Shangina, T. (2019). The importance of being informed: forecasting market risk measures for the Russian RTS index future using onli | T1 | SECTIONS: abstract + introduction + litera | RTS index future, daily 2006-2019. Adding Google Trends and implied volatility did not improve, and often worsened, VaR forecasts; some augmented mode |
| S19 | Andrei, D. and Hasler, M. (2015). Investor Attention and Stock Market Volatility. Review of Financial Studies 28(1), 33-72. | T1 | SECTIONS: abstract (RFS) + EPFL working-pa | Attention and volatility are linked by an increasing, **quadratic** relation: a positive quadratic term (faster information revelation) and a negative |
| S20 | Hu, C. et al. (2025). Retail investor attention and stock return volatility: the moderating role of ownership concentration in China. Review of Financ | T1 | ABSTRACT-ONLY | Baidu search frequency raises return volatility; ownership concentration moderates the relation. The closest analogue to this thesis's H6 (state owner |
| S21 | Ullah, S. et al. (2026). Investor attention and stock market volatility: does geopolitical risk matter? International Journal of Business and Risk (IJ | T3-T4 | ABSTRACT-ONLY | Geopolitical risk weakens, magnifies or changes the attention-volatility relation depending on the economy. Low-tier venue; used only to support 'the  |
| S22 | Investor attention on the Russia-Ukraine conflict and stock market volatility: evidence from China (2022). Finance Research Letters. | T1 | ABSTRACT + highlights | Attention to the Russia-Ukraine conflict predicts Chinese stock volatility and contains information beyond leverage, jumps and geopolitical risk; LASS |
| S23 | When does attention matter? The effect of investor attention on stock market volatility around news releases (2022). International Review of Financial | T1 | ABSTRACT + highlights | Retail attention raises post-announcement volatility; institutional attention lowers it. The effect is heterogeneous in news type and topic and has ec |
| S24 | Institutional investor attention and stock market volatility and liquidity: international evidence (2022). Applied Economics 54(42), 4839-4854. | T1 | ABSTRACT-ONLY | Nine-country panel including **Russia**, ~1m daily observations 2011-2020; institutional attention raises volatility and liquidity. Evidence that the  |
| S25 | Shaydullin, A.I., Mi, A.E. and Mitkinov, V.E. (2026). Forecasting volatility of Russian companies' stocks with social media data. Lomonosov Economics  | T1 | ABSTRACT-ONLY (Russian) | Seven Russian companies; sentiment and attention weights from social media; forecast quality improves by up to 7% for Yandex. Shows the Russian attent |
| S26 | Search attention and opinion divergence in explaining retail investor behavior (2025). Moscow University Economics Bulletin (Vestnik MGU, Seriya 6). | T1 (bibliographic details UNVERIFIED) | ABSTRACT-ONLY | Uses **search-query statistics on economic-political and investment topics** as a proxy for private-investor attention to explain returns of Russian i |
| S27 | Decoding Russian stock market trends through ensemble methods and sentiment analysis of social media (2025). Annals of Operations Research 353(3). | T1 | ABSTRACT-ONLY | Retail sentiment, attention and divergence indices from Russian social media affect returns and volumes across quantiles. |
| S28 | News sentiment index and its predictive power for the Russian stock market (2026). Voprosy Ekonomiki. | T1 | ABSTRACT-ONLY | FinBERT sentiment from news and Telegram for 925 MOEX-listed companies 2015-2024; strongest effects on volume and on low-capitalisation returns; negat |
| S29 | Does investor attention increase stock market volatility during the COVID-19 pandemic? (2021). Finance Research Letters (PMC version). | T1 | ABSTRACT + selected tables | Aggregate attention raises realized volatility; expected and unexpected attention components both matter. Supports the market-wide attention control a |
| S30 | Novikova, E. (2026). Attention-induced trading and return reversal: evidence from T-Pulse. Poster, META2026, HSE. | T3 | PROGRAMME-ONLY | A Russian retail-attention paper using T-Pulse (T-Bank social platform) is in progress at the same conference. Asif must position against it; the titl |
| S31 | Panov, V., Khoranyan, N., Morozova, E. and Terentev, V. (2026). Modelling dependence between media attention and cryptocurrency prices: a study via se | T3 | PROGRAMME-ONLY | Attention-price dynamics modelled with self-exciting (Hawkes-type) processes in the same department; an advanced alternative to linear ASVI terms. |
| S32 | Bollerslev, T. (1986). Generalized autoregressive conditional heteroskedasticity. Journal of Econometrics 31, 307-327. | T1 | NOT-OPENED | Definitional reference for GARCH. No claim in this package depends on opening it. |
| S33 | Corsi, F. (2009). A simple approximate long-memory model of realized volatility. Journal of Financial Econometrics 7(2), 174-192. | T1 | NOT-OPENED | Definitional reference for the HAR model used as the forecasting benchmark. |
| S34 | Engle, R.F., Ghysels, E. and Sohn, B. (2013). Stock market volatility and macroeconomic fundamentals. Journal of Business and Economic Statistics 31(4 | T1 | NOT-OPENED | GARCH-MIDAS: a low-frequency variable drives the long-run component of daily volatility. |
| S35 | Hansen, P.R., Huang, Z. and Shek, H.H. (2012). Realized GARCH: a joint model for returns and realized measures of volatility. Journal of Applied Econo | T1 | NOT-OPENED | Definitional reference for Realized GARCH. |
| S36 | Parkinson, M. (1980). The extreme value method for estimating the variance of the rate of return. Journal of Business 53(1), 61-65. | T1 | NOT-OPENED | Range-based variance; the theoretical basis for RV = ln(H/L) as a volatility proxy. |
| S37 | Alizadeh, S., Brandt, M.W. and Diebold, F.X. (2002). Range-based estimation of stochastic volatility models. Journal of Finance 57(3), 1047-1091. | T1 | NOT-OPENED | Range as a high-information volatility proxy; supports the efficiency argument for RV = ln(H/L) at weekly frequency. |
| S38 | Benjamini, Y. and Hochberg, Y. (1995). Controlling the false discovery rate. JRSS-B 57(1), 289-300. | T1 | NOT-OPENED | FDR control across the 74 per-firm tests. |
| S39 | Driscoll, J.C. and Kraay, A.C. (1998). Consistent covariance matrix estimation with spatially dependent panel data. Review of Economics and Statistics | T1 | NOT-OPENED | Spatial (cross-firm) correlation-robust panel standard errors. |
| S40 | Fama, E.F. and MacBeth, J.D. (1973). Risk, return and equilibrium: empirical tests. Journal of Political Economy 81(3), 607-636. | T1 | NOT-OPENED | Weekly cross-sectional slope averaging; handles common shocks without a beta estimate. |
| S41 | Diebold, F.X. and Mariano, R.S. (1995). Comparing predictive accuracy. Journal of Business and Economic Statistics 13(3), 253-263. | T1 | NOT-OPENED | Forecast-comparison test for the HAR-vs-HARX tournament. |
| S42 | Hansen, P.R., Lunde, A. and Nason, J.M. (2011). The model confidence set. Econometrica 79(2), 453-497. | T1 | NOT-OPENED | Set of models not distinguishable from the best; used by both Fantazzini papers (S17, S18). |
| S43 | Andrews, D.W.K. (1991). Heteroskedasticity and autocorrelation consistent covariance matrix estimation. Econometrica 59(3), 817-858. | T1 | NOT-OPENED | Data-dependent HAC bandwidth rule referenced in the methodology. |
| S44 | Bai, J. and Perron, P. (1998). Estimating and testing linear models with multiple structural changes. Econometrica 66(1), 47-78. | T1 | NOT-OPENED | Unknown-break-date testing; the alternative to a hand-chosen 2022 break. |
| S45 | Hansen, P.R. (2005). A test for superior predictive ability. Journal of Business and Economic Statistics 23(4), 365-380. | T1 | NOT-OPENED | Multiple-model comparison against a benchmark. |
| S46 | Yandex Wordstat help: query share and the dynamics tab (official documentation). | T4 | NOT-OPENED (cited via register J1) | Definition of the share column used in register J1-J2; the register's own verification is the evidence, not this row. |
| S47 | Yoshinaga, C. and Rocco, F. (2020). Investor attention: can Google Search Volumes predict stock returns? Brazilian Business Review 17(5), 523-539. DOI | T1 | ABSTRACT-ONLY | 57 Ibovespa stocks, weekly Google data 2014-2018: increases in GSV are followed by LOWER excess returns, and the effect is stronger for more heavily t |
| S48 | Teplova, T. and Gurov, S. (2025). Nonlinear intraday trading invariance in the Russian stock market. Annals of Operations Research 352(3), 441-469. DO | T1 | ABSTRACT-ONLY | Russian stocks 2018-2021: trading activity becomes more synchronized with Google relative search volumes after February 2020, when a surge of retail i |
| S49 | Teplova, T. et al. (2022). A retail investor in a cobweb of social networks. PLoS ONE 17(12), e0276924. | T1 | ABSTRACT-ONLY | Russian social-network messages: attention and sentiment indicators are priced alongside momentum, volatility and volume; evidence of a visibility eff |
| S50 | Duz Tan, O. and Tas, O. (2019). Google search and stock returns: a study on BIST 100 stocks. Borsa Istanbul Review (volume and pages UNVERIFIED). | T1 | ABSTRACT-ONLY (bibliographic details parti | Turkey, weekly firm-level Google search and returns; carried from the earlier round (AGENT_3_FINDINGS) and re-identified here by title; search volume  |
| S51 | Yandex AI Studio documentation: Wordstat API (GetTop, GetDynamics, GetRegionsDistribution, GetRegionsTree). | T4 | SNIPPET-ONLY (page returned a captcha; con | Documents an official Wordstat API whose GetDynamics method returns query frequency aggregated by MONTH, WEEK or DAY. If confirmed on the live page, t |
| S90 | Internal evidence: this package's synthetic lab. Code stage6/sim_lab.py; raw output stage6/SIM_RESULTS.csv; write-up stage6/SIM_REPORT.md. | INTERNAL-EVIDENCE | CODE-OUTPUT | Backs every VERIFIED-CODE claim about power, size, convergence and the quadratic trap. Reproducible with seed 20261020. |
| S91 | Internal evidence: stage3/SEARCH_LOG.csv, the log of the ten literature searches executed on 2026-10-20 (English and Russian). | INTERNAL-EVIDENCE | LOG | Backs the narrowed absence claims; explicitly does NOT prove absence. |
| S92 | Internal evidence: KNOWN_ISSUES_REGISTER.md (supplied 2026-10-20), sections J3, K3, K7, L4 - numbers recomputed on the files by a previous round. | INTERNAL-EVIDENCE | CARRIED-DOC | Source of the dividend (L4), market-adjusted-ex-week (K3) and size-quartile (K7) numbers. Re-run before publication. |

---

*Combined report, 20 October 2026. Part I is the synthesis; Part II is reproduced evidence. Every claim is traceable through Appendix K to a source id or to code in the package. Where a number is approximate it is labelled; where a claim is not verified it is named as hearsay, a gap, or unverified — and nothing is built on it.*
