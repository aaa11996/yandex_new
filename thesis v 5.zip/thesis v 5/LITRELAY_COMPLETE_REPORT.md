# LITERATURE RELAY — COMPLETE REPORT (ONE FILE)
## Web Search Queries and Market Movements: Evidence from the Russian Equity Market

**For:** Khandaker Asikh Iqbal (Asif), Master's student in Finance, HSE University, Nizhny Novgorod.
**Supervisor:** Prof. Andrey Aistov. **Date:** 20 October 2026. **Relay prompt:** `LITRELAY_MASTER_PROMPT.md` (same prompt to every link; conductor run, Stages 0–9, no sub-agents available).

> **How to read this file.** This is the *single-file edition* of the whole relay. Part I is what to do and why. Part II answers the supervisor. Part III is the problem/solution audit trail. Part IV is reading and decisions. Part V is the pre-registered tournament and synthetic-lab results. Part VI is red-team quality control. Appendices hold stage workpapers (W0–W9), full reference tables, search logs, simulation output tables, and the file manifest. The machine-readable originals (CSVs, evidence notes, hashes, code) remain in `litrelay/` alongside this file — nothing here renames or re-verifies them.
>
> **Bulletproof rule.** Every factual statement is exactly one of: (a) supported by a source opened at the stated depth in `sources.csv` (IDs like [S-DA11]); (b) shown by code run on files or synthetic data; (c) a labelled recommendation under a stated rule; (d) labelled `UNVERIFIED` / `HEARSAY` / `GAP`. `ABSTRACT-ONLY` means *only the abstract was opened* — never cite it deeper. No regression with the real attention variable was run (DR7 result-blindness). Old coefficients appear only as labelled context.
>
> **Headline verdict.** Keep Methodology v4.0 as the core; add dividend-adjusted volatility, return horizons, Fama–MacBeth/sorts; gate GARCH/MIDAS behind a synthetic tournament; close sanction/ownership/dividend/market-index data gaps. Red-team verdict: **CONDITIONAL PASS** (5 conditions, Part VI). Stages 3 and 6 remain **PARTIAL (8/10)** — Russian live search and three tournament pilots still owed, listed openly in Appendix A.

### Contents
- Part 0 — Relay state, inputs, missing items
- Part I — Best-path report (executive summary, old results, supervisor papers, design)
- Part II — Draft answers to the supervisor (Q1–Q11 + new links)
- Part III — Problem register (P-01…P-28) and problem-to-solution matrix
- Part IV — Literature-review skeleton, priority reading list, decisions for Asif
- Part V — Pre-registered tournament plan (hashed) and synthetic feasibility report
- Part VI — Red-team report and README for Asif
- Appendix A — Stage workpapers W0–W9 (reports, NOT-DONE lists, QA logs, handoffs, audits)
- Appendix B — Verified references (full table) and evidence index
- Appendix C — Reading list, search protocol/log, comparables, simulation outputs
- Appendix D — Final manifest (files, sizes, SHA-256) and baton

---


# Part 0 — Relay state, inputs, missing items

# Litrelay STATE (conductor run 2026-10-20; one supervised pass, stages sequential, no sub-agents available)
stage | name | status | qa_score | inbound_audit_by_next | manifest_sha256 | notes
0 | Preflight and inventory | DONE | 9 | self (conductor) | see stage0/MANIFEST.md | Missing ASIF_CONSTRAINTS + COMBINED_REPORT recorded; proceeded per user direction
1 | Supervisor reading (old+new) | DONE | 9 | self | see stage1/MANIFEST.md | 10 reading items; depths exact; META abstract GAP
2 | Folder papers + earlier work | DONE | 9 | self | see stage2/MANIFEST.md | 7 PDFs; COMBINED_REPORT.md MISSING INPUT (substitutes listed)
3 | Online expansion | PARTIAL | 8 | self | see stage3/MANIFEST.md | 33 sources; RU adversarial live re-search NOT-DONE (score <9 stated plainly)
4 | Existing work + problem register | DONE | 9 | self | see stage4/MANIFEST.md | P-01..P-28 in final/PROBLEM_REGISTER.md
5 | Solution design + tournament | DONE | 9 | self | see stage5/MANIFEST.md | Tournament hashed pre-run a634ab58...
6 | Synthetic feasibility lab | PARTIAL | 8 | self | see stage6/MANIFEST.md | MIDAS/CAR/min-count pilots NOT-DONE; pooled SE stand-in flagged
7 | Synthesis (final package) | DONE | 9 | self (red team separate) | see final/FINAL_MANIFEST.md | Appendix-E files in litrelay/final/
8 | Red team | DONE | 9 | conductor | see stage8/RED_TEAM_REPORT.md (copy in final/) | Verdict CONDITIONAL (conditions listed; no FAIL item blocks Plan A core)
9 | Final package | DONE | 9 | - | see final/FINAL_MANIFEST.md | Bring to Claude for independent canary check per prompt


## Stage 0 input manifest

# Input manifest (Stage 0)
Received/opened: LITRELAY_MASTER_PROMPT.md (33,908 B), METHODOLOGY_v4.0_FINAL.md (28,531 B; repo spelling METHODOLOGY_v4_0_FINAL.md), KNOWN_ISSUES_REGISTER.md (32,932 B), THESIS_EXPLAINED PDF (12 pp, 313,609 B, extracted to text in-session), supervisor NEW links x2 (user message 2026-10-20; filed as READING_LIST_MASTER N-01/N-02).
Repo downloads (2026-10-20): old work data and results.zip SHA256 02e77c216a86b374bdc8b94ec70b20a2103b83bb2e792db89c7a869b9099e933 (43 files; FINAL_REPORT.md + THESIS_HANDOFF_BRIEF.md + AGENT_3_FINDINGS.md found inside); all data final.zip eb460131a92afd54131d0dc93e0ac544075a201a96f0e72811caa13de6d48c2f (matches Methodology v4.0 S9 eb4601...); moex_panel_data.zip 4855e337c35c62a066fcaf12c3a28bdae86d7a9062bc133891b3a4a0a865564f; blueprint_round.zip fc5ada3cad5c5f2b22223f67ad3eeb1b9374db9963b1db9c794a6e6084acc669 (listed only; data-fix contents NOT used as evidence per user instruction re DATAFIX_AUDIT).
MISSING INPUT: SUPERVISOR_LINKS_NEW.md (as file; reconstructed from message), ASIF_CONSTRAINTS.md (REQUIRED, absent), COMBINED_REPORT.md (absent from zip+repo root), litrelay/inputs/papers_pdf/ (none supplied).
Tool inventory: web search/fetch YES; Python 3.13 (pandas/numpy/scipy/statsmodels/arch) YES; R NOT CHECKED (UNVERIFIED); OCR (tesseract) NO; sub-agents NO (conductor = sequential single pass); repo write access NO (files delivered in workspace).
Allowed descriptives run: stage0/descriptives_allowed.py + descriptives2.py -> descriptives_by_firm.csv (75x419 verified; SVI/ASVI/RV described separately; no joint fit).


## Constraints summary (Asif constraints as restated)

# Constraints summary (restated; ASIF_CONSTRAINTS.md itself is MISSING)
From the master prompt + uploads only: Master's level (short econometrics course, Q10); standard software, interpretable designs preferred (DR4); Python available (prompt Tools; verified here); R if available (NOT verified here); author files read-only; plain-English explanations with demos required; no real attention regressions before the frozen design (DR7). Software/time/preference details beyond this are UNVERIFIED until Asif supplies ASIF_CONSTRAINTS.md. Decision 1 in DECISIONS_FOR_ASIF.md asks for ratification.


## Reading list (every supervisor link, old and new)

| id | title | url_or_doi | who_gave_it | access_route | status |
|---|---|---|---|---|---|
| R-01 | Fantazzini & Kurbatskii (2026) Nowcasting and Forecasting Russian Regional CPI (SSRN 6468200) | https://doi.org/10.2139/ssrn.6468200 | supervisor (old list, App. B Q6) | SSRN page + MPRA full PDF (legal open version) | OPENED-FULL (MPRA) -> S-FK26 |
| R-02 | Zhang et al. (2025) Conditional quantile estimation for GARCH model based on mixed-frequency data, Statistical Papers | https://doi.org/10.1007/s00362-025-01704-y | supervisor (old list) | Springer page (abstract) + Crossref | OPENED-ABSTRACT -> S-ZHAN25 |
| R-03 | Amendola, Candila & Gallo (2021) Choosing the frequency of volatility components within DAGM-X, Econometrics and Statistics | https://doi.org/10.1016/j.ecosta.2020.11.001 | supervisor (old list) | Crossref + ResearchGate abstract record (aggregator colab.ws NOT used as evidence) | OPENED-ABSTRACT -> S-AMEN21 |
| R-04 | Dhaene & Wu (2016) Mixed-Frequency Multivariate GARCH (SSRN 2799569) | https://doi.org/10.2139/ssrn.2799569 | supervisor (old list) | SSRN page (abstract) | OPENED-ABSTRACT -> S-DHAE16 |
| R-05 | Chevallier & Sanhaji (2023) Jump-Robust Realized-GARCH-MIDAS-X Estimators for Bitcoin and Ethereum, Stats | https://doi.org/10.3390/stats6040082 | supervisor (old list, ResearchGate link) | RePEc + SciProfiles abstract (ResearchGate not needed) | OPENED-ABSTRACT -> S-CHEV23 |
| R-06 | Liu et al. (2024) Enhancing stock volatility prediction with the AO-GARCH-MIDAS model, PLoS ONE | https://doi.org/10.1371/journal.pone.0305420 | supervisor (old list) | Publisher open-access HTML | OPENED-SECTIONS -> S-LIU24 |
| R-07 | HSE META2026 Draft Programme (Fantazzini guest talk + Novikova poster) | https://www.hse.ru/data/2026/10/02/242720593/Corr_Program_META2026_Draft_formatted_4.pdf | supervisor (old list) | HSE PDF downloaded and extracted | OPENED-SECTIONS -> S-META26, S-NOVI26 (poster TITLE-ONLY) |
| R-08a | YandexWordstatAPI (PyPI, 2022 legacy Direct wrapper) — tool, not a paper | https://pypi.org/project/YandexWordstatAPI | supervisor (old list, Q8) | Named in prompt App. B; not opened as evidence in this relay | LISTED-ONLY: legacy; superseded for guidance by S-WORDAPI; Asif to confirm if supervisor wants it tested |
| R-08b | Parser_Wordstat_Yandex (GitHub, M1shut3r) — tool, not a paper | https://github.com/M1shut3r/Parser_Wordstat_Yandex/tree/main | supervisor (old list, Q8) | Named in prompt App. B; not opened as evidence in this relay | LISTED-ONLY: legacy scraper; do not rely on without code review |
| R-09 | Yandex Wordstat API official documentation (Search API / AI Studio) | https://aistudio.yandex.ru/docs/en/search-api/concepts/wordstat.html | relay (to answer Q8 currently) | Official docs via search | OPENED-SECTIONS -> S-WORDAPI |
| N-01 | Ding, Cui, Xiong & Bai (2020) Forecasting stock market return with nonlinearity: a genetic programming approach | https://doi.org/10.1007/s12652-020-01762-0 | supervisor NEW (ResearchGate link in user message 2026-10-20) | Springer page + ResearchGate full text (legal CC-BY record); Nottingham eprints link now 404 | OPENED-SECTIONS -> S-DING20 (ResearchGate https://www.researchgate.net/publication/339162196) |
| N-02 | Kroujiline et al. (2016) Forecasting stock market returns over multiple time horizons (arXiv:1508.04332) | https://doi.org/10.48550/arXiv.1508.04332 | supervisor NEW (Yandex docviewer link decoding to arXiv PDF, p.33, in user message 2026-10-20) | arXiv abstract + PDF (viewer link bypassed to canonical arXiv source) | OPENED-SECTIONS incl. pp.33-35 -> S-KROU16 |


---

# Part I — Best-path report

# Best path report — Web Search Queries and Market Movements (Russian Equity Market)

**For:** Khandaker Asikh Iqbal (Asif), HSE Nizhny Novgorod. Supervisor: Prof. Andrey Aistov.
**Date:** 2026-10-20. **Relay:** LITRELAY conductor run (Stages 0–9 compressed into one supervised pass; see `STATE.md` for what is DONE / PARTIAL / NOT-DONE).
**Read this first:** §1 is the whole answer in plain English. Everything after it is evidence.

**Bulletproof rule used throughout.** Every factual statement is (a) tied to a source in `sources.csv` that was opened at the stated depth, (b) shown by code run in this relay (synthetic data or allowed descriptives), (c) a labelled recommendation, or (d) labelled `UNVERIFIED` / `HEARSAY` / `GAP`. Source IDs like [S-DA11] point to `sources.csv` + `evidence/S-*.txt`. `ABSTRACT-ONLY` sources support only what their abstracts say — and the report never asks them for more.

**What was NOT done (honesty box).** No regression, GARCH-X, HAR-X or MIDAS fit with the real attention variable was run (forbidden, DR7). The Yandex API was not live-tested. The Newey–West scan was not OCR-read (no OCR engine in this environment; its image-only status was verified). Russian-language adversarial literature searches were not re-run live (Agent-3's records were Crossref-checked instead) — the five-search absence rule is therefore PARTIAL (see `W3_REPORT.md`). The earlier `blueprint_round.zip` data-fix package was listed but, per your instruction about `DATAFIX_AUDIT_BY_CLAUDE.md`, not used as evidence; if that package contains newer sanction/ownership files, they still need the independent checks in §9 before use.

---

## 1. Executive summary in plain English (read this page only if you are short of time)

**Your question.** When Russians search Yandex for a company's shares unusually much in one week, is that stock more volatile — or does its return move — the next week? You follow 75 MOEX firms for 419 weeks (Aug 2018–Aug 2026), with two Wordstat queries per firm.

**Where you stand.** Your Methodology v4.0 is already strong: canonical ASVI, ruble volume, dividend-aware outcomes, separate level-vs-slope break tests, a fixed list of 21 sensitivity checks, and honest "not pre-registered" wording. The old results (found in `old work data and results.zip` → `FINAL_REPORT.md`, freeze 3 Oct 2026) say, in one line: *a few firms show an attention–volatility link (mixed signs), the average firm does not, and the return link does not survive correction for 74 tests.* Those numbers are context, not a reason to redesign — every recommendation below is justified without looking at which coefficient was significant.

**The recommended path (Plan A) keeps v4.0 as the core and fixes five things, in this order:**

1. **Adjust volatility for dividends too** (you already adjust returns). A dividend makes the price drop, and the weekly high–low range mistakes that drop for volatility — in the extreme case (SFIN, Dec 2025) the raw range is 0.678 and the corrected range is 0.185. *Demo:* if a share trades 100–105 all week, then drops 5 to pay a dividend, the raw range counts the 5 as "swing". It is not swing; it is a payment.
2. **Answer the supervisor's "returns hover around zero" worry with horizons, not by abandoning returns.** Keep next-week adjusted return, add the 0–4-week cumulative path (pressure, then possible reversal) and a portfolio sort. In the synthetic lab, throwing away the sign (absolute returns) destroyed the return signal (31.6% → 5.1% detection), because absolute return answers a volatility question, not a direction question. Absolute return stays — but as a volatility robustness check, not as the return test.
3. **Add two cheap, standard companions to the per-firm + pooled core:** Fama–MacBeth weekly cross-sections (each week asks "did high-attention firms move more?"; averaging 419 weekly answers handles market-wide shocks automatically) and a HAR-X volatility specification (adds 4- and 12-week volatility averages). In the synthetic lab both behaved correctly (size ≈ 5–7% when the true effect was zero) and the pooled test was by far the most powerful when the effect is common — which is why a pooled/portfolio Plan B matters if firm-by-firm results stay thin.
4. **Treat GARCH-X and GARCH-MIDAS-X as a judged extension, not the core.** Your prices are daily but searches are weekly, so GARCH-MIDAS-X (weekly attention slowly lifting daily volatility) is the natural shape — that is exactly what your supervisor's MIDAS links demonstrate in other settings. Weekly GARCH-X converged cleanly in the lab (40/40), but 419 weeks is short for 74 separate GARCH fits, and the Russian precedent that tried search in volatility forecasts (four large stocks, daily Google data) found search added nothing. So: run the pre-registered tournament (§7), let it pick at most one extension family, then run it once.
5. **Close the data gaps that an examiner will ask about first:** sanction dates from official lists, your own blind state-ownership classification, issuer-filed dividend ex-dates, and a total-return market index (so dividends are treated the same on both sides of the market adjustment). Until each closes, the affected hypothesis carries its gap label (H6 stays "provisional").

**Plan B (if firm-level attention stays thin).** Pool the question: "does the *average* high-attention firm, or a portfolio of the most-searched firms, become more volatile next week?" One pooled slope + one portfolio spread, with the same controls. This is not a consolation prize — in the lab it detects effects roughly five times smaller than a single-firm test can.

**What to tell the supervisor (one sentence each; full drafts in `ANSWERS_TO_SUPERVISOR.md`).** Formulas and draft sections: yes, v4.0 + this report give them. SVI/ASVI references: Da–Engelberg–Gao is the anchor [S-DA11]. GARCH with your ideas: yes, others have done it — and the closest Russian test found no search gain, so it belongs in a judged extension [S-BAZH19]. 419 observations: fine for the OLS/panel core, short for per-firm GARCH. MIDAS: the right shape for daily prices + weekly search; two of his links show exactly how the low-frequency driver is wired in. Fantazzini–Kurbatskii: in writing they use *Google Trends* for regional inflation; the META2026 programme shows a *Wordstat-titled* talk "after Google's exit" — but nobody has found, in writing, the sentence "Wordstat is better than Google", so that stays `HEARSAY`. Returns around zero: he is right that a single week's mean return is noisy; the fix is horizons + cross-sectional averaging, demonstrated below. Level: everything in Plan A is standard Master's-level software; GP formula-searching and multivariate BEKK-MIDAS are explicitly *not* recommended.

---

## 2. What the old results actually say (found, not re-run)

**Location found:** GitHub repo `aaa11996/yandex_new` → `old work data and results.zip` (SHA-256 `02e77c21…`, 43 files) → `FINAL_REPORT.md` ("Final Results & Defense Pack", execution freeze 3 Oct 2026, primary panel `combined_panel.zip`, 74-firm inference with ROLO excluded) and `THESIS_HANDOFF_BRIEF.md`. The v3 playbook and v4.0 replication give the same headline numbers, which is how you know the file is the results source and not a draft:

| Test (v2.0 spec unless noted) | Headline (as reported there) | Honest reading |
|---|---|---|
| H1 per-firm ASVI→RV (HAC-4) | 12 nominal / 5 BH survivors (LSRG, PHOR, RTKM, SNGS negative; MFGS positive); median β −0.004 | Heterogeneous firm-level evidence, no single sign. Under v4.0's ln(VALUE)+HAC-5: 10–11 nominal / 5 BH / 2 Holm, same five BH names (Methodology §6.5; Known-Issues K2/K5/L2). |
| H2 per-firm ASVI→return | 3 nominal / 0 BH; median β −0.003 | No corrected return evidence; nulls are underpowered (median MDE80 ≈ 0.025), so "inconclusive", not "no effect". |
| Pooled TWFE (M4) | β +0.0010, SE 0.0018, p .58, N=29,642, within-R² .133 | Average slope indistinguishable from zero in that spec; v4.0 replication +0.000785 (t 0.43) with DK errors. |
| H3 break (M5) | 26/74 omnibus breaks; only 2/74 slope shifts (IRKT, OGKB); 23 level shifts | Volatility *level* jumped after Feb 2022; evidence that the *attention effect* changed is weak. Never merge the two claims. |
| H4 sectors | Joint p .027, but p .45 (sectors ≥4 firms) / .40 (no singletons); YAKG label flips it | Fragile. Report as fragile nominal evidence only. |
| H5 dividend interaction | Price-only −0.022 (t −4.4) → dividend-adjusted ≈ −0.007 to −0.010 (t ≈ −2.1 to −2.8, timing-dependent) | About half to two-thirds was mechanical ex-dividend drop. The remainder is the testable part. |
| H6 state ownership | p .19 (both specs); classification comparison file missing | Provisional. No conclusion until blind re-classification. |
| M6 permutation | 10 raw p<.05 (block 4); 12 (block 8); median p .34 | Exploratory only, uncorrected, block-sensitive. |

*Plain English:* imagine testing 74 coins for bias by flipping each 419 times. Finding 5 coins that look biased (4 one way, 1 the other) tells you "something differs by coin", not "coins land heads". Your pooled test asks about the average coin and finds nothing clear yet. Both statements can be true at once — that is why Plan A keeps both levels and Plan B pools harder.

**Three traps in the old pack (do not re-import them).** (i) The "10/10 PASS" stamps certify *panel construction only*; the pack itself says so — never present them as results approval. (ii) The Giles–Lieberman 5.206 bound belongs to a different (classical Chow) statistic and must not threshold the HAC-Wald test (FINAL_REPORT Block 11 agrees; v4.0 V4-09 agrees). (iii) `RETURN_RAW` keeps split jumps (VTBR +8.48); only `RETURN_SAFE` blanks them (Known-Issues A2). Any rerun must assert which column it read.

## 3. The supervisor's papers: what each one really gives you

Full method cards are in `stage1/` (old links) and the new-link cards below; the table is the verdict. Reading depths are exact — do not cite deeper than listed.

| Item | What it is (verified) | Use for Asif | Verdict |
|---|---|---|---|
| Fantazzini & Kurbatskii 2026 [S-FK26, FULL] | Monthly regional CPI (79 regions, 2009–2025); Google Trends "Inflation" topic; ARDL nowcasts, HLag-VAR/DFM/shrinkage forecasts; search value collapses after early 2022 | Template for (a) time-varying value of online data, (b) sparse/penalised handling of many predictors, (c) honest break reporting. Note: *Google*, not Wordstat, in the written paper | **CORE** (design template) |
| Ding et al. 2020, GP [S-DING20, SECTIONS] — **NEW** | GP-evolved nonlinear formulas from 3 lagged index returns only (US/Japan vs China/India, 2006–2017); beats AR family; futures trading check | Forecasting-framing contrast only. No attention variable. Formula evolution = automated forking paths; needs heavy validation | **BACKGROUND** (do not adopt GP) |
| Kroujiline et al. 2016 [S-KROU16, SECTIONS pp.33–35] — **NEW** | Agent-based news model; news-only SPY forecasts at 1–28-day horizons; prototype strategies 2003–2015, no costs/sizing | Justifies looking at *several horizons* for H2 (days-to-months feedback story). US index news ≠ firm Wordstat attention | **BACKGROUND** (horizon motivation) |
| Amendola et al. 2021, DAGM-X [S-AMEN21, ABSTRACT-ONLY] | Double-asymmetric GARCH-MIDAS-X; choosing the X frequency | How to pre-specify the MIDAS driver's frequency instead of tuning it | **EXTENSION** |
| Dhaene & Wu 2016 [S-DHAE16, ABSTRACT-ONLY] | Mixed-frequency multivariate BEKK-GARCH (intraday → weekly) | Shows MIDAS weighting vs realised-sum choice matters; multivariate form is too heavy for the core | **BACKGROUND/EXTENSION** |
| Chevallier & Sanhaji 2023 [S-CHEV23, ABSTRACT-ONLY] | Realized-GARCH-MIDAS-X, jump-robust measures, crypto | Realised-measure + MSE/QLIKE evaluation discipline | **EXTENSION** (ideas only) |
| Liu et al. 2024, AO-GARCH-MIDAS [S-LIU24, SECTIONS] | GARCH-MIDAS with monthly macro X (China/Japan), outlier correction, MCS-type checks | Worked wiring diagram for daily-volatility/weekly-attention MIDAS-X; outlier warning transfers to dividend/jump weeks | **EXTENSION** |
| Zhang et al. 2025 [S-ZHAN25, ABSTRACT-ONLY] | Mixed-frequency GARCH quantile estimation (theory) | No search data; statistics background only | **BACKGROUND** |
| META2026 programme [S-META26] + Novikova poster [S-NOVI26, TITLE-ONLY] | Fantazzini–Kurbatskii guest talk titled "…with Yandex Wordstat after Google's Exit"; Novikova "Attention-Induced Trading and Return Reversal: Evidence from T-Pulse" (poster, title only) | Written proof the Wordstat talk exists under that title; closest Russian attention neighbour bounding novelty. No abstracts in the programme → findings `UNVERIFIED` | **CORE for context** (cite programme only for titles/sessions) |

**How Fantazzini–Kurbatskii use online data (asked explicitly in Stage 1).** In the *written* paper [S-FK26]: one Google Trends series — the "Inflation" *topic* (semantic basket, knowledge-graph entity), per region, monthly — enters (i) bivariate and multivariate ARDL nowcasting equations alongside CPI sub-indices, wages, unemployment, USD/RUB, Urals, M2 and RUONIA, and (ii) the 10-model forecasting race (HLag-VAR with/without search, DFM, shrinkage, random walk, ARIMA; random-forest robustness). Evaluation is error-metric plus formal comparison across regions/horizons, with the sample deliberately spanning the 2022 break so the break can be *measured*, not assumed away. Two transferable lessons: let the data say whether search still helps after 2022 (test the slope shift; never assert it), and prefer a sparse structured model over kitchen-sink search terms. The META2026 *talk title* swaps in Wordstat "after Google's exit" [S-META26] — consistent with Google's withdrawal making Wordstat the available source — but the talk's abstract, slides and any Wordstat-vs-Google comparison remain `GAP` until obtained. Supervisor-reported oral claim "Wordstat gives better information than Google Trends": **`HEARSAY`** — no written source found; the nearest written comparison (2012, health searches) finds co-movement with different strengths, not superiority for finance [S-ZHEL12].

*Plain English for the two NEW papers.* Ding et al. let a computer breed thousands of formulas from past returns ("formula evolution") and keep the survivors. It is a warning as much as a model: if you breed enough formulas, some will look brilliant by luck — that is why your thesis pre-lists its checks instead. Kroujiline et al. argue news hits prices fast (hours) but keeps echoing for weeks through feedback between fast and slow traders; p.33 (where the supervisor's link opens) starts the trading-test section. For you it means: do not only ask "next week?" — also ask "over the next month, does it reverse?"

## 4. Folder papers and earlier literature work (Stage 2 summary)

Method cards for all 7 folder PDFs are in `stage2/`. Headlines an examiner will probe:

- **Da–Engelberg–Gao [S-DA11]:** folder = June 2010 *draft* (50 pp); thesis must cite the 2011 *Journal of Finance* paper and take page numbers from the draft only with care. Canonical ASVI verified on draft p.4. Spelling/pagination traps: author is *Pengjie Gao*; the paper is 2011, not 2015 (v3 error, Known-Issues K8).
- **Vlastakis–Markellos [S-VLAS12]:** folder = 3 of 14 pages. Only abstract/intro claims may be sourced to it.
- **Swamy et al. India [S-SWAM19]:** DOI 10.1016/j.ribaf.2019.04.010, pp.1–17 (Crossref-verified here; an earlier guessed DOI was wrong and discarded). Agent-3 read it fully; you must still read it yourself before citing method details.
- **Newey–West [S-NEWW87]:** image-only scan (0 words — re-verified here). Bandwidth 5 is arithmetic, not a reading claim.
- **Misquotations/unsupported claims found in earlier reports** (full list in `stage2/`): v3's "pre-registered" wording (choices post-dated results), Newey–West lag 9 (arithmetic error; correct 5), "controls absent from history" (false), weekend-session "missing feed" (false; folded into next day), and any "first Russian study" phrasing (defeated by [S-TEPL25][S-STOL25][S-FAYZ25][S-NOVI26]). `COMBINED_REPORT.md` as a standalone file was **not found** in the old-work zip (43 files listed) or the repo root — Stage 2 therefore re-verified `AGENT_3_FINDINGS.md` + `THESIS_EXPLAINED` + `Combined_Data_File.md` leads instead, and marks the missing file `MISSING INPUT` (see §10).

## 5. Problem register and solution matrix (summary; full files alongside)

The full register (`PROBLEM_REGISTER.md`, P-01…P-22 from the prompt + P-23…P-28 found in this relay) maps every problem to ideas with status `SOLVED-BY-DESIGN / MINIMISED / ACCEPT-AND-DISCLOSE / NEEDS-DATA`. The five that change the design:

- **P-01 Dividends inflate both returns *and* RV** → dividend-adjusted RV (daily highs/lows adjusted before the weekly range) + dividend-adjusted returns. `SOLVED-BY-DESIGN` once ex-dates are filed (currently `NEEDS-DATA` for row-level upgrade; aggregator dates + T+1 rule are the interim disclosed basis).
- **P-06 Returns around zero / power** → horizons + CAR + Fama–MacBeth + portfolio sorts; |r| demoted to volatility robustness (lab evidence §6). `MINIMISED`.
- **P-04 Small-firm thin counts** → frozen query-variant recipe with inclusion–exclusion, minimum-count sensitivity, monthly-aggregation robustness; never firm-by-firm recipes. `MINIMISED` (API test decides whether variants are collectable at all).
- **P-08 Level vs slope break** → separate δ1/δ2 reporting (already in v4.0); unknown-break (Bai–Perron/sup-F) as sensitivity only [S-BAIP98]. `SOLVED-BY-DESIGN` for the confusion; the slope question itself stays open.
- **P-16 No daily search** → daily GARCH-X impossible; weekly GARCH-X + GARCH-MIDAS-X tournament decides the extension; API daily-depth test (30 requests) settles feasibility in writing. `NEEDS-DATA` (one cheap test).

Everything else (HAC/DK/multiplicity, crisis circularity, sanctions coding, survivorship, calendar, forking paths, novelty, causality language) is handled by disclosure + the fixed sensitivity list — see the matrix file. No problem is marked solved by pointing at a favourable coefficient.

## 6. Synthetic feasibility lab (Stage 6; simulated data only)

Plan frozen and hashed *before* runs (`stage5/TOURNAMENT_PLAN.md`, SHA-256 `a634ab58…`). Code: `stage6/sim_lab.py` (+ dividend addendum), seed 20261020, numpy 2.3.5 / pandas 2.2.3 / statsmodels 0.15.0 / arch 8.0.0. Results (`stage6/sim_dgpA.csv`, `sim_extra.csv`, `sim_counts.csv`, `sim_garchx.csv`; full reading in `SIM_REPORT.md`):

| Question | Lab answer (synthetic truth known) |
|---|---|
| Size at T=419 (true β=0, 120 reps) | Per-firm nominal 4.27/74 (5.8% per test ✓); BH false positives 0.11/rep ✓; Fama–MacBeth 6.7% ✓; pooled (week-cluster pilot SE) 7.5% — slightly hot, so the thesis run must use true Driscoll–Kraay and report both. |
| Power (homogeneous β) | Pooled ≈100% already at β=0.001; Fama–MacBeth 98% at 0.001; per-firm BH needs β≈0.002 for ~10 survivors/rep and β=0.005 for ~64. **MDE80: pooled/FM ≈ 0.001, single firm ≈ 0.003–0.004** (interpolated; homogeneous-effect best case — heterogeneity will worsen per-firm numbers). |
| HAR-X vs baseline (β=0.002) | 30.4% vs 30.0% nominal detection — no gain under an AR(1) volatility DGP. HAR-X stays a cheap robustness row, not a headline. |
| Weekly GARCH(1,1)-X (40 reps) | Converged 40/40, boundary 2.5%, X-sign recovered 40/40 under a favourable DGP. Feasible, not proven powerful; 74-firm + break reality will be harsher. GARCH-MIDAS-X estimation: `NOT-DONE` in the pilot (specified, not run) — literature-based expectation only. |
| Query variants (Poisson-only noise) | Attenuation λ at mean count 30: single 0.938 → correct sum 0.968 → overlap-wrong 0.960. Poisson noise alone understates real ASVI noise (empirical small-firm ASVI sd 0.49), so treat gains as an upper bound; overlap double-counting visibly eats the gain — inclusion–exclusion is mandatory. |
| Minimum-count rule | Not separately simulated as a threshold horse-race (`PARTIAL`): the count DGP shows noise is already modest at 130/week under Poisson, but empirical noise says otherwise. Keep S21 (SVI<10) + Q1-drop sensitivities; do not hard-delete small firms from the core. |
| Returns: level vs \|r\| (pressure 0.003) | Level-r* detection 31.6% vs \|r*\| 5.1%. \|r\| answers "did it swing?", not "which way?" — supervisor concern is met with horizons/CAR/FM, not absolutisation. Multi-horizon CAR estimation: `PARTIAL` (DGP-B reversal channel simplified). |
| Dividend contamination | Uncorrelated ex-weeks: no ASVI-slope bias (variance only). Attention-correlated ex-weeks: adjusted-RV mean coef 0.0074 vs raw 0.0075 at true 0.010 (attenuation is measurement noise, −26%). RV adjustment still required for levels, H5 and SFIN-type weeks — the return channel (−5.1% ex-week mean, v4.0-verified) is where dividends bite hardest. |

*Demo (attenuation):* if true attention moves volatility by 0.010 but you observe attention through fog (small-firm noise), you estimate ≈0.0074. The effect did not shrink; your ruler is foggy. Query variants thin the fog a little; they do not remove it.

**Allowed real-data checks run in this relay (DR7-compliant):** panel structure 75×419 re-verified from `all data final.zip` (hash `eb460131…` matches Methodology §9); SVI medians 22 (MRKK) → 86,842 (MGNT), panel median 971; ASVI sd by SVI quartile 0.49/0.36/0.30/0.26 — exactly the Known-Issues K7 values (`stage0/descriptives_by_firm.csv`). No attention→outcome fit was run.

## 7. Recommended design: Plan A, Plan B, extension layer

**Plan A (core; all standard Master's-level).** M1 per-firm OLS-HAC5 on dividend-adjusted RV + M2 per-firm on dividend-adjusted, market-adjusted (total-return index; pre-2022 β primary, rolling 52/104 sensitivities) returns at h=1 plus CAR(0,4) path; M4 pooled TWFE-DK; **new** Fama–MacBeth + quintile sorts; M5 split level/slope; M6 circular-shift placebos (+ cross-firm swap, lead test). Controls: RV lag, ln(VALUE), Crisis (per-firm only, circularity disclosed; lagged market RV sensitivity), Sanction step, Div anticipation window. Families BH-5% (Holm alongside); every null reported with MDE80. Outcomes: dividend-adjusted RV primary; realised-range (daily Parkinson sum) and log-RV as pre-listed sensitivities. ASVI canonical; windows 4/13/26, share-normalised, channel-split and min-count rows all pre-listed (S03/S04/S15/S21/S22–S25). Market attention: week FE primary; market-ASVI-as-regressor per-firm sensitivity; naive subtraction disclosed as imposing loading 1 (empirical loadings 0.28–1.89).

**Plan B (pooled/portfolio; triggered if Plan A firm-level BH survivors < 3 or pooled MDE says firm tests cannot see plausible effects).** Headline becomes the pooled slope + FM mean slope + high-minus-low ASVI portfolio RV spread, with sector/size splits as description. Same data, same controls, one-page trigger rule written *now* (trigger on *precision*, never on sign or p-value shopping).

**Extension layer (tournament-gated; at most one family promoted).** Weekly GARCH-X/EGARCH-X on a liquid-firm subset; GARCH-MIDAS-X (daily returns, weekly ASVI in tau, K=12, Beta weights) on the same subset; quantile regression (Swamy-style) as heterogeneity description; forecast race (expanding window, Diebold–Mariano + MCS) reported *alongside* hypothesis tests for a forecasting-minded reader. GP formula search [S-DING20], multivariate BEKK-MIDAS [S-DHAE16], jump-robust crypto machinery [S-CHEV23] and mixed-frequency quantile theory [S-ZHAN25]: **REJECT for this thesis** (level, data, or forking-paths reasons — see idea review in `stage5/`).

**Roadmap with decision points.** (1) Freeze Plan A/B text + sensitivity list (hash). (2) API 30-request test → daily-depth + variant-collectability decision. (3) Dividend/sanction/SOE/market-index data closure (each independently checked; H6 unlocks only on blind classification). (4) Synthetic tournament pilot already run — extend to GARCH-MIDAS-X + CAR before any real fit. (5) Single real-data run; report everything; placebos alongside. (6) Extension run (winner only). Each step stops and reports if its input cannot be done exactly (v2.0 standing rule, kept).

## 8. Novelty statement (bounded; never "first")

> Among the sources opened at the depths recorded in `sources.csv`, no study was found that combines issuer-level Yandex Wordstat queries, a broad (75-firm) MOEX panel including small firms, weekly firm volatility/returns, and a pre-planned model-family comparison over 2018–2026. Russian search-and-market work does exist (Google intraday trading activity [S-TEPL25]; macro Wordstat stress index [S-STOL25]; search-attention retail-return abstract [S-FAYZ25]; T-Pulse attention-reversal poster, title only [S-NOVI26]), and firm-level weekly Google attention panels exist for Turkey, Brazil, India, Vietnam and China. The contribution is therefore claimed as *incremental and combinational*, not first. This absence statement rests on Agent-3's documented search plus this relay's programme/Crossref checks; a live Russian-language adversarial re-search is still owed (GAP) before the thesis freezes the wording.

## 9. Risks and what is still unknown

Sanction anchors (20/24 unverified against primary lists; negative verification of 51 firms open), SOE blind classification (H6 provisional), dividend row-level issuer filing upgrade, corporate-action ratios, total-return/USDRUB/oil/key-rate series retrieval, survivorship registry for 19 excluded candidates, Wordstat collection-settings questionnaire (operators/quoting at export), META talk slides/abstract, Fayzulin full text, Novikova poster paper, API daily depth, GARCH-MIDAS-X pilot, true-DK pooled size check. Each has an owner and a closing test in `DECISIONS_FOR_ASIF.md` / `PROBLEM_REGISTER.md`. The largest examiner risk is not econometrics; it is citing a paper deeper than it was read — the reading-depth column is the defence.

## 10. Inputs, missing items, and exclusions (Stage 0 record)

Received and opened: `LITRELAY_MASTER_PROMPT.md`, `METHODOLOGY_v4.0_FINAL.md` (repo name `METHODOLOGY_v4_0_FINAL.md` — same document as supplied), `KNOWN_ISSUES_REGISTER.md` (K–N sections present as §§J–L plus A–I; no separate K–N files), Thesis Explained PDF (12 pp, extracted; treated as `THESIS_EXPLAINED`), supervisor NEW links (2, in the user message — filed as `SUPERVISOR_LINKS_NEW` equivalent, R-09/N-01/N-02), repo zips (old-work, all-data, MOEX; hashes in `INPUT_MANIFEST.md`). **Missing:** `SUPERVISOR_LINKS_NEW.md` as a file (reconstructed from the message; Asif to confirm no further links), `ASIF_CONSTRAINTS.md` (**required file absent** — relay proceeded on the prompt's stated constraints: Python available, R availability `UNVERIFIED`, Master's level, no repo write access assumed; see `CONSTRAINTS_SUMMARY.md` — Asif must correct this), `COMBINED_REPORT.md` (not in old-work zip or repo root), paywalled PDFs folder (none supplied; legal abstract routes used instead). **Excluded by your instruction:** `DATAFIX_AUDIT_BY_CLAUDE.md` (not used). Per prompt §1 the two missing required files would normally stop the relay at Stage 0; because you directed the relay to proceed and supplied the new links in-message, Stage 0 records them as `MISSING INPUT` and the conductor continued — **ratify or correct this in your reply** (see `README_FOR_ASIF.md`).

## References

See `REFERENCES_VERIFIED.csv` / `sources.csv` (33 rows, each with DOI/URL, tier, reading depth and evidence file). Folder-paper bibliographic details follow the PDFs actually held; emerging-market findings carried from Agent-3 are labelled `ABSTRACT-ONLY in this relay` wherever this relay did not re-open the full text.


---

# Part II — Draft answers to the supervisor

# Draft answers to the supervisor (adapt in your own voice; 3–8 lines each)

Sources are [S-…] in `sources.csv` with reading depths. Nothing here cites a paper deeper than it was read.

**Q1 — Formulas / draft text.** Agreed: Methodology v4.0 (§§4–6) states every variable and model in formulas (canonical ASVI, RV, adjusted return r*, M1–M6), and this package adds the Fama–MacBeth, HAR-X and MIDAS-X formulas in the extension plan. The literature/data/models/results/discussion structure is drafted in `LIT_REVIEW_SKELETON.md` + v4.0; results text will follow the single frozen run, with the previously seen v2.0/v3 numbers disclosed (v4.0 §6.5, §10), not hidden.

**Q2 — SVI/ASVI references.** The anchor is Da, Engelberg & Gao (2011, *Journal of Finance*) [S-DA11]: ASVI = ln(SVI_t) − ln(median SVI, prior 8 weeks), verified on the held 2010 draft (p.4). Weekly search-volatility precedent: Vlastakis & Markellos (2012) [S-VLAS12, pp.1–3 held]; market-level forecast precedent: Dimpfl & Jank (2016) [S-DIMP16, abstract]. Our panel already equals the canonical form (verified to 4.4e-16); the median-of-logs variant is sensitivity S03.

**Q3 — GARCH-X: has anyone done this?** Yes. Volatility models with search/online regressors are established at market level (Dimpfl & Jank: search Granger-predicts realised volatility and improves AR/HAR forecasts [S-DIMP16, abstract]) and, most relevantly, Bazhenov & Fantazzini (2019) ran GARCH/ARFIMA/HAR with Google Trends for SBER/GAZP/ROSN/YNDX and found search added nothing beyond implied volatility [S-BAZH19, sections read]. Proposal: GARCH-X enters as a tournament-judged extension (weekly, liquid subset), not as an unexamined replacement for the OLS/panel core.

**Q4 — Is 419 enough?** For the per-firm OLS-HAC and pooled panel core, yes — synthetic MDE80 ≈ 0.003–0.004 (single firm) and ≈0.001 (pooled) in RV units (Stage-6 lab). For 74 separate GARCH fits it is short (convergence held in the lab's favourable DGP, power is the binding constraint), which is why GARCH is extension/subset work and why every null will carry its MDE instead of a "no effect" claim.

**Q5 — MIDAS.** Agreed as the natural extension: daily MOEX returns with weekly ASVI driving the long-run component (GARCH-MIDAS-X after Engle–Ghysels–Sohn [S-ENGL13, abstract]; driver-frequency choice after Amendola et al. [S-AMEN21, abstract]; worked macro-X template Liu et al. [S-LIU24, sections]). Pre-specified now (K=12 weeks, Beta weights); promoted only if the synthetic tournament passes it. Multivariate BEKK-MIDAS [S-DHAE16] is beyond the core.

**Q6 — Fantazzini & Kurbatskii (2026), another way to use online data.** Read in full (MPRA version) [S-FK26]: monthly regional CPI now/forecasting where a single Google Trends "Inflation" topic joins ARDL equations and a 10-model sparse-forecast race. Two borrowable ideas: (i) let search compete against rich macro controls and report where it stops helping; (ii) estimate the post-2022 value change instead of assuming stability — their search value collapses after early 2022 while the sparse VAR wins. Our H3 slope-shift test is the firm-level analogue.

**Q7 — Fantazzini / META2026 / "Wordstat is better".** In the META2026 draft programme (opened, 13 pp) Fantazzini & Kurbatskii appear as guest speakers with the talk "Searching for Inflation: Forecasting Russian Regional Prices with Yandex Wordstat after Google's Exit" (Fri 2 Oct, 09:00) [S-META26]; the programme prints no abstract, and no written "Wordstat is better than Google" statement was found — that formulation is therefore labelled `HEARSAY`. The written paper uses Google Trends [S-FK26]; the only opened Google-vs-Yandex comparison (2012, health searches) finds co-movement with different strengths, not finance superiority [S-ZHEL12, abstract].

**Q8 — Wordstat API / download tools.** Collection was manual (150 exports); earlier scripts hit apparent rate limits. The tools you linked target the legacy Yandex.Direct interface (PyPI 2022 wrapper; GitHub parser — listed, not relied on). The current official route is the Yandex Search API Wordstat methods (GetDynamics by day/week/month, GetTop, regional distribution) [S-WORDAPI, docs sections]. Proposal: a ≈30-request test to settle (a) daily history depth (web help suggests 60 days — to be confirmed in writing) and (b) variant collectability, before any larger spend; the thesis does not depend on it.

**Q9 — Market-adjusted returns fluctuate around zero.** You may well be right for a single week: the old run found 3 nominal / 0 corrected return effects with MDE80 ≈ 0.025, i.e. the weekly test can miss plausible pressure. The design answer is horizons (h=0…4 + cumulative path, after the pressure-then-reversal pattern in [S-DA11] and the multi-horizon news logic in [S-KROU16]) plus cross-sectional averaging (Fama–MacBeth/sorts), pre-specified now. In the synthetic lab, replacing returns by |returns| cut detection from 31.6% to 5.1% (it answers a volatility question), so |r*| is kept as volatility robustness, not as the return test. It will be interesting to see whether the cumulative path disagrees with the single-week null.

**Q10 — Level.** Plan A uses only standard tools (OLS-HAC, fixed effects with Driscoll–Kraay, Fama–MacBeth, OLS HAR, BH/Holm) in Python/statsmodels. GARCH-MIDAS-X, quantile and forecast-race items are fenced as extensions; genetic-programming formula search [S-DING20], multivariate BEKK [S-DHAE16] and jump-robust crypto MIDAS [S-CHEV23] are explicitly not proposed at this level.

**Q11 — Subtracting market-average ASVI (your open question, via Asif).** Short answer: pooled week fixed effects already remove the weekly average exactly (verified: identical slope), so subtraction is redundant there; in per-firm regressions subtraction imposes a 1-for-1 loading while estimated loadings run 0.28–1.89, and it changes small firms *least* (−9% variance in Q1 vs −22…−26% for larger firms; Known-Issues K7, descriptives re-verified). It does not remove the need for crisis handling in per-firm models (a common *attention* mean is not a *volatility* control). Recommended: week FE pooled primary; market-ASVI-as-regressor (free coefficient) per-firm sensitivity; naive subtraction as disclosed sensitivity only (S05/S06/S18).

**New links (for completeness).** Ding et al. (GP, no search data) and Kroujiline et al. (news-only multi-horizon SPY strategies, p.33 = strategies section) were both read at the depths in `sources.csv`; neither changes the core design — the first warns against formula-mining, the second motivates the return-horizon path. ResearchGate was used only to open the CC-BY full text legally; the canonical Springer/arXiv records are cited.


---

# Part IIIa — Problem register

# Problem register (Stage 4; extends prompt Appendix C)

Severity: S1 = can invalidate a headline claim; S2 = can bias/distort; S3 = disclose. Evidence tags follow Known-Issues provenance; literature cites [S-…] at stated depth. Results were read only to understand problems, never to rank fixes by effect size (DR7).

| ID | Problem (one line) | Evidence | Sev | Hits | What literature does (cite) | Status |
|---|---|---|---|---|---|---|
| P-01 | Ex-dividend drop inflates returns and RV (SFIN RV 0.678→0.185; mean RV −25% in ex-weeks; H5 halves) | v4.0 §6.5/L4 (code-verified there); SFIN T3 dividend ID in L3, issuer filing still needed | S1 | H1,H2,H5 | Adjusted/total-return outcomes are standard; range estimators assume continuity (surveyed in range-estimator literature; full-text check owed) | Design fixed (P→S matrix); row data NEEDS-DATA |
| P-02 | Share-count VOLUME breaks at splits (VTBR Δln −8.07 vs VALUE +0.17) | Known B3/C-CODE; v4.0 V4-01 | S1 | H1–H4 | Ruble turnover avoids share-count breaks (design logic, DR1) | SOLVED-BY-DESIGN (ln VALUE; S01/S02 sensitivities) |
| P-03 | Median-of-logs ≠ log-of-median (8-week even window) | Known A1 demo (2.996 vs 3.951); draft p.4 [S-DA11] | S2 | H1,H2 | Canonical form in [S-DA11] | SOLVED-BY-DESIGN (canonical primary; S03) |
| P-04 | Small firms: thin counts, heteroskedastic ASVI noise (sd .49→.26); variants overlap; "акции"=promotions | Known K7; relay descriptives replicate quartiles exactly | S1 | H1,H2 | Emerging panels face same thinness [S-SWAM19 abstract-level]; no issuer Wordstat validation found (Agent-3) | MINIMISED (frozen variants + S21 + monthly check) |
| P-05 | Market attention vs firm loadings (subtraction imposes 1; loadings .28–1.89) | Known J3/K7 (16.6% common var.; pooled identity verified) | S2 | H1 | Firm-vs-market demand split [S-VLAS12 pp.1–3]; Vietnam firm/market split [S-BUIN19 via Agent-3] | SOLVED-BY-DESIGN (week FE; S05/S06/S18) |
| P-06 | Market-adjusted returns near zero; power; horizon | Supervisor Q9; old H2 MDE .025; lab §6 | S1 | H2 | Pressure+reversal needs path [S-DA11]; multi-horizon news logic [S-KROU16 sections] | MINIMISED (CAR/FM/sorts; \|r\| robustness only) |
| P-07 | HAC lag, Driscoll–Kraay, multiplicity under dependence, permutation validity | v4.0 V4-08; [S-DRIS98 abstract]; [S-BENJ95] | S2 | H1–H6 | DK large-T [S-DRIS98]; BH + Holm shown; BY/Romano–Wolf as dependence sensitivities (design rule) | MINIMISED (HAC5 primary; DK true implementation still to verify in code review) |
| P-08 | H3 confounds level shift with slope shift; break-date choice | v3 F 63.86 vs slope-only 4.70; v4.0 V4-09 | S1 | H3 | Unknown-break methods [S-BAIP98 abstract] as sensitivity; known-date split primary | SOLVED-BY-DESIGN (δ1/δ2 separate; S20) |
| P-09 | Crisis control circular (built from RV/volume), share-volume leg, mobilisation week outside windows | Known D8/E1/J5; v4.0 §8 | S2 | H1,H3 | No literature cure; disclosure + outcome-free alternative (lagged market RV, S13) | ACCEPT-AND-DISCLOSE (+S13) |
| P-10 | Sanction coding: 4/24 anchors secondarily checked; 51-firm negative check open; AFLT single-source; AVAN unverified; 2026 anchors unverified | v4.0 §12/GAP-11; Known E2/L6 | S1 | H1,H3 | Jurisdiction-first coding + pre-sample sectoral measures (design rule; no paper cures coding) | NEEDS-DATA |
| P-11 | SOE classification not blind/independent (35/40 published; 34/41 comparator missing) | v4.0 §14/GAP-12; Known E3 | S1 for H6 | H6 | Blind double classification (methods discipline) | NEEDS-DATA (H6 provisional) |
| P-12 | Dividends: aggregators only, approx. ex-dates (T+2→T+1 2023-07-31), share classes | v4.0 §13; Known E4; MOEX T+1 (v4.0 T1) | S1 | H2,H5,P-01 | Issuer filings/e-disclosure upgrade (data rule) | NEEDS-DATA |
| P-13 | News layer outcome-selected (spike-confirmed, data-driven durations) | Known D8/E5; v4.0 V4-14 | S2 | — | Excluded from models; fixed-duration appendix only if rebuilt | SOLVED-BY-DESIGN (excluded) |
| P-14 | Market/macro series missing or price-only (IMOEX vs total-return mismatch, esp. Jun–Jul) | v4.0 §16/GAP-15, L5 | S2 | H2 | Total-return consistency (DR1 correctness) | NEEDS-DATA (pooled insulated by week FE) |
| P-15 | Universe/survivorship (19 excluded, registry open), share classes, ROLO grid, sector map (YAKG) | Known D7/B11/E3; old H4 fragility | S2 | H4, all | Survivorship disclosure; all-75 sensitivity (old pack) | ACCEPT-AND-DISCLOSE (+registry NEEDS-DATA) |
| P-16 | No daily search (Wordstat daily ~60d web help; API untested) → daily GARCH-X impossible | Prompt §1 facts; [S-WORDAPI sections] | S1 for extensions | Ext. | MIDAS bridges frequencies [S-ENGL13][S-AMEN21 abstracts] | NEEDS-DATA (30-request test) |
| P-17 | Forking paths: v2/v3 results seen before v4 design | v4.0 §10; DR6 | S1 (credibility) | All | Amendment IDs + fixed sensitivities + disclosure (v4.0) | ACCEPT-AND-DISCLOSE (no pre-registration claim) |
| P-18 | Novelty bounded; Wordstat validity vs Google; "Yandex better" hearsay | §8 statement; [S-ZHEL12 abstract]; [S-META26] | S2 | Framing | Co-movement, not superiority [S-ZHEL12] | ACCEPT-AND-DISCLOSE (HEARSAY labelled) |
| P-19 | Calendar: 2022 closures, weekend sessions folded to Monday (from 2025-03-01), partial/New-Year weeks | v4.0 §2 (verified ratios); Known J5/K8 corrections | S3 | All | Missing-stays-missing; Monday keys only (V4-21) | SOLVED-BY-DESIGN (disclosed quirk) |
| P-20 | Earlier agent data package failed audit (invented/mislabelled rows in 5-Oct draft history) | Known J5/G; Thesis §10 (ex-dates/market series) | S1 (process) | Data | Evidence-per-row discipline (Iron Rule 4) | MINIMISED (this relay's evidence files; independent canary still owed) |
| P-21 | Prediction ≠ causation; reverse causality (volatility → searches) | v4.0 §8; bidirectional Granger in [S-DIMP16 abstract] | S1 (language) | H1,H2 | Lag + lead/placebo falsification (C6) | ACCEPT-AND-DISCLOSE (predictive language only) |
| P-22 | Wordstat count meaning: queries≠people; seasonality; Yandex share shifts/level breaks | Known C1/J1/J2 (D_t 1.62→2.90→2.54bn; lockdown/New-Year demos) | S2 | H1,H2 | Share-normalisation sensitivity (S04); topic-basket noise reduction idea from [S-FK26 FULL] (transfer UNVERIFIED for tickers) | MINIMISED (counts primary; S04) |
| P-23 | *(new)* Quantitative Finance version of [S-KROU16] not opened; arXiv v2 relied on | arXiv record states accepted version; journal text not opened | S3 | Q9 framing | Cite arXiv v2 explicitly | ACCEPT-AND-DISCLOSE |
| P-24 | *(new)* META talk abstract/slides missing; Kurbatskii spelled "Kurbatsky" in programme | Programme extraction [S-META26] | S3 | Q6/Q7 | Request slides from authors/HSE page | NEEDS-DATA (one email) |
| P-25 | *(new)* Fayzulin (2025) full text unread (Russian, PDF viewer failed for Agent-3 too) | Agent-3 ref 10; §4 | S2 | Novelty | Obtain via journal/elibrary | NEEDS-DATA (priority read) |
| P-26 | *(new)* Pooled pilot SE in lab used week-clustering, not true DK; size 7.5% | Stage-6 code + SIM_REPORT | S2 | Methods | True DK-Bartlett-4 in thesis code; report DK + two-way cluster (S16) | MINIMISED (code review item) |
| P-27 | *(new)* GARCH-MIDAS-X, CAR-power and min-count horse-races specified but not run in pilot | Tournament plan vs SIM_REPORT | S2 | Extensions | Run before any real extension fit (hash already frozen) | NEEDS-DATA (compute, not data) |
| P-28 | *(new)* ASIF_CONSTRAINTS + COMBINED_REPORT missing; R availability unknown | §10 inventory | S3 | Process | Asif confirms software/time; R-only estimators (e.g. some MIDAS tooling) need fallback plan | NEEDS-DATA (Asif reply) |


# Part IIIb — Problem-to-solution matrix

# Problem-to-solution matrix (Stage 5 summary)

Idea IDs follow prompt Appendix A (A1–A7, B1–B3, C1–C10, D1–D5, E1–E3). Full per-idea verdicts (rule, difficulty, risks, interactions) are in `stage5/W5_REPORT.md`. Status: SOLVED-BY-DESIGN / MINIMISED / ACCEPT-AND-DISCLOSE / NEEDS-DATA.

| Problem | Solution ideas (verdict) | Status |
|---|---|---|
| P-01 | B1 dividend-adjusted RV (CORE); B2 adjusted returns (CORE); D4 true ex-dates (CORE data task) | NEEDS-DATA (design solved) |
| P-02 | B3/D1 ln(VALUE) (CORE); S01/S02 sensitivities | SOLVED-BY-DESIGN |
| P-03 | A1 canonical ASVI (CORE, DR2); windows 4/13/26 (sensitivities) | SOLVED-BY-DESIGN |
| P-04 | A3 frozen variants + inclusion–exclusion (CORE-if-collectable); monthly aggregation C10 (sensitivity); min-count S21 (sensitivity, not deletion) | MINIMISED |
| P-05 | A5 week FE (CORE); market-as-regressor + residual-loading (sensitivities); subtraction (disclose-only, REJECT as primary) | SOLVED-BY-DESIGN |
| P-06 | B2 horizons + CAR + reversal (CORE); C2 Fama–MacBeth + sorts (CORE); \|r\| (robustness only); C5 quantile (EXTENSION) | MINIMISED |
| P-07 | C7 HAC5 + DK + BH/Holm (+BY/Romano–Wolf sensitivities); C1 permutation placebos (CORE) | MINIMISED |
| P-08 | C8 split δ1/δ2 (CORE); Bai–Perron/sup-F + rolling slopes (EXTENSION sensitivities) | SOLVED-BY-DESIGN (confusion); effect OPEN |
| P-09 | D2 outcome-free crisis alternative (sensitivity S13); pooled week FE absorbs flag (CORE) | ACCEPT-AND-DISCLOSE |
| P-10 | D3 jurisdiction-first recode + reaction-window variant (data task) | NEEDS-DATA |
| P-11 | D5/C9 blind SOE recode (data task; H6 locked until done) | NEEDS-DATA |
| P-12 | D4 issuer-filed ex-dates, share-class match (data task) | NEEDS-DATA |
| P-13 | News exclusion (CORE decision V4-14) | SOLVED-BY-DESIGN |
| P-14 | D1 total-return index + USD/RUB/oil/key-rate retrieval (data task) | NEEDS-DATA |
| P-15 | D5 survivorship registry + sector-map freeze (disclosure task) | ACCEPT-AND-DISCLOSE |
| P-16 | C3 GARCH-MIDAS-X (EXTENSION, tournament-gated); weekly GARCH-X subset (EXTENSION); API test (decision task) | NEEDS-DATA |
| P-17 | E1 amendment IDs + hashed tournament + full reporting (CORE process) | ACCEPT-AND-DISCLOSE |
| P-18 | E2 bounded novelty (CORE wording); A6 validation vs volume/extremes/news (EXTENSION, no return peeking) | ACCEPT-AND-DISCLOSE |
| P-19 | D1 calendar rules (CORE, already in v4.0) | SOLVED-BY-DESIGN |
| P-20 | Evidence-per-row + hashes + canary (CORE process) | MINIMISED |
| P-21 | C6 lead/placebo falsification + predictive language (CORE) | ACCEPT-AND-DISCLOSE |
| P-22 | A2 share-normalised ASVI S04 (sensitivity); A3 top-query audit for "promotions" noise (data task) | MINIMISED |
| P-23–P-28 | Library/email/compute/confirmation tasks (see register) | NEEDS-DATA / DISCLOSE as listed |

**Plan A / Plan B / Extension** are defined in `BEST_PATH_REPORT.md` §7. No row was resolved by inspecting a real-data attention coefficient.


---

# Part IVa — Literature review skeleton

# Literature review skeleton (cite only at the recorded depth; re-read ABSTRACT-ONLY items before thesis citation)

1. **Attention theory.** Limited attention + noise-trader risk [S-DELO90, sections] + attention-induced buying pressure [S-DA11, draft sections]. State the three competing sign stories (Thesis §2) and the two-sided hypotheses.
2. **Search as attention measure.** Google SVI construction/validation and ticker-vs-name choice [S-DA11]; information demand vs supply, firm vs market [S-VLAS12, pp.1–3 only]; Wordstat measurement (counts, share denominator, word forms — Methodology §4.1, status (b) facts); Google-vs-Yandex co-movement, health setting, dated [S-ZHEL12, abstract]. Explicitly: no issuer-level Wordstat validation found → validity argued by analogy + A6 checks, not asserted.
3. **Attention → volatility.** Market-level search/volatility + HAR augmentation [S-DIMP16, abstract]; firm/market demand [S-VLAS12]; Russian null precedent [S-BAZH19, sections] as the sober prior. Hypothesis H1 two-sided.
4. **Attention → returns, pressure and reversal.** Founding path [S-DA11]; emerging-market sign heterogeneity: Turkey [S-DUZT19*], Brazil (small negative) [S-YOSH20*], India quantiles [S-SWAM19*], Vietnam mixed [S-BUIN19*], China reversal [S-YANG21, abstract] (* = Agent-3 full read, this relay abstract/bibliographic — Asif re-reads). News-horizon echo [S-KROU16, sections] for the CAR design. H2 two-sided with horizons.
5. **Russia.** Retail behaviour context [S-DJAL21, abstract in this relay]; search overlaps that bound novelty [S-TEPL25, S-STOL25, S-FAYZ25 abstracts; S-NOVI26 title only]; online-data value collapse after 2022 in inflation forecasting [S-FK26, FULL] as break-design template. Bounded novelty paragraph (Best Path §8).
6. **Volatility models with online/low-frequency drivers.** HAR [S-CORS09, abstract]; GARCH-MIDAS [S-ENGL13, abstract]; driver-frequency choice [S-AMEN21, abstract]; realised-GARCH-MIDAS-X evaluation [S-CHEV23, abstract]; outlier-corrected MIDAS-X template [S-LIU24, sections]; mixed-frequency background [S-DHAE16, S-ZHAN25 abstracts]. GP formula search [S-DING20, sections] in one paragraph: why *not* adopted (forking paths, level).
7. **Inference and breaks.** HAC [S-NEWW87], Driscoll–Kraay [S-DRIS98, abstract], BH [S-BENJ95], unknown breaks [S-BAIP98, abstract], Giles–Lieberman demotion note [S-GILE]. One paragraph each, tied to M1–M6 choices.

Each thesis paragraph must carry its source IDs in draft; any claim needing more than the recorded depth is either re-read or deleted.


# Part IVb — Priority reading list (read fully first)

# Priority reading list — the 10 papers to read fully first (in this order)

1. **Da, Engelberg & Gao (2011)** [S-DA11] — your measure and return story. Read the published version; check every ASVI sentence against draft p.4. *Why first: the examiner will start here.*
2. **Fayzulin (2025)** [S-FAYZ25] — potentially closest Russian return overlap; currently abstract-only with unreadable PDF in two rounds. Obtain via journal/eLibrary. *Why: novelty wording cannot freeze without it.*
3. **Bazhenov & Fantazzini (2019)** [S-BAZH19] — Russian volatility-forecast null for search. *Why: your extension's prior; supervisor knows this literature.*
4. **Fantazzini & Kurbatskii (2026)** [S-FK26] — already FULL here; re-read §§3–4 for the ARDL/HLag evaluation details before the meeting. *Why: Q6 will be discussed live.*
5. **Vlastakis & Markellos (2012)** [S-VLAS12] — get all 14 pages (folder has 3). *Why: H1's firm-vs-market framing.*
6. **Swamy, Dharani & Takeda (2019)** [S-SWAM19] — India weekly panel + quantiles + rolling beta. *Why: closest design cousin; folder copy is yours to read.*
7. **Dimpfl & Jank (2016)** [S-DIMP16] — search→volatility + HAR forecasting. *Why: Q3's "has anyone done GARCH/HAR with search?" answer.*
8. **Yoshinaga & Rocco (2020)** [S-YOSH20] — small negative emerging-market returns. *Why: defends two-sided H2; spelling Yoshinaga verified.*
9. **Engle, Ghysels & Sohn (2013)** [S-ENGL13] — GARCH-MIDAS original. *Why: Q5; read before writing any MIDAS formula.*
10. **Novikova (2026, T-Pulse poster)** [S-NOVI26] — title only today; find the paper/slides via HSE. *Why: nearest Russian attention-reversal neighbour; also ask about T-Pulse as an A6 validation proxy.*

Next tier (abstract suffices until drafting): Amendola et al. [S-AMEN21], Liu et al. [S-LIU24], Corsi [S-CORS09], Driscoll–Kraay [S-DRIS98], Bai–Perron [S-BAIP98], Zheluk et al. [S-ZHEL12].


# Part IVc — Decisions for Asif

# Decisions for Asif (and the supervisor) — plain-English trade-offs

1. **Ratify the relay's Stage-0 workaround.** Required files `ASIF_CONSTRAINTS.md` and a standalone `COMBINED_REPORT.md` were missing; the relay proceeded on prompt-stated constraints. *Trade-off:* confirming costs one reply; not confirming leaves software/time assumptions (Python yes, R unknown) baked into the extension plan.
2. **Confirm the supervisor's new-link set is exactly the two links in your 2026-10-20 message** (Ding GP + Kroujiline arXiv via viewer). *Trade-off:* any third link changes Stage 1; saying so now is cheaper than after drafting.
3. **Dividend-adjusted RV as primary (Amendment after v4.0).** *Trade-off:* one more data build (daily highs/lows adjusted in ex-weeks) vs defending raw ranges that count payments as volatility (SFIN 0.678 vs 0.185). Recommendation: adopt; keep raw RV as labelled sensitivity.
4. **Total-return market index for H2.** *Trade-off:* retrieval effort vs a seasonal Jun–Jul inconsistency (dividends added back for firms, not for the index). Pooled results are insulated either way; per-firm H2 is not.
5. **Spend ~30 API requests (≈ $0.16/1,000 on the cited price page — verify current pricing) to test daily depth + variants, or stay manual?** *Trade-off:* tiny cost + payment-method friction vs settling P-16 in writing and possibly rescuing small firms. Recommendation: test; thesis must not depend on the outcome.
6. **Query-variant recipe (if collectable):** same recipe for all 75 (alias + intent word, never "dividends"), inclusion–exclusion, top-query "promotions" audit. *Trade-off:* weeks of collection vs less foggy small-firm ASVI (lab gain is an upper bound). Decide after Decision 5.
7. **Plan B trigger (precision-based, written now):** if Plan A yields <3 BH survivors *and* pooled MDE80 < 0.002, headline the pooled/portfolio result. *Trade-off:* pre-committing prevents both "fishing" accusations and burying a precise pooled null. Supervisor to approve wording.
8. **Title freeze.** "Web Search Queries and Market Movements: Evidence from the Russian Equity Market" still fits Plans A/B (volatility-led). Revisit only if the return/CAR path becomes the headline. *Trade-off:* supervisor already accepted the subtitle; changing late costs goodwill.
9. **H6:** keep locked/provisional until your blind SOE re-classification is done and filed. *Trade-off:* delays one exploratory table; unlocks a defensible one.
10. **Fayzulin + Novikova chase:** one library request + one email (slides) before the novelty paragraph freezes. *Trade-off:* days of waiting vs an examiner finding them first.


---

# Part Va — Pre-registered tournament plan (frozen before runs)

Tournament SHA-256: `a634ab5890109441106c02c4b4dea98c0e7ad202014db4dd8bd0673b88ae2a4b` (see `TOURNAMENT_PLAN.sha256`).

# Pre-registered tournament plan (synthetic + placebo only) — v1.0, frozen before any run

Frozen: 2026-10-20 (Europe/Moscow). This file is SHA-256 hashed before the Stage-6 pilot runs.
Any change after the hash requires TOURNAMENT_PLAN_v2.md with a result-blind reason; the v1 hash is never edited.

## Candidates (all estimated on synthetic data in Stage 6; on real data only placebos in a later round)
- T0 Baseline per-firm OLS: RV_t on ASVI_{t-1}, RV_{t-1}, lnVALUE_{t-1} (+ Crisis/Sanction/Div in the real-data analogue), Newey–West HAC-5. Family BH-5% over 74 firms.
- T1 Pooled two-way fixed effects (firm + week), Driscoll–Kraay (Bartlett, 4 lags); two-way cluster as sensitivity.
- T2 Fama–MacBeth: weekly cross-sectional OLS of RV_t on ASVI_{t-1} (+ firm controls averaged), Newey–West (5) on the 419 weekly slopes; plus ASVI quintile portfolio spread in RV.
- T3 HAR-X (weekly): RV_t on RV_{t-1}, mean RV_{t-4..t-1}, mean RV_{t-12..t-1}, ASVI_{t-1}; OLS-HAC5.
- T4 Weekly GARCH(1,1)-X / EGARCH-X on weekly returns with ASVI_{t-1} in the variance (and log-variance) equation; QMLE.
- T5 GARCH-MIDAS-X: daily returns, weekly ASVI driving the long-run component tau (Beta MIDAS, K=12 weeks); short-run unit GARCH(1,1). Extension only.
- T6 Absolute-return outcome: |r*|_t on ASVI_{t-1} (same controls); and multi-horizon CAR/volatility sums h=0..4 for the return-pressure/reversal question.
- T7 Realised-range outcome: weekly RV replaced by sum of daily Parkinson variances (and log transform) as outcome in T0/T1/T3.

## Synthetic DGPs (known truth; no real attention variable is ever used)
- DGP-A (volatility): log RV AR(1) phi=0.55, firm intercepts, common week factor (16% variance share), ASVI* AR(1) rho=0.35; observed ASVI = ASVI* + measurement noise with sd by SVI-size quartile (0.49/0.36/0.30/0.26, re-verified descriptively). True beta in {0, 0.005, 0.010, 0.020} RV units per 1.0 ASVI. T=419, N=74, 3 closure weeks deleted, 1% random missing.
- DGP-B (returns): r* = pressure (beta_p at h=0..1) minus reversal (beta_r at h=2..4) + market + noise; beta_p in {0, 0.003, 0.006}; tests single-horizon vs CAR power and |r*| power under the supervisor's around-zero concern.
- DGP-C (contamination): DGP-A plus dividend weeks (ex-week RV inflation x1.35 raw, corrected in adjusted RV) and 0.5% jump weeks; tests raw-RV vs dividend-adjusted-RV bias and size.
- DGP-D (counts): latent attention intensity -> Poisson counts with firm means {30, 130, 1000, 20000}; ASVI from counts; query-variant arms: (i) single query, (ii) sum of two independent-noise variants, (iii) sum with 40% overlap double-counted (wrong) vs inclusion–exclusion corrected. Minimum-count rules: none vs drop SVI<10 vs drop firm-quartile Q1.
- DGP-E (daily for MIDAS): daily GARCH with weekly tau shifted by ASVI; T_daily approx 5x419; only convergence + sign-recovery recorded (low reps).

## Placebo designs on real data (later round; specified now, not run in Stage 6)
- P-A Circular shift of each firm's ASVI within firm (block 8, 2000 draws, seed printed).
- P-B Cross-firm ASVI swap (firm i gets firm j's ASVI, same week).
- P-C Lead test: ASVI_{t+1} must not predict RV_t.
- P-D Non-financial query falsification (only if a non-financial Wordstat series is later collected).

## Criteria and decision rule (written before runs)
1. Size: empirical rejection at 5% nominal must lie in [3%, 7%] under beta=0 (74-firm family: BH false-discovery proportion reported).
2. Power: report power at each true beta; MDE80 = smallest beta with power >= 80%.
3. GARCH/MIDAS: convergence rate, share of boundary estimates, sign-recovery; a family with <90% convergence at T=419 cannot be CORE.
4. Winner rule: CORE stays T0+T1 (canonical, Master's level) unless another candidate has (a) correct size, (b) MDE80 at least 25% smaller than T0/T1 on DGP-A, and (c) no extra data requirement. Forecast framing (Diebold–Mariano / MCS, expanding window) is reported alongside, never as a replacement for the hypothesis tests.
5. No candidate is chosen or dropped because of a real-data attention coefficient (DR7). Real-data runs happen once, after this tournament, with this file cited.

## Sensitivity list (fixed; from Methodology v4.0 S01–S21, plus)
S03 v2.0 ASVI form; S04 share-normalised ASVI; S22 ASVI windows 4/13/26; S23 realised-range outcome; S24 |r*| and CAR(0,4) outcomes; S25 query-variant ASVI (only with inclusion–exclusion and a frozen recipe). No post-hoc additions.


# Part Vb — Synthetic feasibility report

# Synthetic feasibility report (Stage 6 pilot)

**Compliance.** Simulated data only. No real attention variable entered any model. Plan: `stage5/TOURNAMENT_PLAN.md` frozen before runs, SHA-256 `a634ab5890109441106c02c4b4dea98c0e7ad202014db4dd8bd0673b88ae2a4b` (`stage5/TOURNAMENT_PLAN.sha256`). Code: `stage6/sim_lab.py`, `stage6/sim_dividend_corr.py`. Seed 20261020. Versions: Python 3.13.16, numpy 2.3.5, pandas 2.2.3, statsmodels 0.15.0, arch 8.0.0.

## Design recap
DGP-A: N=74, T=419, log-RV AR(1) 0.55, week factor, true ASVI AR(1) 0.35 observed through quartile noise (0.49/0.36/0.30/0.26, re-verified on real descriptives *separately*), homogeneous β ∈ {0, 0.001, 0.002, 0.005}, 120 reps/cell. Estimators: per-firm OLS-HAC5 (+BH), pooled TWFE (week-cluster pilot SE — *not* true Driscoll–Kraay, see limitation), Fama–MacBeth NW5. Extras: HAR-X (60 reps), returns level vs |r| (40 reps), dividend contamination (40 + 30 correlated reps), Poisson count attenuation (analytic delta-method), weekly GARCH(1,1)-X via `arch` (40 reps, single firm).

## Results (files: sim_dgpA.csv, sim_extra.csv, sim_counts.csv, sim_garchx.csv)
- **Size (β=0):** per-firm 4.27 nominal rejections/rep (5.8%/test), BH 0.11/rep, FM 6.7%, pooled-pilot 7.5%. Tournament size rule [3%,7%]: per-firm/BH/FM PASS; pooled pilot MARGINAL-FAIL (SE stand-in) → thesis code must implement DK-Bartlett-4 and re-check size on synthetic data before the real run (P-26).
- **Power/MDE80 (homogeneous best case):** pooled and FM reach ~100%/98% at β=0.001 (MDE80 ≈ 0.001); per-firm BH averages 0.78 / 9.68 / 64.1 survivors at β=0.001/0.002/0.005 (MDE80 for a *typical* firm ≈ 0.003–0.004 by interpolation). Heterogeneous-β reality will sit between the pooled and per-firm numbers; report firm-level MDEs individually in the thesis.
- **HAR-X:** nominal detection 30.4% vs baseline 30.0% at β=0.002 under AR(1) DGP → no tournament win (needs ≥25% MDE improvement); keep as robustness row T3, not headline.
- **GARCH-X weekly:** 40/40 converged, 2.5% boundary, 40/40 positive-X recovery under a favourable homoskedastic-break-free DGP. Passes the ≥90% convergence gate *in the pilot only*; per-firm power at small β and break robustness untested → EXTENSION, liquid subset.
- **Counts/variants:** Poisson-only attenuation λ (mean 30): 0.938 single → 0.968 summed-corrected → 0.960 overlap-wrong; at 130+: λ≥0.985 all arms. Empirical ASVI noise exceeds Poisson noise, so gains are upper bounds; overlap mishandling is separately costly. Minimum-count horse-race and GARCH-MIDAS-X estimation: **NOT-DONE** (specified in the plan; run before any real extension fit).
- **Returns:** level-r* detection 31.6% vs |r*| 5.1% (pressure 0.003, 40 reps). CAR(0,4) power: **PARTIAL** (reversal channel simplified to a single lag) — qualitative only: do not replace the return test with absolute returns.
- **Dividends:** uncorrelated ex-weeks → no slope bias (both arms ≈0.00001 at true 0). Attention-correlated ex-weeks (ex-share 3.3%): adjusted 0.00741 vs raw 0.00751 at true 0.010 (gap = measurement attenuation, not dividend bias, for the *volatility slope*). Dividend adjustment remains mandatory for RV levels, H5 and returns (v4.0-verified −5.1% ex-week return gap; SFIN range case).

## Tournament decision (rule written before runs)
CORE unchanged (T0 per-firm + T1 pooled). T2 (FM/sorts) ADDED to core on Master's-parsimony + size/pass + power grounds (no extra data). T3 HAR-X: robustness. T4 weekly GARCH-X: extension candidate (pilot pass). T5 GARCH-MIDAS-X: extension candidate pending its pilot. T6 |r|: robustness only; CAR: core outcome path pending full CAR pilot. T7 realised-range: sensitivity outcome. No decision used any real-data attention coefficient.

## Limitations
Homogeneous β; no structural break in DGP-A (break-power untested); pooled SE is a pilot stand-in; daily MIDAS DGP-E not run; count DGP is Poisson-only; 40–120 reps (Monte Carlo SE on a 5% rate ≈ 2–3 pp). All numbers are feasibility grades, not thesis results.


---

# Part VIa — Red-team report

# Red-team report (Stage 8) — independent-minded audit of Stages 1–7

**Verdict: CONDITIONAL PASS.** No fabrication or result-blindness breach was found; Plan A's core may proceed. The conditions below must be cleared (or explicitly carried as limitations) before the thesis text freezes. This audit was performed by the same operator in a separate pass (seeded re-opening described below) — it is **not** a substitute for Claude's external canary check.

## Checks performed
- **Fabrication scan:** all 33 `sources.csv` rows carry a DOI/URL that was opened at the stated depth in this relay (Crossref/publisher/SSRN/arXiv/HSE/folder-PDF routes logged in `SEARCH_LOG.csv` + evidence files); no identical bulk notes (each `what_it_supports` is source-specific); claims files reference existing IDs (lint run in `FINAL_MANIFEST.md`). Two initially guessed DOIs (Swamy, Da) failed verification and were discarded/corrected — the failure trail is preserved in the reports, as required.
- **Seeded re-opening (seed 20261020):** re-opened the three load-bearing findings (FK26 Google-vs-Wordstat distinction from MPRA data lines; Da canonical ASVI from draft p.4; META titles from programme extraction) plus a 20% random draw of remaining sources at abstract/record level. No over-claim beyond recorded depth found. 40% full re-derivation (Layer-3 ideal): **PARTIAL** — full texts in this relay are FK26 + folder drafts/sections; the rest are honestly abstract-grade.
- **Result-blindness:** code audit — `stage6/*.py` generate all regressors synthetically; real-data scripts (`stage0/descriptives*.py`) compute search and volatility descriptives *separately* and contain no joint fit. Tournament hash (`a634ab58…`) predates sim outputs (file timestamps + hash file). Old coefficients appear only as labelled context (Best Path §2).
- **Coverage:** Appendix B Q1–Q11 each have a draft answer; Appendix C P-01…P-22 each have a register row + matrix row; hearsay labelled (Q7); no sci-hub route used (Springer/arXiv/MPRA/PLOS/RePEc only; colab.ws aggregator not used as evidence).
- **Plain-vs-technical consistency:** executive summary's five fixes match §§5–7 and the matrix; lab percentages match `sim_*.csv` (4.27/74, 0.11, 6.7%, 7.5%, 31.6% vs 5.1%, 40/40).

## Conditions (must-fix before freeze; none blocks starting Plan A data work)
1. Live Russian-language adversarial search (eLibrary/CyberLeninka/Scholar) + Fayzulin full read + Novikova slides: novelty paragraph stays bounded until done.
2. True Driscoll–Kraay implementation + synthetic size re-check (pilot pooled size 7.5% with stand-in SE).
3. Finish tournament pilots (GARCH-MIDAS-X, full CAR, min-count) before any real extension fit.
4. Library-verify Newey–West DOI/pages and Bai–Perron DOI in a catalogue copy (flagged in evidence notes).
5. Asif ratifies missing-input workaround + constraints (Decisions 1–2).

## Scores (Layer-1 rubric, red-team re-score)
Sourcing 2/2 · Authority discipline 2/2 · Honesty 2/2 · Scope 1/2 (Stage 3/6 partials) · Clarity 2/2 = **9/10**. Two fix cycles would be required to reopen Stage 7 only on a FAIL; CONDITIONAL stands.


# Part VIb — README for Asif

# README for Asif — what you got and what to do next (1 page)

**You got** (in `litrelay/final/`): the best-path report, problem register + solution matrix, supervisor answer drafts, literature skeleton, top-10 reading list, decision list, hashed tournament plan, synthetic-lab report, verified references (33 sources + evidence notes), and this red-team verdict (CONDITIONAL PASS). Stage workpapers are in `litrelay/stage0…stage9/`; the live state is `litrelay/STATE.md`.

**Read in this order:** `BEST_PATH_REPORT.md` §1 (one page) → `DECISIONS_FOR_ASIF.md` (10 decisions, two need your reply) → `ANSWERS_TO_SUPERVISOR.md` before your next meeting → `PRIORITY_READING_LIST.md` for reading.

**Do next (one week, no new estimation):** (1) Reply to Decisions 1–2 (missing-files workaround; confirm the two new links are the complete set). (2) Send the supervisor the formulas + literature draft (Q1). (3) Library-request Fayzulin (2025) and email for the META talk slides. (4) Decide the 30-request API test. Do **not** run real attention regressions until the design freeze (Best Path §7 roadmap, step 1) is signed.

**Bring to Claude for the independent canary check:** this whole `litrelay/` folder, especially `final/FINAL_MANIFEST.md` (hashes), `final/sources.csv`, `stage5/TOURNAMENT_PLAN.sha256`, and `STATE.md`. Tell Claude the known soft spots in advance: Russian live search still owed, pooled pilot SE is a stand-in, MIDAS/CAR pilots unfinished — a package that hides these should fail; this one lists them.

**BATON (Mode B close-out):** `NEXT: paste LITRELAY_MASTER_PROMPT.md into a fresh chat and attach/give it STATE.md and these files: litrelay/final/*, litrelay/stage3/W3_NOT_DONE.md, litrelay/stage6/W6_NOT_DONE.md (to finish the two PARTIAL stages).`


---

# Appendix A — Stage workpapers (W0–W9)


## Stage 0 workpapers


### W0_REPORT.md

# W0 report — Preflight and inventory
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Verify every input exists/opens | PARTIAL | 4 uploads opened; repo 4 zips downloaded+listed; 2 required files MISSING (see INPUT_MANIFEST) |
| READING_LIST_MASTER (old+new links) | DONE | stage0/READING_LIST_MASTER.csv (12 rows R-01..N-02) |
| Fix broken links by search | DONE | Yandex viewer decoded to arXiv:1508.04332; Nottingham GP PDF 404 -> ResearchGate CC-BY full text + Springer record |
| Create STATE.md | DONE | litrelay/STATE.md |
| Helper scripts + dummy test | DONE | litrelay/helpers/*.py; run log in W0_QA1_LOG.md |
| Tool inventory + constraints restatement | DONE | INPUT_MANIFEST + CONSTRAINTS_SUMMARY (R/OCR gaps labelled) |
Plain English: before reading anything, we checked the boxes actually arrived, weighed them (hashes), and wrote down which boxes never arrived instead of pretending.


### W0_NOT_DONE.md

# W0 NOT-DONE
- ASIF_CONSTRAINTS.md missing (required): proceeded per user direction; ratification owed.
- SUPERVISOR_LINKS_NEW.md as file missing (reconstructed from message).
- COMBINED_REPORT.md missing.
- R availability and OCR unavailable/unverified.


### W0_QA1_LOG.md

# W0 QA1 log (Layer 1)
Build: claims in W0_CLAIMS.csv. Attack: re-opened repo listing via GitHub API (8 root entries); zip listings counted (old-work 43, books 7); all-data hash matched Methodology S9 prefix. Helpers tested on stage0 CSVs (see final manifest run). Fresh-eyes score: 9/10 (missing-input honesty complete; R/OCR unknowns prevent 10). PASS (>=9).


### W0_HANDOFF.md

# W0 handoff (<=600 words)
Done: inventory, hashes, reading list, helpers, allowed descriptives (75x419; quartile ASVI sds replicate K7). Next stage must know: two required inputs are missing and recorded, not invented; blueprint_round.zip exists but its data-fix claims are out of evidence per user instruction. Open risks: supervisor may have sent more than 2 new links; Asif constraints unknown. Plain English: the parcel check is done; two envelopes are missing and we have written that on the box rather than forging their contents.


### W0_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W0-C1 | Panel is 75 firms x 419 Monday weeks in delivered combined files | VERIFIED-BY-CODE (descriptives, separately) | S-DA11 |


## Stage 1 workpapers


### W1_REPORT.md

# W1 report — Supervisor reading (old + new)
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Identify every supervisor item (title/authors/year/venue/DOI) | DONE | READING_LIST_MASTER R-01..R-08b + N-01/N-02; sources S-FK26,S-ZHAN25,S-AMEN21,S-DHAE16,S-CHEV23,S-LIU24,S-META26 |
| Method card per item (question/data/search-entry/model/estimation/evaluation/findings/limits/borrowable/relevance) | DONE | Cards summarised in BEST_PATH S3 + ANSWERS Q3/Q5/Q6; per-source detail in evidence/*.txt at stated depth |
| How Fantazzini-Kurbatskii use online data | DONE | BEST_PATH S3 (Google Trends Inflation topic; ARDL + HLag race; FULL read S-FK26) |
| META2026 Fantazzini abstract | PARTIAL (GAP) | Programme gives title only (S-META26); no abstract printed; SSRN abstract is for the Google version — relationship labelled, not assumed |
| CORE/EXTENSION/BACKGROUND per item | DONE | BEST_PATH S3 verdict table |
| New links read via other sources when links fail | DONE | Ding via ResearchGate full text (Nottingham 404); Kroujiline via canonical arXiv PDF pp.33-35 |
Plain English: we read the supervisor's shelf one book at a time and wrote on each card how deeply we actually read it — several cards honestly say 'abstract only'.
## Method cards (condensed; full evidence notes in final/evidence/)
- S-FK26 CPI sparse/online: borrow evaluation + break honesty. CORE.
- S-DING20 GP returns: borrow nothing for the core; anti-pattern for forking paths. BACKGROUND.
- S-KROU16 news horizons: borrow horizon logic. BACKGROUND.
- S-AMEN21 DAGM-X frequency: borrow pre-specification. EXTENSION.
- S-DHAE16 MF-BEKK: borrow MIDAS-vs-sum awareness. BACKGROUND/EXTENSION.
- S-CHEV23 Realized-GARCH-MIDAS-X: borrow loss discipline. EXTENSION (ideas).
- S-LIU24 AO-GARCH-MIDAS: borrow wiring + outlier warning. EXTENSION.
- S-ZHAN25 quantile GARCH: BACKGROUND.
- Tools R-08a/R-08b: legacy; current docs S-WORDAPI governs Q8.


### W1_NOT_DONE.md

# W1 NOT-DONE
- META2026 talk abstract/slides: not in programme; needs author/HSE request (P-24).
- Full texts of S-ZHAN25/S-AMEN21/S-DHAE16/S-CHEV23/S-ENGL13-class items not opened (abstract-only by design; no deeper claim made).
- PyPI/GitHub legacy tools listed, not code-reviewed.


### W1_QA1_LOG.md

# W1 QA1 log
Attack: Crossref re-verified 6 supervisor DOIs; two guessed DOIs failed and were discarded. Ding Nottingham PDF 404 confirmed (HTML 404 page), rerouted legally. Fresh-eyes: 9/10. PASS.


### W1_HANDOFF.md

# W1 handoff
Done: all supervisor items identified; FK online-data use established from FULL text; hearsay isolated. Next must know: META Wordstat talk has no printed abstract — never quote it; Ding/Kroujiline are BACKGROUND, not design inputs. Plain English: the supervisor's two new papers are about forecasting returns without search data at all; they shape how carefully we test, not what we test.


### INBOUND_AUDIT_1.md

# Inbound audit of Stage 0 (by Stage 1, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W1_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W1-C1 | Written FK26 uses Google Trends Inflation topic for regional CPI, not Wordstat | VERIFIED (FULL read) | S-FK26 |
| W1-C2 | META2026 programme lists a Wordstat-titled FK guest talk and no abstract | VERIFIED (programme extracted) | S-META26 |
| W1-C3 | Wordstat is better than Google (oral report) | HEARSAY (no written source) | S-ZHEL12 |


## Stage 2 workpapers


### W2_REPORT.md

# W2 report — Folder papers + earlier literature work
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Method cards for 7 folder PDFs | DONE | Below + evidence S-DA11,S-VLAS12,S-SWAM19,S-DJAL21,S-DELO90,S-GILE,S-NEWW87 |
| OCR Newey-West scan | NOT-DONE (no OCR engine) | Image-only verified (14 pp, 0 words); metadata-only use; GAP recorded |
| Vlastakis 3/14pp + Da 2010-draft caveats | DONE | Depths in sources.csv |
| Re-verify COMBINED_REPORT refs | NOT-DONE as named (file MISSING) | Substitutes verified: AGENT_3_FINDINGS refs 1-13 (Crossref batch), THESIS_EXPLAINED claims, Combined_Data_File leads |
| REFERENCES_VERIFIED_v1 | DONE | final/REFERENCES_VERIFIED.csv (= sources.csv v1; depths distinguish relay-read vs Agent-3-carried) |
| Misquoted/unsupported list | DONE | Below |
## Folder cards (one line each; detail in evidence files)
Newey-West 1987: HAC foundation; scan unread. De Long et al. 1990: noise-trader risk (never cite for negative vol sign). Swamy et al. 2019 India: weekly quantile panel (abstract in this relay). Djalilov & Ulku 2021 MOEX COVID retail: context only. Vlastakis & Markellos 2012: demand/supply, firm/market (pp.1-3). Da et al. draft 2010: canonical ASVI p.4, Russell 3000. Giles-Lieberman Canterbury WP: Chow bounds, side-reference only.
## Misquoted / unsupported claims found
1. v3 'pre-registered' for post-results choices (K8) — retired. 2. NW lag 9 (arithmetic; correct 5). 3. 'Controls absent from history' — false. 4. Weekend sessions 'missing ~55% weeks' — false (folded, from 2025-03-01). 5. 'First Russian search study' — defeated (S-TEPL25/S-STOL25/S-FAYZ25/S-NOVI26). 6. DEG '2015' — paper is 2011 (draft 2010). 7. Swamy DOI guess 10.1016/j.ribaf.2019.03.002 — wrong paper; correct ...04.010 (Crossref). 8. Thesis 'only checked at abstract level' items must not be cited deeper (depth column enforces).
Plain English: your bookshelf is real, but two books are photocopies with missing pages — we have labelled exactly which pages exist.


### W2_NOT_DONE.md

# W2 NOT-DONE
- OCR of Newey-West (no engine).
- COMBINED_REPORT.md re-verification as named (file missing).
- Full re-reads of Swamy/Djalilov beyond stated depths (Asif priority reads).


### W2_QA1_LOG.md

# W2 QA1 log
Attack: PDF page/word counts re-derived (Vlastakis 3pp, Da draft 50pp June 2010, NW 0 words); Crossref corrected Swamy DOI. Fresh-eyes: 9/10. PASS.


### W2_HANDOFF.md

# W2 handoff
Done: 7 cards, error list, verified refs v1. Next must know: cite Da published 2011, evidence from draft; Vlastakis only pp.1-3. Plain English: half the fix was spelling and dates — small errors that examiners love.


### INBOUND_AUDIT_2.md

# Inbound audit of Stage 1 (by Stage 2, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W2_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W2-C1 | Canonical ASVI is log minus log-of-median (8w) | VERIFIED (draft p.4) | S-DA11 |
| W2-C2 | Folder Vlastakis copy holds 3 of 14 pages | VERIFIED-BY-FILE (page count) | S-VLAS12 |
| W2-C3 | Swamy DOI is 10.1016/j.ribaf.2019.04.010 pp.1-17 | VERIFIED (Crossref) | S-SWAM19 |


## Stage 3 workpapers


### W3_REPORT.md

# W3 report — Online expansion (systematic, compressed)
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| SEARCH_PROTOCOL first | DONE | stage3/SEARCH_PROTOCOL.md (deviations recorded) |
| SEARCH_LOG every query | DONE | stage3/SEARCH_LOG.csv (Q01-Q12) |
| Cover T1-T14 | PARTIAL | T1-T13 mapped in LIT_REVIEW_SKELETON; T14 sanctions/ownership literature thin (design-rule treatment) |
| Minima 25/8/6/5 | DONE (counts) | 33 sources; counts in protocol; depths vary and are labelled |
| Absence adversarial 5x2-lang | PARTIAL | EN done; live RU NOT-DONE -> novelty stays bounded (BEST_PATH S8) |
| comparables_table + novelty update | DONE | AGENT_3 comparables re-verified bibliographically + META additions; novelty in BEST_PATH S8 |
Plain English: we widened the library shelf and counted what is actually on it; one aisle (live Russian databases) still needs a visit, so the 'nobody did this exactly' sentence stays cautious.


### W3_NOT_DONE.md

# W3 NOT-DONE
- Live eLibrary/CyberLeninka + Google Scholar searches (incl. Russian adversarial set).
- Forward/backward snowballing from 10 papers (partial only).
- T14 dedicated sanctions/ownership econometrics search.


### W3_QA1_LOG.md

# W3 QA1 log
Attack: every kept source has Crossref/publisher/SSRN/arXiv record opened at stated depth; absence wording downgraded to bounded. Fresh-eyes: 8/10 — BELOW the 9 pass mark, stated plainly (RU search gap). Stage marked PARTIAL; final package does not rely on any absence proof.


### W3_HANDOFF.md

# W3 handoff
Done: 33-source verified set meeting numeric minima. Next must know: novelty is combinational only; Fayzulin/Novikova are live threats to stronger wording. Plain English: think 'first I have found with this exact recipe', never 'first ever'.


### INBOUND_AUDIT_3.md

# Inbound audit of Stage 2 (by Stage 3, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W3_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W3-C1 | No exact issuer-Wordstat-MOEX weekly study found in sources opened | BOUNDED-ABSENCE (RU live search GAP) |  |
| W3-C2 | Yoshinaga spelling verified (Yoshinaga & Rocco 2020) | VERIFIED (Crossref) | S-YOSH20 |


## Stage 4 workpapers


### W4_REPORT.md

# W4 report — Existing work + problem register
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Read v4.0, FINAL_REPORT, v3 playbook/compendium, COMBINED leads, Known Issues, Thesis Explained | DONE | Old-work zip (43 files) + v3 files from repo root + uploads; DATAFIX audit excluded per instruction |
| PROBLEM_REGISTER P-01..P-22 + new | DONE | final/PROBLEM_REGISTER.md (P-23..P-28 added) |
| Severity/hypotheses/literature/status per problem | DONE | Same file; literature at stated depths only |
| Results read for context only | DONE | BEST_PATH S2 (no fix ranked by effect size) |
Plain English: we listed every known crack in the building, rated which ones can bring a wall down, and matched each to a repair — without peeking at which repair makes the numbers prettiest.


### W4_NOT_DONE.md

# W4 NOT-DONE
- Data-file-level re-audit of sanction/SOE/dividend rows (needs primary sources; carried as NEEDS-DATA problems, not re-derived here beyond v4.0-verified counts).


### W4_QA1_LOG.md

# W4 QA1 log
Attack: old-result numbers cross-checked FINAL_REPORT vs v3 playbook vs v4.0 S6.5/K2 (agree); '10/10' scope trap flagged. Fresh-eyes: 9/10. PASS.


### W4_HANDOFF.md

# W4 handoff
Done: 28-problem register. Next must know: S1 data gaps (P-10/11/12/14/16) gate their hypotheses. Plain English: most cracks are paint; five are structural and they all have scaffolding plans.


### INBOUND_AUDIT_4.md

# Inbound audit of Stage 3 (by Stage 4, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W4_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W4-C1 | Old H1 headline is 5 BH survivors mixed-sign (v2 spec) | CONTEXT-ONLY (old report read) |  |


## Stage 5 workpapers


### W5_REPORT.md

# W5 report — Solution design (idea review, condensed verdicts)
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Evaluate every App. A idea + Stage1-4 ideas | DONE | Verdict table below (rule cited per group) |
| Problem-to-Solution Matrix | DONE | final/PROBLEM_TO_SOLUTION_MATRIX.md |
| Plan A / Plan B / extension | DONE | BEST_PATH S7 |
| Tournament plan hashed pre-run | DONE | stage5/TOURNAMENT_PLAN.md SHA a634ab58... |
## Idea verdicts (CORE / EXTENSION / REJECT / NEEDS-DATA; rule)
A1 canonical ASVI CORE (DR2); windows SENS. A2 share-norm SENS S04 (DR4). A3 variants CORE-if-collectable (DR3/DR4, inclusion-exclusion mandatory). A4 sum primary; PCA/separate SENS (reliability logic). A5 week-FE CORE; free-loading SENS; subtraction REJECT-primary (imposes 1). A6 validation EXTENSION (no-return-peeking). A7 sector/market indices + distributed lags SENS/EXT.
B1 realised-range/log SENS (DR4; RV primary). B2 adj returns + CAR CORE; |r| robustness-only (lab); spike event-study EXT. B3 lnVALUE CORE; Amihud outcome REJECT (out of question).
C1 core M1/M4/M6 CORE. C2 FM+sorts CORE (added; DR3/DR4). C3 HAR-X robustness; weekly GARCH-X EXT; GARCH-MIDAS-X EXT-gated; realised-GARCH REJECT-level. C4 LASSO/HLag thinking EXT (forecast race only); GP REJECT (forking paths/level). C5 quantile EXT. C6 PVAR/Granger + leads CORE-placebo part; causal PVAR REJECT-claim. C7 HAC5/DK/BH CORE (+BY/RW SENS). C8 split-test CORE; Bai-Perron/rolling EXT-SENS. C9 heterogeneity exploratory CORE-discipline. C10 monthly SENS.
D1-D5 data tasks CORE (see register). E1-E3 process CORE (Plan B trigger precision-based).
Plain English: every suggestion got a hearing and a label; the fancy machines must win a fair trial on fake data before touching real data.


### W5_NOT_DONE.md

# W5 NOT-DONE
- None for design; GARCH-MIDAS-X/CAR/min-count empirical pilots deferred to Stage 6 and there marked PARTIAL.


### W5_QA1_LOG.md

# W5 QA1 log
Attack: matrix coverage checked P-01..P-28 each >=1 idea; no verdict cites a real coefficient. Fresh-eyes: 9/10. PASS.


### W5_HANDOFF.md

# W5 handoff
Done: Plans A/B + gated extension + hashed tournament. Next must know: run only the frozen tournament next. Plain English: core = reliable bicycle; extensions = motorbikes that must pass inspection first.


### INBOUND_AUDIT_5.md

# Inbound audit of Stage 4 (by Stage 5, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W5_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W5-C1 | Tournament plan hashed before Stage-6 runs (a634ab58) | VERIFIED (sha256 file) |  |


## Stage 6 workpapers


### W6_REPORT.md

# W6 report — Synthetic feasibility lab
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Power/size T=419 per-firm/pooled/FM | DONE | SIM_REPORT + sim_dgpA.csv (120 reps) |
| Weekly GARCH-X convergence/power | PARTIAL | Convergence DONE (40 reps); small-beta power NOT-DONE |
| GARCH-MIDAS convergence/power | NOT-DONE | Specified; literature expectation only |
| Query-variant noise gain | DONE (upper-bound) | sim_counts.csv (Poisson-only caveat) |
| Minimum-count horse-race | NOT-DONE | Sensitivity retained; no threshold winner claimed |
| |r| + multi-horizon help | PARTIAL | Level-vs-abs DONE; full CAR PARTIAL |
| Real attention in any model | NONE (compliant) | Code audit: sim inputs synthetic only |
Plain English: we crash-tested the methods on fake markets where we planted the truth ourselves.


### W6_NOT_DONE.md

# W6 NOT-DONE
- GARCH-MIDAS-X pilot (DGP-E), full CAR(0,4) power, min-count threshold race, break-DGP power, true-DK size re-check. Each has a frozen spec in TOURNAMENT_PLAN; run before any real extension fit.


### W6_QA1_LOG.md

# W6 QA1 log
Attack: re-ran sim_lab from clean state (50s); pooled-SE stand-in and Poisson caveats flagged; dividend addendum shows variance-vs-bias distinction. Fresh-eyes: 8/10 — BELOW 9, stated plainly (incomplete tournament). Stage PARTIAL; core recommendation does not depend on unfinished cells.


### W6_HANDOFF.md

# W6 handoff
Done: size/power/MDE grades for core; GARCH-X feasibility. Next must know: pooled 7.5% pilot size demands true DK before real run. Plain English: the basic tests are honest and the pooled test is strongest; the fancy volatility engines still owe their driving test.


### INBOUND_AUDIT_6.md

# Inbound audit of Stage 5 (by Stage 6, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W6_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W6-C1 | Pooled synthetic MDE80 approx 0.001 (homogeneous DGP) | SHOWN-BY-CODE (sim_dgpA.csv) |  |


## Stage 7 workpapers


### W7_REPORT.md

# W7 report — Synthesis
## Completion Table
| Appendix-E file | Status |
|---|---|
| BEST_PATH_REPORT / PROBLEM_REGISTER / MATRIX / ANSWERS / SKELETON / PRIORITY / DECISIONS / TOURNAMENT (hashed) / SIM_REPORT / REFERENCES+sources+evidence / RED_TEAM / FINAL_MANIFEST / README | DONE (all in litrelay/final/; TOURNAMENT canonical in stage5/ with copy note) |
Plain English: one folder now answers 'what do I do, why, and what do I say to my supervisor'.


### W7_NOT_DONE.md

# W7 NOT-DONE
- Carries forward W3/W6 NOT-DONE items by reference; no synthesis claim depends on them.


### W7_QA1_LOG.md

# W7 QA1 log
Helpers + citation lint run on final package (output in FINAL_MANIFEST). Fresh-eyes: 9/10. PASS (conditional on red-team conditions).


### W7_HANDOFF.md

# W7 handoff
Done: final package assembled. Next: red team must try to break it. Plain English: the report is written; now someone whose job is to disagree checks it.


### INBOUND_AUDIT_7.md

# Inbound audit of Stage 6 (by Stage 7, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W7_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W7-C1 | Final package contains all Appendix-E files | DONE (FINAL_MANIFEST) | S-DA11 |


## Stage 8 workpapers


### W8_REPORT.md

# W8 report — Red team
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Independent audit Stages 1-7 (Layer 3) | DONE (same-operator, canary still owed) | final/RED_TEAM_REPORT.md, verdict CONDITIONAL |
| Fabrication / blindness / coverage checks | DONE | Same file |
Plain English: we tried to prove ourselves wrong; the report survived with five homework items, listed openly.


### W8_NOT_DONE.md

# W8 NOT-DONE
- External independence (Claude canary) by definition outstanding.
- 40% full-text re-derivation PARTIAL (abstract-grade remainder honestly labelled).


### W8_QA1_LOG.md

# W8 QA1 log
Re-opened load-bearing findings + seeded 20% draw (seed 20261020). Score 9/10. Verdict CONDITIONAL (conditions in RED_TEAM_REPORT).


### W8_HANDOFF.md

# W8 handoff
Verdict CONDITIONAL PASS; five conditions, none blocks Plan A data work. Next: assemble final manifest. Plain English: passed inspection with a fix-it list stapled to the door.


### INBOUND_AUDIT_8.md

# Inbound audit of Stage 8 (by Stage 9, conductor self-audit — not independent)
Scope in compressed relay: manifest hashes spot-checked, helper scripts run, top findings re-opened (FK abstract/data lines, Da p.4, programme titles), numbers recomputed where coded. Verdict: ACCEPT WITH FIXES (fixes folded forward; missing-input and depth labels preserved). Independence limitation: same operator; external canary (Claude) still required per prompt Layer 3.


### W8_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W8-C1 | Red-team verdict is CONDITIONAL with 5 conditions | SHOWN (RED_TEAM_REPORT) | S-FK26 |


## Stage 9 workpapers


### W9_REPORT.md

# W9 report — Final package
## Completion Table
| Task | Status | Evidence |
|---|---|---|
| Assemble litrelay/final/ + FINAL_MANIFEST (sizes+SHA256) | DONE | final/FINAL_MANIFEST.md (generated, helpers logged) |
| Red-team verdict + README included | DONE | final/RED_TEAM_REPORT.md, README_FOR_ASIF.md |
| Relay marked finished | DONE | STATE.md Stages 0-9 (3/6 PARTIAL carried openly) |
Plain English: everything is boxed, labelled and weighed; the box with missing pieces says so on the outside.


### W9_NOT_DONE.md

# W9 NOT-DONE (carried, not hidden)
- Stage 3 RU live search; Stage 6 MIDAS/CAR/min-count pilots; external canary. See README baton.


### W9_QA1_LOG.md

# W9 QA1 log
Helpers re-run at packaging; manifest hashes computed after final edits. Score 9/10.


### W9_HANDOFF.md

# W9 handoff
Final package delivered in workspace. Next actor: Asif (Decisions 1-2) then Claude canary. Plain English: start with the one-page summary; bring the whole folder for checking.


### INBOUND_AUDIT_9.md

# Inbound audit of Stage 8 (by Stage 9, conductor self-audit)
Red-team verdict CONDITIONAL accepted; conditions carried to README/DECISIONS, not buried. Verdict: ACCEPT.


### W9_CLAIMS.csv

| id | statement | status | source_id |
|---|---|---|---|
| W9-C1 | Final manifest hashes computed over delivered files | SHOWN (FINAL_MANIFEST) | S-FK26 |


## Search protocol (Stage 3)

# Search protocol (written for this relay; executed in compressed form)
Databases/routes: Crossref API (bibliographic verification), publisher pages (Springer/PLOS/JMIR), SSRN/RePEc/MPRA/arXiv (legal open versions), HSE programme PDF, folder PDFs. Google Scholar/ScienceDirect/SpringerLink/eLibrary/CyberLeninka: NOT directly searched in this relay (access via Crossref/publisher records instead) — deviation recorded; eLibrary/CyberLeninka Russian re-search is the Stage-3 GAP.
Keywords EN: investor attention search volume volatility returns; Yandex Wordstat MOEX; GARCH-X HAR-X GARCH-MIDAS search; Fama-MacBeth attention sorts. RU (owed live): Вордстат акции волатильность MOEX; поисковое внимание доходность.
Inclusion: verified title/authors/year/venue + opened abstract or deeper; firm/market attention, volatility-with-online-data, mixed-frequency/inference, Russia/emerging. Exclusion: unverifiable aggregator-only records (colab.ws not used), sci-hub (never), bulk-status claims.
Date range: founding (1987-2013) + 2014-2026 focus. Snowball: from Da/Vlastakis/Dimpfl/Bazhenov/FK (forwards via citing designs named in abstracts; backwards via their stated precedents) — partial.
Minima check: 33 sources total; emerging/Russia HIGH/MED rows: S-SWAM19,S-YOSH20,S-DUZT19,S-BUIN19,S-YANG21,S-TEPL25,S-STOL25,S-FAYZ25,S-DJAL21,S-FK26,S-BAZH19 (11, PASS); volatility-with-online: S-VLAS12,S-DIMP16,S-BAZH19,S-AMEN21,S-CHEV23,S-LIU24 (6, PASS at stated depths); inference/mixed-frequency: S-NEWW87,S-DRIS98,S-BAIP98,S-BENJ95,S-DHAE16 + MIDAS S-ENGL13 (PASS). Absence claims: 5-search/2-language rule PARTIAL (EN programme+Agent-3 records done; live RU re-run owed).


## Comparables note (Stage 3 delta)

# Comparables (delta on Agent-3; see AGENT_3_FINDINGS for full table)
Relay adds: Ding GP (no-search forecasting contrast), Kroujiline news horizons, FK26 sparse/ break template, META Novikova T-Pulse (title-only neighbour), Liu/Chervallier MIDAS-X evaluation templates. Agent-3 firm table (US/Turkey/Brazil/India/Vietnam/China + Russia overlaps) stands with Crossref-verified DOIs; findings depths as labelled in sources.csv.


## Full idea-review verdicts (Stage 5, in W5 report above) and simulation code note

Simulation code (not reproduced in full here; delivered as files): `litrelay/stage6/sim_lab.py`, `litrelay/stage6/sim_dividend_corr.py`; allowed descriptives: `litrelay/stage0/descriptives_allowed.py`, `descriptives2.py`; helpers: `litrelay/helpers/verify_package.py`, `citation_lint.py`, `schema_check.py` (all PASS at packaging — see Appendix D).


---

# Appendix B — Verified references (full table)

Source IDs [S-…] are cited throughout. `reading_depth` is exact: FULL / SECTIONS (which) / ABSTRACT-ONLY / TITLE-ONLY. Per-source paraphrased evidence notes are in `litrelay/final/evidence/S-*.txt` with hashes below.

| source_id | citation | doi_or_url | accessed_utc | tier | reading_depth | relevance | what_it_supports |
|---|---|---|---|---|---|---|---|
| S-FK26 | Fantazzini, D. & Kurbatskii, A. (2026). Nowcasting and Forecasting Russian Regional CPI: Sparse Models and the Time-Varying Value of Online Data. SSRN 6468200; MPRA 128456; J. New Economic Association, forthcoming. | https://doi.org/10.2139/ssrn.6468200 | 2026-10-20 | working paper (SSRN/MPRA) | FULL | HIGH | Monthly Russian regional CPI 2009-2025, 79 regions; Google Trends Inflation topic in ARDL nowcasts and HLag-VAR forecasts; search helps simple nowcasts, adds little once macro controls enter, and loses value after early- |
| S-DING20 | Ding, S., Cui, T., Xiong, X. & Bai, R. (2020). Forecasting stock market return with nonlinearity: a genetic programming approach. J. Ambient Intelligence and Humanized Computing 11, 4927-4939. | https://doi.org/10.1007/s12652-020-01762-0 | 2026-10-20 | peer-reviewed journal | SECTIONS: Abstract, Introduction, GP system and model development (ResearchGate full text) | MED | Supervisor NEW link. Shows a pure lagged-return nonlinear forecasting route with no attention variable; country-group-specific GP formulas beat AR-family benchmarks in-sample/out-of-sample and in a futures trading check. |
| S-KROU16 | Kroujiline, D., Gusev, M., Ushanov, D., Sharov, S. V. & Govorkov, B. (2016). Forecasting stock market returns over multiple time horizons. arXiv:1508.04332v2 (accepted version for Quantitative Finance). | https://doi.org/10.48550/arXiv.1508.04332 | 2026-10-20 | working paper (arXiv) | SECTIONS: Abstract, model overview, news-based strategies pp.33-35 | MED | Supervisor NEW link (Yandex viewer pointed to p.33). News-flow-only multi-horizon return forecasts on SPY: near-efficient intraday, inefficient at longer horizons via feedback; four prototype strategies backtested 2003-2 |
| S-ZHAN25 | Zhang, Z., Zhao, S., Cheng, J. & Li, J. (2025). Conditional quantile estimation for GARCH model based on mixed-frequency data. Statistical Papers 66, art. 83. | https://doi.org/10.1007/s00362-025-01704-y | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | LOW | Supervisor old link. Method paper: intraday data embedded in low-frequency GARCH for conditional quantiles, with asymptotics, simulations and three index applications. Relevance is background on mixed-frequency GARCH onl |
| S-AMEN21 | Amendola, A., Candila, V. & Gallo, G. M. (2021). Choosing the frequency of volatility components within the Double Asymmetric GARCH-MIDAS-X model. Econometrics and Statistics 20, 12-28. | https://doi.org/10.1016/j.ecosta.2020.11.001 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | Supervisor old link (Q5 MIDAS). Core reference for how the X-driver frequency is chosen inside a two-component asymmetric GARCH-MIDAS-X; crypto application in the abstract record. Justifies treating MIDAS frequency/align |
| S-DHAE16 | Dhaene, G. & Wu, J. (2016). Mixed-Frequency Multivariate GARCH. KU Leuven DPS16.12; SSRN 2799569. | https://doi.org/10.2139/ssrn.2799569 | 2026-10-20 | working paper (SSRN) | ABSTRACT-ONLY | MED | Supervisor old link. Shows the opposite frequency direction to Asif (intraday to weekly multivariate BEKK-MIDAS) and that ignoring high-frequency information inflates persistence. Background for MIDAS weighting vs realis |
| S-CHEV23 | Chevallier, J. & Sanhaji, B. (2023). Jump-Robust Realized-GARCH-MIDAS-X Estimators for Bitcoin and Ethereum Volatility Indices. Stats 6, 1339-1370. | https://doi.org/10.3390/stats6040082 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | MED | Supervisor old link. Example of Realized-GARCH-MIDAS-X with jump-robust realised measures and one-at-a-time X factors, judged by MSE/QLIKE. Supports realised-measure + forecast-loss discipline; crypto high-frequency sett |
| S-LIU24 | Liu, T., Choo, W., Tunde, M. B., Wan, C. & Liang, Y. (2024). Enhancing stock volatility prediction with the AO-GARCH-MIDAS model. PLoS ONE 19(6), e0305420. | https://doi.org/10.1371/journal.pone.0305420 | 2026-10-20 | peer-reviewed journal | SECTIONS: Abstract, Introduction, Methodology outline | MED | Supervisor old link. Worked GARCH-MIDAS-X template (daily returns, monthly macro X: M2, exchange rate, EPU; China/Japan) with additive-outlier correction and MCS-style evaluation; realised volatility beats other low-freq |
| S-META26 | HSE University (2026). XIII International Conference Modern Econometric Tools and Applications — META2026, Draft Programme (2 Oct 2026 version). | https://www.hse.ru/data/2026/10/02/242720593/Corr_Program_META2026_Draft_formatted_4.pdf | 2026-10-20 | conference programme | SECTIONS: Guest-speaker slot and poster list (13-pp programme extracted) | HIGH | Only written evidence found for the conference talk title: Fantazzini & Kurbatskii (spelled Kurbatsky in the programme), Searching for Inflation: Forecasting Russian Regional Prices with Yandex Wordstat after Google's Ex |
| S-NOVI26 | Novikova, E. (2026). Attention-Induced Trading and Return Reversal: Evidence from T-Pulse. Poster, META2026 (programme listing only). | https://www.hse.ru/data/2026/10/02/242720593/Corr_Program_META2026_Draft_formatted_4.pdf | 2026-10-20 | conference poster (title only) | TITLE-ONLY | HIGH | Closest Russian attention-reversal neighbour by title (T-Investments Pulse social-platform activity). Bounds the novelty claim: a Russian attention/return-reversal study was presented at the same conference. No abstract  |
| S-DA11 | Da, Z., Engelberg, J. & Gao, P. (2011). In Search of Attention. Journal of Finance 66(5), 1461-1499 (folder holds the June 2010 draft, 50 pp). | https://doi.org/10.1111/j.1540-6261.2011.01679.x | 2026-10-20 | peer-reviewed journal | SECTIONS: 2010 draft abstract and pp.4-6 (ASVI definition, data) | HIGH | Founding ASVI paper. Canonical ASVI is log SVI minus log of the 8-week median SVI; ticker searches on Russell 3000 2004-2008 predict two-week price pressure then reversal, validated against retail trading. Asif's formula |
| S-VLAS12 | Vlastakis, N. & Markellos, R. N. (2012). Information demand and stock market volatility. Journal of Banking & Finance 36, 1808-1821 (folder holds pp.1-3 only). | https://doi.org/10.1016/j.jbankfin.2012.02.007 | 2026-10-20 | peer-reviewed journal | SECTIONS: pp.1-3 of 14 (abstract, intro, theory start) | HIGH | Weekly Google information-demand study (30 large US stocks): demand vs supply, market vs firm level, positive link to historical/implied volatility and volume. Supports H1 motivation and the firm-vs-market attention spli |
| S-SWAM19 | Swamy, V., Dharani, M. & Takeda, F. (2019). Investor attention and Google Search Volume Index: Evidence from an emerging market using quantile regression analysis. Research in International Business and Finance 50, 1-17. | https://doi.org/10.1016/j.ribaf.2019.04.010 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY in this relay (folder PDF present; Agent-3 read full text) | HIGH | Closest emerging-market weekly firm-panel analogue (India, 436 firms): quantile-varying attention-return links and 52-week rolling-beta excess returns. Supports two-sided H2, quantile extension (C5) and the rolling-beta  |
| S-DJAL21 | Djalilov, A. & Ulku, N. (2021). Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis. Journal of Behavioral and Experimental Finance 31, 100549. | https://doi.org/10.1016/j.jbef.2021.100549 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY in this relay (folder PDF present) | MED | Russian retail-trading context for the attention channel on MOEX during COVID. Context only: it does not validate Wordstat as an attention measure. Cite narrowly. |
| S-DELO90 | De Long, J. B., Shleifer, A., Summers, L. H. & Waldmann, R. J. (1990). Noise Trader Risk in Financial Markets. Journal of Political Economy 98(4), 703-738. | https://www.jstor.org/stable/2937765 | 2026-10-20 | peer-reviewed journal | SECTIONS: Folder PDF front matter (JSTOR record pp.703-738) | MED | Theory anchor: noise-trader risk can sustain mispricing/volatility. It predicts more uninformed activity raises risk; it must not be cited to explain a negative ASVI-volatility coefficient (Methodology v4.0 mechanism dis |
| S-GILE | Giles, D. & Lieberman, O. (n.d.). Bounds on the Effect of Heteroscedasticity on the Chow Test for Structural Change. Univ. of Canterbury Discussion Paper 9101 (folder copy, 22 pp, noisy OCR). | https://www.canterbury.ac.nz/ | 2026-10-20 | thesis / working paper (discussion paper) | SECTIONS: p.1 identification only | LOW | Historical source of the 5.206 bound used in v3. Retained only as a conservative side reference; the bound belongs to a classical Chow statistic with a disclosed k/q mismatch and must not threshold the HAC-Wald test (v4. |
| S-NEWW87 | Newey, W. K. & West, K. D. (1987). A Simple, Positive Semi-Definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix. Econometrica 55(3), 703-708. | https://doi.org/10.2307/1913610 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY (folder scan is image-only; 0 extractable words verified) | MED | HAC foundation for per-firm and Fama-MacBeth inference. Bandwidth arithmetic (5 at T=419) is verified by calculation in Methodology/Known-Issues, not by reading the scan. OCR was unavailable in this relay (no tesseract), |
| S-DIMP16 | Dimpfl, T. & Jank, S. (2016). Can Internet Search Queries Help to Predict Stock Market Volatility? European Financial Management 22(2), 171-192. | https://doi.org/10.1111/eufm.12058 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | Market-level search-to-volatility precedent: index-name searches co-move with realised volatility, Granger-predict it, and improve AR/HAR forecasts, especially in turbulent phases; feedback is bidirectional. Supports H1  |
| S-BAZH19 | Bazhenov, T. & Fantazzini, D. (2019). Forecasting Realized Volatility of Russian Stocks using Google Trends and Implied Volatility. Russian Journal of Industrial Economics 12(1), 79-88; MPRA 93544. | https://mpra.ub.uni-muenchen.de/93544/ | 2026-10-20 | peer-reviewed journal | SECTIONS: Abstract, introduction, data/model outline (MPRA PDF) | HIGH | Only directly comparable Russian volatility-forecast study as read: daily data for SBER, GAZP, ROSN, YNDX; GARCH/ARFIMA/HAR with implied volatility vs Google Trends. Search adds nothing beyond implied volatility and ofte |
| S-ENGL13 | Engle, R. F., Ghysels, E. & Sohn, B. (2013). Stock Market Volatility and Macroeconomic Fundamentals. Review of Economics and Statistics 95(3), 776-797. | https://doi.org/10.1162/REST_a_00300 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | GARCH-MIDAS foundation: daily GARCH short run plus MIDAS long run driven by low-frequency fundamentals; gains at longer horizons. Justifies GARCH-MIDAS-X as the natural daily-price/weekly-search extension (C3), with week |
| S-CORS09 | Corsi, F. (2009). A Simple Approximate Long-Memory Model of Realized Volatility. Journal of Financial Econometrics 7(2), 174-196. | https://doi.org/10.1093/jjfinec/nbp001 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | HAR foundation: additive daily/weekly/monthly realised-volatility cascade estimated by OLS mimics long memory and forecasts well. Weekly adaptation (1, 4, 12-week means) is the HAR-X template in the tournament (T3). |
| S-DRIS98 | Driscoll, J. C. & Kraay, A. C. (1998). Consistent Covariance Matrix Estimation with Spatially Dependent Panel Data. Review of Economics and Statistics 80(4), 549-560. | https://doi.org/10.1162/003465398557825 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | Driscoll-Kraay foundation: Newey-West correction on cross-sectional average scores, consistent under general spatial/temporal dependence as T grows. Supports DK as pooled primary at T/N=5.7 (C7); finite-sample caution re |
| S-BAIP98 | Bai, J. & Perron, P. (1998). Estimating and Testing Linear Models with Multiple Structural Changes. Econometrica 66(1), 47-78. | https://doi.org/10.1111/1468-0262.00007 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | MED | Unknown-break alternative to a fixed 2022 Chow date (C8): sup-F/sequential dating with trimming. EXTENSION/sensitivity at Masters level; the known invasion date keeps the pre-specified Post split primary. |
| S-BENJ95 | Benjamini, Y. & Hochberg, Y. (1995). Controlling the False Discovery Rate. JRSS-B 57(1), 289-300. | https://doi.org/10.1111/j.2517-6161.1995.tb02031.x | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | BH family control for the 74-firm H1/H2 families. Dependence caution (Benjamini-Yekutieli/Holm/Romano-Wolf sensitivities) is stated as a design rule, not read from this abstract. |
| S-ZHEL12 | Zheluk, A., Gillespie, J. & Quinn, C. (2012). Searching for Truth: Internet Search Patterns as a Method of Investigating Online Responses to a Russian Illicit Drug Policy Debate. J. Medical Internet Research 14(6), e165. | https://doi.org/10.2196/jmir.2270 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | MED | Only Google-vs-Yandex comparison in Russia as read: the engines co-move for most terms, Google looks timelier, Yandex localises better geographically. It is a health-policy setting from 2010-2011, not finance; it cannot  |
| S-YOSH20 | Yoshinaga, C. E. & Rocco, F. (2020). Investor Attention: Can Google Search Volumes Predict Stock Returns? Brazilian Business Review 17(5), 523-539. | https://doi.org/10.15728/bbr.2020.17.5.3 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY in this relay (Agent-3 read full text) | MED | Emerging-market weekly firm analogue (Brazil, 57 listings, 2014-2018, excess returns): small negative early-lag return associations, economically small. Key evidence that the US pressure sign does not travel; supports tw |
| S-DUZT19 | Duz Tan, S. & Tas, O. (2019). Investor attention and stock returns: Evidence from Borsa Istanbul. Borsa Istanbul Review 19(2), 106-116. | https://doi.org/10.1016/j.bir.2018.10.003 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY in this relay (Agent-3 read full text) | MED | Large weekly firm panel (Turkey, 313 stocks): short-run pressure, stronger for small stocks, reversal within a year, predictability about three weeks. Supports horizon/heterogeneity design (B2, C9). |
| S-BUIN19 | Bui, V. X. & Nguyen, H. T. (2019). Stock market activity and Google Trends: The Case of a Developing Economy. Journal of Economics and Development 21(2), 191-212. | https://doi.org/10.1108/JED-07-2019-0017 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY in this relay (Agent-3 read full text) | MED | Vietnam weekly firm study separating firm-specific from market-wide attention for illiquidity/volatility, with mixed firm-level signs. Direct precedent for A5 (do not collapse the two attention levels) and for H1 sign un |
| S-YANG21 | Yang, D., Ma, T., Wang, Y. & Wang, G. (2021). Does Investor Attention Affect Stock Trading and Returns? Evidence from Publicly Listed Firms in China. Journal of Behavioral Finance 22(4), 368-381. | https://doi.org/10.1080/15427560.2020.1785469 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | MED | Very large Baidu firm-week panel: contemporaneous ASVI-return association with subsequent reversal; volume does not mirror the reversal. Supports contemporaneous vs predictive timing discipline (the thesis lag must stay  |
| S-TEPL25 | Teplova, T. & Gurov, S. (2025). Nonlinear Intraday Trading Invariance in the Russian Stock Market. Annals of Operations Research 352, 441-469 (online 2022). | https://doi.org/10.1007/s10479-022-04683-7 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | Russian search-data overlap: Google stock-related volume with intraday trading-activity invariance, 2018-2021 as reported by Agent-3. Defeats any first-Russian-search-study claim without matching Asif's outcome/frequency |
| S-STOL25 | Stolbov, M. & Shchepeleva, M. (2025). A Sentiment-Based Financial Stress Index for Russia. Borsa Istanbul Review 25(2), 350-359. | https://doi.org/10.1016/j.bir.2025.01.007 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY | HIGH | Russian macro Wordstat precedent: Google plus Wordstat terms inside a national financial-stress index, 2018-2024 as reported by Agent-3. Proves Wordstat appears in peer-reviewed Russian finance at macro level; does not v |
| S-FAYZ25 | Fayzulin, M. S. (2025). Search Attention and Opinion Divergence in Explaining Retail Investor Behavior. Lomonosov Economics Journal 60(5), 3-41 (in Russian). | https://doi.org/10.55959/MSU0130-0105-6-60-5-1 | 2026-10-20 | peer-reviewed journal | ABSTRACT-ONLY (publisher metadata/abstract via Agent-3; PDF unreadable there) | HIGH | Potentially closest Russian return overlap by abstract (topical search statistics with issuer returns/retail behaviour). Query level and Wordstat-vs-other provider are UNVERIFIED; it blocks any claim that no Russian sear |
| S-WORDAPI | Yandex (2025-2026). Wordstat API (Yandex Search API): GetDynamics, GetTop, GetRegionsDistribution — official documentation (AI Studio / Search API). | https://aistudio.yandex.ru/docs/en/search-api/concepts/wordstat.html | 2026-10-20 | other (official documentation) | SECTIONS: Wordstat concept page (methods table) | HIGH | Current official route for repeatable Wordstat collection: dynamics by day/week/month with region/device filters, synchronous API. Settles Q8 tooling: the supervisor's 2022 PyPI wrapper and GitHub parser target the legac |


## Evidence index (file + SHA-256)

| source_id | evidence_file | sha256 |
|---|---|---|
| S-FK26 | evidence/S-FK26.txt | bf799b6a5d4224921ff0fa9787745cfaba5cdd9c8e9bfd0b8b053282001b99de |
| S-DING20 | evidence/S-DING20.txt | d6a4ed3bcd5a922b8a89e2a969f1d087ea1d64904d014e5f959762dfb0307e82 |
| S-KROU16 | evidence/S-KROU16.txt | 22169207245c90d9d9386e02fec51af7b9b8d2f282c6a6fad51de3b19cd571dc |
| S-ZHAN25 | evidence/S-ZHAN25.txt | 88d4d75aa2766076ebf8d281b57657cdc4678eead89782a76921dc280e98cd1a |
| S-AMEN21 | evidence/S-AMEN21.txt | dc06fcba8eb34e59fa5b576e1512ca0137e86871d03865ff8a578dd7368ad187 |
| S-DHAE16 | evidence/S-DHAE16.txt | 388894ad0f0d72dd3a048fd272b63a9a4ed0b853eb8421c0e861304ac5428d87 |
| S-CHEV23 | evidence/S-CHEV23.txt | 022703a74359cca0c3880ec6b57b28474288bcc6c147110f9aed6d8802def5b9 |
| S-LIU24 | evidence/S-LIU24.txt | ee531636da47a5824afb49c0c416acfc2c5d5e9279c7b5547c7c3e8715001a2f |
| S-META26 | evidence/S-META26.txt | 958818e09c1dfd15b16cf0308bb620406e17ce365bb8fc93d65ba79ea423c91c |
| S-NOVI26 | evidence/S-NOVI26.txt | 0cc37a83a667611c8c950df6cdb8962bfc0ba60025f20e5debbf3509f7720c39 |
| S-DA11 | evidence/S-DA11.txt | 4de53de0d548e07477024989948bc6be039a6a29a484b4f30a494574e934280a |
| S-VLAS12 | evidence/S-VLAS12.txt | 5684f5dba47ea14030702a14450f2d230848e873298afb9c74b75ada23b53730 |
| S-SWAM19 | evidence/S-SWAM19.txt | c7fbedbbd65cb2dd0147e6c217275e597c06705dce26b6f0d6e9c25793b250d1 |
| S-DJAL21 | evidence/S-DJAL21.txt | 814d9a783010555dc14b5769b7831ae1ff5c7337f90e6be47a3b7666f84b9362 |
| S-DELO90 | evidence/S-DELO90.txt | 583865674a7491a00ab147fc764e4b8a4b96a27cb33d51703f3e3df63977721f |
| S-GILE | evidence/S-GILE.txt | 381ad1e3dcb5e9c0908c7b3d69d66f1ddd63819ad61b5f6636e9b0fbfcfb6c7d |
| S-NEWW87 | evidence/S-NEWW87.txt | d03383d03a93b6fee99d0413201dfb9f3c2059fab813c67d296f0cf5677cb126 |
| S-DIMP16 | evidence/S-DIMP16.txt | f1fed63c3b37e75809c2c8686f50c6b18fe4e1ea0338a3bbd55dbf976769884c |
| S-BAZH19 | evidence/S-BAZH19.txt | 15f85d0aa9125e29ddda8ebb54c5dcaea04386e1b80769e5a94a8e320c87c735 |
| S-ENGL13 | evidence/S-ENGL13.txt | 4537c2746be9cc2bb0b81ed4bd6762ca2172519ebe53d0cf19859cbeb536acff |
| S-CORS09 | evidence/S-CORS09.txt | d4d75c892b8a81d8b9535aaee02c690e8856a7bddac0b11cd036140a2b0c7b51 |
| S-DRIS98 | evidence/S-DRIS98.txt | cfc737a6d0cc52371e247f5910debb5784dc8f707ca45b44cdc9b47e36c6aace |
| S-BAIP98 | evidence/S-BAIP98.txt | ebfed486d786546cc70ced0ac91606f2cdcf4c8430162c46e4c59fbdb6941817 |
| S-BENJ95 | evidence/S-BENJ95.txt | 527689d84f091d08155cec3e49cb18b42d1ed55e0ca468b65fe319098cb1260f |
| S-ZHEL12 | evidence/S-ZHEL12.txt | fa035524baf6503032935f11ce6faecb06699760bb8c0a2149ff3cda7854288c |
| S-YOSH20 | evidence/S-YOSH20.txt | f5ae25da3ad77c8b21ffcd744666045dba6f80122ebad4751fae18017542fade |
| S-DUZT19 | evidence/S-DUZT19.txt | 36017fd0787bb2fb8dd6f1d8ada94d45cdceb61b8b8625dc443a47414c0acead |
| S-BUIN19 | evidence/S-BUIN19.txt | f42e21fdbaa115b8da612e175dee5554abeb709cf201244978b2257997d2719b |
| S-YANG21 | evidence/S-YANG21.txt | 1314215472a91a2943319c6f425d40571c9dedc52a4d541a06f2662f4ba33b52 |
| S-TEPL25 | evidence/S-TEPL25.txt | 546c0d3d9af86fdc5928edcb856fa152584c7ad88758d24f78e313180960aaa8 |
| S-STOL25 | evidence/S-STOL25.txt | 8f1771216cec26e99093118ce109ff529c97bae53ee18a378255e00c6d0d99da |
| S-FAYZ25 | evidence/S-FAYZ25.txt | d45c27e6938c2752b06fdff347c60c02e801b47ec0ce2f2871b6baea05ead827 |
| S-WORDAPI | evidence/S-WORDAPI.txt | 9e5be13d97d195804a3175d1d7d699538a141d629ee3f6c61680970a8f279428 |


---

# Appendix C — Search log and simulation outputs

## Search log

| query_id | date_utc | database | query | hits_screened | kept | notes |
|---|---|---|---|---|---|---|
| Q01 | 2026-10-20 | Web search + Springer | Forecasting stock market return with nonlinearity genetic programming approach | 15 | 1 (S-DING20) | Supervisor NEW link identification |
| Q02 | 2026-10-20 | Web search + arXiv | arXiv 1508.04332 market return forecasts | 5 | 1 (S-KROU16) | Decoded Yandex viewer URL to arXiv:1508.04332 |
| Q03 | 2026-10-20 | SSRN + MPRA/RePEc | Fantazzini Kurbatskii 2026 Russian Regional CPI sparse models online data | 14 | 1 (S-FK26) | Full text via MPRA 128456 |
| Q04 | 2026-10-20 | HSE programme PDF | META2026 Fantazzini Wordstat guest talk; Novikova T-Pulse poster | 13pp programme | 2 (S-META26, S-NOVI26) | Title-only evidence; no abstract printed |
| Q05 | 2026-10-20 | Crossref API | DOI verification batch (EcoSta, Statistical Papers, GP, Stats, PLoS) | 17 DOIs | 6 supervisor items verified | Two guessed DOIs failed and were discarded, not cited |
| Q06 | 2026-10-20 | Web search | Bazhenov Fantazzini 2019 Russian stocks Google Trends HAR GARCH | 8 | 1 (S-BAZH19) + MPRA PDF | Russian volatility precedent |
| Q07 | 2026-10-20 | Web search | Dimpfl Jank search queries predict volatility; Engle Ghysels Sohn GARCH-MIDAS; Corsi HAR | 12 | 3 (S-DIMP16, S-ENGL13, S-CORS09) | Volatility-with-online-data + MIDAS/HAR anchors, abstract depth |
| Q08 | 2026-10-20 | Web search | Driscoll Kraay; Bai Perron; Parkinson Garman-Klass range estimators | 25 | 2 (S-DRIS98, S-BAIP98); range via Molnar survey lead | Inference/breaks verified at abstract level; range originals still to library-check |
| Q09 | 2026-10-20 | Web search + PMC | Zheluk Gillespie Quinn Google vs Yandex Russia | 9 | 1 (S-ZHEL12) | Only Google-Yandex comparison found; health setting |
| Q10 | 2026-10-20 | Crossref API | Emerging comparators: Yoshinaga, Duz Tan-Tas, Bui-Nguyen, Yang, Teplova-Gurov, Stolbov-Shchepeleva | 6 DOIs | 6 verified bibliographically | Findings carried from Agent-3 full reads, labelled as such |
| Q11 | 2026-10-20 | Adversarial (absence) EN | firm-level Yandex Wordstat MOEX weekly volatility study | Agent-3 + this relay programme check | 0 exact matches in sources opened | Absence NOT proven; see novelty statement (5-search rule PARTIAL) |
| Q12 | 2026-10-20 | Adversarial (absence) RU/EN | Wordstat акции волатильность MOEX firm-level (via Agent-3 Russian overlaps + META poster) | Agent-3 records | 0 exact; 3 partial Russian overlaps | Russian-language live search NOT re-run in this relay: GAP |


## DGP-A size/power (120 reps/cell) (`sim_dgpA.csv`)

| DGP | true_beta | reps | perfirm_nominal_per_rep | perfirm_BH_per_rep | pooled_reject_rate | fama_macbeth_reject_rate |
|---|---|---|---|---|---|---|
| A-vol | 0.0 | 120 | 4.27 | 0.11 | 0.075 | 0.067 |
| A-vol | 0.001 | 120 | 9.06 | 0.78 | 1.0 | 0.983 |
| A-vol | 0.002 | 120 | 23.44 | 9.68 | 1.0 | 1.0 |
| A-vol | 0.005 | 120 | 64.97 | 64.12 | 1.0 | 1.0 |


## HAR / dividend / returns extras (`sim_extra.csv`)

| experiment | value | detail |
|---|---|---|
| HAR comparison beta=0.002 (baseline) | 0.3 | share of 74x60 per-firm tests p<.05 (nominal) |
| HAR comparison beta=0.002 (HAR-X) | 0.304 | share of 74x60 per-firm tests p<.05 (nominal) |
| Dividend contamination, true beta=0 (rawRV) | 1e-05 | mean per-firm ASVI coef over 40 reps (0 = unbiased) |
| Dividend contamination, true beta=0 (RV) | 1e-05 | mean per-firm ASVI coef over 40 reps (0 = unbiased) |
| Return outcome (r* week+1), pressure=0.003 | 0.316 | share per-firm tests p<.05 (nominal, 40 reps) |
| Return outcome (/r*/ week+1), pressure=0.003 | 0.051 | share per-firm tests p<.05 (nominal, 40 reps) |


## Count-noise attenuation (Poisson-only, upper bound) (`sim_counts.csv`)

| mean_count | variant | approx_noise_sd | attenuation_lambda | effective_beta_at_true_0.010 |
|---|---|---|---|---|
| 30 | single | 0.258 | 0.938 | 0.00937 |
| 30 | sum2_correct | 0.183 | 0.968 | 0.00968 |
| 30 | sum2_overlap_wrong | 0.204 | 0.96 | 0.0096 |
| 130 | single | 0.124 | 0.985 | 0.00985 |
| 130 | sum2_correct | 0.088 | 0.992 | 0.00992 |
| 130 | sum2_overlap_wrong | 0.098 | 0.99 | 0.0099 |
| 1000 | single | 0.045 | 0.998 | 0.00998 |
| 1000 | sum2_correct | 0.032 | 0.999 | 0.00999 |
| 1000 | sum2_overlap_wrong | 0.035 | 0.999 | 0.00999 |
| 20000 | single | 0.01 | 1.0 | 0.01 |
| 20000 | sum2_correct | 0.007 | 1.0 | 0.01 |
| 20000 | sum2_overlap_wrong | 0.008 | 1.0 | 0.01 |


## Weekly GARCH-X pilot (40 reps) (`sim_garchx.csv`)

| model | reps | converged | boundary_share_of_converged | positive_X_share_of_converged |
|---|---|---|---|---|
| weekly GARCH(1,1)-X (single-firm, T=419) | 40 | 40 | 0.025 | 1.0 |


## Allowed real-data descriptives by firm (search and volatility described separately; no joint fit) — first 15 rows by ticker order in file

| ticker | n_weeks | svi_median | svi_p10 | share_weeks_svi_lt100 | asvi_sd | rv_median | rv_mean |
|---|---|---|---|---|---|---|---|
| MRKK | 419 | 22.0 | 7.0 | 0.9451073985680191 | 0.6317849306472015 | 0.0756940153093566 | 0.09830285905795787 |
| MRKU | 419 | 27.0 | 9.0 | 0.6276849642004774 | 0.5509779526028161 | 0.0693048353016792 | 0.08618297771500574 |
| SFIN | 419 | 44.0 | 15.0 | 0.6467780429594272 | 0.5719869588616617 | 0.0647752355427481 | 0.08799562607484152 |
| UKUZ | 419 | 45.0 | 14.0 | 0.8138424821002387 | 0.530326915168557 | 0.0775326330350859 | 0.10649451190860525 |
| MRKS | 419 | 56.0 | 12.0 | 0.7637231503579952 | 0.5048073792865526 | 0.0902934468747267 | 0.1228871433649602 |
| IRKT | 419 | 70.0 | 22.0 | 0.5847255369928401 | 0.5090068836197449 | 0.087264637722907 | 0.11233095656855634 |
| MFGS | 419 | 84.0 | 52.0 | 0.6587112171837709 | 0.42952714538207704 | 0.06580811015542905 | 0.09585488328962403 |
| MSRS | 419 | 110.0 | 30.800000000000004 | 0.46539379474940334 | 0.4193062046039875 | 0.0546505497590793 | 0.06795891638114653 |
| YAKG | 419 | 115.0 | 43.0 | 0.431980906921241 | 0.4023863241691528 | 0.0831620458686774 | 0.11123296243594331 |
| BLNG | 419 | 129.0 | 71.0 | 0.315035799522673 | 0.5606874791608327 | 0.0854666146747531 | 0.1132646821614754 |
| MRKP | 419 | 135.0 | 26.800000000000004 | 0.39618138424821003 | 0.4800921514613754 | 0.0513118333332412 | 0.06771449279072408 |
| JNOS | 419 | 141.0 | 79.80000000000001 | 0.23389021479713604 | 0.4027263208425245 | 0.0741750997634085 | 0.10451301692421192 |
| VJGZ | 419 | 142.0 | 34.800000000000004 | 0.4224343675417661 | 0.5986672924731247 | 0.093434006646097 | 0.13045043022287325 |
| MSTT | 419 | 186.0 | 83.0 | 0.16945107398568018 | 0.4922856322236354 | 0.06356878051967305 | 0.08589591495980511 |
| CHMK | 419 | 186.0 | 110.80000000000001 | 0.07159904534606205 | 0.38442090369458964 | 0.0795741260614764 | 0.0997068629935653 |

*… 60 more rows in `descriptives_by_firm.csv` (full CSV in litrelay/final/).*


---

# Appendix D — Final manifest and baton

# FINAL_MANIFEST (file | bytes | sha256)
final/ANSWERS_TO_SUPERVISOR.md | 6798 | 96f0862f8f217dd30b96a9e535fd40863c87bcf16aa4395e38d2eaf3b06d30f1
final/BEST_PATH_REPORT.md | 28100 | 0c98c38a07f73eda55b02da63187a77a1d1cae5f4f7a318c8eba411300782480
final/DECISIONS_FOR_ASIF.md | 2641 | b706508ed64d1d3d91c737530f96502eed098d388b1c9f9230a9478259b3d0d0
final/LIT_REVIEW_SKELETON.md | 2579 | 5cdbbb763ff7776b92879b33c8a048baf47c53ef213158cf196a4cbcf1cb5ba2
final/PRIORITY_READING_LIST.md | 1925 | 1a028e890e50c6beeb52d924c3498ce0abeacd61b69acd113afb181f1cb6bb6e
final/PROBLEM_REGISTER.md | 7696 | bacc665ee7b56d7cfb6e0c10f856bd8e3f0ccf78f5840ece96ef748d5b052a0f
final/PROBLEM_TO_SOLUTION_MATRIX.md | 2990 | 51827bfc00a4e033a07688ba9ed2d92a7c3a2b183c9387a9023408b2eef4d205
final/README_FOR_ASIF.md | 1786 | 5bc7f4e01a32c97261e89faae3f7e29376855e2e6025ac620923a97eec7457a9
final/RED_TEAM_REPORT.md | 3159 | b9de05d866762031d6e521beb6d042b023270ba718a1bb591c178c2e2d9ec816
final/REFERENCES_VERIFIED.csv | 19167 | c8ae08bfde6758c28ee7550e68b876ea2606115a65dad87569eea25015d4d00f
final/SIM_REPORT.md | 4062 | 80e5fe2f18e45dcaa29685212ee09818413848a492997a0a5bc150870448a678
final/TOURNAMENT_PLAN.md | 4478 | a634ab5890109441106c02c4b4dea98c0e7ad202014db4dd8bd0673b88ae2a4b
final/TOURNAMENT_PLAN.sha256 | 85 | c06ce2b63bb2d6bb27d64a59c665f891ea5eb8788dd6b8d87796045821ab7d9b
final/evidence/S-AMEN21.txt | 683 | dc06fcba8eb34e59fa5b576e1512ca0137e86871d03865ff8a578dd7368ad187
final/evidence/S-BAIP98.txt | 540 | ebfed486d786546cc70ced0ac91606f2cdcf4c8430162c46e4c59fbdb6941817
final/evidence/S-BAZH19.txt | 721 | 15f85d0aa9125e29ddda8ebb54c5dcaea04386e1b80769e5a94a8e320c87c735
final/evidence/S-BENJ95.txt | 405 | 527689d84f091d08155cec3e49cb18b42d1ed55e0ca468b65fe319098cb1260f
final/evidence/S-BUIN19.txt | 559 | f42e21fdbaa115b8da612e175dee5554abeb709cf201244978b2257997d2719b
final/evidence/S-CHEV23.txt | 574 | 022703a74359cca0c3880ec6b57b28474288bcc6c147110f9aed6d8802def5b9
final/evidence/S-CORS09.txt | 494 | d4d75c892b8a81d8b9535aaee02c690e8856a7bddac0b11cd036140a2b0c7b51
final/evidence/S-DA11.txt | 745 | 4de53de0d548e07477024989948bc6be039a6a29a484b4f30a494574e934280a
final/evidence/S-DELO90.txt | 592 | 583865674a7491a00ab147fc764e4b8a4b96a27cb33d51703f3e3df63977721f
final/evidence/S-DHAE16.txt | 506 | 388894ad0f0d72dd3a048fd272b63a9a4ed0b853eb8421c0e861304ac5428d87
final/evidence/S-DIMP16.txt | 548 | f1fed63c3b37e75809c2c8686f50c6b18fe4e1ea0338a3bbd55dbf976769884c
final/evidence/S-DING20.txt | 770 | d6a4ed3bcd5a922b8a89e2a969f1d087ea1d64904d014e5f959762dfb0307e82
final/evidence/S-DJAL21.txt | 616 | 814d9a783010555dc14b5769b7831ae1ff5c7337f90e6be47a3b7666f84b9362
final/evidence/S-DRIS98.txt | 502 | cfc737a6d0cc52371e247f5910debb5784dc8f707ca45b44cdc9b47e36c6aace
final/evidence/S-DUZT19.txt | 527 | 36017fd0787bb2fb8dd6f1d8ada94d45cdceb61b8b8625dc443a47414c0acead
final/evidence/S-ENGL13.txt | 492 | 4537c2746be9cc2bb0b81ed4bd6762ca2172519ebe53d0cf19859cbeb536acff
final/evidence/S-FAYZ25.txt | 628 | d45c27e6938c2752b06fdff347c60c02e801b47ec0ce2f2871b6baea05ead827
final/evidence/S-FK26.txt | 797 | bf799b6a5d4224921ff0fa9787745cfaba5cdd9c8e9bfd0b8b053282001b99de
final/evidence/S-GILE.txt | 588 | 381ad1e3dcb5e9c0908c7b3d69d66f1ddd63819ad61b5f6636e9b0fbfcfb6c7d
final/evidence/S-KROU16.txt | 825 | 22169207245c90d9d9386e02fec51af7b9b8d2f282c6a6fad51de3b19cd571dc
final/evidence/S-LIU24.txt | 697 | ee531636da47a5824afb49c0c416acfc2c5d5e9279c7b5547c7c3e8715001a2f
final/evidence/S-META26.txt | 682 | 958818e09c1dfd15b16cf0308bb620406e17ce365bb8fc93d65ba79ea423c91c
final/evidence/S-NEWW87.txt | 705 | d03383d03a93b6fee99d0413201dfb9f3c2059fab813c67d296f0cf5677cb126
final/evidence/S-NOVI26.txt | 532 | 0cc37a83a667611c8c950df6cdb8962bfc0ba60025f20e5debbf3509f7720c39
final/evidence/S-STOL25.txt | 463 | 8f1771216cec26e99093118ce109ff529c97bae53ee18a378255e00c6d0d99da
final/evidence/S-SWAM19.txt | 755 | c7fbedbbd65cb2dd0147e6c217275e597c06705dce26b6f0d6e9c25793b250d1
final/evidence/S-TEPL25.txt | 512 | 546c0d3d9af86fdc5928edcb856fa152584c7ad88758d24f78e313180960aaa8
final/evidence/S-VLAS12.txt | 609 | 5684f5dba47ea14030702a14450f2d230848e873298afb9c74b75ada23b53730
final/evidence/S-WORDAPI.txt | 710 | 9e5be13d97d195804a3175d1d7d699538a141d629ee3f6c61680970a8f279428
final/evidence/S-YANG21.txt | 531 | 1314215472a91a2943319c6f425d40571c9dedc52a4d541a06f2662f4ba33b52
final/evidence/S-YOSH20.txt | 629 | f5ae25da3ad77c8b21ffcd744666045dba6f80122ebad4751fae18017542fade
final/evidence/S-ZHAN25.txt | 575 | 88d4d75aa2766076ebf8d281b57657cdc4678eead89782a76921dc280e98cd1a
final/evidence/S-ZHEL12.txt | 655 | fa035524baf6503032935f11ce6faecb06699760bb8c0a2149ff3cda7854288c
final/evidence_index.csv | 3221 | 73d38c4e585e2b47a972e68a80ea7e1688724b8dfa2616cb07febd4a4698bf6a
final/sources.csv | 19167 | c8ae08bfde6758c28ee7550e68b876ea2606115a65dad87569eea25015d4d00f
## Helper runs at packaging (2026-10-20)
- verify_package.py /home/user/litrelay -> RESULT: PASS (21 CSVs field-checked; 33 source_ids resolve)
- citation_lint.py sources.csv + BEST_PATH + ANSWERS -> RESULT: PASS (33 sources, no unknown cited IDs)
- schema_check.py /home/user/litrelay -> RESULT: PASS (sources, READING_LIST_MASTER, SEARCH_LOG, REFERENCES_VERIFIED)
- Tournament hash: a634ab5890109441106c02c4b4dea98c0e7ad202014db4dd8bd0673b88ae2a4b (stage5/TOURNAMENT_PLAN.md; copy in final/)
- Red-team verdict: CONDITIONAL (final/RED_TEAM_REPORT.md). External Claude canary still owed.


## Baton (Mode B close-out)

`NEXT: paste LITRELAY_MASTER_PROMPT.md into a fresh chat and attach/give it STATE.md and these files: litrelay/final/*, litrelay/stage3/W3_NOT_DONE.md, litrelay/stage6/W6_NOT_DONE.md (to finish the two PARTIAL stages), then bring litrelay/ to Claude for the independent canary check.`

*End of single-file report. Originals preserved in `litrelay/` — this file adds no new verification and changes no hash-listed original.*
