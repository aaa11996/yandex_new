# Web Search Queries and Market Movements — combined final report

**Prepared for:** Khandaker Asikh Iqbal (Asif), HSE University, Nizhny Novgorod
**Thesis:** *Web Search Queries and Market Movements: Evidence from the Russian Equity Market*
**Supervisor:** Prof. Andrey Aistov
**Prepared by:** the literature relay (ten-stage review), Arena.ai Agent Mode
**Date:** 20 October 2026

---

## How to read this document

This is the single combined report. It merges the eight delivered artefacts — the recommended path, the
answers to the supervisor, the decision sheet, the problem register, the simulation study, the literature
skeleton, the reading list and the red-team audit — into one narrative that can be read start to finish or
dipped into by section.

It is written in plain English. Formulas appear only where a formula is the point. Every number is traceable
to a file in the package: the report says which one.

| If you have | Read |
|---|---|
| 10 minutes | §1 (the answer in one page) and §9 (what to do on Monday) |
| An hour | §1–§5, then §8 (decisions) |
| A supervisory meeting | §2 (the five findings) and §9 (answers to his eleven questions) |
| A defence coming | §6 (problems) and §10 (what an examiner will attack) |

**Three conventions used throughout.** A claim marked **VERIFIED** was read in the source itself and the
excerpt is in `evidence/`. **VERIFIED-CODE** means it was produced by code in this package and can be
re-run. **HEARSAY / GAP / UNVERIFIED** means exactly what it says and nothing may be built on it. The full
list of thirty load-bearing statements is `CLAIMS.csv`.

> **What this package does not contain.** It does not estimate a single coefficient on Asif's real search
> data. That was a deliberate constraint, held throughout: no regression, no GARCH-X, no HAR-X, no MIDAS
> with the real attention variable against a real outcome. Everything quantitative below comes either from
> the published literature or from simulated panels calibrated to the observed moments. The reason is
> simple — if the design has already been shown to be under-powered, the thesis should know that before it
> spends its one shot at the data, not after.

---

## 1. The answer in one page

**Keep the question. Change what counts as an answer.**

The thesis asks whether unusually heavy Yandex searches for a company say something about that company's
shares the following week. After reading the literature, auditing the methodology and running a
pre-registered synthetic tournament, three things are clear.

**First, the returns version is very probably unanswerable with 419 weeks.** A weekly return is mostly
unforecastable news. The effect being looked for is a few basis points, and the signal-to-noise ratio of a
weekly market-adjusted return is roughly 1:200. No estimator recovers signal that is not there. The
supervisor's instinct — that market-adjusted returns are awkward because they fluctuate around zero — is
right, though for a sharper reason than the one he gives: they fluctuate around zero because they contain
almost no signal.

**Second, the volatility version is answerable, but not as currently specified.** Volatility is persistent
and measurable from the high–low range, so a small effect is detectable. The simulation in this package
shows the pooled panel detects a coefficient of 0.005 with 96% probability, while the per-firm design would
need a coefficient of 0.029 — six times larger — to reach 80% power. The 74 per-firm regressions, currently
the main test, are the least powerful instrument in the package.

**Third, there is a theory that predicts a curve and the thesis fits a line.** Andrei and Hasler (2015)
derive that attention both speeds up information arrival (raising volatility) and reduces uncertainty
(lowering it). The net relation is increasing and convex: negative linear term, positive quadratic term. If
that is the truth and a straight line is fitted, the estimated slope is negative on average *even where
volatility rises*. The simulation demonstrates this exactly: against a U-shaped truth, a linear-only
regression returns −0.00795 (true average derivative −0.008) and is significantly negative in 100% of 400
replications. That is a confident, publishable, wrong answer.

**So the recommended path is:** volatility as the primary outcome; the pooled panel and Fama–MacBeth as the
primary estimators; linear **and** squared attention in every table; the 74 per-firm regressions demoted to
a heterogeneity display; the 2022 break treated as a central object rather than an appendix; and the
measure validated against non-price data before any regression appears.

None of this discards the thesis. It converts a likely null into a powered result, and it gives the
negative Russian evidence a constructive role: the study becomes a test of whether firm-level Wordstat
attention still carried information after Google left the Russian market.

---

## 2. The five findings that matter

### Finding 1 — One of the supervisor's references does not say what it is cited for

The ResearchGate paper on genetic-programming nonlinearity (*Forecasting stock market return with
nonlinearity: a genetic programming approach*) is an index-level **forecasting** paper. It does not
establish a firm-level attention–volatility mechanism, and it does not provide a sign. If it is cited as the
theoretical foundation, an examiner who opens it will find a mismatch between the citation and the claim.

The arXiv paper the supervisor pointed to (1508.04332, Kroujiline et al.) is a distinct and more relevant
object: it studies search-query horizons and market dynamics. Its horizon logic is usable; its results are
about the aggregate market, not about 75 MOEX firms.

**What to do.** Cite Andrei & Hasler (2015) for the mechanism and its curvature, and cite the supervisor's
papers where they genuinely apply: the genetic-programming paper as a precedent for nonlinearity in
returns, Kroujiline et al. for the horizon argument. Both keep their place in the review without carrying
weight they cannot bear.

### Finding 2 — The strongest published evidence on this exact question is negative, and it is Russian

Bazhenov and Fantazzini (2019) put Google Trends into HAR, ARFIMA and GARCH(1,1) models for four liquid
Russian stocks. Result: no significant search effect on realized volatility, and **worse** out-of-sample
forecasts in several cases. Fantazzini and Shangina (2019) repeat the exercise on RTS futures and report
that several augmented models failed to converge.

This is not a reason to abandon the thesis. It is a reason to state the prior honestly, and then to say
what is different here: firm-level (not index-level) data, Yandex Wordstat rather than Google Trends, a
sample that is 60% post-2022, and a specification that allows the relation to be curved. A thesis that
names its negative precedent in the introduction is stronger than one that is surprised by it in the
conclusion.

### Finding 3 — The Russian attention space is crowded; the novelty has to be narrow and stated precisely

At least six Russian or Russia-focused studies occupy adjacent ground: Teplova & Gurov (2025) on intraday
trading invariants and Google search; Teplova et al. (2022) on social-network "hype"; Bazhenov & Fantazzini
(2019); Fantazzini & Kurbatskii (2026); Shaidullin et al. (2026); and the topic-level attention work in the
Lomonosov Economics Journal.

The defensible novelty is therefore not "attention and Russian stocks". It is: **firm-level weekly Yandex
Wordstat attention for the 75 MOEX firms, 2018–2026, with the post-Google-exit period as the object of
study and a nonlinear specification.** That is narrow enough to be true and specific enough to be checked.

**Do not claim "first".** The absence search (`stage3/SEARCH_LOG.csv`) was run in English and Russian and
found nothing identical, but eLibrary could not be searched deeply from this environment. The word "first"
would convert a search limitation into a false claim.

### Finding 4 — There is a theory that predicts a curve, and Russian work has not used it

Andrei and Hasler (2015) is the only paper in the corpus that derives a *shape* rather than a sign. Its
prediction — negative linear, positive quadratic, with a turning point — is testable with one extra column
and it makes the thesis falsifiable in a way that "does attention matter?" is not.

The simulation adds a warning that is worth putting in the thesis itself: when the truth is curved, the
linear coefficient is not "biased towards zero", it is **confidently wrong**. Reporting the linear slope
without the quadratic term is not a conservative choice.

### Finding 5 — The design's power is in the panel, not in the 74 regressions

Measured on simulated panels calibrated to the observed moments (ASVI standard deviation by size quartile
0.49/0.36/0.30/0.26; 16.6% common variance; AR(1) 0.55), 400 replications per cell:

| True β | Per-firm (74 tests) | Pooled TWFE | Fama–MacBeth | HAR-X |
|---:|---:|---:|---:|---:|
| 0.002 | 6.1% | 31.5% | 30.0% | 39.3% |
| 0.005 | **9.6%** | **96.3%** | **96.0%** | **98.5%** |
| 0.010 | 21.1% | 100% | 100% | 100% |

Per-firm 80% power requires β ≈ 0.029. **Caveat, stated wherever the 96% appears:** the simulated pooled
standard error is 0.72× the observed one, because week fixed effects absorb the common shock that inflates
the real Driscoll–Kraay error. All pooled figures are therefore **upper bounds**. They are still an order of
magnitude better than the per-firm design.

There is a second, more uncomfortable consequence. Applied to the five firms that survived Benjamini–
Hochberg in the existing results, the same arithmetic gives implausible magnitudes: RTKM's slope of −0.040
implies that doubling attention lowers its weekly range volatility by about 34% of its mean; LSRG −0.021
implies 18%; PHOR −0.016 implies 14%. Effects that large are not attention effects. They are what an
under-powered design produces when it finally rejects: the few estimates far enough from zero to clear the
bar, which are the ones contaminated by dividends, thin trading or a corporate event. **Report them as a
specification diagnostic, not as a finding.**

---

## 3. What the literature supports, and what it does not

Eleven methods were reviewed. For each, the question is not "is this a good method" but "what can it
support in *this* data". Full cards are in `stage1/METHOD_CARDS.md`.

| Method | What it can support here | Where it fails |
|---|---|---|
| Da–Engelberg–Gao ASVI | a validated abnormal-attention measure | the log-of-median vs median-of-logs detail must be exact |
| Fama–MacBeth | the average weekly cross-sectional slope, no beta needed | needs cross-sectional variation each week; thin weeks bite |
| Two-way FE + Driscoll–Kraay | the pooled slope with market-wide shocks absorbed | DK errors are optimistic when the common shock dominates (0.72×) |
| Per-firm OLS + BH | heterogeneity display | power 9.6% at β = 0.005 — cannot carry a hypothesis |
| Quadratic (Andrei–Hasler) | a test of the *shape*, a turning point | mildly liberal size (7.5%), must be reported with the linear term |
| Range volatility | a low-noise volatility proxy from daily OHLC | contaminated by ex-dividend weeks unless corrected |
| HAR / HAR-X | one-week-ahead forecast comparison | needs a hashed evaluation plan (declared NOT-DONE here) |
| GARCH(1,1)-X | a literature comparison | 50.5% convergence at T = 419; zero power — excluded |
| GARCH-MIDAS-X | weekly attention in the long-run component | no mature Python implementation; needs R `mfgarch` |
| Break tests (Bai–Perron, rolling) | whether the relation moved in 2022 | needs a pre-specified window, not a search |
| Permutation inference | a distribution-free check on the whole family | not a substitute for a pre-specified test family |

**The three claims that recur and are weaker than they look.**

1. *"Yandex Wordstat is better than Google Trends for Russia."* This is **HEARSAY** in this package. The
   supervisor attributes it to Fantazzini; the written paper in his list uses Google Trends. The Wordstat
   comparison exists only as a conference talk title (META2026, 2 October). Label it a personal
   communication until a draft appears. The citable argument for Wordstat is different and stronger: after
   Google's exit, Yandex is the only engine with continuous coverage of Russian users.
2. *"Russian attention research is thin."* It is not thin; it is crowded (Finding 3). What is thin is
   **firm-level weekly Wordstat** work.
3. *"The measure is validated because Da–Engelberg–Gao validated theirs."* Their validation is on their
   data. Asif's measure needs its own validation table (see §5, A4) — four correlations against non-price
   outcomes, before any regression.

---

## 4. The audit: thirty-one problems, eleven open

The register (`stage4/PROBLEM_REGISTER.md`) extends the six known issues in the supplied
`KNOWN_ISSUES_REGISTER.md` plus the twenty-two in the methodology's Appendix C to thirty-one, each with
evidence, severity, the hypothesis it affects, what the literature does about it, and status.

Severity means consequence for the thesis, not difficulty of the fix: **S1** can invalidate a conclusion,
**S2** biases or weakens it, **S3** is disclosure only.

| Region | Problems | The substance |
|---|---|---|
| Outcome measurement | P-01, P-12, P-19, P-25, P-29 | dividends inflate RV; ex-dates are derived; one-week horizon only |
| Measurement of attention | P-03, P-05, P-18, P-22, P-23 | median-of-logs; imposed loading of 1.0; the measure never validated |
| Design and power | P-04, P-16, P-26, P-27, P-31 | thin counts for small firms; no daily search data; MDE never stated in economic units |
| Inference | P-07, P-17, P-21, P-28 | HAC lag; forking paths; reverse causality; convergence reporting |
| Data quality | P-02, P-10, P-11, P-14, P-15, P-30 | share counts, sanctions coding, state-ownership labels, macro series, universe |
| Framing | P-06, P-08, P-09, P-13, P-20, P-24 | market-adjusted returns; break vs slope shift; circular crisis control; abandoned news layer |

**Six of the 31 are S1 and still open: P-01, P-06, P-23, P-24, P-27, P-31.** They are exactly the six that
Plan A addresses — the plan was built from the register, not alongside it.

The four that would end a chapter if unanswered:

- **P-01 (ex-dividend mechanics).** The vendor price series is not total return. In ex-dividend weeks the
  measured range is mechanically wider. Register L4 measures a 25% average change in RV in those weeks and
  62% of them move by more than 10%. Correcting returns but not the OHLC bars leaves the volatility outcome
  contaminated in precisely the weeks the dividend control is switched on.
- **P-23 (measure never validated).** Nothing in the current design checks that the Wordstat series measures
  attention rather than curiosity, a corporate event or a news spike. A four-line validation table fixes it.
- **P-24 (linear contradicts the only theory of sign).** See Finding 4.
- **P-31 (power never stated for the design).** Now closed by the simulation, including the correction of an
  earlier, wrong draft figure: per-firm power at β = 0.005 is **9.6%**, not ~35%.

---

## 5. Plan A — the recommended design, in five components

### A1 · The outcome: range volatility, dividend-corrected

Weekly range volatility from daily high and low, on dividend-adjusted bars. Register L4 measures mean RV at
0.1022, falling to 0.0762 once the dividend is added back to the highs and lows — a 25% correction in
ex-dividend weeks, arithmetic rather than modelling.

*Why it matters:* without this, part of any state-ownership or dividend result is a mechanical artefact of
the ex-date.

### A2 · The regressor: canonical ASVI, and its square

$$ASVI_{i,t}=\ln(SVI_{i,t})-\ln\!\big(\text{median}(SVI_{i,t-8},\dots,SVI_{i,t-1})\big)$$

the founding paper's exact form (log **of the median**, not median of logs — register P-03; verified at
draft lines 92 and 364). Then a centred, z-unit square:

$$ASVI^{2}_{i,t}=\left(\frac{ASVI_{i,t}-\overline{ASVI}}{\sigma_{ASVI}}\right)^2$$

Unit matters. In raw units the squared term is nearly collinear with the linear one and inflates the
linear coefficient by about 0.06; in z-units the inflation is 0.010 — the simulation shows mean +0.00997
against a true +0.010.

### A3 · The estimators: pooled and Fama–MacBeth, with the market on the right

**Primary (E1):** two-way fixed effects with Driscoll–Kraay errors, firm and week effects, the market return
entering as a regressor rather than being subtracted from the outcome:

$$RV_{i,t}=\alpha_i+\gamma_t+\beta_1 ASVI_{i,t-1}+\beta_2 ASVI^{2}_{i,t-1}+\delta\, r^{m}_{t-1}+\varepsilon_{i,t}$$

**Cross-check (E2):** Fama–MacBeth — a cross-section each week, 419 weekly slopes averaged, which needs no
beta estimate and no market adjustment.

**Return outcome (E3, secondary):** absolute abnormal return as the dependent variable, because the *size*
of the move is what attention theory speaks about; and the market return on the right-hand side, so nothing
is generated.

**What this design deliberately does not do:** no GARCH-X (§7), no penalised search over query variants, no
news layer.

### A4 · Validation of the measure — the cheapest credibility in the package

Before any regression: four correlations between ASVI and non-price outcomes — trading volume, absolute
return, the number of news days, and turnover. If ASVI does not move with volume and with absolute returns,
it is not measuring attention and the rest of the thesis is moot. One table, one afternoon.

### A5 · Time variation — the supervisor's own idea, applied

A rolling 156-week coefficient plot for the ASVI slope, with the 2022 break marked. Three weeks of MOEX
closure (2022-02-28, 03-07, 03-14) sit in the middle of it. This is the component that turns the negative
precedent into a contribution: if the relation was alive before 2022 and dead after, the full-sample average
is a blend of two regimes and will look like nothing.

**Plan B, if the core fails or data stay thin.** (i) Decile portfolio sorts on z: top-minus-bottom, a
non-parametric version of the same question; (ii) an ASVI-spike event study around attention shocks;
(iii) reframe as a measurement paper — *"What does a Yandex search for a stock measure?"* — which is a real
contribution, is mostly descriptive, and cannot be refuted by an insignificant coefficient.

---

## 6. What the design can and cannot detect

`stage6/sim_lab.py` is a synthetic tournament: twelve specifications × 400 replications (4,650 in total),
seed 20261020, calibrated to the observed moments. It was written and hashed **before** it was run
(`stage5/TOURNAMENT_PLAN.sha256`, 2026-10-20T16:42:44Z; final run 16:55:50Z). Every figure below has a row in
`stage6/SIM_RESULTS.csv`.

### Size — honest, with one exception

| Specification | Rejection rate under the null |
|---|---:|
| S1 per-firm | 0.057 |
| S1 pooled | 0.052 |
| S2 linear term | 0.050 |
| **S2 quadratic term** | **0.075** — mildly liberal |
| S4 Fama–MacBeth | 0.058 |
| S5 HAR-X | 0.033 — conservative |

The quadratic term's own test is liberal at 7.5%. That is a fact to report, not to tune away; it is one
reason the reporting rule below pairs the two terms.

### Power — the numbers that change the design

| True β | Per-firm | Pooled TWFE | Fama–MacBeth | HAR-X |
|---:|---:|---:|---:|---:|
| 0.002 | 6.1% | 31.5% | 30.0% | 39.3% |
| 0.005 | 9.6% | 96.3% | 96.0% | 98.5% |
| 0.010 | 21.1% | 100% | 100% | 100% |

Per-firm MDE80 ≈ 0.029. Pooled ≈ 0.005, and even that is optimistic by 0.72×.

In economic units — effect of *doubling* attention, as a share of mean RV, using effect = β·ln2 ÷ 0.08 (the
dividend-corrected mean RV is 0.0762; 0.08 is used so the shares read as round numbers, and the scaling is
labelled approximate):

| Design | Detectable β at 80% | Doubling attention moves mean RV by |
|---|---:|---:|
| Per-firm | 0.029 | 25% |
| Pooled / Fama–MacBeth | 0.005 | 4.4% |

A genuine attention effect of 4.4% per doubling is small but real. The per-firm design can only see effects
six times larger — which is why its "insignificant" results carry no information.

### Robustness — measurement error, missing data, and the quadratic trap

| Stress | Result |
|---|---|
| Classical measurement error, +50% of signal variance | coefficient attenuates 0.00508 → 0.00313 (−38%); power 97.3% → 84.7% |
| +100% | mean 0.00233; power 72.0% |
| 5% of weeks missing | pooled power 93.2%, Fama–MacBeth 92.0% |
| 15% missing | 84.8% / 82.4% |
| **U-shaped truth fitted with a line** | mean slope −0.00795, significantly negative in **100%** of replications |
| Same truth, quadratic reported | mean +0.00997 (true +0.010), detected 100% |

### The ruling table

| Rule | Fired? | Consequence |
|---|---|---|
| DR-T1 (if per-firm size is acceptable, keep it primary) | **yes** | S1 pooled linear becomes primary; per-firm demoted |
| DR-T3 (if the linear estimator is biased, the quadratic becomes primary) | **no** — the linear estimator is consistent for the *average derivative* | quadratic stays mandatory-secondary, with the rule that **S1 and S2 are always reported together** |
| DR-T5 (if GARCH-X converges and has power) | **fails** — 50.5% convergence, zero power | GARCH-X **excluded**; literature discussion with the power table; GARCH-MIDAS-X as the extension |
| DR-T6 (no specification search) | honoured | no LASSO over variants, no post-hoc subsetting |

**Disclosed honestly:** DR-T3 was written as "S2 becomes primary if S1 is *biased*". Under the U-shaped
design the linear estimator turns out to be consistent for the average derivative, so the rule did not fire
and the plan's own wording had been mis-specified in advance. This is stated in the report rather than
retro-fitted.

**Declared NOT-DONE:** the forecast evaluation (HAR versus HAR-X, Diebold–Mariano, model confidence set).
It needs the real series and its own hashed plan, and it is not smuggled in as a result.

---

## 7. Why GARCH is not the main model — and what to say when asked

The supervisor asked for GARCH.augmented with the thesis's ideas. The answer is: yes, it has been done, on
Russian data, and it is the reason not to lead with it.

- **Bazhenov & Fantazzini (2019)** — HAR, ARFIMA and GARCH(1,1) with Google Trends for four Russian stocks:
  no significant search effect, worse out-of-sample forecasts in several cases.
- **Fantazzini & Shangina (2019)** — RTS futures; several augmented models failed to converge.
- **This package's simulation** — a weekly GARCH(1,1)-X at T = 419 converged in **50.5%** of 200 simulated
  series and had **zero** power for an effect that raises variance by 10%.

Running 75 of them and reporting the ones that converged is selective reporting — register P-28 forbids it.
The constructive alternative is **GARCH-MIDAS-X**, where weekly search drives the long-run component of
daily volatility: it uses the daily price data that exists, it is the architecture of Amendola, Candila &
Gallo (2021), and it is estimable. The practical obstacle is software: there is no mature Python
implementation, so the main-text approximation is U-MIDAS (unrestricted MIDAS, i.e. OLS with distributed
lags) and the true model becomes the extension if R's `mfgarch` is available.

---

## 8. Eight decisions that are yours

None of these is a technical detail. Each changes what the thesis is.

| # | Decision | Recommendation | Cost of the other branch |
|---|---|---|---|
| **D-1** | Returns or volatility primary? | **Volatility primary**, returns secondary with the market on the right | a main table that cannot distinguish "no effect" from "design too weak" |
| **D-2** | Report the quadratic term? | **Yes, always, in every table**, with the turning point | if the truth is curved, you write the opposite of what is happening |
| **D-3** | Keep 74 per-firm regressions as the main test? | **No** — panel carries H1, per-firm becomes heterogeneity | the main claim rests on the least powerful estimator |
| **D-4** | Correct RV for dividends, or only returns? | **Both** | a reviewer attributes part of any H5 result to the dividend |
| **D-5** | Run GARCH? | **No** — power table instead; GARCH-MIDAS-X as extension | a chapter of fragile fits and a hidden selection problem |
| **D-6** | Handle 2022 as appendix or centre? | **Centre it** — rolling coefficient, pre/post split | report a null that is really a mixture of two regimes |
| **D-7** | Keep the state-ownership hypothesis (H6)? | **Keep it but mark it provisional** and report the label problems | "How did you classify VSMO?" ends the chapter's credibility |
| **D-8** | If everything is insignificant? | **Report the MDE and write the measurement paper — decided now, in writing** | results become unfalsifiable and the thesis unmarkable |

D-8 is the one worth signing before the results arrive. It is not pre-registration — the results have
already been seen once — but it is a written commitment that the fallback is a real thesis rather than a
specification search.

**Not your decision.** The nine data-quality items and the two statistical corrections (log-of-median;
ln(VALUE) instead of share volume) are not preferences. They are errors, and fixing them is mandatory. If
the supervisor asks why the numbers moved, the answer is a correctness rule, not a choice.

---

## 9. The eleven answers the supervisor is owed

Short versions below; the file `stage7/ANSWERS_TO_SUPERVISOR.md` has the sendable text with sources.

**Q1 — He wants the draft with formulas fixed.** Agreed, and they are now fixed at four equations: ASVI as
log count minus log of the eight-week median; weekly range volatility on dividend-adjusted bars; a two-way
fixed-effects panel with linear and quadratic attention and Driscoll–Kraay errors; and a return model that
keeps the market return on the right-hand side. The draft order is literature review → data and measurement
→ models → results → discussion → conclusions, with a validation table for the measure before any
regression appears.

**Q2 — "Do the articles measure SVI and ASVI the same way?"** Da–Engelberg–Gao define ASVI as the log count
minus the log of the eight-week median and my measure is identical to that. Swamy et al. (India) and
Yoshinaga & Rocco (Brazil) use an abnormal search measure on weekly firm data, but the standardisation
differs — Yoshinaga works with lagged *changes* in search volume — so I state my formula explicitly rather
than claim identical construction. Two caveats: Wordstat returns counts, Google Trends returns a 0–100 index,
so the *input* differs even when the formula does not; and my sample is post-2018, so the comparison to
2011-era studies is on method, not on data.

**Q3 — "Why not GARCH?"** Because it is been done twice on Russian data with null results, and because at
419 weeks a weekly GARCH-X converges half the time and has zero power for a large effect (§7). I report it
as a literature discussion with a power table and offer GARCH-MIDAS-X as the estimable extension.

**Q4 — "419 observations can be fine for some models."** Agreed, and I can now say which. Enough for the
panel (96% power at β = 0.005, though optimistic); not enough for the 74 per-firm regressions (9.6% power at
the same β, MDE 0.029); not enough at all for GARCH.

**Q5 — "Try MIDAS."** Agreed in principle, and sequenced: GARCH-MIDAS with weekly attention in the long-run
component is the natural specification, but there is no mature Python implementation, so U-MIDAS is the
main-text approximation and true GARCH-MIDAS-X is the extension.

**Q6 — "Fantazzini and Kurbatskii (2026)."** That paper gave the review its most useful idea and its
sharpest warning. The idea: the value of online data is time-varying, so H3 should be a rolling coefficient
rather than a single break test. The warning: their abstract reports that Russian search data's predictive
power was significant before the early-2022 shift and degraded sharply afterwards. With 60% of the sample
post-2022, the subperiod analysis must be a main result.

**Q7 — "Fantazzini said Wordstat beats Google Trends."** I looked, and the written record says something
slightly different: the SSRN paper in your list uses Google Trends; the Wordstat comparison appears only as
a META2026 talk title ("…with Yandex Wordstat after Google's exit", 2 October). I will label it a personal
communication until slides or a draft appear, and I have built the Wordstat argument on a separate, citable
basis — after 2022 Yandex is the only engine with continuous coverage of Russian users.

**Q8 — "Did you use a Wordstat API?"** I downloaded manually; the scripted attempts looked rate-limited. The
current official route is the Wordstat API in Yandex AI Studio, whose `GetDynamics` method returns frequency
by month, week or day — if that confirms on ten test queries, weekly re-collection becomes scriptable.
Legacy Direct-API wrappers are dated and scraping is fragile and a terms-of-service risk.

**Q9 — "I am afraid of market-adjusted returns."** You are right, but the reason is signal-to-noise, not the
zero mean. Three fixes: put the market return on the right-hand side instead of subtracting it, so nothing
is generated; use Fama–MacBeth, which needs no beta at all; and make the main return outcome the *absolute*
abnormal return, the size of the move, which is what attention theory speaks about.

**Q10 — "The ideas are enough; keep the recommendation realistic."** Yes — Plan A is five pieces and every
one is standard software. Nothing outside pandas/statsmodels/linearmodels; the whole estimation runs in
minutes. The expensive options are in an extension layer that can be dropped without damaging the thesis.

**Q11 — "Does subtracting the cross-sectional average distort the signals, and does it remove the need for
crisis dummies?"** Subtracting does not specifically hurt small firms — the measured effect is the opposite
of the worry: it removes −9%/−17%/−26%/−22% of the variance from smallest to largest quartile, so it removes
least from the smallest, and it raises variance for 4 of 75 firms. Two real problems remain: noise differs
by size (ASVI s.d. 0.49 smallest vs 0.26 largest), and subtraction imposes a common sensitivity of 1.0 when
the measured loadings run 0.28–1.89. My proposal: do not subtract — week fixed effects do the job exactly in
the pooled model, and the per-firm models should estimate the sensitivity rather than impose it.

---

## 10. What an examiner will attack, and the answer

The red team (`stage8/RED_TEAM_REPORT.md`) audited the package adversarially. Its verdict was **conditional
pass**; the conditions are disclosure, not correctness. What it found, and how to handle it:

| Attack | Answer |
|---|---|
| "Your supervisor's own reference contradicts your mechanism." | It is a forecasting paper; the mechanism is cited from Andrei–Hasler. Stated openly in §2, Finding 1. |
| "You ran 75 regressions and reported 5." | Exactly — which is why the panel is now primary and the per-firm family is labelled heterogeneity with the MDE printed beside it. |
| "Your standard errors are too small." | Measured: the simulated DK SE is 0.72× the observed, so the power figures are upper bounds and are labelled as such. |
| "You chose the specification after seeing the data." | The tournament plan was hashed before the runs (`sha256sum -c` reproduces `OK`), and the one rule that had to be interpreted is disclosed rather than hidden. |
| "GARCH would have worked." | 50.5% convergence and zero power in the simulation; two Russian papers with null GARCH results. The power table goes in the appendix. |
| "Your Wordstat measure is unvalidated." | Correct in the current draft; A4 fixes it with four correlations before any regression. |
| "The five significant firms are your finding." | They imply 14–34% volatility changes per doubling of attention. They are a specification diagnostic (P-01, thin trading), not a finding. |
| "You never collected data weekly." | The Wordstat API `GetDynamics` aggregates by week; a ten-query test is the first task in §11. |

**Two things the package cannot answer**, and says so: the deep Russian-language search (eLibrary was not
reachable from this environment, so the absence claim is narrowed, never "first"), and the external canary
check by an independent reader.

---

## 11. What to do, in order

| Step | Action | Time | Result-blind safe? |
|---|---|---|---|
| 1 | Sign D-8 (the fallback decision) and D-1 to D-7 | 30 min | yes |
| 2 | Test the Wordstat API on ten queries; confirm weekly aggregation; record the settings | 1 h | yes |
| 3 | Rebuild RV from dividend-adjusted OHLC (A1) | 3 h | yes |
| 4 | The four-correlation validation table (A4) | 2 h | yes |
| 5 | Fix P-03 (log of median) and the volume denominator | 1 h | yes |
| 6 | Estimate A3 with linear and squared ASVI; report both always | 2 h | no — the first look |
| 7 | Rolling 156-week coefficient plot with the 2022 break (A5) | 2 h | no |
| 8 | Write up; put the MDE in the results section, not an appendix | 1 day | no |
| 9 | Hand `BEST_PATH_REPORT.md` §2 and the power table to the supervisor before he asks | 15 min | yes |

Steps 1–5 are all result-blind. That is deliberate: by the time the first coefficient appears in step 6,
every choice that could be made "to get a result" has already been made and written down.

---

## 12. What is still unknown

| Unknown | Effect on the thesis | How it closes |
|---|---|---|
| Whether the Wordstat API really aggregates weekly | decides whether the sample can be rebuilt properly | ten-query test (step 2) |
| Whether the relation survived 2022 | the central hypothesis | rolling coefficient (A5) |
| Why five firms survived BH with implausible magnitudes | whether H1 is contaminated or real | dividend correction + validation table |
| The exact ex-date derivation quality | contaminates 62% of dividend weeks | register P-12 rebuild |
| Whether the Wordstat talk has a written version | hearsay vs citation | ask the supervisor directly |
| eLibrary Russian-language coverage | the width of the novelty claim | a library session in Moscow |

---

## 13. The audit trail behind this report

| File | What it establishes |
|---|---|
| `stage0/W0_REPORT.md`, `READING_LIST_MASTER.csv` | the 18 supplied sources, with bibliographic anchors |
| `stage1/METHOD_CARDS.md` | 11 method cards: what each method can support |
| `stage2/CORPUS_READING.md` | the 7 corpus papers read in depth; R1–R8 support limits |
| `stage3/` | the search protocol, the comparables table, the narrowed novelty claim, the search log |
| `stage4/PROBLEM_REGISTER.md` | 31 problems with evidence, severity, fix and status |
| `stage5/IDEA_REVIEW.md`, `PROBLEM_TO_SOLUTION_MATRIX.md`, `TOURNAMENT_PLAN.md` (+ hash) | the design tournament, hashed before it ran |
| `stage6/sim_lab.py`, `SIM_RESULTS.csv`, `SIM_LOG.txt`, `SIM_REPORT.md` | the synthetic evidence for every power number |
| `stage7/` | the recommended path, the supervisor answers, the decision sheet, the literature skeleton, the reading list |
| `stage8/RED_TEAM_REPORT.md` | the adversarial audit and its conditions |
| `CLAIMS.csv` | 30 load-bearing statements with status and source |
| `sources.csv` | 54 sources with tier and reading depth |
| `evidence/` | 17 excerpts from the sources actually opened |
| `VALIDATION_REPORT.md` | the actual output of every automated check |

**Verification, as delivered:**

```
[PASS] csv-shapes: 7 CSVs · claim->source: 30 claims, 15 VERIFIED, links ok
[PASS] evidence: all FULL sources have an evidence file        RESULT: PASS
[PASS] schema: ok    [PASS] duplicate titles: none    [PASS] no phantom ids
TOURNAMENT_PLAN.md: OK      (hash unchanged since 16:42:44Z, before any run)
manifest: every file present with the recorded size and SHA-256
```

**The honest limits of that.** One context ran all ten stages, so the inbound audits are self-audits. Fifteen
sources are `NOT-OPENED` (standard classics used only to name methods). Seventeen are `ABSTRACT-ONLY`. The
register's K3/K7/L4 numbers are carried from a previous round and not re-derived here. All of this is
disclosed in the red-team report rather than buried; a package that hides its own near-misses is not
auditable.

---

## 14. One paragraph for the supervisor

> A literature and feasibility review of the proposed design was carried out against the eighteen supplied
> sources and the submitted methodology. The review identifies three substantive risks: the theoretical
> reference does not support a firm-level attention–volatility mechanism; the Russian evidence points to
> null or negative search effects, particularly after the 2022 structural break; and per-firm weekly
> regressions at the available sample size have low power for plausible effect magnitudes, while pooled
> estimation is better powered but sensitive to common shocks. A pre-registered synthetic tournament
> establishes which specifications can be trusted before any estimation on the research data. Thirty-one
> problems are documented with fixes, and the recommended path reframes the contribution around the
> post-2022 break and the measurement properties of Yandex Wordstat.

---

*Combined final report, 20 October 2026. Every claim above is traceable through `CLAIMS.csv` to a source id
or to code in this package. Where a number is approximate, it is labelled. Where a claim is not verified, it
is named as hearsay, a gap, or unverified — and nothing is built on it.*
