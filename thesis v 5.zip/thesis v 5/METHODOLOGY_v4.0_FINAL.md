# METHODOLOGY v4.0 — FINAL
## Web Search Queries and Market Movements: Evidence from the Russian Equity Market
### Complete research design, estimation plan, and event/control data compendium

Assembled 7 Oct 2026 by the Blueprint Round (10-agent loop; Judge A assembly, Judge B sign-off). This document **replaces** `methodology_final.md` (v2.0) as the methodology. It is a new file; the author's abstract, framework and prospectus texts are untouched.

**Status discipline (§0 of the loop prompt).** Every statement below is one of: **(a)** supported by a cited source opened during this round; **(b)** verified by code run on the repository files (scripts in `blueprint_round/repro/`, outputs in `blueprint_round/final/DATA/`); **(c)** a labelled design decision under a stated rule (see `DECISION_REGISTER.md`); or **(d)** labelled `UNVERIFIED` / `GAP` with a pointer into `GAP_REGISTER.md`. There is no fifth kind.

---

# PART I — RESEARCH DESIGN AND ESTIMATION

## 1. Purpose, research questions, hypotheses

The thesis asks whether abnormal attention of Russian internet users to listed firms — measured from Yandex Wordstat search counts — predicts next-week volatility and returns of 75 Moscow Exchange (MOEX) stocks, weekly, 2018-08-27 to 2026-08-31 (419 Monday-labelled weeks).

| Hyp. | Statement | Expected sign | Basis |
|---|---|---|---|
| H1 | Abnormal search volume (ASVI) predicts next-week realised volatility (RV). | **Two-sided.** Information-demand studies find a positive link (Vlastakis & Markellos 2012, corpus pp. 1–3); the v2.0 Russian estimates were predominantly negative. No universal sign is established across markets (register D3). | (a),(c) |
| H2 | ASVI predicts next-week returns, with possible later reversal. | **Two-sided**; the founding paper reports short-run price pressure then reversal for retail-driven attention (Da, Engelberg & Gao 2011; corpus draft pp. 3–5, 26–30). | (a) |
| H3 | The ASVI–volatility relation changed around 24 Feb 2022. | Two separate claims: a volatility **level shift** (expected, large) and an **attention-slope shift** (open). They are tested separately (V4-09). | (c) |
| H4 | The relation differs across sectors. | Exploratory; family-corrected. | (c) |
| H5 | The relation differs in dividend season. | Tested on **dividend-adjusted** returns; the price-only interaction is partly mechanical (Part I §6.5, verified). | (b) |
| H6 | The relation differs for state-owned firms. | **Provisional** until the blind SOE re-classification closes GAP-12. | (d) |

**Mechanism discipline.** De Long et al. (1990) noise-trader risk predicts that uninformed-trader activity *raises* volatility; it must not be cited to explain a *negative* ASVI–volatility coefficient (register, Agent-1 role note). A negative coefficient, if found, is reported as an empirical result with candidate explanations (attention concentrated in calm weeks; measurement timing), not forced onto a theory that predicts the opposite.

## 2. Setting (verified facts only)

- MOEX equity market, high retail participation after 2022 (corpus: Djalilov & Ülkü-type evidence on MOEX retail behaviour, J. Behav. Exp. Finance 2021).
- **Full-market closure:** weeks of 2022-02-28, 2022-03-07, 2022-03-14 — all 75 panel tickers show zero trading days (verified on the panel: 225 ticker-weeks; status (b)).
- **Settlement:** unified T+1 cycle for equities from **31 July 2023** (MOEX's own page, moex.com/s3511; status (a), T1).
- **Weekend sessions:** began **1 March 2025**, experimental; weekend trades belong to the *next* trading day (RBC 25-02-2025; Finuslugi/MOEX-group page; status (a), V-2SRC). Consistent with the data: only 8 Saturday dates exist in the daily files, and the median Monday/Tue–Fri turnover ratio across the 75 firms rises from ≈1.09 (2023/24) and ≈1.13 (2024/25) to ≈1.28 after March 2025 (status (b)). Nothing is "missing"; Monday bars absorb weekend trading after March 2025 — a small timing quirk, disclosed, no adjustment made.
- Sanctions environment and non-resident access restrictions: see Part II §12 and §16.

## 3. Sample and universe

75 firms × 419 weeks = 31,425 panel rows (verified: structure, uniqueness, Monday grid, `MOEX_WEEK_END_SUNDAY = SEARCH_MONDAY + 6`; status (b)). Sector map and share class per the panel files. **Survivorship disclosure:** the universe comprises firms with usable Wordstat and MOEX data through 2026 and no ticker/name change; 19 candidate firms were excluded at assembly (registry to be reproduced — GAP-16). Results therefore speak to surviving, continuously listed firms; this is stated in the limitations. ROLO is excluded from every RV-involving model (1-kopeck price grid; v2.0 rule retained; quantization screen pre-registered for all other tickers — §7).

## 4. Data and variable construction

### 4.1 Search data
- **Source files:** per firm, Latin-ticker query and Cyrillic "«name» акции" query, weekly Wordstat exports ("all regions, all devices"; header verified on all 150 files; status (b)). Collection settings (operators, quoting, export date) are not documented in the files → Wordstat settings questionnaire for the author (GAP-19b).
- **Reconciliation:** `SEARCH_LATIN_RAW + SEARCH_CYRILLIC_RAW` from the raw exports reproduces panel `SVI_RAW` with **0 mismatches** across 31,006 non-Yandex firm-weeks (status (b)). Yandex itself: YNDX + Cyrillic, YDEX excluded (disclosed firm-specific rule, V4-04).
- **SVI** = Latin count + Cyrillic count (sum rule retained; justification rewritten — the sum is the broadest pre-specified proxy; low inter-channel correlation is *not* evidence of distinct searcher populations, since noise alone lowers correlation; V4-04). SVI = 0 ⇒ missing.
- **ASVI (canonical, V4-03):** `ASVI_t = ln(SVI_t) − ln(median(SVI_{t−8}…SVI_{t−1}))`, requiring 8 valid prior weeks. This is the founding paper's exact form (corpus draft p. 4) and is what the delivered panel already contains (verified to 4.4e−16). The v2.0 median-of-logs form differs only on even-window ties (corr 0.99976, 37 sign flips) and is sensitivity S03.
- **Share-of-total normalisation (V4-19, sensitivity S04):** the Wordstat "Percentage of total queries" column is documented by Yandex and internally consistent — count ÷ (share/100) yields one common weekly total across ~145 queries with median CV 0.69% (status (b)); implied total Yandex queries: 1.62bn (2018-08-27) → 2.90bn (2022-02-28) → 2.54bn (2026-08-24). The denominator series `D_t` (median across all queries) ships in `DATA/D_t_implied_denominator.csv`. The rounded share itself (2–3 significant digits) must never be used directly. Counts remain primary (DR4: `D_t` is itself an estimate); the normalised variant is reported for the weeks where total-traffic shocks matter (Apr-2020 lockdown, New-Year weeks).

### 4.2 Price data
- **Source:** MOEX daily/weekly files (`moex_panel_data.zip`); weekly Sunday label = week **end** (investing.com's Sunday label is the day *before* its week — cross-source joins must apply the shift; V4-21). All joins in this thesis use `week_monday` keys only.
- **Corporate actions:** four flagged event weeks (GMKN 100:1 split 2024-04-08; VTBR 5000:1 reverse split 2024-07-15; PLZL 10:1 split 2025-03-24; ROLO dilution 2023-01-16) — panel notes verified against the volume/value break signature (status (b)); ratios not yet verified against issuer/MOEX filings (GAP-02). **SFIN week 2025-12-22 is an unresolved in-week break** (low 931 vs prior-week low 1,610; RV 0.678): cause unknown, RV masked in sensitivity S09.
- **Volume control (V4-01):** **ln(VALUE)** (ruble turnover), because VOLUME is a share count that breaks at splits (VTBR Δln(VOLUME) = −8.07 across its consolidation while Δln(VALUE) = +0.17; status (b)). ln(VOLUME) demoted to sensitivity.
- **Calendar:** 2022 closure weeks and 328 no-trade ticker-weeks stay missing (no fill); 7 H=L bars coded missing; the final grid week (2026-08-31) has 5 trading days for all 75 firms, so the delivered `PARTIAL_WEEK_FLAG` is relabelled "horizon-truncation flag" (V4-17).

### 4.3 Outcomes
- **RV** = ln(High_w / Low_w), weekly range volatility (retained, DR4). Scale-invariant, hence valid on whole-week post-event rows; invalid on in-week breaks (SFIN rule above).
- **Returns.** Basis: `RETURN_SAFE` (gap-safe weekly log close-to-close; missing on event weeks — verified that `RETURN_RAW` instead keeps the jumps: VTBR +8.48 etc., register A2).
  Primary H2/H5 outcome (V4-05): **dividend-adjusted, market-adjusted return**
  `r*_{i,t} = ln(exp(RETURN_SAFE_{i,t}) + DPS_{i,t}/P_{i,t−1}) − β_i^{pre}·r^{IMOEX}_t`,
  where DPS is the dividend assigned to the approximate ex-week (Part II §13) and β_i^{pre} is the firm's OLS beta on IMOEX over 2018-08-27…2022-02-21 (pre-break window; rolling-β 52/104-week variants = sensitivity S07; the 52-week rolling form is what Swamy et al. 2019 use, corpus p. 4). Rationale is correctness, not results: ex-dividend weeks mechanically carry −5.1% average market-adjusted price return vs +0.1% elsewhere (528 ex-weeks; status (b)).
- **Timing convention:** every regressor dated t−1 is known by the end of week t−1; Wordstat weeks and MOEX weeks are aligned Monday-to-Monday (verified grid rule).

## 5. Controls and event variables (construction in Part II)

| Control | Form in models | Notes |
|---|---|---|
| Crisis_{t−1} | market-wide 0/1, 4 windows, 23 weeks | identical across firms (verified) ⇒ absorbed by week FE in pooled models; retained in per-firm models with circularity disclosure (§8); sensitivity S13 replaces it with lagged market RV |
| Sanction_{i,t−1} | permanent step, 24 firms | anchors in `DATA/sanction_anchors.csv`; reaction-window variant = sensitivity |
| Div_{i,t−1} | 1 in the 4 weeks before the record week | anticipation window; ex-date mechanics live in the outcome, not here |
| ln(VALUE)_{i,t−1} | volume control | V4-01 |
| RV_{i,t−1} | persistence control | |
| SOE_i, Sector_i | cross-sectional interactions (H4/H6) | SOE provisional (GAP-12) |
| News | **excluded from all models** (V4-14) | matrix absent; selection and duration outcome-driven (circular, DR7); descriptive appendix only |

## 6. Models

All families estimated on the 419-week Monday grid, missing stays missing, ROLO excluded wherever RV enters. N for the pooled baseline: 29,642 firm-weeks (replicated this round to the row).

**M1 (H1, per-firm):** for each firm i: `RV_t = α + β·ASVI_{t−1} + γ1·RV_{t−1} + γ2·ln(VALUE)_{t−1} + γ3·Crisis_{t−1} + γ4·Sanction_{t−1} + γ5·Div_{t−1} + ε_t`, OLS with Newey–West HAC, **bandwidth 5** (= floor(4(T/100)^{2/9}) for T≈419; V4-08; bandwidths 4 and 8 as sensitivities — replication shows identical BH/Holm survivor sets at 4/5/8/9). Family: 74 firms, Benjamini–Hochberg 5% + Holm reported together with nominal counts.

**M2 (H2, per-firm):** same regressors with `r*_t` as outcome (dividend- and market-adjusted; V4-05), ln(VALUE)_{t−1} now included (fixes v2.0's inconsistency, register D5).

**M3 (Granger-style lag tests):** retained from v2.0 with BH/Holm; common-sample rule stated explicitly (both directions estimated on the identical row set per firm).

**M4 (pooled):** `RV_{i,t} = β·ASVI_{i,t−1} + controls + μ_i + λ_t + ε_{i,t}`, two-way fixed effects, **Driscoll–Kraay (Bartlett, 4 lags) errors** (T/N = 419/74 = 5.7 favours DK; two-way clustering = sensitivity S16). Replicated this round: β = +0.000785, SE = 0.001832, t = 0.43, within-R² = 0.1331, N = 29,642. Week FE make market-attention subtraction irrelevant (identical slope, verified; V4-20). Crisis drops (collinear with λ_t).

**M5 (H3, redesigned; V4-09):** interaction form `RV_{i,t} = … + δ1·Post_t + δ2·(ASVI_{i,t−1}×Post_t) + …` with Post = weeks starting 2022-02-21 (first grid week containing 24 Feb 2022; the Crisis-W2 overlap is disclosed). δ1 (level shift) and δ2 (slope shift) are reported **separately**, per-firm (HAC-5) and pooled (DK; λ_t replaced by sub-period FE where needed for identification of δ1). The Giles–Lieberman bound (corpus: Giles & Lieberman, Univ. of Canterbury discussion paper; row Cu(0.1,10] = 5.206 with a disclosed k=4-vs-q=3 mismatch) is retained only as a conservative side reference. Claims discipline: a post-2022 volatility level shift is **not** evidence that the attention effect changed.

**M6 (permutation):** circular block shift of each firm's ASVI series (block length 8, 2,000 draws, seed printed), preserving autocorrelation; plus cross-firm placebo (sensitivity S12).

**Multiple testing families:** (i) 74 per-firm H1 tests; (ii) 74 per-firm H2 tests; (iii) H4 sector set; each corrected within family (BH 5%, Holm shown). **Power:** every null is accompanied by MDE80 ≈ 2.8×SE (identity verified against the prior report's numbers).

### 6.5 What is already known about these specifications (transparency, not design input)
Replication this round, from raw files + original control matrices: M1 baseline gives 12 nominal / 6 BH / 3 Holm rejections (survivors AFKS, LSRG, MFGS+, PHOR, RTKM, SNGS; mean slope −0.0045; 55/74 negative) — matching the v3 playbook exactly. Under the adopted ln(VALUE) control the set becomes 11/5/2 (AFKS exits). H5 price-only interaction −0.0221 (t −4.35) falls to −0.0072 (t −2.06) when dividends are added back — the adopted outcome. These numbers are disclosed because v4.0 is **not pre-registered** (§10); they did not drive the rulings, each of which cites a result-neutral rule (see `DECISION_REGISTER.md`).

## 7. Pre-registered robustness list (fixed before the final rerun; DR5)

S01 ln(VOLUME) in place of ln(VALUE) · S02 split-adjusted share volume (needs GAP-02 factors) · S03 v2.0 ASVI form · S04 share-of-total ASVI (D_t) · S05 market-median ASVI as added regressor (per-firm) · S06 market-median subtracted (disclosure only; imposes loading 1.0) · S07 β=1, rolling-β 52w/104w market adjustment · S08 H2 horizons h=0…4 + cumulative · S09 SFIN week masked · S10 drop 8 warm-up weeks + final truncated week · S11 HAC 4/5/8 · S12 cross-firm placebo (seeded) · S13 Crisis → lagged market RV · S14 Div window shifted to ex-week proxy · S15 channels: Latin-only / Cyrillic-only · S16 pooled SEs: DK / two-way cluster / firm cluster · S17 ASVI standardised by firm trailing sd · S18 ASVI residualised on market ASVI with expanding-window firm loading · S19 H2/H5 on price-only returns (mirror of primary) · S20 H3 level-only / slope-only / joint · S21 minimum-count rule (SVI < 10 excluded). No post-hoc additions or deletions; every sensitivity row is labelled "sensitivity only; not a design input".

## 8. Threats to validity and limitations (honest, evidence-linked)

1. **No causal claim.** Attention and volatility respond to common news within the week; lagged regressors mitigate simultaneity, not omitted common drivers. The thesis claims predictive association only.
2. **Circular controls.** Crisis windows (and the discarded News layer) are built from the same outcomes they would control; retained only with disclosure and sensitivity S13 (DR7).
3. **Survivorship** (§3): selection of 75 survivors; direction of bias unknown.
4. **Measurement.** Wordstat counts queries, not investors; collection settings undocumented; channel sum is a design choice; ASVI noise differs by firm size (sd 0.49 → 0.26 across size quartiles; register K7); minimum-count sensitivity S21 addresses the extreme-small-firm cells.
5. **Specification history** (§10): no pre-registration; results of v2.0/v3 were known before v4.0 was written.
6. **Open data gaps** (Part II §18): sanctions negative verification, SOE blind re-check, dividend T1 upgrade, corporate-action ratio verification, macro series. Any conclusion touching these carries the gap label until closed.
7. **2022 structural break and closure:** three missing market weeks; all break-related results condition on the post-period's different liquidity and investor mix.

## 9. Reproducibility protocol

One-command scripts, each printing library versions and seeds: `blueprint_round/repro/verify_core.py` (panel, ASVI, matrices, dividends, calendar, volume breaks, SFIN, NW arithmetic), `verify_wordstat.py` (raw parses, D_t, raw↔panel diff), `replicate_models.py` (M1 + sensitivities), `replicate_pooled.py` (M4/H2/H5, Driscoll–Kraay), `build_data_folder.py` (adopted data + manifest). Environment: Python 3.13, pandas 2.2.3, numpy 2.3.5, statsmodels 0.15.0. Input hashes: `all data final.zip` eb4601…48c2f, `moex_panel_data.zip` 4855e3…564f, `yandex_final.zip` (git `2c5d6d5`) d75ab9…016a. Adopted data files and SHA-256 in `DATA/DATA_MANIFEST.md`.

## 10. Specification history and transparency statement

v2.0 was frozen and estimated; a v3 draft and results playbook followed; both were seen by the author before this document was written. **Nothing in v4.0 is pre-registered.** v4.0 was specified after seeing the v2.0 and v3 results; the defence against forking-paths criticism is (i) every change from v2.0 carries an amendment ID and a result-neutral rule (Appendix B/C), (ii) the sensitivity list was fixed before the final rerun (§7), and (iii) the previously observed results are disclosed in §6.5 rather than hidden. Novelty wording: this is, to the author's knowledge after a dedicated search, among the first *firm-level weekly Wordstat* studies of MOEX stocks, but at least three Russian-market attention studies exist; the thesis claims incremental, not first-mover, contribution (V4-18).

---

# PART II — EVENT AND CONTROL DATA: CONSTRUCTION AND VERIFICATION

All adopted files live in `blueprint_round/final/DATA/` (schemas + SHA-256 in `DATA_MANIFEST.md`); every datum has a row in `DATA_PROVENANCE_TABLE.csv`; everything unverified is in `GAP_REGISTER.md`.

## 11. Crisis windows
Rule (v2.0, retained descriptively): firm-week spike = RV ratio ≥ 2 AND volume ratio ≥ 2 vs own trailing-52-week median; stress week = ≥ 25% of eligible firms spike; window = contiguous run (one-week bridge) with peak ≥ 40%. Four windows (Monday labels, verified from the restored matrix): **2020-02-24…2020-04-13 (8 wks) · 2022-02-21…2022-03-28 (6 wks) · 2023-09-04…2023-09-18 (3 wks) · 2026-06-22…2026-07-27 (6 wks)**; 23 weeks × 75 firms = 1,725 cells (verified). The matrix codes **every** firm 1 in window weeks — it is a market-level dummy, hence collinear with week FE (Part I §5). Known issues, disclosed: volume leg uses share VOLUME (contaminated near the four CA events; GAP-10 re-derivation on VALUE); windows are outcome-derived (circularity, §8); the 2022-09-19 mobilisation week sits outside all windows despite a large attention spike; external anchors for W4 (June–July 2026) remain UNVERIFIED. Adopted file: `DATA/crisis_i_t.csv` (week_monday key only).

## 12. Sanctions
Coding: permanent step = 1 from the Monday of the first economically binding designation week (announcement-week convention; for lagged use, note the anchor is the Monday of the announcement week, so Sanction_{t−1} first bites the week after the announcement week). 24 step firms, 3,687 firm-weeks (verified); anchors and per-anchor verification status in `DATA/sanction_anchors.csv`; reaction matrix (5-week unions, 181 cells, 26 ticker columns populated) as variant. **Verified this round:** ROSN & LKOH — OFAC full blocking 22 Oct 2025 (anchor week 2025-10-20 ✓); SIBN & SNGS — OFAC designation 10 Jan 2025 (anchor week 2025-01-06 ✓); both V-2SRC from independent law-firm/press summaries of the Treasury actions. **Not re-verified this round (GAP-11):** the other 20 anchors against the primary OFAC/EU/OFSI lists; the negative verification of the remaining 51 firms; AVAN (flagged unverified by the prior compile) and AFLT (single-source). The prior draft's claim of "20 verified, 3 parent-level" is carried as DOC, not as fact.

## 13. Dividends
Adopted working table: the **original** `dividend_record_dates.csv` restored from git history — 587 confirmed-paid record dates, 63 payers, 38 weekend record dates (legal), 58 record dates pre-dating the panel (verified counts). The v3 dohod.ru rebuild (572 dates, 57 firms) is retained only as a cross-check; the originals were never absent from history (V4-26). Sources are aggregators (T3) → row-level upgrade to issuer filings / e-disclosure.ru is open (GAP-13). `Div_{i,t}` = 1 in the four weeks before the record week: 2,110 firm-weeks (verified); the 587→529 record-week-cell→2,110 bridge is reproduced arithmetically in the count-bridge note shipped with the data. 18 announced-not-paid exclusions per `phase1_exclusion_audit.csv` (DOC; row-level re-audit open). **Ex-dates:** approximated from the settlement regime — ex-week = record week under T+1 (from 2023-07-31, MOEX s3511, T1 verified); record date −1 business day before that (no holiday calendar; both timing variants are sensitivities). `DATA/dividends_verified.csv` carries `ex_date_approx`, `ex_week_monday`, `amount`, and per-row status. These feed the dividend-adjusted return (Part I §4.3): 528 ex-weeks matched in the panel; mechanical check verified (−5.1% vs +0.1%).

## 14. State ownership
Rule: SOE = 1 iff Russian state (federal or sub-federal, direct or via state-controlled holding) ≥ 25% of voting shares; UNDETERMINED allowed. Published classification: **35 SOE / 40 non-SOE / 0 UNDETERMINED** (re-parsed from the unified paper's 75-row table into `DATA/soe.csv`; counts verified). Knife-edge and flagged cases carried with their printed evidence: VSMO (Rostec exactly 25%+1), TATN/TTLK/UTAR regional, MGNT/RUAL/RGSS/PIKK/TRMK time-varying or flagged, LKOH/SNGS/CBOM tier-B opacity. **The blind double classification required by the loop was not performed this round** → H6 is provisional (GAP-12); the earlier "agent2b_soe.csv (34/41)" comparison file does not exist.

## 15. Company news events
17 events / 12 companies / 54 company-weeks per the rebuild (DOC); weekly matrix absent. **Excluded from all models** (V4-14, DR7): admission partly conditioned on price/volume spikes and durations set by RV/volume — selection on the outcome. If a news appendix is wanted, only the two-source-verified event list with **fixed** (not data-driven) durations may be tabulated; six named gaps remain open (GAP-14).

## 16. Market-level and macro series; institutional events
`DATA/market_series_weekly.csv`: IMOEX weekly OHLC, log return and range-RV on the Monday grid, extracted from the panel after verifying the IMOEX columns are identical across all 75 firm files (status (b)). Institutional events (all dated in Part I §2 / this part): 2022 closure weeks (b); T+1 on 2023-07-31 (a); weekend sessions from 2025-03-01 folded into next trading day (a, V-2SRC). **Not retrieved this round (GAP-15):** USD/RUB (CBR), Brent (EIA), key rate decisions (CBR), MOEX total-return index, index-exclusion and non-resident-restriction event list — exact source URLs are listed in the Gap Register; each is marked NOT RETRIEVED and no number from them appears anywhere in this document.

## 17. Corporate actions and trading calendar
`DATA/corporate_actions.csv`: the four panel-flagged events (verified internally via the volume/value break signature; issuer-side ratio verification = GAP-02) plus SFIN 2025-12-22 as CANDIDATE-UNRESOLVED. `DATA/trading_calendar.csv`: per grid week, firms trading, median trading days, closure and truncation flags (closure weeks verified; 328 no-trade ticker-weeks; 7 H=L bars).

## 18. Verification log and gap register
What was re-verified by code this round (all PASS): panel structure (31,425×39; 75×419; unique; Monday grid; Sunday rule) · panel ASVI = canonical form (4.4e−16) · raw-Wordstat↔panel reconciliation (0 mismatches, 31,006 rows) · D_t common-denominator property (CV 0.69%) · all four control-matrix totals and the week_sunday label bug · dividend-table counts (587/63/38/58) · volume-break table · SFIN rows · closure/no-trade/H=L/final-week calendar facts · NW bandwidth arithmetic (5, not 9) · M1 baseline replication (exact) · M4 replication (exact to reported precision) · H5 price-only vs dividend-adjusted (−0.0221 → −0.0072) · ex-week mechanical return gap (−5.1% vs +0.1%) · market-attention variance share (16.6%) · pooled-slope invariance to de-meaning · SOE table counts (35/40). What was verified from sources: T+1 (T1), weekend sessions (V-2SRC), ROSN/LKOH/SIBN/SNGS OFAC anchors (V-2SRC), canonical ASVI formula (V-READ p. 4), Swamy 52-week rolling beta (V-READ p. 4), Vlastakis & Markellos corpus truncation (3 of 14 pp.), Giles–Lieberman identification (V-READ p. 1), De Long et al. identification (V-READ p. 1), Newey–West PDF image-only (V-CODE, 0 extractable words). Everything else: `GAP_REGISTER.md`.

---

# APPENDICES

## A. Data dictionary (adopted analysis variables)
`SEARCH_MONDAY` (join key everywhere) · `SVI_RAW` = Latin+Cyrillic weekly counts · `ASVI` canonical (§4.1) · `RV` = ln(H/L) · `RETURN_SAFE` · `r*` dividend- and market-adjusted return (§4.3) · `ln(VALUE)` volume control · `CRISIS, SANCTION, DIV` per Part II · `SOE, SECTOR` cross-sectional. Full field list: panel README + `DATA_MANIFEST.md`.

## B. Decision Register
See `DECISION_REGISTER.md` (rulings CA-01…CA-27 with rules and evidence).

## C. Change log v2.0 → v4.0
| V4-ID | Change | Rule |
|---|---|---|
| V4-01 | Volume control lnV → ln(VALUE) | DR1 |
| V4-02 | CA handling codified; SFIN flagged; ratio verification opened as gap | DR1/DR7 |
| V4-03 | ASVI canonical ln(median) primary; v2.0 form → sensitivity | DR2 |
| V4-04 | Channel-sum justification rewritten (correlation argument retired) | DR6 |
| V4-05 | H2/H5 outcome → dividend-adjusted, market-adjusted returns | DR1 |
| V4-06 | H2 horizons/reversal added as sensitivities | DR3 |
| V4-07 | RV retained; quantization screen pre-registered | DR4 |
| V4-08 | HAC bandwidth 5 (draft's 9 was arithmetic error); DK primary for pooled; MDE80 mandatory | DR1/DR3 |
| V4-09 | H3 split into level vs slope tests; G–L bound demoted to side reference | DR1/DR6 |
| V4-10 | Crisis disclosed as market-wide & circular; S13 alternative | DR6/DR7 |
| V4-11 | Sanction step retained; anchor spot checks done; full verification = gap | DR3 |
| V4-12 | SOE provisional pending blind re-check | DR3 |
| V4-13 | Dividend ex-date layer added (T+1 verified); T3 sourcing disclosed | DR1/DR6 |
| V4-14 | News layer excluded from models | DR7 |
| V4-16 | Survivorship statement; exclusion registry gap | DR6 |
| V4-17 | Calendar facts verified; weekend-session wording corrected; flag renamed | DR1 |
| V4-18 | Claims policy (two-sided, inconclusive-not-zero, no pre-registration, no "first") | DR6 |
| V4-19 | D_t normalisation as sensitivity; D_t series shipped | DR4/DR6 |
| V4-20 | Market attention: week FE primary; subtraction rejected as primary | DR2/DR3 |
| V4-21 | Monday-only join keys; week_sunday column removed | DR1 |
| V4-26 | Original control matrices restored & adopted; "absent from history" retired | DR1/DR6 |
| V4-27 | Citation/arithmetic hygiene (DEG 2011; NW=5; weekend wording; no self-scores) | DR1 |
Prior-draft audit (CA-22): §J5/§K8 errors all corrected above; v2.0 results remain disclosed (§6.5); no v2.0 file was edited.

## D. Examiner questions, short honest answers
**"Is this pre-registered?"** No. v4.0 was written after the v2.0/v3 results were seen; the protections are the amendment rules, the fixed sensitivity list, and full disclosure of the previously observed numbers (§10). — **"Why ln(VALUE), not share volume?"** Share counts break mechanically at splits (VTBR −8.07 log points); rubles don't. — **"Why did the H5 effect shrink?"** About two-thirds of the price-only interaction was the mechanical ex-dividend price drop; the adopted outcome adds the dividend back, and −0.0072 (t −2.1) is what remains. — **"What does the 2022 break test show?"** Volatility levels clearly shifted; whether the *attention effect* changed is a separate, weaker result (slope-only F = 4.70, 2/74 firms, below the conservative bound). — **"Can you claim causality?"** No; predictive association only. — **"What is still unverified?"** The Gap Register lists it: most sanctions anchors, the SOE blind re-check, dividend row upgrades, CA ratios, macro series.

*Plain-English companion: `PLAIN_ENGLISH_GUIDE.md`. Sign-off: `SIGNOFF_B.md`.*
