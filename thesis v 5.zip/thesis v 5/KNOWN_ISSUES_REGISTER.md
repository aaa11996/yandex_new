# KNOWN ISSUES REGISTER (input file for all agents)

Compiled 5 Oct 2026 from the working session with Asif; sections J and K added 6 Oct 2026, section L added 7 Oct 2026 (the newest section wins where it conflicts with earlier text). **Every item is a hypothesis for you to test, not a fact to trust.** The tag on each item says who established it and how well.

**Provenance tags**
- `[C-CODE]` Claude recomputed it on the files (scope stated). Still verify.
- `[R1A2]` Reported in Round-1 Agent 2's findings (`ROUND1_AGENT_2_FINDINGS.md`); Claude did not re-run it.
- `[R2A3]` Reported in Round-2 Agent 3's findings (`ROUND2_AGENT_3_FINDINGS.md`); Claude did not re-run it.
- `[DOC]` Stated in a repo or input document (file named); not independently verified.
- `[HYP]` Claude's hypothesis. Nobody has verified it.
- `[CORR]` A correction of something Claude said earlier in the session.

---

## A. Corrections to earlier statements (read first)

**A1 [CORR] The "median commutes with log" claim was wrong for even windows.** Claude earlier told agents that `median(ln x) = ln(median x)` because log is order-preserving. That holds only when the window has an odd count (one middle value). The ASVI window is 8 (even), so the median is the average of the two middle values, and averaging does not commute with log. Demo [C-CODE, arithmetic]: weekly counts 1, 2, 3, 4, 100, 100, 100, 100 → median of logs = 2.996; log of median = 3.951. Methodology v2.0 uses the first form; the founding paper's exact form must be confirmed from the PDF (W1). `[R2A3]` raised the same point independently.

**A2 [CORR] "Returns are set to missing on corporate-action rows" is true only for `RETURN_SAFE`.** `RETURN_RAW` keeps the jump: VTBR +8.48, GMKN −4.51, PLZL −2.31, ROLO −2.22 [C-CODE]. FINAL_REPORT says the return outcome is `RETURN_SAFE` [DOC]. Which column the analysis scripts actually read is unverified (the scripts are not in the repo).

**A3 [CORR] Several earlier "contradictions" are definitional differences, not conflicts.** From `data1/event_controls_report.md` [DOC]:
- Div∩Sanction = 3 is the overlap with the **five-week sanction-reaction union**; Div∩Sanction = 217 is the overlap with the **permanent Sanction step**. Both are right under their own definitions.
- 587 record dates, 529 record-week cells, 2,110 Div=1 weeks and 2,108 valid lagged cells are different **units**. The arithmetic bridge between them has not been shown (W8).
- "23 vs 34 anchors": 23 tested anchors; 24 compiled step companies; "34 anchors × 5-week window" is a carried concept in `Combined_Data_File.md` §2.5, labelled provisional.
- "FINAL_COMPLETE_METHODOLOGY.md": the file `yan 2/methodology_final.md` is itself titled "FINAL COMPLETE METHODOLOGY … Version 2.0". A separately named `FINAL_COMPLETE_METHODOLOGY.md` and `METHODOLOGY_REPLACEMENT_BLOCKS.md` are referenced by FINAL_REPORT but are **not in the repo**.

**A4 [CORR] Earlier prompts said the control matrices and daily data might be missing. They are present:** control matrices in `yan 2/data1/` (inside `yandex_final.zip`); daily and weekly MOEX files in `moex_panel_data.zip`. What is **not** in the repo: `FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md`, the `analysis/` scripts and results folder, `gl_bounds_published.csv`, `agent2b_soe.csv`, `news_i_t.csv` (Asif supplies the first two in the input pack). Also not in the repo: the `deliverables/` folder and `audit*.py` scripts mentioned by the 5 Oct draft (FIX1 CSVs, `*_weeklabel_FIXED.csv`); regenerate them.

**A5 [CORR] "Nearly identical slopes" overstated one case.** In Claude's simplified rerun, PHOR moved from −0.0171 to −0.0131 (still p≈.001). The others moved by about 0.002 or less. See B4 for the spec caveats.

---

## B. Price, volume and outcome data

**B1 [C-CODE] MOEX prices are not split/consolidation-adjusted.** VTBR ≈ 0.02 RUB before July 2024 and ≈ 96 RUB after.

**B2 [C-CODE] Four rows carry `CA_FLAG=1`:** GMKN 2024-04-08, PLZL 2025-03-24, ROLO 2023-01-16, VTBR 2024-07-15 (ratios 100:1, 10:1, dilution, 5000:1 are as stated in the panel's `CA_NOTE`; **not verified against issuer or exchange sources**). 17 rows carry `CA_CANDIDATE_FLAG`. RV is retained on the four flagged weeks (argument: ln(H/L) is scale-invariant when the whole week is post-event).

**B3 [C-CODE] `VOLUME` is a share count and breaks at corporate actions.** Median of the 26 weeks after vs before the event:

| Ticker | Δ ln(VOLUME) | Δ ln(VALUE) (rubles) |
|---|---:|---:|
| VTBR | −8.07 | +0.17 |
| GMKN | +4.82 | −0.02 |
| PLZL | +1.70 | −0.39 |
| ROLO | +3.82 | +1.75 |

`[R1A2]` found the same pattern independently. `lnV` (lagged log share volume) is a regressor in M1, M3 and M4 under v2.0, and is the "Vol_ratio" leg of the spike tests behind Crisis, the Sanction verification and the News layer.

**B4 [C-CODE] Simplified rerun, ASVI slope with `lnV` vs `ln(VALUE)` control.** Spec: per-firm OLS, RV on ASVI_l1, RV_l1 and the volume control; statsmodels HAC with 4 lags; **no** Crisis, Sanction or Div; row-order lags without calendar-gap handling; not equivalent to the FINAL_REPORT specification.

| Ticker | lnV β (p) | ln(VALUE) β (p) |
|---|---|---|
| SNGS | −0.0345 (.000) | −0.0354 (.000) |
| RTKM | −0.0357 (.000) | −0.0342 (.000) |
| LSRG | −0.0216 (.001) | −0.0207 (.002) |
| PHOR | −0.0171 (.000) | −0.0131 (.001) |
| MFGS | +0.0277 (.031) | +0.0273 (.033) |
| VTBR | −0.0014 (.934) | −0.0061 (.715) |
| GMKN | −0.0029 (.569) | −0.0069 (.299) |
| PLZL | +0.0020 (.811) | +0.0043 (.593) |
| SBER | −0.0171 (.207) | −0.0161 (.387) |

**B5 [C-CODE] Split-signature scan on the panel.** Only three weeks have |Δ ln VOLUME − Δ ln VALUE| above ln 10: GMKN, PLZL, VTBR, all already flagged. ROLO's event week is about 8.75× (below that threshold). A 10× screen cannot see a 2:1 split.

**B6 [C-CODE] SFIN, week of 2025-12-22 is unresolved.** Prior week: low 1,610, close 1,796, volume 3.4M, RV 0.136. Event week: low 931, close 961, volume 6.1M, high ≈ 1,833, **RV 0.678**. Next week: low 920, close 921, volume 1.0M, RV 0.055. Flagged as a candidate only; not masked. Cause (split-like event vs large dividend gap vs other) is unknown. RV is not scale-invariant if the event falls inside the week.

**B7 [C-CODE] `PARTIAL_WEEK_FLAG` is set on the final week (2026-08-31), yet `N_TRADING_DAYS = 5` in all 75 rows.**

**B8 [R1A2] Weekly bars rebuilt from daily files: 282,825 cells, zero mismatches.** Date rule, OHLC logic and VWAP test also reported as passing. Not re-run by Claude. Round-1 Agent 2 did not see FINAL_REPORT or the scripts.

**B9 [DOC] The Sunday-label convention differs by source.** investing.com weekly files: the Sunday label is the day **before** the Mon–Fri week (v2.0 §2). MOEX weekly files: the Sunday label is the week's **end** (e.g., SBER_weekly first row 2018-09-02). Panel rule: `SEARCH_MONDAY = MOEX_WEEK_END_SUNDAY − 6`. Any cross-source join must apply the right shift.

**B10 [HYP] Returns are price returns and ignore dividends.** Size of the distortion around ex-dividend dates is unknown.

**B11 [DOC/HYP] Tick-size quantization.** v2.0 excludes ROLO from every RV-involving model because of its 1-kopeck price grid. Whether other low-priced names or periods (e.g., VTBR before consolidation) are affected is `[HYP]`.

**B12 [DOC] Trading calendar claims, none checked against official MOEX announcements:** 3 full-market closure weeks (2022-02-28, 03-07, 03-14); 328 no-trade ticker-weeks; 7 weekly bars with high = low (coded missing). SBER's weekly file has 416 rows vs the 419-week grid.

**B13 [DOC] Two analysis runs exist.** OLD run on investing.com weekly prices: `EXECUTION_AND_BLOCKER_REPORT.md` (n = 29,445; 404 weeks; within-R² .161). NEW run on the MOEX panel: `FINAL_REPORT.md` (N = 29,642; within-R² .1331). Which price source each control layer (Crisis, Sanction verification, News) was derived from is **unverified**; the News layer says it was built "from the raw weekly OHLCV panel" without naming the source.

**B14 [HYP] The volume break (B3) may contaminate the spike tests that built Crisis, the Sanction verification, and News** in the weeks around GMKN 2024-04, VTBR 2024-07, ROLO 2023-01, PLZL 2025-03.

---

## C. Search data and ASVI

**C1 [DOC] Definition under v2.0.** SVI = ticker count + Cyrillic "<name> акции" count (summed before logs); Yandex uses YNDX + Cyrillic only; SVI = 0 is missing; ASVI needs 8 valid prior weeks. SVI counts queries, not unique investors `[R2A3]`.

**C2 [CORR]** Even-window median issue: see A1.

**C3 [DOC/HYP] The channel-combination rule.** Asif's description to his supervisor: if the ticker-vs-Cyrillic correlation is below 85%, the channels are summed. The exact statistic (levels, logs or ASVI) is in `UNIFIED_PAPER_about_state_ownership.md` §3.2 and Appendix B. FINAL_REPORT states all 74 non-Yandex firms are in the "sum" branch, with maximum correlation 0.807 (TRMK). `[HYP]` Low correlation between two noisy measures does not prove they come from different people: measurement noise also lowers correlation.

**C4 [R2A3/UNVERIFIED] No issuer-level validation of Yandex Wordstat was found in the literature.** The export header states "all regions, all devices", but operators and exact-match quoting used at collection are not documented. See §J1: the file does contain a documented share-of-total-queries column that v2.0 discards.

**C5 [DOC] YDEX is excluded by decision.** `iqbal thesis/Data/Tech/YNDX/` contains `YNDX.csv`, `YDEX.csv` (smaller file), `Яндекс акции.csv`, and the investing.com file `YANDEX Stock Price History.csv`.

**C6 [DOC] A 17-item data-quality registry (R1–R17)** sits in `UNIFIED_PAPER_about_state_ownership.md` (§3.5, Appendix C). Several handling rules in v2.0 §2 use investing.com Sunday labels (weeks 2024-06-16, 2024-08-25, 2022-02-27).

---

## D. Models and method

**D1 [R2A3] M2 (returns) is not market-adjusted.** M4's week fixed effects absorb common weekly shocks; per-firm M1/M2 do not. The only market-wide control in M1/M2 is lagged Crisis (a 0/1 stress flag).
**D2 [R2A3] H2 tests one horizon.** The founding attention literature describes price pressure followed by reversal over later weeks.
**D3 [R2A3] The sign of the attention effect varies across markets** in comparable studies; no universal sign is predicted.
**D4 [R2A3] Novelty is not established.** Three existing Russian papers touch the same space (Google/Wordstat attention with Russian stocks or stress). Do not claim "first".
**D5 [R2A3] Minor:** M2 omits lagged volume while M1/M4 include it.
**D6 [DOC] Reported results (context only; never a design input).** M4 pooled β=.001014, SE=.001833, p=.5803, MDE80=.005132 (`MDE ≈ 2.8×SE` reproduces this to rounding [C-CODE]); H4 p=.02668 (fragile); H5 p=.09763; H6 p=.18624 (earlier run ≈ .09).
**D7 [HYP] Survivorship and selection.** Universe = firms with usable data to 2026 and no ticker/name change; 19 candidates excluded; the handoff mentions delistings among excluded names. Effect unknown.
**D8 [DOC/HYP] Circularity.** v2.0 itself notes Crisis(t) is built from the same week's outcomes. The Crisis, Sanction-verification and News layers are all built from RV and volume spikes; News duration is data-driven (stays on while RV or volume ≥ 1.5× trailing median, capped at 4 weeks); News events were "confirmed" partly by a spike test. A control selected or timed by the outcome it controls can mechanically link to that outcome.
**D9 [HYP] Controls absent from v2.0 that comparable markets may use:** market/index return, USD/RUB, oil, key policy rate, size/liquidity, index-exclusion events (e.g., MSCI/FTSE), non-resident access restrictions. Literature support is not yet established.
**D10 [DOC] M5 (Chow).** Break at 2022-02-24; asymmetric reduced form; q = 3 against a k = 4 tabulation is a disclosed mismatch; chosen Giles–Lieberman row Cu(0.1,10] = 5.206 was hand-transcribed into `gl_bounds_published.csv`, which is **not in the repo**. Crisis W2 starts 2022-02-21 and FINAL_REPORT's post-period start was seen as 2022-02-21: consistency to check.
**D11 [DOC] Standing rule in v2.0:** if a step cannot be done exactly as written, stop and report; never substitute silently. Keep this spirit in v3.0.
**D12 [DOC] The panel "10/10" audit gates covered panel integrity only.** They did not catch B3.

---

## E. Event and control data (Part II material)

**E1 Crisis [DOC].** Four windows (Monday labels): W1 2020-02-24…04-13; W2 2022-02-21…03-28; W3 2023-09-04…09-18; W4 2026-06-22…07-27. Rule: firm spikes if RV ratio ≥ 2 AND volume ratio ≥ 2 vs own trailing-52-week median; stress week if ≥ 25% of eligible firms (≥ 30 trailing obs) spike; window confirmed if contiguous (one-week bridge) with peak ≥ 40%. Matrix: `data1/crisis_i_t.csv` (419 rows × 75 tickers). Seven rejected candidate windows are described in `Sanctions Events, Crisis Windows & Data Readiness.md` §4.2.

**E2 Sanction [DOC].** Permanent step from the first economically binding entity/parent/affiliate anchor week; 24 compiled step companies; 23 tested anchors (7 with confirmed price reaction, 13 not, 3 borderline); sources OFAC/OFSI/EU lists; matrices `data1/sanction_i_t.csv`, `data1/sanction_reaction_i_t.csv` (five-week union). The sanctions report has a section on documented access constraints (§5.3). Overlaps: Crisis∩Sanction = 204 company-weeks (permanent step), 2 of 23 anchor onsets, 10 reaction company-weeks.

**E3 SOE [DOC].** Rule: Russian state ≥ 25% voting control, direct or via a state-controlled holding; 1/0/UNDETERMINED. Published table: 35 SOE / 40 non-SOE (`Combined_Data_File.md` §5; `UNIFIED_PAPER…` Appendix A). The comparison table `agent2b_soe.csv` (34/41) **does not exist**, so H6 is provisional. VSMO is a knife-edge case (25% + 1 share). YAKG's sector label is disputed.

**E4 Dividends [DOC].** `data1/dividend_record_dates.csv`: 587 confirmed-paid record dates, 63 payers, 12 non-payers (JNOS, MFGS, RNFT, VJGZ, BLNG, CHMK, ROLO, UKUZ, UNAC, FESH, UTAR, MRKK), 18 announced-not-paid exclusions (`data1/phase1_exclusion_audit.csv`). Sources per row are smart-lab.ru, dohod.ru, T-Bank and the registry-closure site: **aggregators, not issuer filings**. Div = 1 for the four weeks before the record week. `[HYP]` Price drops happen at the **ex-dividend date**, which can fall in the week before the record week; and for firms with ordinary and preferred shares, dividends differ by class, so the table must match the traded share class in the panel.

**E5 News [DOC].** Rebuild dated 2026-09-21: 17 confirmed events, 12 companies, 54 company-weeks, vs old benchmark 31 events / 23 companies / 89 weeks. Weekly matrix `news_i_t.csv` is **absent**, so News-based models are "not estimable" per FINAL_REPORT. Six named provisional gaps (GMKN, MVID, BANE/CBOM/FEES/LKOH, empty categories EARN and LEAD, sanction-anchored discards, un-swept zero-event firms). e-disclosure.ru was unreachable to the builder.

**E6 Overlaps [DOC].** Div∩Crisis = 85; Div∩Sanction(step) = 217; documented list of 11 robustness-check candidates (AVAN, SBER, USBN, VTBR, AKRN, GCHE, NVTK, TATN, LSRG, RTKM, AFLT) vs a later reconstruction of 29–30 (unexplained).

---

## F. Literature corpus facts [C-CODE, file inspection]

`thesis books.zip` → `books/` holds **7 PDFs**:
1. `A SIMPLE, POSITIVE SEMI-DEFINITE,.pdf` (14 pp): the Newey–West covariance paper; **image-only, needs OCR** (text extraction returns 0 words).
2. `DeLongShleiferSummersWaldmann90.pdf` (37 pp): "Noise Trader Risk in Financial Markets", JPE 98(4), 1990.
3. `GSVI_India.pdf` (17 pp): investor attention and Google Search Volume Index, evidence from India, Research in International Business and Finance 50 (2019).
4. `Individual investors' trading behavior in Moscow Exchange and the COVID-19 crisis.pdf` (14 pp): J. of Behavioral and Experimental Finance 31 (2021) 100549.
5. `information-demand-and-stock-market-volatility-3f9rke46sb.pdf`: Vlastakis & Markellos, J. of Banking & Finance 36 (2012) 1808–1821. **Only 3 pages are in the file** (the article is 14 pages); claims beyond those pages cannot be verified from the corpus.
6. `Paul Gao Paper.pdf` (50 pp): Da, Engelberg & Gao "In Search of Attention", **a June 2010 working-paper draft**, not the 2011 published version; page numbers differ.
7. `canterbury-nz-034.pdf` (22 pp): Canterbury (NZ) department working paper with the Giles–Lieberman tabulation; text layer exists but is noisy.
Not in the corpus: Benjamini–Hochberg (1995), Alizadeh–Brandt–Diebold (2002), Parkinson (1980), Barber–Odean, Merton (1987), and every emerging-market comparable.

---

## G. Process lessons

- Agents cannot see each other's sandboxes. Past agents cited files that existed only in their own sandbox. Every handoff needs a manifest and hashes.
- Templated "all verified" lists hid problems. Evidence must be row- or company-level.
- Round-1 Agent 2 and Round-2 Agent 3 did not have `FINAL_REPORT.md` or the handoff; the repo root does not contain them.

## H. Supervisor and thesis context

Supervisor (econometrics, HSE) agreed to supervise. Working title: "Web Search Queries and Market Movements: Evidence from the Russian Equity Market" (the title may be corrected later if the data or trajectory changes). The supervisor suggested starting the literature review and settling the model and data. Reader of the methodology: a Master's committee, not a research-frontier referee.

## I. Standing preferences of the author

Plain-English explanations with small demos. Direct, honest assessment; no empty reassurance. **Do not modify his abstract or framework text.** New methodology goes in new files.


---

## J. Findings added after this register was first issued (6 Oct 2026)

**J1 [C-CODE + official help page] The Wordstat share column is documented and consistent.** Every raw file has three data columns: week, "Number of queries", and "Percentage of total queries, %". Yandex's Wordstat help (yandex.ru/support2/wordstat/ru/interface/new) defines the share as the number of queries containing the phrase divided by the total number of queries to Yandex in the selected region. Test on all 75 firms × 2 channels: `count ÷ (share/100)` gives one common total per week, with spread across about 145 queries of under 1% (median CV 0.7%). The share is rounded to 2–3 significant digits, so the total is best estimated as the median across all queries, not read from one row. Implied total weekly Yandex queries (billions): 1.62 (2018-08-27), 1.76 (2019-12-30), 2.87 (2020-04-13), 2.90 (2022-02-28), 2.45 (2023-09-04), 2.17 (2024-12-30), 2.54 (2026-08-24). 2,961 channel-weeks have count 0 (share 0).

**J2 [C-CODE] Effect of normalising by total traffic.** ASVI on counts vs ASVI on count ÷ D_t (same v2.0 formula): pooled correlation 0.977. Week-average ASVI across firms, counts vs normalised: 2020-04-06 +0.051 vs −0.182 (total traffic +0.231); 2024-12-30 −0.631 vs −0.394 (total traffic −0.239); 2023-09-04 +0.250 vs +0.175. Correlation of the week-average count-ASVI with the total-traffic jump: 0.46. My re-computation of the panel's count-ASVI reproduces it exactly (max |diff| 4e−16, n = 30,532).

**J3 [C-CODE] Market-wide attention.** Share of ASVI variance common to the week: 16.6% (counts), 13.2% (normalised). Each firm's ASVI vs the market-average ASVI: median correlation 0.43 (range 0.20–0.63). In the pooled firm+week fixed-effects regression the ASVI slope is identical whether ASVI is raw or has the weekly cross-sectional mean removed (0.001403 both; N = 29,642; simplified spec with ln VALUE control, no Div/Sanction, no Driscoll–Kraay). In per-firm simplified M1 (HAC 4, ln VALUE control; **sensitivity only**): nominal p<.05 in 14 of 74 firms with raw ASVI, 12 with the market average as a control, 10 with the market average subtracted. Of the five H1 survivors: LSRG, RTKM, SNGS hold; MFGS (p .033 → .063 control, .054 subtracted) and PHOR (p .001 → .133 control, .085 subtracted) weaken.

**J4 [C-CODE, PDF page 1] Corpus identification.** `GSVI_India.pdf` is Swamy, Dharani & Takeda (2019). `information-demand-and-stock-market-volatility-….pdf` is Vlastakis & Markellos (2012); its abstract states that information demand and supply are studied at the firm and market level and that idiosyncratic and market-wide information are separated. Swamy et al. build excess returns as return minus the stock's **52-week** rolling beta times the market return (a 104-week window is a suggestion in an earlier answer, not what that paper does).

**J5 [mixed] The 5 Oct prior draft (`FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md`).** *Verified or consistent:* `week_sunday = week_monday − 1` in `crisis_i_t.csv` (checked on that file; the draft says all four) [C-CODE]; ASVI median-of-logs vs log-of-median mismatch is real [C-CODE arithmetic; its reported materiality (corr .9998, 87 sign flips, 75/75 significance concordance) is unverified]; the control matrices' counts (Crisis 1,725 firm-weeks; Sanction step 24 firms, 3,687 firm-weeks; reaction 35 windows, 181 firm-weeks; Div 2,110 firm-weeks) are the draft's figures [DOC]. *False or wrong:* (i) "No Vlastakis and no Swamy are in the corpus": both are (J4). (ii) "MOEX has run regular weekend sessions since 2022; 228 of 232 Saturdays are missing; VOLUME and HIGH/LOW are biased in ~55% of post-2022 weeks": MOEX press releases (moex.com/n93219, moex.com/n93256) state that weekend equity sessions **began 1 March 2025** and are part of the **next trading day**, with weekend volume about 7% of weekday volume (Mail.ru Finance citing MOEX); MOEX's own daily files contain only 8 Saturday dates (4 since April 2022). Nothing is "missing"; weekend trades after March 2025 are attributed to the next trading day, a small timing quirk. (iii) "Newey–West data-driven rule gives m = 9": `floor(4·(T/100)^(2/9))` equals 5 for T = 400 or 419 (the draft used 2.44 for (4)^(2/9), which is 1.36). (iv) It calls smart-lab.ru a "primary source"; it is an aggregator (T3). (v) It admits its first dividend table contained 36 of 93 invented rows. *Unverified:* the claim that settlement moved from T+2 to T+1 on 2023-07-31; the external anchors it cites for Crisis W4 (June–July 2026); the sanctions verification (20 verified, 3 parent-level, AFLT single-source, AVAN excluded); the 8-of-8 dividend spot check. *Also notes (DOC):* the 2022-09-19 mobilisation week lies outside all four crisis windows despite a large attention spike (GAZP Cyrillic 160,577 → 214,597 → 270,996 per the draft); payment and announcement dates are not in the dividend table; 58 record dates precede the panel start (2018-01-08 … 2018-06-01); 38 record dates fall on weekends (legal in Russia).

**J6 [C-CODE] Repo root on 6 Oct 2026:** `README.md`, `combined_panel.zip`, `moex_panel_data.zip`, `yandex_final.zip`, `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md`. Latest commit message: "semi final without total yandex and moex".

**J7 [C-CODE]** The pooled sample size in my simplified two-way fixed-effects run (74 firms, ROLO out, rows with all lags) is 29,642, the same N as FINAL_REPORT's M4.


---

## K. Review of the v3 draft and results, and the scale question (6 Oct 2026)

**K1 [C-CODE] Repo state.** Root files: `README.md`, `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md` (5 Oct draft), `THE_FINAL_MOEX_ASVI_METHODOLOGY_AND_DATA_COMPENDIUM_v3.md`, `THE_v3_RESULTS_AND_DEFENSE_PLAYBOOK.md`, `all data final.zip` (folders `combined data for all 75 companies/` (75 files, 39 columns, IMOEX included), `raw data/`, `books/`), `moex_panel_data.zip`. `combined_panel.zip`, `yandex_final.zip` and `build_combined_panel.py` were deleted from the current files in commits `b648ad9`, `138f215`, `0c543f7`. `yandex_final.zip` is recoverable at `https://github.com/aaa11996/yandex_new/raw/2c5d6d5/yandex_final.zip` (valid zip, 25 entries, includes `data1/`).

**K2 [C-CODE] Independent replication of the v3 results, using the ORIGINAL control matrices from history (Crisis 1,725, Sanction 3,687, Div 2,110 firm-weeks), joined on `week_monday`.** Canonical ASVI reproduces the panel's `ASVI` exactly (max difference 4e−16, n = 30,532). Per-firm M1 (RV on ASVI_{t−1}, RV_{t−1}, lnV_{t−1}, Crisis_{t−1}, Sanction_{t−1}, Div_{t−1}; HAC 4; ROLO out): 12 nominal, 6 BH, 3 Holm, mean slope −0.00453, 55 of 74 negative; survivors AFKS −0.0165, LSRG −0.0212, MFGS +0.0456, PHOR −0.0165, RTKM −0.0399, SNGS −0.0338: identical to the v3 playbook. Pooled firm+week FE (Driscoll–Kraay 4): ASVI β = +0.000785 (t 0.43) on RV, N = 29,642; +0.001173 (t 0.78) on market-adjusted returns, N = 29,554; idiosyncratic and canonical ASVI give identical pooled slopes. H5 on market-adjusted returns: ASVI×Div = −0.02224 (t −4.37). Simplified: no calendar-gap-aware HAC; the v3 reconstruction of the controls evidently did not move the results.

**K3 [C-CODE] H5 is partly mechanical.** Using the original dividend table (587 paid dividends, 63 firms) and approximate ex-dates (record date, minus one business day before 2023-07-31; no holiday calendar; the T+1 date is confirmed on MOEX's own site): 528 firm-weeks are ex-dividend weeks; the market-adjusted return averages −5.1% in them vs +0.1% otherwise; all of them fall inside the outcome weeks flagged by Div_{t−1} = 1 (by construction); inside that window last week's ASVI is higher in ex-weeks (0.143 vs 0.088). Adding the dividend back in the ex-week, the H5 interaction moves from −0.02224 (t −4.37) to −0.01001 (t −2.84) with the main mapping, −0.00749 (t −2.15) if the ex-week is the record week, −0.01234 (t −3.16) if it is the week before. 34–56% of the price-only effect remains.

**K4 [DOC] H3.** The v3 playbook's Variant A (intercept and slopes) gives F = 63.86; its slope-only variant gives F = 4.70 (p = .0091), below the 5.206 Giles–Lieberman value it uses, with 2 of 74 firms. The playbook nevertheless says the conclusion is identical under both. A level shift in volatility after February 2022 is not evidence that the attention effect changed.

**K5 [C-CODE] Volume unit matters in the full specification.** Replacing lnV by ln(VALUE) in the per-firm M1: nominal 12 → 11, BH 6 → 5, Holm 3 → 2, mean slope −0.00453 → −0.00396, negative 55 → 49. AFKS (not a split firm) drops out: p .0023 → .0064 against a BH line of .0041 for the sixth test. Survivors then: LSRG, MFGS, PHOR, RTKM, SNGS. The v3 methodology does not mention the volume unit break.

**K6 [C-CODE] Idiosyncratic ASVI in per-firm M1:** nominal 11, BH 2, Holm 2, mean slope −0.00310, 45 of 74 negative; survivors MFGS, RTKM. In the pooled model the choice is irrelevant (K2).

**K7 [C-CODE] Scale diagnostics (all 75 firms).** Median weekly SVI by firm: minimum 22 (MRKK), 10th percentile 112, median 971, 90th percentile 9,851, maximum 86,842 (MGNT); SBER 41,809, GAZP 75,193. ASVI is a log ratio, so a +10% move is +0.095 for 700 or for 30,000 queries. Noise is not scale-free: median sd of ASVI by size quartile (smallest → largest): 0.49, 0.36, 0.30, 0.26. Loading of each firm's ASVI on the market-median ASVI: median 1.08, 10th–90th percentile 0.64–1.39, lowest AVAN 0.28, MGTS 0.40, BANE 0.49, highest RNFT 1.89, AKRN 1.53, SELG 1.42; SBER 0.76. Share of a firm's ASVI variance explained by the market (R²) by size quartile: 0.09, 0.18, 0.28, 0.23 (correlation of log level with R² = 0.49; with the loading = −0.28). Subtracting the market median changes the variance of ASVI by −9%, −17%, −26%, −22% (smallest → largest) and **raises** it for 4 of 75 firms; removing a firm-specific loading instead changes it by −9%, −18%, −28%, −23%. So the worry that subtraction wipes out small firms is not what the data show (it changes them least); the real issues are noise that differs by size and the imposed loading of 1.0.

**K8 [C-CODE/DOC] Errors in the v3 documents.** (i) "Controls absent from git history": false (K1). (ii) Newey–West data-driven lag stated as 9; it is 5 (4×(4.11)^(2/9) = 5.5). In my replication, 4, 5 and 9 lags give 12, 11 and 13 nominal rejections and the same six BH survivors and three Holm survivors. (iii) ASVI attributed to "Da–Engelberg–Gao (2015)": the paper is 2011; the corpus PDF is a June 2010 draft. (iv) Weekend equity sessions described as missing from the feed: the daily files fold them into the next trading day; median (75 firms) Monday/Tue–Fri turnover ratio is 1.036 for 2024-03-04…2025-02-24 and 1.201 for 2025-03-03…2026-08-24 (0.990 for 2023-03-06…2024-02-26). (v) "Pre-registered" used for choices made after seeing v2.0 results. (vi) §1.4 says the idiosyncratic ASVI complements week fixed effects; the pooled slope is identical. (vii) Self-issued "10/10 approved" gates while (i)–(vi) stand. (viii) The v3 reconstruction used 572 record dates and 57 firms (dohod.ru) vs the original 587 and 63.

**K9 Not checked by Claude.** Live MOEX index feed (sandbox cannot reach it); sanctions anchors and 2026 events; Crisis external anchors; M6 and the power analysis; SOE classification; the News events; H2 and H4/H6 tables.


---

## L. Review of Methodology v4.0 and what the data-completion round must close (7 Oct 2026)

**L1 [C-CODE] Repo state.** Root files: `README.md`, `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md`, the v3 compendium and results playbook, `all data final.zip`, `moex_panel_data.zip`, and **`old work data and results.zip`** (43 entries: control matrices, the 587-row dividend table, `FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md`, `FINAL_COMPLETE_METHODOLOGY.md`, `methodology_final.md`, the Sanctions/News/Combined_Data documents, `VERIFICATION_FINDINGS_2026-10-05.md`). The v4.0 file and its `DATA/` folder are not in the repo; Asif uploads `METHODOLOGY_v4_0_FINAL.md` to `blueprint_round/inputs/`.

**L2 [C-CODE] What reproduces from v4.0.** M1 with ln(VALUE): 11 / 5 / 2 nominal / BH / Holm at bandwidth 4; **10 / 5 / 2 at bandwidth 5** (v4.0 §6.5 quotes 11 under a bandwidth-5 model; survivor sets are the same). Pooled M4 +0.000785 (t 0.43). H5 price-only −0.0222 → −0.0072 in v4.0; Claude's range −0.0075 to −0.0123 depending on ex-date timing. Newey–West rule 5; T+1 31 July 2023; closure 225 ticker-weeks; Crisis 1,725 cells; D_t CV 0.7%.

**L3 [C-CODE + 3 T3 sources] SFIN week of 2025-12-22 is a dividend, not a split.** 902 RUB per share (9M-2025), record date 2025-12-25, last cum-dividend day 2025-12-24 (investmint.ru, dohod.ru, investfunds.ru; all T3; the issuer filing is still needed). Price 1,796 → 961 matches 902/1,796 = 50%. The panel's flagged "candidate" is therefore a dividend gap.

**L4 [C-CODE] RV carries the same dividend mechanics as returns.** For 358 ex-dividend weeks with at least one cum-dividend day in the week (original 587-row table; approximate ex-dates; additive subtraction of the dividend from the pre-ex daily highs and lows): mean RV 0.1022 → 0.0762 (−25.5%), median change −19.6%; RV falls by more than 10% in 62% of these weeks, more than 25% in 44%, more than 50% in 18%; SFIN 0.678 → 0.185. Per-firm M1 (v4.0 spec, bandwidth 5): 10 / 5 / 2 and the same five survivors with or without the adjustment; pooled ASVI slope +0.000804 (t 0.45) → +0.000367 (t 0.21). v4.0 adjusts returns (V4-05) but not RV. Remedy: Amendment V4-28.

**L5 [HYP] Market leg inconsistency.** v4.0's adjusted return adds dividends back to the stock but subtracts IMOEX, a price index. The MOEX total-return index was not retrieved (GAP-15). Pooled models are insulated through week fixed effects; per-firm models carry a seasonal mean difference around June–July. Remedy: Amendment V4-29.

**L6 [DOC] Open gaps in v4.0 (Part II §§11–18):** sanctions: 4 of 24 anchors checked (ROSN, LKOH, SIBN, SNGS, from secondary summaries), 20 not re-verified, negative verification of 51 firms not done, AVAN unverified, AFLT single-source, the four 2026-04-20 anchors (AVAN, BANE, JNOS, MFGS) unverified; ownership: blind double classification not performed (H6 provisional); dividends: aggregator sources only, ex-dates approximated; corporate actions: ratios for GMKN, VTBR, PLZL, ROLO unverified against issuer or MOEX filings, no scan below a 10× threshold; market series: USD/RUB, Brent, key rate, total-return index not retrieved; crisis: external anchors for the 2026 window unverified; news: excluded; survivorship registry of the 19 excluded firms not reproduced.

**L7 [DOC] Small points in v4.0.** The sentence "the v2.0 form differs only on even-window ties" is wrong: the forms differ whenever the two middle values differ. The change log has no ruling for CA-15 (macro series) or CA-23 (scale); S17, S18 and S21 are listed as sensitivities and limitation 4 mentions the noise, but there is no decision entry.
