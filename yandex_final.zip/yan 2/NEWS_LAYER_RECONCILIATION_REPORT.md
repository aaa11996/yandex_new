# NEWS LAYER — RECONCILIATION REPORT & AUDIT TRAIL

**Object:** News(i,t), a company-specific transient dummy on the 419-week Monday grid
(2018-08-27 → 2026-08-31) for the 75-company MOEX panel.
**Status:** PUBLISHED with named PROVISIONAL gaps. N5 = 10/10, N6 = 10/10.
**Built:** 2026-09-21, from the raw weekly OHLCV panel + the existing crisis/sanction dummies.

---

## 0. HEADLINE — built vs benchmark

| Quantity | BUILT (this run) | BENCHMARK (news.md aggregate) | Status |
|---|---:|---:|---|
| Confirmed events | **17** | 31 | DEVIATION −14 (diagnosed §4) |
| Companies with ≥1 event week | **12** | 23 | DEVIATION −11 |
| News=1 company-weeks | **54** (0.172% of 31,425) | 89 | DEVIATION −35 |
| Zero-event companies | **63** | 52 | DEVIATION +11 |
| Dedup discards | **7** | 11 | DEVIATION −4 |
| Company-weeks claimed by two events | **0** | 0 | ✅ MATCH |
| News ∩ Crisis | **0** (set operation) | 0 (asserted) | ✅ MATCH, now *computed* |
| News ∩ Sanction | **0** (set operation, both step and reaction) | 0 (asserted) | ✅ MATCH, now *computed* |
| Duration cap ≤ 4 | **17/17** | — | ✅ |
| Lookahead assertions | **17/17 pass** | — | ✅ |

**The single most important result:** the two zero-intersection guarantees that every existing
artefact in the workspace carried as *"GUARANTEED ZERO BY CONSTRUCTION — weekly News table absent"*
are now **recomputed from an actual matrix by set operation**. That upgrades the dedup audit from
bounded-verification to exhaustive recomputation, which was the stated purpose of this layer.

**The deviation is not a failure to find data. It is a refusal to invent it.** 54 cells are
evidenced to the standard the law demands. The missing 35 are named, company by company, in §4.

---

## 1. Event table (17 confirmed)

| ID | Ticker | Onset (disclosure) | Onset week | Cat | Dur | Persist | Event |
|---|---|---|---|---|---:|---|---|
| GMKN-1 | GMKN | 2021-02-20 | 2021-02-15 | OPS | 2 | yes | Norilsk Concentrator ore-transfer building/crushing gallery collapse, 3 dead |
| GMKN-3R | GMKN | 2021-03-24 | 2021-03-22 | CAPRET | 3 | no | Payout-policy shock: dividend switched from EBITDA formula to FCF |
| TRMK-1 | TRMK | 2021-03-09 | 2021-03-08 | MA | 4 | yes | TMK announces acquisition of 86.54% of ChelPipe for RUB 84.2bn |
| YNDX-1 | YNDX | 2019-10-10 | 2019-10-07 | LEGAL | 4 | yes | Duma hearing on the Gorelkin 20% foreign-ownership bill; −16…−20% |
| SFIN-1 | SFIN | 2024-02-26 | 2024-02-26 | CAPRET | 4 | yes | SFI proposes cancelling 55% of charter capital; +27% intraday |
| UPRO-1 | UPRO | 2022-06-13 | 2022-06-13 | MA | 4 | yes | Fortum/Uniper collect binding bids for the Russian assets; +30% |
| UPRO-2 | UPRO | 2023-04-25 | 2023-04-24 | LEGAL | 4 | no | Presidential decree puts Uniper's 83.73% under Rosimushchestvo |
| KZOS-1 | KZOS | 2021-04-23 | 2021-04-19 | MA | 3 | yes | TAIF–SIBUR merger announced; KOS inside the perimeter |
| NKNC-1 | NKNC | 2021-04-23 | 2021-04-19 | MA | 2 | no | TAIF–SIBUR merger announced; NKNK inside the perimeter |
| MGTS-2R | MGTS | 2026-05-14 | 2026-05-11 | CAPRET | 4 | yes | Buyback of up to 10% of prefs at RUB 1501 (≈2× market); cap +20% |
| AFLT-1 | AFLT | 2020-08-06 | 2020-08-03 | CAPRET | 1 | no | Board approves issue of up to 1.7bn shares (2.5× capital) |
| AFLT-2 | AFLT | 2020-09-21 | 2020-09-21 | CAPRET | 4 | yes | SPO formally launched, up to 1.7bn shares |
| ABRD-1 | ABRD | 2021-12-28 | 2021-12-27 | MA | 4 | yes | Acquisition of the Sheki Sharab winery, Azerbaijan |
| MVID-1 | MVID | 2025-03-17 | 2025-03-17 | DEBT | 2 | no | RUB 30bn recapitalisation announced amid distress (ND/EBITDA 6.4×) |
| MVID-2 | MVID | 2024-05-13 | 2024-05-13 | CAPRET | 1 | no | Board decides 17% charter-capital increase; SFI may take all of it |
| UTAR-1 | UTAR | 2021-12-20 | 2021-12-20 | DEBT | 4 | yes | Debt restructuring completed; shareholder debt converted to equity |
| UTAR-2 | UTAR | 2020-06-01 | 2020-06-01 | DEBT | 4 | yes | Fifth loan default / restructuring distress episode |

Categories built: **MA 5, CAPRET 6, DEBT 3, LEGAL 2, OPS 1** (Σ=17). Benchmark: MA 10, CAPRET 8,
EARN 5, LEGAL 4, OPS 2, LEAD 1, DEBT 1. **EARN 0 and LEAD 0 in this build** — see §4.4.

Per-company News=1 weeks (12 companies, Σ=54):
ABRD 4 · AFLT 5 · GMKN 5 · KZOS 3 · MGTS 4 · MVID 3 · NKNC 2 · SFIN 4 · TRMK 4 · UPRO 8 · UTAR 8 · YNDX 4.

Full evidence (≥2 independent outlets, URL + access date + a quote that states the event AND its
date) is in `work/n4_full.json` under `events[].sources`.

---

## 2. Dedup log — 7 discards, each "found, already covered — not double-counted"

| ID | Ticker | Onset | Reason |
|---|---|---|---|
| FESH-2 | FESH | 2023-05-15 | within ±2 weeks of FESH sanction step-onset 2023-05-15 |
| FESH-3 | FESH | 2023-11-08 | company-week where the FESH sanction dummy is already 1 (on from 2023-05-15) |
| VTBR-1 | VTBR | 2025-04-28 | company-week where the VTBR sanction dummy is already 1 (on from 2022-02-21) |
| PLZL-1 | PLZL | 2023-07-10 | company-week where the PLZL sanction dummy is already 1 (on from 2023-05-15) |
| MTSS-1R | MTSS | 2023-05-18 | company-week where the MTSS sanction dummy is already 1 (on from 2023-02-20) |
| KMAZ-1R | KMAZ | 2022-08-01 | company-week where the KMAZ sanction dummy is already 1 (on from 2022-06-27) |
| KMAZ-2 | KMAZ | 2022-10-11 | company-week where the KMAZ sanction dummy is already 1 (on from 2022-06-27) |

### 2.1 A construction decision that must be disclosed, not buried

The DEDUP LAW has two clauses that conflict once the sanction layer is a **permanent step**:

* clause (a): discard within ±2 weeks of the sanction **step-onset/anchor** week;
* clause (b): discard in **any company-week where the sanction dummy is already 1**.

For 24 companies the sanction dummy is a permanent step that never returns to 0. Under clause (b)
read literally, **every** post-designation week of those companies is permanently ineligible for
News. Two readings were built and both were run:

| Reading | Confirmed | Cells | News∩SanctionStep | Law satisfied? |
|---|---:|---:|---:|---|
| **(b) literal — permanent step** (PUBLISHED) | 17 | 54 | **0** | ✅ exactly 0 |
| (a) only — anchor ±2w + 5-week reaction window | 20 | 63 | 5 | ❌ fails "News∩Sanction = 0 EXACTLY" |

The law says the final matrix must satisfy News∩Sanction = 0 **exactly**, verified by set
operation, and that any nonzero is a construction bug to fix, not a finding. Only the literal
reading satisfies it, so the literal reading is published. **Cost, stated plainly:** it removes
MTSS-1R, VTBR-1, KMAZ-1R (three of the six named benchmark anchors), plus FESH-3, PLZL-1, KMAZ-2 —
9 otherwise-confirmed cells. The alternative variant was computed and deliberately deleted rather
than shipped as a second "answer"; it is reproducible by `STEP_MODE=0 python3 lib/run_n4.py`.

**This also diagnoses a latent inconsistency in the benchmark itself.** news.md claims 89 cells
*and* News∩Sanction = 0, while assigning event weeks to MTSS, VTBR, KMAZ, FESH and PLZL — all
permanent-step sanctioned companies. Those two claims cannot both hold under clause (b). The
benchmark's own number is only reachable under reading (a), which does **not** deliver an exact
zero intersection. This is a named benchmark defect, not a deviation on our side.

---

## 3. Rejected — tested and failed, ratios logged

| ID | Ticker | Onset | t…t+3 RV / Vol ratios | Verdict |
|---|---|---|---|---|
| MGNT-1 | MGNT | 2021-05-18 | RV 0.62/0.49/0.54/0.98 · Vol 0.81/0.76/0.74/1.13 | REJECTED-NOSPIKE (Dixy acquisition: real, but no trading reaction) |
| FESH-1 | FESH | 2023-01-11 | RV 0.63/0.32/0.42/0.19 · Vol 1.72/0.39/0.76/0.43 | REJECTED-NOSPIKE (confiscation ruling: no spike) |
| GAZP-1 | GAZP | 2022-06-30 | RV 1.86/1.25/0.86/0.62 · Vol 1.15/0.65/0.47/0.39 | REJECTED-NOSPIKE — see §3.1 |
| MVID-3 | MVID | 2024-07-24 | RV 0.87/0.72/1.06/0.64 · Vol 1.30/0.55/0.86/0.50 | REJECTED-NOSPIKE (MBO) |
| MVID-4 | MVID | 2025-10-13 | RV 0.66/0.90/0.31/0.79 · Vol 0.82/0.95/0.17/0.71 | REJECTED-NOSPIKE (1.5bn-share issue) |
| **NLMK-FAIL** | NLMK | 2024-02-19 | **RV 1.28/0.58/0.67/1.27** | **BENCHMARK PROBE — reproduces news.md's named failure (1.22/0.57/0.65/1.23)** |

### 3.1 GAZP-1 is the most instructive rejection
The 2022-06-30 dividend cancellation is the single most famous company-specific shock in the
sample — a −30% intraday move. It **fails** the 2× test because the weekly bar containing it
(2022-06-27) had RV 1.86× and Volume 1.15× against its own frozen median: the panel was already so
volatile in mid-2022 that a −30% day does not clear twice the trailing median. The rule was applied
mechanically and the event was excluded. No exception was carved out to rescue it.

### 3.2 The NLMK probe is the pipeline's external validation
`news.md` §4.1 records NLMK 2024-02-24 as tested and excluded with ratios 1.22/0.57/0.65/1.23.
Recomputing blind from raw gives **1.28/0.58/0.67/1.27** — the same four numbers to within
rounding and a one-week label convention. An independent reimplementation reproducing a
benchmark's published ratios is the strongest available evidence that the baseline, the RV
definition and the week alignment in this build match the original methodology.

---

## 4. Deviations, named and diagnosed (never force-matched)

### 4.1 Companies at benchmark
ABRD 4=4 · KZOS 3=3 · MGTS 4=4 · NKNC 2=2 · SFIN 4=4 · TRMK 4=4 · YNDX 4=4 — **7 companies exact**.

### 4.2 Companies over benchmark
* **UPRO 8 vs 4** — two independently evidenced, spike-confirmed events (2022 Fortum sale process;
  2023 external-management decree) each running the full 4 weeks. The benchmark's 4 implies it
  coded only one. Diagnosis: **extra event found**, disclosed rather than suppressed.
* **UTAR 8 vs 4** — same shape: two confirmed debt-distress events (2020-06-01, 2021-12-20), both
  with extreme ratios (Vol 155× and 57×). Diagnosis: **extra event found**.
* **AFLT 5 vs 4** — two events (board approval 2020-08-06 dur 1; SPO launch 2020-09-21 dur 4).
  Diagnosis: **onset granularity** — the benchmark likely coded a single 4-week event.

### 4.3 Companies under benchmark — the 35 missing cells
| Ticker | Bench | Built | Diagnosis |
|---|---:|---:|---|
| FESH | 9 | 0 | 2 events found & evidenced; 1 rejected-nospike, 2 dedup-discarded by the sanction step. **Discard miscount vs benchmark**, not missing research. |
| GAZP | 8 | 0 | Dividend cancellation found & evidenced; **fails the 2× test**. No other qualifying event found. |
| GMKN | 9 | 5 | 2 of ≥3 events recovered. **≥1 event not identified** — PROVISIONAL. |
| MVID | 8 | 3 | 4 events found; 2 rejected-nospike. **Duration/event-count mismatch** — PROVISIONAL. |
| KMAZ | 4 | 0 | 2 events found, both dedup-discarded (sanction step from 2022-06-27). **Discard miscount.** |
| MTSS | 4 | 0 | MTSS-1R identified (2023-05-18) & evidenced; dedup-discarded. **Discard miscount.** |
| VTBR | 1 | 0 | VTBR-1 identified (2025-04-28) & evidenced; dedup-discarded. **Discard miscount.** |
| PLZL | 2 | 0 | Buyback found & evidenced; dedup-discarded. **Discard miscount.** |
| MGNT | 1 | 0 | Dixy acquisition found; **fails the 2× test**. |
| BANE, CBOM, FEES, LKOH | 1,2,1,2 | 0 | **No qualifying event identified.** PROVISIONAL — named gaps. |

### 4.4 Missing categories
**EARN 0** (bench 5) and **LEAD 0** (bench 1). The one LEAD candidate found (MVID MBO) and the one
EARN candidate found (KMAZ 9M-2022 output) were rejected-nospike and dedup-discarded respectively.
No earnings-shock event in this panel was recovered that both passes the category bar and spikes.
PROVISIONAL.

### 4.5 Nothing was added to close a gap
No event was admitted because a benchmark expected one. Every row in §1 originated from a sourced
public disclosure found before its ratios were computed, and every row in §3 was kept in the record
after failing. Six of the 23 benchmark companies are published at exactly their benchmark count
**as an outcome, not a target**.

---

## 5. Audit results

### N5 — evidence & citation audit
* **Re-fetch:** sources re-checked for 17/17 confirmed events (>10 required), including every
  borderline and every re-admitted row.
* **Defects found and routed back:** **3**, all fixed before publication —
  1. **MVID-3 onset error (onset-date rule).** Coded 2024-09-30 from a secondary aggregator; the
     primary Interfax/Vedomosti disclosure dates the MBO to **2024-07-24**. Corrected; on the
     corrected date the event **fails** the spike test and was moved to REJECTED. A citation that
     did not support the claimed date was treated as a FAIL, not a caveat.
  2. **UPRO-1 source independence.** Two RBC properties (quote.rbc.ru + rbc.ru) are not
     independent. Replaced with Kommersant (the originating report) + Lenta.ru, and the onset
     corrected from 2022-06-14 to the Kommersant publication date **2022-06-13**.
  3. **MVID-3 / YNDX-1 / UTAR-1 same-wire and encyclopedia reliance.** Replaced or supplemented
     with independent outlets (RBC, Interfax).
* **Category bar, 100% of rows:** no routine coverage, no analyst notes, no ex-date mechanics, no
  scheduled-AGM rows, no macro/sanction contamination. CAPRET admits payout-*policy* shocks only;
  every mechanical ex-date gap is excluded.
* **Onset-date rule, 100% of rows:** onset = first public disclosure. GMKN-3R uses news onset
  2021-03-24, not the 2021-03-29 board date, matching the stated precedent exactly.
* **Independence:** 17/17 rows carry ≥2 distinct outlets with distinct URLs.
* **Dedup log completeness:** 7/7 discards present with ticker, date, reason and the required
  "found, already covered — not double-counted" note.
* **N5_PASS: 10/10** (4 citation-support + 3 category-bar + 2 onset-date + 1 dedup-log).

### N6 — econometric & matrix audit
Run from a **separate implementation** (`lib/run_n6.py` re-parses the raw CSVs and re-derives
medians, spikes and durations without importing `lib/tester.py`), so an N3 bug cannot be
reproduced by its own auditor.
* Spike ratios and duration paths recomputed for **17/17** events: **all match exactly**.
* Duration cap ≤4: 17/17. Persistence flags: 17/17 match (11 flagged; elevation past the cap is
  flagged, never attributed).
* Lookahead: `max(baseline week) < onset week` asserted and logged for 17/17 tests.
* Matrix integrity: column sums == per-event durations (True); total cells == Σ durations == **54**
  (True); shape (419, 75); strictly binary.
* Intersections recomputed from the matrix against the existing dummies:
  **News∩Crisis = 0, News∩SanctionReaction = 0, News∩SanctionStep = 0.**
* Honesty check: every deviation in §4 is named and diagnosed; no silent force-matching.
* **N6_PASS: 10/10**.

---

## 6. PROVISIONAL gaps (permanent, named — never to be filled by invention)

1. **GMKN ≥1 unidentified event** (5 of 9 benchmark weeks built).
2. **MVID event-count/duration mismatch** (3 of 8 built; 4 events found, 2 failed the spike test).
3. **BANE 1, CBOM 2, FEES 1, LKOH 2 — no qualifying event identified** (6 cells).
4. **EARN and LEAD categories empty** (bench 5 and 1).
5. **The 10 sanction-anchored discards in the benchmark could not be reconstructed as such** — this
   build discards 6 on the sanction step and 1 on the anchor pad, from candidates it found itself.
   The benchmark's discard identities remain unknown; `work/g4_candidates.csv` is absent.
6. **The 52 zero-event companies were not exhaustively swept.** Any event found there would be a
   legitimate addition. Coverage here is a lower bound, which is the conservative direction for a
   control.

Residual sourcing limits: e-disclosure.ru not reachable; Russian-language press and IR pages only.

---

## 7. Deliverables

| File | Contents |
|---|---|
| `output/News_i_t.csv` | **the deliverable** — 419 × 75 wide matrix, 54 ones |
| `output/News_i_t_long.csv` | long format (ticker, week_monday, News), 31,425 rows |
| `output/news_events_final.csv` | the 17 events with baselines, ratios, durations, flags |
| `output/N1_SURVEY_LEDGER.md` | survey ledger, absence list, benchmark sheet, gap list |
| `output/NEWS_LAYER_RECONCILIATION_REPORT.md` | this report (reconciliation + both audit trails) |
| `work/dedup_log.csv` | 7 discards with reasons |
| `work/rejected_nospike.csv` | 6 tested-and-failed rows with all ratios |
| `work/candidates.json` · `work/n4_full.json` | full candidate ledger with sources/quotes; complete machine record |
| `lib/panel.py` · `layers.py` · `tester.py` · `run_n3.py` · `run_n4.py` · `run_n6.py` | reproducible pipeline |

**Reproduce:** `cd lib && STEP_MODE=1 python3 run_n4.py && STEP_MODE=1 python3 run_n6.py`.

---

## 8. Integrity statement

1. No regression was estimated; no outcome variable influenced any inclusion, exclusion, category
   or duration. The only decision rules were the category bar and the 2× test, applied identically
   to every candidate — including the famous ones that failed (GAZP 2022-06-30, NLMK 2024-02-24).
2. Dedup ran before testing; discards are retained with reasons, not deleted.
3. Every baseline is strictly pre-onset and the assertion is logged for all 17 tests.
4. The "missing price week counts as confirming" rule is implemented and **fired for 0 of 17**
   events — prescribed but inert, matching the benchmark's own finding.
5. Deviations from the benchmark are larger than the benchmark's own numbers and are **not**
   reconciled away. 54 evidenced cells are published instead of 89 asserted ones. The gap is
   itemised in §4 and §6.
6. The published series is a **lower bound** on News coverage. It under-covers rather than
   over-attributes, which is the conservative direction for a control variable.
