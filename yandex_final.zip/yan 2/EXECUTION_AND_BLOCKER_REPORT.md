# EXECUTION AND BLOCKER REPORT

**Project:** 75-company MOEX panel · 419 weeks (WordStat Mondays 2018-08-27 → 2026-08-31) · ASVI → volatility/returns
**Executed:** 2026-09-21 by the multi-agent swarm (Data Engineer → Econometrician → QA Auditor → Blocker Analyst → Reporter)
**Governing methodology:** `methodology_final.md` v2.0 (Corrected Freeze, C1–C8 + E1–E4), with Amendment A1/C9 (Crisis∩Sanction overlap is structural)
**Archive:** `yandex_data.zip` → `yan 2/` (docs + `data1/` controls) + nested `iqbal thesis data.zip` (raw WordStat + price files, 75 company folders) + `thesis books.zip` (references, incl. `canterbury-nz-034.pdf`)
**Software:** Python 3.11.2 · pandas 3.0.6 · numpy 2.4.6 · statsmodels 0.15.0 · scipy 1.17.1 · linearmodels 7.0 · permutation seed 20260921 (1,000 draws/null)
**Inference:** per-company Newey-West HAC, bandwidth 4 (lags 0–4, Bartlett; custom engine validated against statsmodels to max|ΔSE| = 2.3e-13) · pooled Two-Way FE via `PanelOLS` with Driscoll-Kraay kernel SEs (Bartlett, bandwidth 4)
**Machine outputs:** `work/derived/` (panel, mappings, QC log) · `work/results/` (all coefficient CSVs, `results_summary.json`, `qa_audit.json`)

---

## 1. Data Inventory & Panel Construction

### 1.1 CSVs successfully ingested

| File (path under `yan 2/`) | Role | Verified against documentation |
|---|---|---|
| `data1/crisis_i_t.csv` | Crisis(i,t), 419×75 wide | 1,725 cells · 23 Monday-weeks (W1–W4) — exact |
| `data1/sanction_i_t.csv` | Sanction(i,t) permanent step | 24 step-firms, anchor weeks match Combined_Data_File §2.4 (one disclosure, §4.6 below) |
| `data1/sanction_reaction_i_t.csv` | 5-week reaction windows | ingested; not used in M1–M6 (permanent step is the regressor) |
| `data1/div_i_t.csv` + `data1/div_i_t_long.csv` | Div(i,t) + RecordWeek(i,t), 31,425 rows | Div=1 cells = **2,110** — exact |
| `data1/dividend_record_dates.csv` | row-level confirmed-paid record dates | **587 rows, 63 paying firms** — exact (this IS the row-level table whose absence was flagged as G1 for the compilation agents) |
| `data1/div_window_log.csv`, `data1/event_overlap_summary.csv`, `data1/phase1_exclusion_audit.csv` | window provenance / overlaps / exclusions | overlap figures re-derived from the panel: Div∩Crisis=85, Div∩Sanction(step)=217, Crisis∩Sanction=204 — all exact |
| `iqbal thesis/Data/<Sector>/<TICKER>/<TICKER>.csv` (75) | WordStat weekly counts, Latin-ticker channel | 419 rows each, grid 27.08.2018→31.08.2026 |
| `iqbal thesis/Data/<Sector>/<TICKER>/<name> акции.csv` (75) | WordStat weekly counts, Cyrillic channel | same grid |
| `iqbal thesis/Data/<Sector>/<TICKER>/*Stock Price History*.csv` (75) | investing.com weekly OHLCV (Sunday labels, MM/DD/YYYY) | located by header sniffing; YNDX price file = `YANDEX Stock Price History.csv` |

Non-CSV sources used: `methodology_final.md` (rules), `Combined_Data_File.md` (SOE 75-row table §5, sanction anchors §2.4, crisis windows §1.2, 11 robustness candidates), `UNIFIED_PAPER_about_state_ownership.md` (Appendix B ASVI-coverage benchmarks, §3.5 data-quality registry R1–R17, §4.3 handling rules), `news.md` (News aggregates only — see BLOCKER 1), `canterbury-nz-034.pdf` (Giles–Lieberman bounds, extracted successfully).

### 1.2 Files MISSING from the directory (never invented; see §3)

`news_i_t.csv` · `news_company_summary.csv` / `work/g4_events_final.csv` · `agent2b_soe.csv` · `soe_classifications_compiled.csv` (published CSV; its 75-row content survives inside `Combined_Data_File.md` §5 and was transcribed, labelled `derived/soe_classifications_compiled_REBUILT.csv`) · `sanction_anchor_table.csv` (content recoverable: shipped `sanction_i_t.csv` + §2.4 table) · `gl_bounds_published.csv` (resolved by genuine PDF extraction, §2.3) · `group3/yandex_final_series.csv`, `group3/channel_selection.csv`, `group3/data_quality_registry.csv`, `group2/soe_classifications.csv`, `final_dividend_table.csv` (derived intermediates; each reconstructed from raw data under the documented rules and benchmark-verified, or superseded by an ingested file).

### 1.3 Panel construction (from RAW data — no pre-calculated substitutes were needed)

* **Grid:** 75 firms × 419 Monday weeks = **31,425 rows** (never truncated). Join rule verified: WordStat Monday = price-file Sunday + 1 day.
* **SVI(t)** = ticker-channel count + Cyrillic-channel count (raw counts summed before any transform; zero/missing channel contributes 0; **SVI = 0 → missing**, never a small constant). **YNDX:** SVI = «YNDX» + «Яндекс акции»; **`YDEX.csv` never read** (documented limitation: excludes ~2 years of real post-2024 YDEX volume).
* **ASVI(t)** = ln SVI(t) − median(ln SVI(t−1)…ln SVI(t−8)); requires 8 valid priors, else missing.
* **RV(t)** = ln(High/Low); **High = Low → missing, not zero** (26 flat weeks found; 13 of them placeholders dropped entirely, §1.5). **R(t)** = ln(Close_t/Close_{t−1}) strictly week-over-week (gaps never filled). **lnV(t)** = ln(Vol).
* **Reconstruction benchmarks — all EXACT:** per-company ASVI coverage matches UNIFIED_PAPER Appendix B with **0 mismatches** (MRKK 282, MRKC 344, MRKS 377, MRKU 382, UKUZ 393, SFIN 395, other 68 firms 411, YNDX 411); YNDX continuity stats exact (min SVI 3,381 @ 2018-12-31; peak 143,979 @ invasion week 2022-02-21; ASVI range [−0.60, +2.08], sd 0.298); suspension structure exact (0 bars at 2022-03-06 and 2022-03-13; reopening bar 2022-03-20 present in 26/75 files); R1 artifact week 2024-06-16 present in exactly GAZP/SBER/VTBR (3/75).
* **Controls merged:** Crisis, Sanction (step), Div, RecordWeek from `data1/`; **SOE** from the transcribed 35/40 table (35 SOE=1, 40 SOE=0, 0 UNDETERMINED — PROVISIONAL under the C6 gate, §3 BLOCKER 2).
* **Frozen sector mapping (E3)** from raw folder names (`derived/frozen_sector_mapping.csv`): Metals&Mining 15, Utilities 15, Energy 12, Banking 6, Chemicals 5, Consumer&Retail 4, Transportation 4, Telecom 4, Tech 3, Real Estate 3, Diversified 2, Industrial 1, Insurance 1. **YAKG dispute (G5) resolved by the folder** → Utilities; disagreement with the SOE paper's Energy assignment logged as required.
* **Lags** (positional on the Monday grid, never filled): ASVI_l1…l4, RV_l1, R_l1, lnV_l1, Crisis_l1, Sanction_l1, Div_l1, RecordWeek_l1. Panel carries 32 columns.

### 1.4 Final panel dimensions and descriptives

**75 firms × 419 weeks = 31,425 rows × 32 variables** (raw levels, RV/R/lnV/ASVI, controls, lags, DQR flags).

| Variable | Valid obs | Mean | SD | Min | Max |
|---|---|---|---|---|---|
| SVI | 31,369 | 5,949 | 17,671 | 4 | 635,549 |
| ASVI | 30,532 | 0.0199 | 0.3703 | −2.00 | +3.42 |
| RV = ln(H/L) | 30,959 | 0.0795 | 0.0700 | 0.0024 | 1.1233 |
| R | 30,735 | −0.0001 | 0.0568 | −2.31 | +0.84 |
| lnV | 30,897 | 15.40 | 4.13 | 2.30 | 30.35 |

### 1.5 Data Quality Registry applied (R1–R17 per UNIFIED_PAPER §4.3)

1. **Twelve 2022-02-27 flat placeholder rows dropped** (ABRD, AFKS, AFLT, AKRN, ALRS, AVAN, BANE, BLNG, BSPB, CBOM, CHMF, CHMK — flat price + empty volume; treated as missing, never forward-filled) **+ YNDX 2024-06-23 placeholder** (R11). The other 13 High=Low rows (early illiquidity: ABRD/AVAN/VJGZ/JNOS 2018–19, ROLO) are genuine bars: Close/Vol kept, **RV set missing (never zero)**. QA-verified: no flat week carries an RV anywhere in the panel.
2. **Week 2024-06-16 (R1 artifact):** only 3/75 real bars (GAZP −1.67%, SBER, VTBR — market demonstrably traded). Per registry, the 3 bars stay in single-company models (M1/M2/M3/M5/M6); the week is **excluded from all pooled cross-sections** (M4, H4–H6, Sections 5–6).
3. **Week 2024-08-25 (R2 volume artifact; Vol empty in 73/75):** lnV set missing for **all 75** firms that week (uniform exclusion from volume-based metrics); price metrics retained. Consequence: lnV_l1 missing the following week (listwise loss, documented).
4. **ROLO (R4, 1-kopeck grid): excluded from every inferential model containing RV** (M1, M2, M3 both blocks, M4 all variants, M5, M6, Sections 5–6) → inferential universe = **74 firms**; ROLO retained for descriptives only. QA-verified absent from every output.
5. Documented gaps kept missing (LSNG Mar–May 2020, MSTT Sep–Oct 2020, FEES 2022-12-25/2023-01-01, YNDX relisting Jun–Jul 2024, AVAN early illiquidity, 2022 suspension weeks). USBN sub-kopeck price scale = watch item only (R5: no tick quantization).
6. Pooled-sample weeks: **404 of 419**. The 15 absent weeks are fully structural: 9 ASVI warm-up weeks (2018-08-27…2018-10-22), 4 suspension weeks (2022-02-28…2022-03-21), artifact week 2024-06-17, R2-volume week 2024-09-02.

---

## 2. Successful Execution Results (The Numbers)

> Every model below ran on real, ingested/reconstructed data. Per-company estimates use NW HAC (bw 4); pooled estimates use entity+time FE with Driscoll-Kraay SEs. **No model used any News variable (none exists — §3).**

### 2.1 H1/H2 — M1 & M2 per-company OLS (74 firms each; ROLO excluded)

**M1 (H1):** `RV ~ ASVI_l1 + RV_l1 + lnV_l1 + Crisis_l1 + Sanction_l1 + Div_l1`
**M2 (H2):** `R ~ ASVI_l1 + R_l1 + RV_l1 + Crisis_l1 + Sanction_l1 + Div_l1`
Observations per firm: M1 median 402 (range 274–405); M2 median 401 (range 273–405). Column drops: `Sanction_l1` for the 50 non-step firms; `Div_l1` for the 13 zero-Div firms (all QA-verified consistent with 74−24 and the 12+2 non-payer list).

| Statistic | M1 (H1: RV) | M2 (H2: R) |
|---|---|---|
| Median β_ASVI | **−0.00407** | **−0.00359** |
| Mean β_ASVI (q10…q90) | −0.00396 (−0.0198…+0.0118) | −0.00170 (−0.0115…+0.0098) |
| Positive / negative β | 21 / 53 | 30 / 44 |
| Nominal 5% significant | **12** (10 negative, 2 positive) | **5** (2 positive, 3 negative) |
| **BH survivors (block-wise)** | **4** | **0** |
| Holm survivors | 2 | 0 |

**BH survivors, H1 block (exact coefficients):**

| Firm | β_ASVI | SE | t | p | q(BH) | p(Holm) | Verdict |
|---|---|---|---|---|---|---|---|
| RTKM | −0.03546 | 0.00768 | −4.62 | 0.00001 | 0.00039 | 0.00039 | BH+Holm survivor |
| MFGS | +0.04723 | 0.01247 | +3.79 | 0.00018 | 0.00653 | 0.01289 | BH+Holm survivor |
| SNGS | −0.03382 | 0.01029 | −3.29 | 0.00111 | 0.02729 | 0.07965 | BH survivor |
| LSRG | −0.02194 | 0.00687 | −3.19 | 0.00152 | 0.02803 | 0.10758 | BH survivor |

Remaining nominal-only H1 significants: PHOR −0.0135 (p=0.004), AFKS −0.0156 (p=0.006), JNOS +0.0371 (p=0.026), YNDX −0.0213 (p=0.028), NLMK −0.0170 (p=0.030), VSMO −0.0179 (p=0.037), MAGN −0.0242 (p=0.047), IRAO −0.0143 (p=0.047). M2 nominal significants: FEES −0.0311 (p=0.017), GCHE +0.0119 (p=0.020), PLZL +0.0326 (p=0.034), RNFT −0.0103 (p=0.041), LSNG −0.0219 (p=0.042) — none survives BH/Holm.

**Verdicts.** *H1:* attention significantly predicts next-week range volatility for a distinct minority of firms; after BH the effect is robust for 4/74 (RTKM, SNGS, LSRG negative; MFGS positive) — predominantly **negative** (attention up → next-week range down), median β < 0. *H2:* **no evidence** of an ASVI→return effect after multiplicity correction (0 BH, 0 Holm survivors).

**H3-Granger (M3), classical F on ASVI lags L∈{1,2,4}, BH/Holm applied separately within the H1 and H2 blocks (never pooled; 222 p-values per block), with by-(block,L) BH (74 p-values) reported alongside:**

| Block | L | Median F | Nominal 5% | BH (block-level) | Holm (block-level) | BH by-(block,L) survivors |
|---|---|---|---|---|---|---|
| H1 (RV) | 1 | 0.787 | 10 | 3 | 1 | MFGS (F=22.54, q=0.0002), RTKM (13.60, 0.0096), JNOS (11.65, 0.0175), LSRG (9.17, 0.0485) |
| H1 (RV) | 2 | 0.941 | 10 | 3 | 1 | MFGS (11.83), RTKM (8.45), JNOS (6.78) |
| H1 (RV) | 4 | 1.080 | 10 | 2 | 2 | MFGS (7.09), JNOS (5.98), RTKM (4.29), UTAR (4.18) |
| H2 (R) | 1 | 0.592 | 3 | 0 | 0 | — |
| H2 (R) | 2 | 0.711 | 6 | 0 | 0 | — |
| H2 (R) | 4 | 0.837 | 8 | 0 | 0 | VJGZ (F=5.24, p=0.0004, q_byL=0.030) — not a block-level survivor |

ASVI Granger-causes RV for MFGS, RTKM, JNOS at every lag depth (LSRG/UTAR at some depths); it does not Granger-cause returns robustly for any firm. Consistent with M1/M2.

### 2.2 H3 — M5 asymmetric Chow break at 2022-02-24 (74 per-company tests)

Specification (C8): reduced form `RV ~ 1 + ASVI_l1 + RV_l1 + crisis_chow` (crisis_chow = Crisis(t)·Post(t)), post-period = Monday weeks ≥ 2022-02-21; **q = 3** restrictions (intercept, ASVI_l1, RV_l1 free post-break), **k_pool = 4**. Median subsample sizes T1 = 173, T2 = 230 (ratio ∈ (0.1,10] → the chosen tabulation row applies). Zero rank-deficient companies.

* F distribution: **median 1.899**, mean 3.107, q10–q90 [0.462, 7.037].
* **Nominal 5% rejections: 30 / 74.**
* **Giles–Lieberman bounds (extracted and verified from the published tabulation — see §2.3):**
  * Chosen row (k=4 diagonal, Cu(0.1,10] = **5.206**): **15 survivors** — CBOM, FEES, IRKT, KAZT, LSRG, MFGS, MRKC, MRKP, MRKU, MSNG, MSTT, OGKB, TGKA, UPRO, YAKG.
  * Alternative off-diagonal row (T1=40, T2=10, Cu = **3.372**): **27 survivors**.
  * Widest row (T1=T2=10, Cu = **18.127**): **0 survivors**.
  * The survivor count is an artefact of which published row one reads (disclosed per C8); the q=3-vs-k=4 mismatch is disclosed.
* Largest F: UPRO 11.85, MSNG 11.22, MRKU 11.08, TGKA 9.73, FEES 9.29, KAZT 9.05 (all p < 1e-4).
* Sensitivity (crisis dummy on ALL crisis weeks incl. pre-break W1): 39 nominal rejections (vs 30) — the literal post-period reading is the conservative primary.

**Structural-break verdict:** a break at the invasion date is **robust (size-controlled under the chosen GL bound) for 15 of 74 firms (20.3%)**, heavily concentrated in Utilities/power names (FEES, MRKC, MRKP, MRKU, MSNG, OGKB, TGKA, UPRO, YAKG = 9 of 15). Under the widest published bound no firm survives; under the alternative row 27 do. Nominal-only evidence (30 firms) overstates robustness, as the bounds exist to show.

### 2.3 Giles–Lieberman bounds provenance (D15 resolved)

`gl_bounds_published.csv` is absent, but genuine extraction from `canterbury-nz-034.pdf` (Giles & Lieberman, *Bounds on the Effect of Heteroscedasticity on the Chow Test for Structural Change*, Canterbury DP 9101) **succeeded**: p.19, **TABLE A3 — nominal 5%, k = 4** contains the diagonal row T1=T2=40 → Cu = **5.206** (CL = 2.499), the off-diagonal row T1=40, T2=10 → Cu = **3.372** (CL = 2.594), and the row T1=T2=10 → Cu = **18.127** (CL = 3.259). All three hand-transcribed values in `methodology_final.md` §4-M5 are **confirmed exactly against the published tabulation**. No substitute or approximation was used.

### 2.4 H4 — M4 pooled TWFE + sector heterogeneity (74 firms, n = 29,445, 404 weeks, within-R² = 0.161)

**M4 (corrected equation, β3 lagged-volume correction included; Crisis omitted — absorbed by time FE by design, C7):**

| Regressor | β | SE (DK) | t | p | Note |
|---|---|---|---|---|---|
| ASVI_l1 | **+0.00098** | 0.00187 | 0.53 | 0.599 | pooled attention effect ≈ 0 |
| RV_l1 | +0.32750 | 0.02131 | 15.37 | <1e-16 | strong persistence |
| lnV_l1 | +0.00303 | 0.00066 | 4.63 | 3.7e-06 | **β3 lagged-volume correction (documented; its earlier omission was the likely cause of the pooled-vs-M1 sign contradiction)** |
| Div_l1 | +0.00668 | 0.00147 | 4.55 | 5.3e-06 | dividend-window RV premium |
| Sanction_l1 | +0.00150 | 0.00125 | 1.19 | 0.233 | **n_with_term = 24** (firms with in-sample anchor variation) |
| Crisis | — | — | — | — | omitted: perfectly collinear with time FE (absorption demonstrated empirically in QA2) |

With β3 included, the pooled β_ASVI is near zero and statistically indistinguishable from the (slightly negative) per-company median — the documented sign contradiction does **not** reappear.

**H4 sector interactions** (ASVI_l1 × sector; reference = Banking; entity FE absorb sector mains): joint Wald **χ²(12) = 24.30, p = 0.0185** → sector heterogeneity jointly significant at 5%.

| Interaction (vs Banking) | β | SE | p | | Interaction | β | SE | p |
|---|---|---|---|---|---|---|---|---|
| Banking (main) | −0.00086 | 0.00387 | 0.823 | | MetalsMining | +0.00013 | 0.00421 | 0.975 |
| Chemicals | −0.00093 | 0.00470 | 0.842 | | RealEstate | −0.00449 | 0.00512 | 0.381 |
| ConsumerRetail | −0.00092 | 0.00528 | 0.861 | | Tech | +0.01191 | 0.01058 | 0.261 |
| Diversified | −0.00437 | 0.00722 | 0.545 | | Telecom | −0.00163 | 0.00615 | 0.791 |
| **Energy** | **+0.01446** | 0.00826 | **0.080** | | Transportation | +0.00596 | 0.00583 | 0.306 |
| **Industrial** | **−0.01985** | 0.00694 | **0.004** | | Utilities | −0.00142 | 0.00426 | 0.739 |
| Insurance | +0.00875 | 0.01144 | 0.445 | | | | | |

Caveats: Industrial = **single firm (KMAZ)** — its "sector" coefficient is one company's effect; Insurance likewise (RGSS). Material disagreement reported, not resolved (methodology §5): the Utilities pool estimate (−0.00578, p=0.019, below) does not match the Utilities interaction (implied sector effect −0.0023, p≈0.74) — different fixed-effect structures (sector-specific week FE in the pool) and samples.

**Section 5 — sector pools (corrected M4 equation incl. Sanction_l1; run only where frozen-mapping N ≥ 4; ROLO excluded → Metals&Mining = 14):**

| Sector | Firms | n_obs | β_ASVI | SE (DK) | p | Sanction n_with_term |
|---|---|---|---|---|---|---|
| Banking | 6 | 2,405 | +0.00106 | 0.00521 | 0.839 | 6 |
| Chemicals | 5 | 2,009 | +0.00428 | 0.00412 | 0.299 | dropped (no step-firm) |
| Consumer&Retail | 4 | 1,609 | +0.00286 | 0.00585 | 0.626 | dropped (no step-firm) |
| Energy | 12 | 4,823 | +0.00752 | 0.00672 | 0.264 | 7 |
| Metals&Mining | 14 | 5,617 | +0.00381 | 0.00316 | 0.228 | 5 |
| Telecom | 4 | 1,610 | +0.00019 | 0.00661 | 0.977 | 1 |
| Transportation | 4 | 1,609 | +0.00969 | 0.00684 | 0.157 | 3 |
| **Utilities** | 15 | 5,765 | **−0.00578** | 0.00247 | **0.019** | dropped (no step-firm) |

Below-threshold sectors (computed from the frozen mapping at execution time, never hard-coded): **Tech (3), Real Estate (3), Diversified (2), Industrial (1), Insurance (1)** — insufficient N for separate pools; their ASVI effects are captured only through H4's interactions. β dispersion across qualifying pools: −0.0058 (Utilities) … +0.0097 (Transportation); only Utilities is individually significant (negative), while the joint H4 test says the sector pattern is non-random.

### 2.5 H5 — M4 + ASVI×Div_l1 interaction

| Sample | β(ASVI×Div_l1) | SE | p | β(ASVI_l1 main) | p | n_obs |
|---|---|---|---|---|---|---|
| Full (74 firms) | **+0.00628** | 0.00475 | **0.186** | +0.00061 | 0.755 | 29,445 |
| Excl. 11 robustness candidates | **+0.00738** | 0.00504 | **0.144** | +0.00064 | 0.756 | 25,027 |

(11 candidates per Combined_Data_File §3.5: AVAN, SBER, USBN, VTBR, AKRN, GCHE, NVTK, TATN, LSRG, RTKM, AFLT — the documented target-11 list.) **Verdict:** the attention effect is directionally ~6–7 log-points stronger inside the (lagged) dividend window, but **not statistically significant** in either sample. C8 disclosure applies: Div_l1 includes the record week (529 of 2,110 cells; §4.4).

### 2.6 H6 — M4 + ASVI×SOE interaction and Section 6 SOE pools — **PROVISIONAL (C6 gate, §3 BLOCKER 2)**

**H6 interaction (full 74-firm sample):**

| Version | β(ASVI×SOE) | SE | p | β(ASVI main) | p | n_obs |
|---|---|---|---|---|---|---|
| Base (entity + time FE) | **+0.00599** | 0.00355 | **0.092** | −0.00189 | 0.311 | 29,445 |
| Sector×week FE confound check (E4) | **+0.00519** | 0.00392 | **0.185** | −0.00215 | 0.315 | 29,445 |

Attenuation under sector×week FE: −13% (0.00599 → 0.00519); significance lost. Per E4's mandated language: **the apparent ownership effect may be partly or wholly a sector-time effect.**

**Section 6 pools (corrected M4 equation per group; UNDETERMINED = 0, so no exclusions; ROLO excluded → Group P models 39 of 40 firms):**

| Group | Firms | n_obs | β_ASVI | SE (DK) | p | Sanction n_with_term |
|---|---|---|---|---|---|---|
| **G (SOE=1)** | 35 | 13,808 | **+0.00192** | 0.00290 | 0.509 | 13 |
| **P (SOE=0)** | 39 | 15,637 | **−0.00071** | 0.00183 | 0.699 | 11 |
| G + sector×week FE (E4 confound check) | 35 | 13,808 | **−0.00012** | 0.00310 | 0.970 | 13 |

**Verdict:** G−P spread = +0.0026 (directionally consistent with the +0.006 interaction but neither significant); Group G's β collapses to ≈0 (and flips sign) once sector×week FE absorb sector-time shocks — Group G is heavily Utilities/Energy/Transportation (27 of 35 firms), so **the state-ownership contrast is not separable from the sector-time pattern in this sample**. All H6/Section-6 results carry the PROVISIONAL label until the C6 reconciliation row is published (§3 BLOCKER 2). Disagreement between the interaction (+0.006, p=0.09) and the G−P pool spread (+0.0026, n.s.) is itself reported, per methodology §6.

### 2.7 M6 — permutation (circular block-shift primary) and power

Primary null: 1,000 random **circular rotations of each company's ASVI series** (preserve serial correlation, destroy week alignment); statistic = HAC t of β1; permutation p = share of placebo |t| ≥ actual |t|. Secondary: i.i.d. shuffle (reported with the explicit caveat that it understates the null's variance and manufactures significance); coefficient-based placebo p reported but never quoted alone.

* Median permutation p (circular): **0.298**.
* **Circular-permutation significant at 5%: 12 firms** — RTKM (p_perm=0.000), SNGS (0.001), PHOR (0.002), LSRG (0.004), MFGS (0.007), AFKS (0.010), YNDX (0.018), MAGN (0.030), IRAO (0.033), NLMK (0.039), VSMO (0.041), JNOS (0.047). The i.i.d. null flags 11 of the same 12 firms (all but MAGN, p_iid = 0.053 — reported with the explicit caveat that the i.i.d. null understates the placebo variance); coefficient-placebo flags 17. The circular-null set closely tracks the M1 nominal/BH sets — no evidence the HAC-t significances are alignment artefacts.
* **Power (non-central t) and MDE80:** median **MDE80 = 0.0222** log-RV units per unit ASVI (q10–q90: 0.0155–0.0429; i.e., the median firm can only detect attention effects ≥ ~2.2 log-points of RV at 80% power). Median post-hoc power at the observed effect: 0.183.
* **Underpowered nulls (C1 discipline):** of 62 nominal nulls, **62 have power < 0.80** → every M1 null is reported as **"inconclusive due to insufficient power," never "no effect exists."**

---

## 3. Missing Data & Blockers (What is needed to finish)

### BLOCKER 1 — News matrix (`news_i_t.csv`) — ABSENT → News-dependent work cannot run

The archive contains only News **aggregates** (news.md / Combined_Data_File §3): 31 confirmed events · 23 companies · 89 News=1 company-weeks · per-company week counts · two date-bearing events (GMKN-3R 2021-03-24; PHOR-1 2026-07-22 discarded at dedup). The per-event date/duration table (`work/g4_events_final.csv`) and the weekly 419×75 matrix were never shipped. **Consequences (all flagged, none fabricated):**
* **Robustness r2** (M1/M2 with News(i,t−1)) cannot be estimated — no News column exists in any model run here.
* **Sensitivity 1** (drop the 5 revision-affected events; confirm explained-spike share 62.2% → 61.7%) and **Sensitivity 2** (widen windows to t…t+5 for the 21 persistence-flagged events) cannot run: both need event-level rows.
* **Sensitivity 3** (strict Crisis/Sanction definitions; residual unexplained share → 49.2%) cannot be re-derived week-by-week for the same reason (spike attribution requires News coverage).
* The **News deduplication audit** (News∩Crisis = 0, News∩Sanction = 0, Div∩News = 0) rests on the source's construction guarantee + bounded verification (Combined_Data_File §6.1–§6.2), **not** on exhaustive recomputation.
* **To unblock:** provide `news_i_t.csv` (419×75 weekly binary) or the 31-event table (ticker, event date, category, duration/weeks).

### BLOCKER 2 — SOE reconciliation (`agent2b_soe.csv`) — ABSENT → H6/Section 6 remain PROVISIONAL (C6)

The C6 mandate requires reconciling the two surviving source tables — **35/40 over 75** (UNIFIED_PAPER App.A / Combined_Data_File §5) vs **34/41 over 75 pre-screen** (33/41 over the 74 modelled; the 34-vs-33 difference is the documented MRKK screen artifact and is reported as such, not a disagreement) — naming every firm whose label differs, with each side's citation and vintage, and declaring the governing table. `agent2b_soe.csv` is not in the archive, so the reconciliation is **one-sided and cannot be mathematically completed**; exactly one firm's label (35 vs 34) is unidentified without it. Also absent: the published `soe_classifications_compiled.csv` named in `data1/event_controls_report.md` — its 75-row content was **transcribed verbatim from Combined_Data_File §5** into `work/derived/soe_classifications_compiled_REBUILT.csv` (labelled as a transcription substitute per methodology §8(c): the difference is provenance only, content is the published table; quantitative consequence: none for the 35/40 split, but the C6 cross-check remains open). **Per the swarm mandate, H6 and Section 6 WERE executed on the surviving table and every affected number above is labelled PROVISIONAL until the reconciliation row is published. To unblock:** provide `agent2b_soe.csv` (or the reconciliation row itself). Sensitivities 5–6 (federal-only SOE; VSMO flip-test) remain gated by the same mandate.

### BLOCKER 3 — Raw OHLCV / ASVI panel: **NOT missing (no reliance on pre-calculated data)**

Contrary to the worst case anticipated, the raw archive was complete: all 75 WordStat channel pairs and all 75 investing.com weekly OHLCV files were present in `iqbal thesis data.zip`. **ASVI, RV, R and lnV were built from raw files** exactly per methodology §2 (SUM-RAW channel rule; Parkinson ln(H/L); Sunday+1 join; YDEX never read). What IS missing are the *derived intermediates* (`group3/yandex_final_series.csv`, `channel_selection.csv`, `data_quality_registry.csv`, `group2/soe_classifications.csv`); each was reconstructed from raw data under the published rules and **verified exact against every published benchmark** (Appendix-B coverage per company; YNDX continuity stats; R1/R2/R14 registry counts). Residual limitation (documented, not fixable from the archive): the SVI channel-selection correlations themselves were not republished per company, but all 74 decisions are SUM RAW with max corr 0.8066 < 0.85, and the reconstruction reproduces the resulting coverage counts exactly.

### Resolved pseudo-blockers (for completeness)

* `gl_bounds_published.csv` absent → **resolved by genuine extraction** from `canterbury-nz-034.pdf` (Table A3, k=4, 5%): all three values (5.206 / 3.372 / 18.127) confirmed exactly (§2.3). Methodology §8's "named blocker if extraction fails" was therefore not triggered.
* `sanction_anchor_table.csv` absent → anchors fully recoverable from the shipped `sanction_i_t.csv` step structure + Combined_Data_File §2.4 (24 anchor weeks verified).
* `final_dividend_table.csv` absent → the row-level 587-date table exists as `data1/dividend_record_dates.csv` (587 rows / 63 payers verified), so the G1 blocker recorded by the compilation agents does not bind this execution; the C8 Div_l1 record-week count (529) was computed from real rows.

---

## 4. Econometric Problems & Warnings Encountered

1. **FE absorption (by design, demonstrated):** `Crisis(t)` is perfectly collinear with time FE in M4 and is absorbed — QA re-ran M4 *with* Crisis included and `drop_absorbed=True`: linearmodels absorbed it silently, confirming the C7 statement that its absence is design, not oversight. **`Sanction(i,t−1)` varies within-firm** (24 anchors in-sample) and was included everywhere, with **n_with_term = 24** reported beside every pooled Sanction coefficient (13 in Group G pools, 11 in Group P; 6/7/5/1/3 in the Banking/Energy/Metals/Telecom/Transportation sector pools).
2. **Per-company column drops (collinearity handled, never hidden):** `Sanction_l1` dropped for the 50 firms with no designation step (constant 0); `Div_l1` dropped for the 13 firms with zero in-panel dividend weeks (12 zero-dividend firms + IRKT/MSTT pay only pre-panel; MRKK counted among zero-dividend). Sector pools: `Sanction_l1` auto-dropped in Chemicals, Consumer&Retail, Utilities (no step-firms). No singular-matrix failures; zero rank-deficient Chow tests; no company lacked the minimum observations for any model (min n_obs = 273).
3. **Amendment C9/A1 confirmed handled correctly:** Crisis∩Sanction = **204 company-weeks** (24-firm permanent step; 195 under strict tested-23) was **measured and retained, not forced to zero** — the VTBR (2022-02-24) and NMTP (2022-02-25) onsets sit inside W2 by structural necessity. Every model carries Crisis_l1 and Sanction_l1 simultaneously; no execution error, no deduplication of the dummies. Div∩Crisis = 85 and Div∩Sanction(step) = 217 likewise measured-and-disclosed, never removed (all three counts re-derived exactly from the merged panel).
4. **C8 Dividend Lag Trap — documented at execution:** `Div_l1` = 1 in {W_R−21d, W_R−14d, W_R−7d, **W_R**}: the lag silently re-includes the record week the raw construction excludes. **529 of 2,110 Div_l1 cells (25.1%) are record weeks** (equals the count of in-panel record weeks, as it must). H5's interaction therefore blends pre-record anticipation with record-week mechanics; robustness r4 (contemporaneous Div) is pre-registered but was outside this execution command.
5. **Sign-contradiction guard (β3):** the lagged-volume correction is in every M4-family run; lnV_l1 is strongly positive (+0.0030, p=3.7e-06). The pooled β_ASVI (+0.0010, n.s.) does not contradict the per-company median (−0.0041) in sign-meaningful terms — the historically documented contradiction did not reappear.
6. **Sanction anchor-week disclosure (LKOH/ROSN):** the shipped `sanction_i_t.csv` steps these firms from Monday **2025-10-20** (US designation 2025-10-22 week), while Combined_Data_File §2.4/D1 lists the UK-first alternative (2025-10-15 → Monday 2025-10-13). The shipped control file was used as-is (data authority); D1 notes neither candidate week falls in a crisis window, so overlap counts and C9 are unaffected.
7. **Data-quality anomalies encountered and handled:** 12 flat placeholder bars 2022-02-27 + YNDX 2024-06-23 placeholder (dropped, never forward-filled); 13 additional genuine High=Low weeks (RV forced missing, never zero); artifact week 2024-06-16 (3/75 real bars; excluded from pooled cross-sections only); volume-artifact week 2024-08-25 (lnV nulled panel-wide); MOEX suspension weeks (no bars; reopening bar 2022-03-20 in 26/75 files only → returns that week are missing for the other 49); documented single-week gaps (KAZT 2018-10-28, ABRD 2018-09-30, MFGS/VJGZ 2018-12-30, VJGZ 2019-01-27) and AVAN early illiquidity kept as gaps. USBN's sub-kopeck 2022 price scale noted as a watch item (R5: fine-decimal quotes, no quantization) — not excluded.
8. **ROLO:** excluded from all RV-bearing inferential models (M1, M2, M3-H1/H2, M4 + H4/H5/H6, M5, M6, Sections 5–6 incl. the Metals&Mining pool at 14 firms); present only in the descriptive panel and registry. QA-verified absent from every inferential output file.
9. **Multiplicity discipline:** BH and Holm applied separately within H1 and H2 blocks for both M1/M2 coefficients and M3 Granger families — never pooled across hypotheses. Under block-level BH, H2 has zero survivors; H1 has four. The gap between 12 nominal and 4 BH survivors in M1 quantifies the false-positive risk the correction absorbs.
10. **Power honesty (C1):** all 62 M1 nulls are underpowered (power < 0.80 at observed effects; median MDE80 = 0.0222) → they are reported as *inconclusive due to insufficient power*, never as absence of effect. The i.i.d. permutation null is reported only alongside the primary circular-block null with the over-tight-null caveat attached.
11. **Single-firm "sectors":** Industrial (KMAZ) and Insurance (RGSS) H4 interaction coefficients are one firm's effect each — flagged, not interpreted as sector evidence; both sectors are below the Section-5 minimum-N rule (computed from the frozen mapping: Tech 3, RealEstate 3, Diversified 2, Industrial 1, Insurance 1).
12. **Not run (outside execution command / gated):** robustness r1–r4 (pre-registered §4.7 — r2 additionally blocked by BLOCKER 1; r4 relevant to item 4), Sensitivities 1–3 (BLOCKER 1), Sensitivities 4 (executed *as part of* H5's excl-11 column), Sensitivities 5–6 (BLOCKER 2 / C6 gate). No hallucinated News, SOE-pre-screen, or anchor data was used anywhere; the QA sweep confirms the panel carries no News column and every SOE value traces to the transcribed published table.

---

### QA audit trail (Phase 3): **29/29 checks PASS, 0 FAIL** (`work/results/qa_audit.json`)

ROLO exclusion (5 checks) · Crisis absorption demo · 50/13 constant-column drops · M5 full rank · C8 count (529/2,110) · no-News guarantees (2) · C9 overlap 204 + onsets {VTBR, NMTP} + Div overlaps 85/217 · HAC engine ≡ statsmodels (2.3e-13) · control totals 2,110/1,725/23/24/587/63 · ASVI coverage ≡ Appendix B (0 mismatches) · YNDX continuity exact · DQR applications (5 checks incl. "no RV from flat weeks") · LKOH/ROSN note · GL bounds extracted from the published PDF.

**Bottom line.** The panel was rebuilt from raw data with zero benchmark deviations, and every model in the execution command ran to completion: H1 finds robust negative attention→volatility effects for RTKM/SNGS/LSRG and a positive one for MFGS (4/74 BH survivors; Granger-consistent with MFGS/RTKM/JNOS); H2 finds nothing robust; H3 finds an invasion-date structural break robust for 15/74 firms (9 of them Utilities/power) under the chosen Giles–Lieberman bound; H4 finds a null pooled effect with jointly significant sector heterogeneity (χ²(12)=24.3, p=0.019; Utilities pool −0.0058, p=0.019); H5 finds an insignificant positive dividend-window moderation (+0.0063, p=0.19); H6/Section 6 (PROVISIONAL under C6) find a marginally positive SOE interaction (p=0.09) that attenuates under sector×week FE — the ownership contrast may be a sector-time effect; M6 confirms the significant firms survive a serial-correlation-preserving permutation null and declares all 62 nulls underpowered. Two true blockers remain open — the News matrix and the SOE reconciliation file — and nothing was invented to fill them.
