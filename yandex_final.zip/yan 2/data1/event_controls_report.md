# Phase 2 — recoverable event controls and blocking declarations

## Control definitions

- **Crisis(i,t):** market-wide 1 on W1 2020-02-24…04-13, W2 2022-02-21…03-28 (six calendar labels around five trading-week bars), W3 2023-09-04…09-18, and W4 2026-06-22…07-27.
- **Sanction(i,t):** permanent step, 1 from the first economically binding entity/parent/affiliate anchor week for the 24 compiled step companies; it does not require a spike reaction.
- **SanctionReaction:** five-week event-window union, retained separately for overlap accounting; the event-level file retains duplicate event claims rather than deduplicating them.
- **News(i,t):** not emitted as a weekly binary because the 31-event date/duration table is absent. Aggregate claims are carried in `news_company_summary.csv`; exact News cells remain blocked.

## Amendment A1 — Crisis∩Sanction

The intersection is **not forced to zero**. It is measured under three coherent definitions: 2/23 tested anchor onsets (3 when the named TATN-affiliate secondary onset is included), 10 primary reaction company-weeks (12 including VTBR SWIFT and the TATN affiliate), and 204 crisis company-weeks under the 24-company permanent-step definition (195 strict tested-23 sensitivity). See `event_overlap_summary.csv`.

Crisis∩News and Sanction∩News remain exactly zero **by construction** under the published pre-test dedup rule; this is a source-level guarantee, not a claim that a missing weekly News table was independently re-created.

## Div overlaps

Using the real 587-row Phase-1 table and the emitted 2,110-cell Div union: Div∩Crisis = 85; Div∩permanent Sanction = 217; Div∩five-week sanction-reaction union = 3 (GAZP 2022-10-03, TATN 2022-10-03, AVAN 2026-04-20). No overlaps were removed.

## SOE and blockers

`soe_classifications_compiled.csv` contains the published 75-row table (35 SOE=1, 40 SOE=0). `agent2b_soe.csv` is absent. Therefore C6/H6/Section 6 and SOE cross-agent reconciliation remain BLOCKED. The YAKG sector dispute is recorded and unresolved.

## Source limits

Sanctions source: `Sanctions Events, Crisis Windows & Data Readiness.md`; News source: `news.md`; SOE source: `UNIFIED_PAPER_about_state_ownership.md`. Forbidden archives and the old prompt were not opened.
