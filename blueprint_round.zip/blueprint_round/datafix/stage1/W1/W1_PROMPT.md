# DATA COMPLETION ROUND: 4 AGENTS, ONE LOOP

>>> YOU ARE AGENT NUMBER: **1** · ROLE: **Sanctions (worker)** <<<

Your number and role are fixed. Do not ask which agent you are. Your files use the prefix `W1_` (for example `W1_REPORT.md`) and your folder is `W1`. Read §0–§5 and §8–§12 (shared rules) and your own role in §6. Skim the other roles only to understand the hand-offs.

Prepared 7 Oct 2026. Roles: 1 Sanctions · 2 State ownership and sector map · 3 Dividends, ex-dates and dividend-adjusted series · 4 Corporate actions, market-level series, institutional events and crisis anchors.

---

## 0. Mission

Asif (Master's student, Finance, HSE Nizhny Novgorod) has a finished methodology (`METHODOLOGY_v4_0_FINAL.md`). Its design is fixed except for the amendments listed in §2. What is **not** finished is the data: the previous round wrote most of the event and control data as open gaps instead of closing them. Your job is to close those gaps by searching the primary sources online, to re-verify what already exists, and to deliver files that go straight into the thesis. Where you cannot verify a datum, you say so honestly and leave it labelled.

You do **not** redesign the methodology, you do **not** choose specifications by their results, and you do **not** edit Asif's files or his abstract and framework text.

**"Bulletproof" has one meaning here.** Every datum and every sentence is exactly one of: (a) supported by a primary or independent source you opened and can cite; (b) verified by code you ran on the files; (c) a labelled coding decision under a stated rule; (d) labelled `CANDIDATE`, `UNVERIFIED` or `GAP`, with what would close it. A gap honestly named is acceptable. A gap quietly filled, or a task quietly skipped, is a failure.

---

## 1. The pipeline

```
STAGE 1  Agents 1–4 in parallel: do your role -> QA LOOP 1 (internal, hard) -> Package v1
STAGE 2  QA LOOP 2 (cross-agent, hard). Pairs: 1<->2 and 3<->4
           2a review your partner's Package v1 -> REVIEW file
           2b answer the review of your own work -> Package v2 + RESPONSE file
           2c check your partner's Package v2 -> CLOSURE file (PASS / CONDITIONAL / FAIL)
STAGE 3  Asif hands the four Package v2 folders and CLOSURE files to Claude, who runs the
         integrity checks (hashes, counts, spot re-verification) and assembles the final
         Part II text and data folder of Methodology v4.1.
```

You stop after Stage 2. If a stage input is missing, write `WAITING FOR: <exact file>` and stop. Never start from memory or from a guess about what another agent produced.

---

## 2. Inputs

Fetch the live repo listing first. Trust only what you can open. Some sites block automated fetching (GitHub HTML pages do; raw links work). If a page cannot be fetched, say so and use another route (search-result text, a mirror, the issuer's own filing) and lower the status accordingly.

**Repo:** https://github.com/aaa11996/yandex_new. Root files (7 Oct 2026): `README.md`, `FINAL_MASTER_METHODOLOGY_AND_DATA_APPENDIX.md`, `THE_FINAL_MOEX_ASVI_METHODOLOGY_AND_DATA_COMPENDIUM_v3.md`, `THE_v3_RESULTS_AND_DEFENSE_PLAYBOOK.md`, `all data final.zip`, `moex_panel_data.zip`, `old work data and results.zip`.

| What | Raw link | Contents (as inspected) |
|---|---|---|
| Main data archive | https://github.com/aaa11996/yandex_new/raw/refs/heads/main/all%20data%20final.zip | Top folder `all data final/`: `combined data for all 75 companies/<Sector>/<TICKER>/<TICKER>_combined.csv` (75 files × 419 weeks = 31,425 rows; 39 columns including `ASVI`, `SVI_RAW`, `RV`, `RETURN_SAFE`, `VOLUME`, `VALUE`, `CA_FLAG`, `CA_NOTE`, `IMOEX_CLOSE`; read with `encoding="utf-8-sig"`), `raw data/<Sector>/<TICKER>/` (Wordstat files, `<TICKER>_daily.csv`, `IMOEX_daily.csv`), `books/`. |
| MOEX daily + weekly | https://github.com/aaa11996/yandex_new/raw/refs/heads/main/moex_panel_data.zip | `moex_panel_data/<Sector>/<TICKER>/<TICKER>_daily.csv` and `_weekly.csv` (TRADEDATE, OPEN, HIGH, LOW, CLOSE, VOLUME, VALUE). Weekly files are labelled by the week-end Sunday. |
| Earlier work and the original control data | https://github.com/aaa11996/yandex_new/raw/refs/heads/main/old%20work%20data%20and%20results.zip | 43 entries, folder `old work data and results/`: the control matrices `crisis_i_t.csv`, `sanction_i_t.csv`, `sanction_reaction_i_t.csv`, `div_i_t.csv`, `div_i_t_long.csv`, `div_window_log.csv`, **`dividend_record_dates.csv`** (587 rows; columns ticker, record_date, amount, currency, paid_status, source_count, sources_checked, source_urls, source_amounts, period_evidence, evidence, amount_note, exclusion_status), `phase1_exclusion_audit.csv`, `event_overlap_summary.csv`; and the documents `Combined_Data_File.md`, `UNIFIED_PAPER_about_state_ownership.md`, `Sanctions Events, Crisis Windows & Data Readiness.md`, `NEWS_LAYER_RECONCILIATION_REPORT.md`, `news.md`, `News_Div_Overlap_Addendum.md`, `Final dividend table.md`, `FINAL_REPORT.md`, `THESIS_HANDOFF_BRIEF.md`, `FINAL_COMPLETE_METHODOLOGY.md`, `methodology_final.md`, `EXECUTION_AND_BLOCKER_REPORT.md`, `VERIFICATION_FINDINGS_2026-10-05.md`. **In the control matrices `week_sunday = week_monday − 1`; join on `week_monday` only.** |
| Original archive in git history (same data, older packaging) | https://github.com/aaa11996/yandex_new/raw/2c5d6d5/yandex_final.zip | 25 entries; folder `yan 2/`. |

**Input Pack (Asif places these in `blueprint_round/inputs/`; raw pattern `https://github.com/aaa11996/yandex_new/raw/refs/heads/main/blueprint_round/inputs/<FILENAME>`, or attaches them to your chat):** `METHODOLOGY_v4_0_FINAL.md` (the methodology; Part II §§11–18 and the Gap Register list what is open), `AMENDMENT_V4-28_RV_DIVIDEND_ADJUSTMENT.md`, `KNOWN_ISSUES_REGISTER.md` (read section K and L first). If a file is in neither place, write `MISSING INPUT: <name>` in your inventory and continue with what you can do honestly.

**Amendments in force beyond v4.0:** V4-28 (weekly range volatility must be computed on dividend-adjusted daily bars; needs verified ex-dates) and V4-29 (market leg of the adjusted return must be consistent: total-return index). Read the amendment file.

**Facts you can rely on (all tested by Claude, still re-verify the ones your role touches):**
- Panel: 75 firms × 419 Mondays (2018-08-27 … 2026-08-31); join key `SEARCH_MONDAY`; MOEX week-end Sunday = Monday + 6.
- Settlement moved from T+2 to T+1 on 31 July 2023 (MOEX press release moex.com/n62684). Weekend equity sessions began 1 March 2025 and are part of the next trading day (moex.com/n93219, moex.com/n93256).
- SFIN, week of 2025-12-22: price fell from about 1,796 to 961 because of a **902 RUB dividend** (9M-2025), record date 25 Dec 2025, last cum-dividend day 24 Dec; seen on three aggregators (T3) only: still needs the issuer's filing.
- Dividend-adjusting RV: across 358 ex-dividend weeks with at least one cum-dividend day in the week, mean RV falls from 0.102 to 0.076 (−25%).

---

## 3. Iron rules (breaking these voids your work)

1. **No hallucination.** Every statement carries a status: `V-CODE` (you ran it), `V-READ` (you opened the source; location given), `V-OFFICIAL` (you opened a primary source), `V-2SRC` (two independent secondary sources), `CANDIDATE` (one non-primary source), `UNVERIFIED`, `CANNOT-VERIFY` (say what blocks it), or `CONFLICT` (sources disagree; list both).
2. **No table is accepted because you "read" it.** Re-parse it programmatically and diff it against its source file. (A prior draft invented 36 of 93 dividend rows by extrapolating the pattern of the real ones.)
3. **No templated "all verified" lists.** Evidence is row-level, in a CSV.
4. **No phantom files.** Name only files you opened or created. Record size and SHA-256 for everything you create. Files you did not receive do not exist for you.
5. **No fabricated citations or dates.** A source must be real and you must have opened it. State the tier. Never estimate, interpolate or "round to a plausible date".
6. **Copyright discipline.** Paraphrase. At most one quote per source, under 15 words. Never reproduce a page or a table of a source.
7. **Read-only on Asif's files.** Never edit them or his abstract/framework text. You write only NEW files in the folders in §9.
8. **Results never decide anything.** You may not choose a coding because of what it does to a regression. You do not run the thesis regressions in this round except where your role says so.
9. **Missing stays missing.** No fill, no interpolation. The grid is 419 Mondays × 75 tickers.
10. **Do not trust other agents or earlier reports.** Re-derive. Where you disagree with the register, v4.0 or an earlier document, show the evidence.
11. **Protect your context.** Keep a running `STATE.md` (done, next, file hashes) so a fresh window can resume from the files.

---

## 4. Sources, verification and the gap rule

**Tiers.** T1 primary official (OFAC, EU Official Journal/EUR-Lex, UK OFSI/Gov.uk, MOEX, Bank of Russia, e-disclosure.ru filings, issuer investor-relations pages and annual reports, Rosimushchestvo, Yandex help pages). T2 reputable secondary (Reuters, Interfax, Bloomberg, Kommersant, RBC, peer-reviewed papers, central-bank bulletins). T3 aggregators and forums (smart-lab, dohod.ru, investmint, investfunds, T-Bank pages, investing.com, blogs): **a pointer, never evidence.**

**A datum is `VERIFIED` only if** you opened a T1 source for it, or two independent T2 sources (different original reporting, not reprints of one wire). Otherwise it is `CANDIDATE` and goes to the gap list with its candidate value; it is never used as data.

**Gap rule.** A gap may be declared only after **at least five documented search attempts**, in English and Russian, including the primary source's own search. Log the queries in `W1_SEARCH_LOG.csv` (query, site, date, result). "Not found in the files" is not a search.

**Every datum records:** date type (announcement / effective / publication / record / ex-date), time zone (Moscow, UTC, US), URL, access date, tier, and a short paraphrase. Conflicts: list both, apply tier precedence, mark equal-tier conflicts `UNRESOLVED`.

**Coverage statement** for every dataset: items total, verified, candidate, unverifiable, coverage %, and the list of unchecked items. Never claim more coverage than you performed.

**Source map.** Sanctions: OFAC recent actions and SDN list (treasury.gov), EU Official Journal (eur-lex.europa.eu), UK OFSI consolidated list (gov.uk). Ownership: issuer annual reports and ownership disclosures, Rosimushchestvo, e-disclosure.ru affiliate and ownership lists, issuer IR pages. Dividends and corporate actions: e-disclosure.ru material facts, issuer releases, MOEX corporate-action and announcement pages. Market series: MOEX index data service, Bank of Russia (cbr.ru) for key rate and FX, EIA or another official source for Brent. Events: MOEX, Bank of Russia and regulator announcements; Interfax, Reuters, Kommersant.

---

## 5. Completion discipline (the previous round skipped tasks silently; you must not)

1. Your report starts with a **Completion Table**: every numbered checklist item in your role, with status `DONE` / `PARTIAL` / `NOT-DONE`, the evidence file, and the coverage number.
2. Anything `PARTIAL` or `NOT-DONE` is also listed in `W1_NOT_DONE.md` with the reason and what you tried.
3. Work in priority order **P1 → P2 → P3**. Finish P1 completely before starting P2. If you run out of context or time, write `STATE.md` and stop honestly; do not rush a row you cannot verify.
4. A bigger table is not a better table. Ten rows verified at T1 beat a hundred rows copied from an aggregator.

---

## 6. Roles

### AGENT 1: Sanctions

**Claims to verify** (first full-blocking-type anchor week per firm, Monday labels, from `sanction_i_t.csv`; 24 firms, 3,687 firm-weeks): NMTP 2022-02-21 · VTBR 2022-02-21 · ALRS 2022-04-04 · CBOM 2022-04-04 · SBER 2022-04-04 · AFLT 2022-05-16 · CHMF 2022-05-30 · IRKT 2022-06-27 · KMAZ 2022-06-27 · MAGN 2022-08-01 · BSPB 2023-02-20 · MTSS 2023-02-20 · USBN 2023-02-20 · FESH 2023-05-15 · PLZL 2023-05-15 · TRMK 2023-05-15 · SIBN 2025-01-06 · SNGS 2025-01-06 · LKOH 2025-10-20 · ROSN 2025-10-20 · AVAN 2026-04-20 · BANE 2026-04-20 · JNOS 2026-04-20 · MFGS 2026-04-20. The earlier draft flags AVAN as unverified and AFLT as single-source; ROSN, LKOH, SIBN and SNGS were checked from secondary summaries only. The 2026 anchors concern events after Claude's own knowledge: find them or mark them `UNVERIFIED`.

**P1: verify the 24.** For each firm: first designation or measure by jurisdiction (US OFAC; EU; UK OFSI; add Canada, Japan, Switzerland, Australia only if they come first), the instrument (SDN full blocking; EU Annex I asset freeze; UK asset freeze; sectoral or directive-based; parent- or subsidiary-level exposure and the 50%-rule basis), announcement date and effective date (Moscow-time week), any removal or relief, T1 URL, access date, status. Say whether each claimed anchor week equals the Monday of the week containing the announcement date, and give the difference in weeks where it does not.
**P2: negative verification of the other 51 firms:** designated or not, in which jurisdiction, when; parents and affiliates whose designation would bind the firm (state the basis); source and date checked. "Not designated" needs the list name, the date searched and the query.
**P3: coding options as ready matrices** (`week_monday` key only, 419 × 75): A any-jurisdiction first full-blocking-type designation (permanent step); B US only; C EU only; D UK only; E number of jurisdictions in force (0–3); F the five-week reaction variant around each verified anchor. Include a short note on lag convention (anchor Monday vs the week after the announcement).
**Deliver:** `sanctions_firm_table.csv` (75 rows), `sanctions_anchors_verified.csv` (24 rows with claimed vs verified week, difference, status), `sanctions_negative_checks.csv` (51 rows), `sanction_i_t_A.csv` … `_F.csv`, `README_sanctions.md`, a Judge-ready draft of Part II §12, `W1_SEARCH_LOG.csv`.

### AGENT 2: State ownership and sector map

**Blindness rule.** **Do not open** `UNIFIED_PAPER_about_state_ownership.md` (Appendix A), `Combined_Data_File.md` §5, `THESIS_HANDOFF_BRIEF.md` or `FINAL_REPORT.md` until Part A is finished and saved with its hash. Log the time you first open any of them in `W2_BLINDNESS_LOG.md`. The rule (from v2.0): SOE = 1 iff the Russian state (federal or regional, direct or through a state-controlled holding) holds ≥ 25% of voting shares; allowed values 1 / 0 / UNDETERMINED.
**Part A (P1): independent classification of all 75 firms** from primary disclosures: percentage held and by whom (direct and indirect, with the chain), as-of date, source, tier; any change of control during 2018–2026 (privatisation, nationalisation, a new state holding) with dates; free-float and any golden share where relevant. Record how the classification would change under thresholds of 10%, 25% and 50%, and under a continuous state-share variable.
**Part B (P2): comparison** with the published 35 SOE / 40 non-SOE table after Part A is saved: list every firm that differs, why, and which evidence wins. Treat the knife-edge and flagged cases explicitly (VSMO, TATN, TTLK, UTAR, MGNT, RUAL, RGSS, PIKK, TRMK, LKOH, SNGS, CBOM, YAKG).
**Part C (P3): sector map check:** verify each firm's sector against its main business from primary sources; resolve the disputed YAKG label.
**Deliver:** `soe_blind_classification.csv` (75 rows with all fields), `soe_vs_published.csv`, `soe_time_variation.csv`, `soe_continuous.csv` (state share by firm and, where it changed, by period), `sector_map_check.csv`, `W2_BLINDNESS_LOG.md`, a draft of Part II §14, `W2_SEARCH_LOG.csv`.

### AGENT 3: Dividends, ex-dates and dividend-adjusted series

**Why this matters.** The primary return outcome (V4-05) and, after V4-28, the weekly range volatility both need the true **ex-dividend date and amount**. The current table has record dates only, from aggregators, with ex-dates approximated.
**P1: ex-dates and amounts for the 587 rows, largest effects first.** Order the rows by dividend yield (amount ÷ the close before the ex-week, from the panel). For each row, find the T1 or two-T2 evidence of: record date, last day with the right to the dividend, ex-date, amount per share and share class, currency. Do the highest-yield 150 rows first, then every row from 2023-07-31 onward (T+1 era), then the rest. Compute the ex-date from the settlement rule only when no source states it, and mark such rows `DERIVED`.
**P2: completeness.** (i) Confirm that each of the 12 non-payers (JNOS, MFGS, RNFT, VJGZ, BLNG, CHMK, ROLO, UKUZ, UNAC, FESH, UTAR, MRKK) paid no dividend in 2018–2026, with the primary evidence. (ii) For the 63 payers, search for **missing** dividends (special, interim, extra) and for the share class: where a firm has ordinary and preferred shares, make sure each dividend belongs to the class traded under the panel's ticker. (iii) Audit the 18 announced-not-paid exclusions (`phase1_exclusion_audit.csv`). (iv) Reproduce arithmetically how 587 record dates become 529 record-week cells, 2,110 Div=1 weeks and 2,108 valid lagged cells (`dividend_count_bridge.csv`).
**P3: build the series.** Implement Amendment V4-28 on the daily files with your verified ex-dates and amounts: `rv_dividend_adjusted_weekly.csv` (TICKER, week_monday, rv_raw, rv_adj, n_dividends_in_week, ex_date, amount, yield, status) and `ret_total_weekly.csv` (dividend-added-back weekly return on the same grid). Report the effect: how many weeks change, by how much, and the verified-vs-approximate-ex-date difference on the rows where both exist. Report both the additive and the multiplicative adjustment on 20 random ex-weeks (seed printed).
**P4:** rebuild `div_i_t.csv` (Div = 1 in the four weeks before the record week; `week_monday` key only) from the verified table.
**Deliver:** `dividends_verified.csv` (one row per dividend; columns: ticker, share_class, record_date, last_cum_date, ex_date, ex_week_monday, amount, currency, source tiers and URLs, status), `dividend_count_bridge.csv`, `div_i_t.csv`, the two series above, scripts in `REPRO/`, a draft of Part II §13, `W3_SEARCH_LOG.csv`.

### AGENT 4: Corporate actions, market-level series, institutional events and crisis anchors

**P1: corporate actions for all 75 firms** (ticker, date, type, ratio, effective and trading-resumption dates, source, tier, status). Verify the four panel-flagged events against issuer or MOEX disclosures: GMKN 100:1 split effective 2024-04-08; VTBR 5000:1 consolidation effective 2024-07-15; PLZL 10:1 split with trading resumed 2025-03-27; ROLO dilution / large share issue with trading resumed 2023-01-19. Scan all 75 daily files for any other split-like event with the signature (week-over-week price ratio and share-volume ratio moving in opposite directions while ruble value stays in a normal range; also run a lower threshold than a factor of 10, because a 2:1 split is invisible to a 10× screen) and for ticker changes and board-lot changes; resolve each hit from sources. **SFIN 2025-12-22:** find the issuer filing for the 902 RUB dividend (record date 25 Dec 2025) and close the case (dividend, not split). Deliver adjustment factors where a split or consolidation needs them.
**P2: market-level series, weekly on the Monday grid, with provenance:** IMOEX (verify the panel's `IMOEX_CLOSE` against the official index history for a seeded sample of at least 40 weeks); the **MOEX total-return index** (needed by V4-29); USD/RUB (Bank of Russia official rate; check and document whether its construction or availability changed during the sample, for example after exchange FX trading stopped); Brent; the Bank of Russia key rate (decision dates and levels, carried to weeks). State the alignment rule (end-of-week level vs weekly average) per series. If a series cannot be downloaded, give the exact URL and series identifier and mark it `NOT RETRIEVED`.
**P3: institutional events with T1 dates:** the 2022 market closure and phased reopening; index exclusions (MSCI, FTSE and any MOEX-side changes); restrictions on non-resident investors; the June 2024 sanctions on the Moscow Exchange and any FX-trading halt that followed; weekend sessions from 2025-03-01; the T+1 switch. Also the **four crisis windows** (2020-02-24…04-13; 2022-02-21…03-28; 2023-09-04…09-18; 2026-06-22…07-27): for each, dated external events from T1/T2 sources that explain the window, and the same for the mobilisation week of 2022-09-19, which lies outside every window.
**P4: trading calendar:** reasons for the 328 no-trade ticker-weeks (suspension, not yet listed, delisted, halt) with sources; the 7 weeks with high = low.
**Deliver:** `corporate_actions.csv`, `adjustment_factors.csv`, `market_series_weekly.csv` plus `market_series_provenance.csv`, `institutional_events.csv`, `crisis_anchors.csv`, `trading_calendar_reasons.csv`, drafts of Part II §§11, 16, 17, `W4_SEARCH_LOG.csv`.

---

## 7. QA LOOP 1: internal and hard (before Package v1)

1. **Build.** Every claim goes into `W1_CLAIMS.csv` (id, statement, status, evidence pointer); every source into `W1_SOURCES.csv` (id, title or URL, tier, accessed, how used, status).
2. **Attack.** For every claim that changes a data value, and every absence claim ("not designated", "no dividend", "not found"): re-derive by a second source or method; run at least five adversarial searches in both languages; re-run all scripts from a clean state; re-parse and diff every table against its source.
3. **Fresh-eyes review.** Act as a separate reviewer reading only your deliverables. Score 0–10, two points each: (1) every datum has evidence a stranger can re-run; (2) every source is real, opened and correctly tiered; (3) honesty: gaps and `NOT-DONE` listed, nothing unverified presented as verified, nothing result-driven; (4) scope: every checklist item done or explicitly marked not done; (5) usability: schemas documented, files load, Completion Table present.
4. **Pass mark ≥ 9/10.** Otherwise fix and repeat (up to 3 rounds). If you still fall short, say so at the top and list the weaknesses.
Write `W1_QA1_LOG.md`.

---

## 8. QA LOOP 2: cross-agent and hard

Pairs: **1↔2, 3↔4.** Asif carries your partner's package to you. **Pairs and file names.** In `REVIEW_of_W<n>.md`, `RESPONSE_W<n>.md` and `CLOSURE_W<n>.md`, `<n>` is the number of the agent whose package is being reviewed (the reviewee). Everywhere else `W1` is your own number.
**2a Review your partner's Package v1.** Verify every manifest hash; refuse mismatched files. Re-run scripts from a clean state. Re-open **every source behind a changed data value and every source behind an absence claim**, plus a seeded random 30% of the rest (state the seed). Run your own five searches for each absence claim. Recompute a seeded sample of at least 30 rows per dataset. Give each claim a verdict (`CONFIRMED` / `NOT REPRODUCED` / `CONTRADICTED` / `UNVERIFIABLE`) and score the package with the QA-1 rubric. Write `REVIEW_of_W<n>.md`.
**2b Respond** to the review claim by claim (fix, or rebut with evidence). Produce Package v2 and `RESPONSE_W<n>.md`.
**2c Closure.** Check your partner's v2. Write `CLOSURE_W<n>.md`: `PASS` (≥ 9/10 and no open S1), `CONDITIONAL` (listed residuals) or `FAIL`.

---

## 9. Hand-off and integrity

**Folders (if you have repo write access; otherwise produce the same files and Asif carries them):** `blueprint_round/datafix/stage1/W1/`, `blueprint_round/datafix/stage2/W1/`.
**Every package has `MANIFEST.md`:** each file with size and SHA-256. A receiver recomputes the hashes and refuses on mismatch. After publishing, re-fetch each file from its live URL and compare hashes, and say plainly whether the round-trip succeeded. If you cannot publish, print the Judge Brief in full and list every file with its hash.
**Package contents:** `W1_REPORT.md` (Completion Table first), `W1_JUDGE_BRIEF.md` (≤ 1,500 words), `W1_CLAIMS.csv`, `W1_SOURCES.csv`, `W1_SEARCH_LOG.csv`, `W1_NOT_DONE.md`, the data files of your role, `REPRO/` (one-command scripts printing library versions and seeds, with their outputs), `W1_QA1_LOG.md`, `MANIFEST.md`.
**Judge Brief:** (1) what is now verified, by dataset, with coverage numbers; (2) what changed relative to v4.0 and the old control files; (3) what is still open and what would close it; (4) a plain-English paragraph for Asif with one demo.

---

## 10. Formats

All weekly files use the single key `week_monday` (ISO date, Monday), 419 rows, ticker columns (wide) or `TICKER,week_monday,value` (long). Dates are ISO. CSV is UTF-8 with header. Every file has a schema note in its README.

**Finding (use exactly):**
```
ID: W3-014 | Class: ERROR | Severity: S2 | Status: V-OFFICIAL
Where: dividends_verified.csv, SFIN, record date 2025-12-25
What is wrong: the panel treats the 2025-12-22 week as an unexplained price break
Evidence: issuer filing <URL, access date>; 902 RUB per share; last cum date 2025-12-24
Effect: weekly RV 0.678 -> 0.185 after adjustment (REPRO/rv_adjust.py)
Proposal (Asif decides): adopt ex-date-based adjustment (V4-28)
Result-neutral reason: yes, a verified corporate fact, found before any estimate was run
```

---

## 11. Plain English (Asif asked for this explicitly)

He is a smart Master's student who wants to understand every step. For every important finding, the Judge Brief says: what it is in ≤ 6 sentences with no jargon (define any term the first time); a tiny runnable demo (5–10 rows of real or toy numbers); what it means for the thesis in one sentence and how worried he should be (low / medium / high) and why.
**Style example:** "A share trades at 1,800 and pays a 902 RUB dividend. The next day it trades near 960. Nobody sold in a panic: the dividend left the company, and the price dropped by the same amount. A weekly high-minus-low range that includes both days reads 0.68, but about 0.5 of that is the dividend leaving. Subtracting the 902 from the days before the ex-date gives 0.185, which is the real trading range."

---

## 12. Final self-check before you finish

- Completion Table present; every `PARTIAL` or `NOT-DONE` item explained in `NOT_DONE.md`?
- Every datum `VERIFIED` has a T1 source (or two independent T2) that I opened? Every aggregator-only row labelled `CANDIDATE`?
- Every gap backed by at least five logged searches in two languages?
- Every table re-parsed and diffed, not "read"?
- Anything chosen because of what a regression result looks like? (must be NO)
- Did I change any of Asif's files or his abstract or framework text? (must be NO)
- Manifest and hashes complete; round-trip result stated?
- QA score ≥ 9, or said plainly that it is not?
- Did I stay inside my stage and write `WAITING FOR` instead of guessing?
