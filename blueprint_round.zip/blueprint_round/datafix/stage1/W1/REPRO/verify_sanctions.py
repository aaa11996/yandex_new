#!/usr/bin/env python3
"""
Agent 1: Sanctions Verification Script
Purpose: Verify sanction dates for 24 firms against primary sources
Author: Data Completion Round - Agent 1
Date: 2026-10-10
"""

import pandas as pd
import csv
from datetime import datetime, timedelta
import hashlib
import os

# ============================================================================
# CONFIGURATION
# ============================================================================

# Agent info
AGENT_NUMBER = "W1"
AGENT_ROLE = "Sanctions"

# Input files
SANCTION_MATRIX = "/home/user/shared_data/control_matrices/sanction_i_t.csv"

# Output files
SEARCH_LOG = "../W1_SEARCH_LOG.csv"
ANCHORS_VERIFIED = "../sanctions_anchors_verified.csv"
FIRM_TABLE = "../sanctions_firm_table.csv"
CLAIM_LOG = "../W1_CLAIMS.csv"
SOURCE_LOG = "../W1_SOURCES.csv"

# Firms to verify (from prompt)
FIRMS_TO_VERIFY = [
    ('NMTP', '2022-02-21'),
    ('VTBR', '2022-02-21'),
    ('ALRS', '2022-04-04'),
    ('CBOM', '2022-04-04'),
    ('SBER', '2022-04-04'),
    ('AFLT', '2022-05-16'),
    ('CHMF', '2022-05-30'),
    ('IRKT', '2022-06-27'),
    ('KMAZ', '2022-06-27'),
    ('MAGN', '2022-08-01'),
    ('BSPB', '2023-02-20'),
    ('MTSS', '2023-02-20'),
    ('USBN', '2023-02-20'),
    ('FESH', '2023-05-15'),
    ('PLZL', '2023-05-15'),
    ('TRMK', '2023-05-15'),
    ('SIBN', '2025-01-06'),
    ('SNGS', '2025-01-06'),
    ('LKOH', '2025-10-20'),
    ('ROSN', '2025-10-20'),
    ('AVAN', '2026-04-20'),
    ('BANE', '2026-04-20'),
    ('JNOS', '2026-04-20'),
    ('MFGS', '2026-04-20'),
]

# Special flags from prompt
SPECIAL_FLAGS = {
    'AFLT': 'single-source in v4.0',
    'AVAN': 'unverified, post-Claude knowledge',
    'BANE': 'unverified, post-Claude knowledge',
    'JNOS': 'unverified, post-Claude knowledge',
    'MFGS': 'unverified, post-Claude knowledge',
    'ROSN': 'secondary summary only',
    'LKOH': 'secondary summary only',
    'SIBN': 'secondary summary only',
    'SNGS': 'secondary summary only',
}

# All 75 firms (from sanction_i_t.csv columns)
ALL_FIRMS = [
    'ABRD', 'AFKS', 'AFLT', 'AKRN', 'ALRS', 'AVAN', 'BANE', 'BLNG', 'BSPB', 'CBOM',
    'CHMF', 'CHMK', 'FEES', 'FESH', 'GAZP', 'GCHE', 'GMKN', 'HYDR', 'IRAO', 'IRKT',
    'JNOS', 'KAZT', 'KMAZ', 'KZOS', 'LKOH', 'LSNG', 'LSRG', 'MAGN', 'MFGS', 'MGNT',
    'MGTS', 'MRKC', 'MRKK', 'MRKP', 'MRKS', 'MRKU', 'MSNG', 'MSRS', 'MSTT', 'MTSS',
    'MVID', 'NKNC', 'NLMK', 'NMTP', 'NVTK', 'OGKB', 'PHOR', 'PIKK', 'PLZL', 'RASP',
    'RGSS', 'RNFT', 'ROLO', 'ROSN', 'RTKM', 'RUAL', 'SBER', 'SELG', 'SFIN', 'SIBN',
    'SNGS', 'TATN', 'TGKA', 'TRMK', 'TTLK', 'UKUZ', 'UNAC', 'UPRO', 'USBN', 'UTAR',
    'VJGZ', 'VSMO', 'VTBR', 'YAKG', 'YNDX'
]

# Jurisdictions to check
JURISDICTIONS = {
    'US': {
        'name': 'US OFAC',
        'sdn_list': 'https://sanctionssearch.ofac.treas.gov/',
        'recent_actions': 'https://home.treasury.gov/policy-issues/financial-sanctions/recent-actions',
        'tier': 'T1'
    },
    'EU': {
        'name': 'European Union',
        'official_journal': 'https://eur-lex.europa.eu/',
        'tier': 'T1'
    },
    'UK': {
        'name': 'UK OFSI',
        'consolidated_list': 'https://www.gov.uk/government/publications/financial-sanctions-consolidated-list-of-targets',
        'tier': 'T1'
    },
    'CA': {'name': 'Canada', 'tier': 'T1'},
    'JP': {'name': 'Japan', 'tier': 'T1'},
    'CH': {'name': 'Switzerland', 'tier': 'T1'},
    'AU': {'name': 'Australia', 'tier': 'T1'},
}


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_week_monday(date_str):
    """Convert a date to the Monday of that week (ISO)"""
    dt = pd.to_datetime(date_str)
    # ISO week: Monday is 1, Sunday is 7
    return dt - timedelta(days=dt.weekday())


def compute_week_difference(announcement_date, anchor_monday):
    """Compute difference in weeks between announcement date and anchor Monday"""
    anchor_dt = pd.to_datetime(anchor_monday)
    # Find the Monday of the announcement week
    ann_monday = get_week_monday(announcement_date)
    # Difference in weeks
    delta = (ann_monday - anchor_dt).days / 7
    return delta


def sha256_file(filepath):
    """Compute SHA-256 hash of a file"""
    sha256 = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()


# ============================================================================
# INITIALIZE LOG FILES
# ============================================================================

def initialize_logs():
    """Initialize all log CSV files with headers"""
    
    # Search log
    search_log_header = [
        'search_id', 'firm', 'query', 'site', 'date_utc', 'result',
        'url', 'tier', 'notes'
    ]
    
    # Anchors verified
    anchors_header = [
        'firm', 'claimed_anchor_week', 'jurisdiction', 'instrument',
        'announcement_date', 'effective_date', 'anchor_monday_matches',
        'week_difference', 'removal_or_relief', 't1_url', 'access_date',
        'status', 'notes', 'flag_from_v4'
    ]
    
    # Firm table
    firm_table_header = [
        'firm', 'soe_status', 'sector', 'first_sanction_date',
        'jurisdictions', 'instrument_types', 'current_status',
        'source_tier', 'verification_date', 'notes'
    ]
    
    # Claims log
    claims_header = [
        'claim_id', 'statement', 'status', 'evidence_pointer',
        'firm', 'date_checked', 'notes'
    ]
    
    # Source log
    source_header = [
        'source_id', 'title_or_url', 'tier', 'accessed',
        'how_used', 'status', 'notes'
    ]
    
    # Write headers
    for filepath, header in [
        (SEARCH_LOG, search_log_header),
        (ANCHORS_VERIFIED, anchors_header),
        (FIRM_TABLE, firm_table_header),
        (CLAIM_LOG, claims_header),
        (SOURCE_LOG, source_header),
    ]:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(header)
    
    print("✓ Log files initialized")


# ============================================================================
# MAIN VERIFICATION FUNCTION
# ============================================================================

def verify_sanction_anchor(firm, claimed_week, flag=None):
    """
    Verify a single sanction anchor for a firm.
    Returns a dictionary with verification results.
    """
    
    result = {
        'firm': firm,
        'claimed_anchor_week': claimed_week,
        'jurisdiction': '',
        'instrument': '',
        'announcement_date': None,
        'effective_date': None,
        'anchor_monday_matches': None,
        'week_difference': None,
        'removal_or_relief': '',
        't1_url': '',
        'access_date': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC'),
        'status': 'UNVERIFIED',
        'notes': '',
        'flag_from_v4': flag or ''
    }
    
    # TODO: Implement actual verification via web search
    # This is a placeholder - actual implementation requires web access
    
    # For now, mark as placeholder
    result['status'] = 'PLACEHOLDER - NEEDS WEB VERIFICATION'
    result['notes'] = 'Verification requires opening T1 sources (OFAC/EU/UK)'
    
    return result


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    print("=" * 70)
    print(f"Agent {AGENT_NUMBER}: Sanctions Verification")
    print("=" * 70)
    print(f"Starting: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print()
    
    # Initialize logs
    initialize_logs()
    
    # Load sanction matrix
    print("Loading sanction matrix...")
    try:
        sanction_df = pd.read_csv(SANCTION_MATRIX)
        print(f"✓ Loaded sanction_i_t.csv: {len(sanction_df)} rows, {len(sanction_df.columns)} columns")
    except Exception as e:
        print(f"✗ Error loading sanction matrix: {e}")
        return
    
    # Verify the 24 anchor firms
    print("\n" + "=" * 70)
    print("P1: Verifying 24 anchor firms")
    print("=" * 70)
    
    anchors_verified = []
    
    for firm, claimed_week in FIRMS_TO_VERIFY:
        print(f"\nProcessing: {firm} - claimed anchor: {claimed_week}")
        flag = SPECIAL_FLAGS.get(firm, '')
        
        # Verify against primary sources
        result = verify_sanction_anchor(firm, claimed_week, flag)
        anchors_verified.append(result)
        
        # Log to console
        print(f"  Status: {result['status']}")
        if result['notes']:
            print(f"  Notes: {result['notes']}")
    
    # Save anchors verified
    print("\nSaving sanctions_anchors_verified.csv...")
    try:
        with open(ANCHORS_VERIFIED, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'firm', 'claimed_anchor_week', 'jurisdiction', 'instrument',
                'announcement_date', 'effective_date', 'anchor_monday_matches',
                'week_difference', 'removal_or_relief', 't1_url', 'access_date',
                'status', 'notes', 'flag_from_v4'
            ])
            writer.writeheader()
            for row in anchors_verified:
                writer.writerow(row)
        print(f"✓ Saved {len(anchors_verified)} records")
    except Exception as e:
        print(f"✗ Error saving anchors: {e}")
    
    # TODO: P2 - Negative verification of 51 firms
    print("\n" + "=" * 70)
    print("P2: Negative verification of 51 firms")
    print("=" * 70)
    print("STATUS: NOT YET IMPLEMENTED")
    
    # TODO: P3 - Coding matrices
    print("\n" + "=" * 70)
    print("P3: Coding matrices (A-F)")
    print("=" * 70)
    print("STATUS: NOT YET IMPLEMENTED")
    
    print("\n" + "=" * 70)
    print(f"Agent {AGENT_NUMBER} initialization complete")
    print(f"Finished: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print("=" * 70)
    
    # Update state
    print("\nNOTE: This script needs to be extended with actual web verification.")
    print("Each firm requires:")
    print("  1. Search OFAC SDN list and recent actions")
    print("  2. Search EU Official Journal")
    print("  3. Search UK OFSI consolidated list")
    print("  4. Check Canada, Japan, Switzerland, Australia if needed")
    print("  5. Log all searches in W1_SEARCH_LOG.csv")
    print("  6. Minimum 5 search attempts per firm (rule from prompt)")


if __name__ == '__main__':
    main()
