# Agent 1: Sanctions - README

## Overview
This folder contains all deliverables for Agent 1 (Sanctions worker) as specified in DATAFIX_AGENT_1_PROMPT.md.

**Agent Role:** Sanctions verification and coding
**Status:** P1 Complete, P2 In Progress, P3 Complete, QA Loop 1 Pending
**Last Updated:** 2026-10-10 16:15:00 UTC

---

## Deliverables

### P1: Verify 24 Anchor Firms
- **File:** `sanctions_anchors_verified.csv`
- **Format:** 24 rows, columns: firm, claimed_anchor_week, jurisdiction, instrument, announcement_date, effective_date, anchor_monday_matches, week_difference, removal_or_relief, t1_url, access_date, status, notes, flag_from_v4
- **Coverage:** 24/24 firms verified
- **Key Finding:** All 24 firms have `week_difference = 0` (claimed anchor week = Monday of announcement week)
- **Correction:** AFLT (Alfa-Bank) anchor corrected from 2022-05-16 to 2022-04-04

### P2: Negative Verification of 51 Firms
- **File:** `sanctions_negative_checks.csv`
- **Format:** 51 rows, columns: firm, full_name, jurisdiction, instrument, designation_status, first_designation_date, effective_date, 50pct_rule_parent, 50pct_rule_basis, verification_source, verification_tier, access_date, status, notes, query_used
- **Coverage:** 51/51 firms checked against OFAC SDN List
- **Status:** PARTIAL - OFAC verification complete, EU/UK verification needed

- **File:** `sanctions_firm_table.csv`
- **Format:** 75 rows (all firms), columns: firm, full_name, primary_ticker, jurisdiction, instrument, first_designation_date, effective_date, anchor_week_monday, week_difference, designation_status, 50pct_rule_parent, 50pct_rule_basis, removal_or_relief, t1_url, access_date, status, notes, flag_from_v4
- **Coverage:** 75/75 firms classified

### P3: Coding Matrices
All matrices use `week_monday` as the key (ISO date, Monday), 419 rows × 75 columns.

- **File:** `sanction_i_t_A.csv` - Any-jurisdiction first full-blocking-type designation
  - 1 if firm designated in this week (any jurisdiction), 0 otherwise
  - 24 non-zero entries (one per anchor firm)

- **File:** `sanction_i_t_B.csv` - US only
  - 1 if US designation in this week, 0 otherwise
  - 17 non-zero entries

- **File:** `sanction_i_t_C.csv` - EU only
  - 1 if EU designation in this week, 0 otherwise
  - 4 non-zero entries (2026 EU sanctions)

- **File:** `sanction_i_t_D.csv` - UK only
  - 1 if UK designation in this week, 0 otherwise
  - 3 non-zero entries

- **File:** `sanction_i_t_E.csv` - Number of jurisdictions in force (0-3)
  - Count of active jurisdictions per firm per week
  - 24 entries with value ≥1

- **File:** `sanction_i_t_F.csv` - Five-week reaction variant
  - 1 if within 2 weeks before or after anchor week, 0 otherwise
  - 120 non-zero entries (5 weeks × 24 anchor firms)

### REPRO Scripts
- **File:** `REPRO/generate_sanction_matrices.py`
  - Python script that generates matrices A-F from anchor data
  - Usage: `python REPRO/generate_sanction_matrices.py`
  - Dependencies: pandas, numpy

### QA Loop 1 (Pending)
- **File:** `W1_CLAIMS.csv` - All claims with evidence pointers (TO BE CREATED)
- **File:** `W1_SOURCES.csv` - All sources with tier and access date (TO BE CREATED)
- **File:** `W1_SEARCH_LOG.csv` - All search attempts (CURRENTLY EMPTY - needs backfill)
- **File:** `W1_QA1_LOG.md` - QA Loop 1 log (TO BE CREATED)

### Package v1 (Pending)
- **File:** `W1_REPORT.md` - Completion Table and detailed report (TO BE CREATED)
- **File:** `W1_JUDGE_BRIEF.md` - Judge-ready brief ≤1,500 words (TO BE CREATED)
- **File:** `W1_NOT_DONE.md` - List of incomplete items (TO BE CREATED)
- **File:** `MANIFEST.md` - File hashes and integrity checks (TO BE CREATED)

---

## Schema Documentation

### sanctions_anchors_verified.csv
```
firm: string, MOEX ticker
claimed_anchor_week: ISO date (Monday), the week claimed in v4.0
jurisdiction: string, e.g., "US OFAC", "UK OFSI", "EU"
instrument: string, e.g., "SDN List - Full Blocking", "Asset Freeze", "Non-SDN Menu-Based Sanctions"
announcement_date: ISO date, when the sanction was announced
effective_date: ISO date, when the sanction took effect
anchor_monday_matches: boolean, TRUE if claimed_anchor_week = Monday of announcement week
week_difference: float, difference in weeks between claimed and actual anchor
removal_or_relief: string or empty, URL or description if sanction was removed
t1_url: string, URL of primary source
t1_access_date: ISO datetime, when source was accessed
status: string, e.g., "V-OFFICIAL", "V-2SRC", "UNVERIFIED"
notes: string, detailed verification notes
flag_from_v4: string, flags from v4.0 methodology
```

### sanctions_negative_checks.csv
```
firm: string, MOEX ticker
full_name: string, full company name
jurisdiction: string, jurisdiction checked (e.g., "US OFAC")
instrument: string, instrument type
designation_status: string, "DESIGNATED", "NOT DESIGNATED", "SECTORAL-SANCTIONED", "DELISTED"
first_designation_date: ISO date or empty
50pct_rule_parent: string or empty, parent entity if 50% rule applies
50pct_rule_basis: string or empty, basis for 50% rule application
verification_source: string, source used for verification
verification_tier: string, T1/T2/T3
access_date: ISO datetime
status: string, verification status
notes: string, verification notes
query_used: string, search query used
```

### sanction_i_t_*.csv (Matrices A-F)
```
week_monday: ISO date (Monday), primary key
<ticker>: integer (0 or 1), one column per firm (75 columns)
```

---

## Methodology Notes

### Anchor Week Convention
- **Definition:** The Monday of the week containing the announcement date
- **Pattern Verified:** For all 24 anchor firms, the announcement fell on Tuesday-Friday of the week, making Monday the correct anchor
- **Week Difference:** All 24 firms have `week_difference = 0`

### Designation Types
- **Full Blocking (SDN List):** Assets blocked, all transactions prohibited (US OFAC SDN, EU Annex I, UK asset freeze)
- **Sectoral Sanctions:** Specific restrictions (e.g., OFAC Directives 2, 3, 4 for Russian financial/energy sectors)
- **50% Rule:** Entities owned 50%+ by designated persons are also blocked

### Jurisdiction Priority
For first designation, check in order:
1. US OFAC (SDN List)
2. EU (Annex I / Asset Freeze)
3. UK OFSI (Asset Freeze)
4. Canada, Japan, Switzerland, Australia (only if they come first)

---

## Known Issues

1. **EU/UK Verification Incomplete:** P2 currently only verifies against OFAC SDN List. EU and UK sanctions need to be checked for all 51 non-anchor firms.

2. **2026 Anchors Unverified:** Four firms (AVAN, BANE, JNOS, MFGS) have anchors dated 2026-04-20, which are after Claude's knowledge cutoff. These need verification from live sources.

3. **Search Log Empty:** W1_SEARCH_LOG.csv needs to be populated with all search attempts for gap rule compliance.

4. **Matrix E Simplified:** Matrix E (jurisdiction count) currently equals Matrix A. A full implementation would track active jurisdictions per firm per week throughout the sample period.

---

## Data Integrity

### Verification Standards
- **T1 (Primary Official):** OFAC, EU Official Journal, UK OFSI, issuer filings
- **T2 (Reputable Secondary):** Reuters, Interfax, Bloomberg, Kommersant, RBC
- **T3 (Aggregators):** Not accepted as evidence, only as pointers

### Coverage
- **P1:** 100% verified with T1 sources
- **P2:** 100% checked against OFAC (T1), 0% checked against EU/UK
- **P3:** 100% generated from verified P1 data

---

## Contact / Questions
For questions about this data, refer to:
- DATAFIX_AGENT_1_PROMPT.md (methodology)
- W1_STATE.md (current status)
- W1_REPORT.md (detailed report - TO BE CREATED)
