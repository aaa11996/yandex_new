# Agent 4 - NOT DONE / Remaining Tasks

**Agent:** 4 - Corporate Actions, Market-Level Series, Institutional Events and Crisis Anchors  
**Status:** P1 STARTED  
**Last Updated:** 2026-10-10 22:45:00 UTC

---

## P1: Corporate Actions (STARTED - 0% complete)

### To Do:
- [x] Create `corporate_actions.csv` template
- [x] Verify GMKN 100:1 split effective 2024-04-08 (T1/T2 sources)
- [x] Verify VTBR 5000:1 consolidation effective 2024-07-15 (T1/T2 sources)
- [x] Verify PLZL 10:1 split with trading resumed 2025-03-27 (T1/T2 sources)
- [x] Verify ROLO 10:1 split with trading resumed 2023-01-19 (T1/T2 sources)
- [ ] Scan all 75 daily files for split-like events (price ratio and volume ratio moving in opposite directions)
- [ ] Scan for ticker changes
- [ ] Scan for board-lot changes
- [ ] Resolve each hit from sources
- [ ] SFIN 2025-12-22: Find issuer filing for 902 RUB dividend (record date 25 Dec 2025)
- [ ] Deliver adjustment factors where splits or consolidations need them
- [ ] Create `adjustment_factors.csv`
- [ ] Add at least 5 searches per unverified datum to W4_SEARCH_LOG.csv
- [ ] Populate W4_CLAIMS.csv with claims for QA Loop 1
- [ ] Populate W4_SOURCES.csv with sources for QA Loop 1

### In Progress:
- Template created, ready for data population

### Done:
- [x] W4_PROMPT.md created
- [x] W4_STATE.md created and updated
- [x] W4_NOT_DONE.md created and updated
- [x] W4_SEARCH_LOG.csv initialized
- [x] corporate_actions.csv template created

---

## P2: Market-Level Series (NOT STARTED)

### To Do:
- [ ] IMOEX: Verify panel's IMOEX_CLOSE against official index history (sample ≥ 40 weeks)
- [ ] MOEX total-return index (needed by V4-29)
- [ ] USD/RUB: Bank of Russia official rate
- [ ] Brent: Official source
- [ ] Bank of Russia key rate: Decision dates and levels, carried to weeks
- [ ] State alignment rule (end-of-week level vs weekly average) per series
- [ ] If series cannot be downloaded, give exact URL and mark NOT RETRIEVED
- [ ] Create `market_series_weekly.csv`
- [ ] Create `market_series_provenance.csv`

---

## P3: Institutional Events and Crisis Anchors (NOT STARTED)

### To Do:
- [ ] 2022 market closure and phased reopening
- [ ] Index exclusions (MSCI, FTSE, MOEX-side changes)
- [ ] Restrictions on non-resident investors
- [ ] June 2024 sanctions on Moscow Exchange and any FX-trading halt
- [ ] Weekend sessions from 2025-03-01
- [ ] T+1 switch
- [ ] Four crisis windows:
  - [ ] 2020-02-24…04-13
  - [ ] 2022-02-21…03-28
  - [ ] 2023-09-04…09-18
  - [ ] 2026-06-22…07-27
- [ ] Mobilisation week: 2022-09-19 (outside all windows)
- [ ] For each window: dated external events from T1/T2 sources
- [ ] Create `institutional_events.csv`
- [ ] Create `crisis_anchors.csv`

---

## P4: Trading Calendar (NOT STARTED)

### To Do:
- [ ] Reasons for 328 no-trade ticker-weeks (suspension, not yet listed, delisted, halt)
- [ ] Reasons for 7 weeks with high = low
- [ ] Create `trading_calendar_reasons.csv`

---

## Final Deliverables (NOT STARTED)

### To Do:
- [ ] Drafts of Part II §§11, 16, 17
- [ ] W4_QA1_LOG.md - QA Loop 1 attack phase
- [ ] W4_REPORT.md - Report
- [ ] W4_JUDGE_BRIEF.md - Judge brief
- [ ] MANIFEST.md - File hashes
- [ ] PROGRESS_SUMMARY.md - Progress summary
- [ ] REPRO/ - Reproduction scripts

---

*Last Updated: 2026-10-10 22:45:00 UTC*
