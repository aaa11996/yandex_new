# Agent 4: Corporate Actions, Market-Level Series, Institutional Events and Crisis Anchors - Prompt

**Agent:** 4 - Corporate Actions, Market-Level Series, Institutional Events and Crisis Anchors (worker)  
**Role:** Verify corporate actions, market series, institutional events, and crisis windows  
**Workspace:** `/home/user/blueprint_round/datafix/stage1/W4/`  
**Prefix:** `W4_`  
**Status:** NOT STARTED

---

## Mission

Verify corporate actions for all 75 firms, build market-level series, document institutional events, and verify crisis anchors.

---

## Tasks (Priority Order: P1 → P2 → P3 → P4)

### P1: Corporate Actions (NOT STARTED)
**Goal:** Verify corporate actions for all 75 firms.

**Steps:**
1. Verify 4 panel-flagged events against issuer or MOEX disclosures:
   - GMKN: 100:1 split effective 2024-04-08
   - VTBR: 5000:1 consolidation effective 2024-07-15
   - PLZL: 10:1 split with trading resumed 2025-03-27
   - ROLO: dilution / large share issue with trading resumed 2023-01-19
2. Scan all 75 daily files for split-like events (price ratio and volume ratio moving in opposite directions)
3. Scan for ticker changes and board-lot changes
4. Resolve each hit from sources
5. SFIN 2025-12-22: Find issuer filing for 902 RUB dividend (record date 25 Dec 2025)
6. Deliver adjustment factors where splits or consolidations need them

**Output:** `corporate_actions.csv`, `adjustment_factors.csv`

### P2: Market-Level Series (NOT STARTED)
**Goal:** Build weekly market-level series on Monday grid with provenance.

**Steps:**
1. IMOEX: Verify panel's `IMOEX_CLOSE` against official index history (sample ≥ 40 weeks)
2. MOEX total-return index (needed by V4-29)
3. USD/RUB: Bank of Russia official rate; check if construction changed during sample
4. Brent: Official source
5. Bank of Russia key rate: Decision dates and levels, carried to weeks
6. State alignment rule (end-of-week level vs weekly average) per series
7. If series cannot be downloaded, give exact URL and mark `NOT RETRIEVED`

**Output:** `market_series_weekly.csv`, `market_series_provenance.csv`

### P3: Institutional Events and Crisis Anchors (NOT STARTED)
**Goal:** Document institutional events with T1 dates.

**Steps:**
1. 2022 market closure and phased reopening
2. Index exclusions (MSCI, FTSE, MOEX-side changes)
3. Restrictions on non-resident investors
4. June 2024 sanctions on Moscow Exchange and any FX-trading halt
5. Weekend sessions from 2025-03-01
6. T+1 switch
7. Four crisis windows:
   - 2020-02-24…04-13
   - 2022-02-21…03-28
   - 2023-09-04…09-18
   - 2026-06-22…07-27
8. Mobilisation week: 2022-09-19 (outside all windows)
9. For each window: dated external events from T1/T2 sources

**Output:** `institutional_events.csv`, `crisis_anchors.csv`

### P4: Trading Calendar (NOT STARTED)
**Goal:** Document reasons for no-trade weeks.

**Steps:**
1. Reasons for 328 no-trade ticker-weeks (suspension, not yet listed, delisted, halt)
2. Reasons for 7 weeks with high = low

**Output:** `trading_calendar_reasons.csv`

---

## Deliverables

1. `corporate_actions.csv` - Corporate actions for all 75 firms
2. `adjustment_factors.csv` - Adjustment factors for splits/consolidations
3. `market_series_weekly.csv` - Market-level series
4. `market_series_provenance.csv` - Series provenance
5. `institutional_events.csv` - Institutional events
6. `crisis_anchors.csv` - Crisis anchors
7. `trading_calendar_reasons.csv` - Trading calendar reasons
8. Drafts of Part II §§11, 16, 17
9. `W4_CLAIMS.csv` - Claims for QA Loop 1
10. `W4_SOURCES.csv` - Sources for QA Loop 1
11. `W4_SEARCH_LOG.csv` - Search log (≥5 per unverified datum)
12. `W4_QA1_LOG.md` - QA Loop 1 attack phase
13. `W4_REPORT.md` - Report
14. `W4_JUDGE_BRIEF.md` - Judge brief
15. `W4_NOT_DONE.md` - Remaining tasks
16. `W4_STATE.md` - State tracker
17. `MANIFEST.md` - File hashes
18. `PROGRESS_SUMMARY.md` - Progress summary

---

## Key Rules

1. **Verification:** T1 sources (MOEX, Bank of Russia, issuer disclosures) or two independent T2 sources
2. **Gap Rule:** At least 5 documented search attempts per unverified datum
3. **Amendment V4-28:** Dividend-adjusted series
4. **Amendment V4-29:** Consistent total-return index
5. **Status Tracking:** Maintain W4_STATE.md and W4_NOT_DONE.md

---

## Data Sources

- **Primary (T1):** MOEX corporate-action pages, Bank of Russia (cbr.ru), EIA, issuer disclosures
- **Secondary (T2):** Reuters, Interfax, Kommersant
- **Data:** MOEX daily files, panel data

---

## Next Steps

1. Start P1: Create `corporate_actions.csv` template
2. Verify 4 panel-flagged corporate actions first
3. Scan all firms for additional corporate actions
4. Document all sources and search attempts
5. Complete P1 before moving to P2

---

*Generated: 2026-10-10 22:45:00 UTC*
