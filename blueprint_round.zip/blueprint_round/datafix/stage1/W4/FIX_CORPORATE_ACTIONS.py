#!/usr/bin/env python3
"""
Fix corporate_actions.csv structural issues
Issue: Commas in description field cause parsing errors
"""

import csv
import re

print("=" * 80)
print("FIXING corporate_actions.csv")
print("=" * 80)

# Read with csv module
with open('/home/user/blueprint_round/datafix/stage1/W4/corporate_actions.csv', 'r') as f:
    reader = csv.reader(f)
    rows = list(reader)

print(f"✓ Read {len(rows)} rows")

# The header has 11 fields
header = rows[0]
print(f"✓ Header: {header}")

# Expected header
expected_header = [
    'ticker', 'event_type', 'event_date', 'effective_date',
    'description', 'ratio', 'source_type', 'sources',
    'verification_status', 'notes', 'as_of_date'
]

# Process data rows
# The issue is that description field may contain commas
# We need to reconstruct rows properly

fixed_rows = [expected_header]

for i, row in enumerate(rows[1:], 1):
    # If row has more than 11 fields, it means description had commas
    if len(row) > len(expected_header):
        # Reconstruct: first 4 fields are safe, then description (may have commas),
        # then ratio, source_type, sources, verification_status, notes, as_of_date
        
        ticker = row[0]
        event_type = row[1]
        event_date = row[2]
        effective_date = row[3]
        
        # The rest: find where description ends
        # description is followed by ratio (which is a simple value like "N/A" or "100:1")
        # Let's look for the ratio field
        
        # Try to find ratio - it should be a simple value
        ratio_idx = None
        for j in range(4, len(row)):
            val = row[j].strip()
            # Ratio is typically "N/A", "100:1", "5000:1", etc.
            if val in ['N/A', '100:1', '5000:1', '10:1', '1:10', '1:100'] or ':' in val:
                ratio_idx = j
                break
        
        if ratio_idx is not None:
            # Reconstruct description from parts 4 to ratio_idx-1
            description = ', '.join(row[4:ratio_idx])
            
            # The remaining fields
            ratio = row[ratio_idx] if ratio_idx < len(row) else ''
            source_type = row[ratio_idx+1] if ratio_idx+1 < len(row) else ''
            sources = row[ratio_idx+2] if ratio_idx+2 < len(row) else ''
            verification_status = row[ratio_idx+3] if ratio_idx+3 < len(row) else ''
            notes = row[ratio_idx+4] if ratio_idx+4 < len(row) else ''
            as_of_date = row[ratio_idx+5] if ratio_idx+5 < len(row) else ''
            
            fixed_row = [
                ticker, event_type, event_date, effective_date,
                description, ratio, source_type, sources,
                verification_status, notes, as_of_date
            ]
            fixed_rows.append(fixed_row)
        else:
            # Can't find ratio, use as-is
            fixed_rows.append(row[:len(expected_header)])
    else:
        # Row has correct number of fields
        fixed_rows.append(row)

print(f"✓ Fixed {len(fixed_rows)-1} data rows")

# Save the fixed file
with open('/home/user/blueprint_round/datafix/stage1/W4/corporate_actions.csv', 'w', newline='') as f:
    writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
    writer.writerows(fixed_rows)

print(f"✅ Fixed corporate_actions.csv saved")

# Verify it loads
try:
    with open('/home/user/blueprint_round/datafix/stage1/W4/corporate_actions.csv', 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    print(f"✅ Verification: {len(rows)} rows load successfully with csv module")
except Exception as e:
    print(f"✗ Verification failed: {e}")

# Also verify with pandas
try:
    import pandas as pd
    df = pd.read_csv('/home/user/blueprint_round/datafix/stage1/W4/corporate_actions.csv')
    print(f"✅ Verification: {len(df)} rows load successfully with pandas")
except Exception as e:
    print(f"✗ Pandas verification failed: {e}")

print("\n" + "=" * 80)
print("CORPORATE ACTIONS FIX: COMPLETE")
print("=" * 80)
