#!/usr/bin/env python3
"""
Fix institutional_events.csv structural issues
Issue: Commas in event_description field cause parsing errors
"""

import csv

print("=" * 80)
print("FIXING institutional_events.csv")
print("=" * 80)

# Read with csv module
with open('/home/user/blueprint_round/datafix/stage1/W4/institutional_events.csv', 'r') as f:
    reader = csv.reader(f)
    rows = list(reader)

print(f"✓ Read {len(rows)} rows")

# The header has 8 fields
header = rows[0]
print(f"✓ Header: {header}")
print(f"✓ Header length: {len(header)}")

# Expected header
expected_header = [
    'event_date', 'event_name', 'event_type', 'event_description',
    'source_type', 'sources', 'verification_status', 'as_of_date'
]

# Process data rows
fixed_rows = [expected_header]

for i, row in enumerate(rows[1:], 1):
    # If row has more than 8 fields, it means event_description had commas
    if len(row) > len(expected_header):
        # Reconstruct: first 3 fields are safe, then event_description (may have commas),
        # then source_type, sources, verification_status, as_of_date
        
        event_date = row[0]
        event_name = row[1]
        event_type = row[2]
        
        # The rest: find where event_description ends
        # event_description is followed by source_type (T1, T2, etc.)
        
        # Try to find source_type - it should be T1, T2, or T3
        source_type_idx = None
        for j in range(3, len(row)):
            val = row[j].strip()
            if val in ['T1', 'T2', 'T3', 'T1/T2']:
                source_type_idx = j
                break
        
        if source_type_idx is not None:
            # Reconstruct event_description from parts 3 to source_type_idx-1
            event_description = ', '.join(row[3:source_type_idx])
            
            # The remaining fields
            source_type = row[source_type_idx] if source_type_idx < len(row) else ''
            sources = row[source_type_idx+1] if source_type_idx+1 < len(row) else ''
            verification_status = row[source_type_idx+2] if source_type_idx+2 < len(row) else ''
            as_of_date = row[source_type_idx+3] if source_type_idx+3 < len(row) else ''
            
            fixed_row = [
                event_date, event_name, event_type, event_description,
                source_type, sources, verification_status, as_of_date
            ]
            fixed_rows.append(fixed_row)
        else:
            # Can't find source_type, use as-is
            fixed_rows.append(row[:len(expected_header)])
    else:
        # Row has correct number of fields
        fixed_rows.append(row)

print(f"✓ Fixed {len(fixed_rows)-1} data rows")

# Save the fixed file
with open('/home/user/blueprint_round/datafix/stage1/W4/institutional_events.csv', 'w', newline='') as f:
    writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
    writer.writerows(fixed_rows)

print(f"✅ Fixed institutional_events.csv saved")

# Verify it loads
try:
    with open('/home/user/blueprint_round/datafix/stage1/W4/institutional_events.csv', 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    print(f"✅ Verification: {len(rows)} rows load successfully with csv module")
except Exception as e:
    print(f"✗ Verification failed: {e}")

# Also verify with pandas
try:
    import pandas as pd
    df = pd.read_csv('/home/user/blueprint_round/datafix/stage1/W4/institutional_events.csv')
    print(f"✅ Verification: {len(df)} rows load successfully with pandas")
except Exception as e:
    print(f"✗ Pandas verification failed: {e}")

print("\n" + "=" * 80)
print("INSTITUTIONAL EVENTS FIX: COMPLETE")
print("=" * 80)
