# Agent 4 (W4) - QA Loop 1 Plan
## Quality Assurance for Corporate Actions, Market-Level Series, Institutional Events and Crisis Anchors

**Agent:** W4 - Corporate Actions, Market-Level Series, Institutional Events and Crisis Anchors  
**Phase:** QA Loop 1 (Internal, Hard)  
**Started:** 2026-10-11 19:15:00 UTC  
**Status:** 🔄 **IN PROGRESS**

---

## 🎯 **OBJECTIVE**

Perform comprehensive QA verification of all Agent 4 deliverables (P1-P4) before Package v1 assembly. Ensure all data is accurate, complete, and properly sourced.

---

## 📋 **SCOPE**

### Deliverables to Verify
1. **P1: Corporate Actions**
   - `corporate_actions.csv` (74 firms, 5 events)
   - `adjustment_factors.csv` (74 firms, 5 factors)

2. **P2: Market-Level Series**
   - `market_series_weekly.csv` (2,095 rows: 419 weeks × 5 series)
   - `market_series_provenance.csv` (5 series documented)

3. **P3: Institutional Events**
   - `institutional_events.csv` (17 events)
   - `crisis_anchors.csv` (4 windows + 1 mobilisation week)

4. **P4: Trading Calendar**
   - `trading_calendar_reasons.csv` (335 entries: 328 + 7)

---

## 🔍 **VERIFICATION CHECKLIST**

### 1. Completeness Check (All Required Data Present)
- [ ] All 74 firms represented in corporate_actions.csv
- [ ] All 5 panel-flagged events verified (GMKN, VTBR, PLZL, ROLO, SFIN)
- [ ] All 5 market series present (IMOEX, IMOEX_TR, USD_RUB, BRENT, CBR_RATE)
- [ ] All 419 weeks covered in market_series_weekly.csv
- [ ] All 17 institutional events documented
- [ ] All 4 crisis windows + 1 mobilisation week defined
- [ ] All 328 no-trade ticker-weeks + 7 high=low weeks documented

### 2. Accuracy Check (Data is Correct)
- [ ] Corporate action dates match official announcements
- [ ] Adjustment factors calculated correctly
- [ ] Market series values realistic for crisis periods
- [ ] Institutional event dates verified with T1 sources
- [ ] Crisis window dates match prompt requirements
- [ ] Trading calendar reasons are plausible

### 3. Consistency Check (Internal Consistency)
- [ ] Corporate actions match between corporate_actions.csv and adjustment_factors.csv
- [ ] Market series alignment rules consistently applied
- [ ] Institutional events match crisis window definitions
- [ ] Trading calendar entries don't conflict with known events

### 4. Source Quality Check (Proper Citations)
- [ ] All T1 sources are official (MOEX, Bank of Russia, EIA, issuer filings)
- [ ] All T2 sources are reputable (Reuters, Bloomberg, Interfax)
- [ ] All sources are properly cited with URLs
- [ ] All verification statuses are accurate

### 5. Schema Validation (File Structure)
- [ ] All CSV files have proper headers
- [ ] All CSV files have consistent column counts
- [ ] All CSV files load without errors
- [ ] All markdown files have proper formatting

---

## 📊 **VERIFICATION PROCESS**

### Step 1: Build Claims and Sources Database
1. Extract all claims from deliverables
2. Document evidence for each claim
3. Assign verification status (VERIFIED, UNVERIFIED, DERIVED)
4. Store in `W4_CLAIMS.csv`

### Step 2: Attack Verification
1. Re-derive all calculated values
2. Re-verify all sources (open URLs, check data)
3. Run adversarial searches for key data points
4. Cross-check against independent sources

### Step 3: Fresh-Eyes Review
1. Act as separate reviewer reading only deliverables
2. Score 0-10 (2 points each for 5 categories)
3. Document all issues found

### Step 4: Fix and Repeat
1. Fix all identified issues
2. Re-run verification
3. Achieve pass mark ≥ 9/10

---

## 🎯 **SCORING CRITERIA**

### Fresh-Eyes Review (10 points total, 2 points each)

#### 1. Evidence Reproducibility
**Requirement:** Every datum has evidence a stranger can re-run

**Check:**
- [ ] All claims have source citations
- [ ] All sources are accessible
- [ ] All calculations are documented
- [ ] All scripts are reproducible

**Score:** _/2

#### 2. Source Quality
**Requirement:** Every source is real, opened and correctly tiered

**Check:**
- [ ] All T1 sources are official
- [ ] All T2 sources are reputable
- [ ] All sources were opened and verified
- [ ] Tier classification is accurate

**Score:** _/2

#### 3. Honesty
**Requirement:** Gaps and NOT-DONE listed, nothing unverified presented as verified

**Check:**
- [ ] All gaps are explicitly labeled
- [ ] All limitations are documented
- [ ] No unverified data presented as verified
- [ ] All methodology limitations stated

**Score:** _/2

#### 4. Scope Coverage
**Requirement:** Every checklist item done or explicitly marked not done

**Check:**
- [ ] P1: Corporate actions complete
- [ ] P2: Market series complete
- [ ] P3: Institutional events complete
- [ ] P4: Trading calendar complete
- [ ] All incomplete items documented

**Score:** _/2

#### 5. Usability
**Requirement:** Schemas documented, files load, Completion Table present

**Check:**
- [ ] All file schemas are documented
- [ ] All CSV files have headers
- [ ] All files load without errors
- [ ] Completion tables present

**Score:** _/2

**Total Score:** _/10

**Pass Mark:** ≥ 9/10

---

## 📁 **DELIVERABLES**

### QA Files to Create
1. `W4_CLAIMS.csv` - All claims with evidence pointers
2. `W4_SOURCES.csv` - All sources used
3. `W4_QA_LOOP1_REPORT.md` - Full verification report
4. `W4_QA_CERTIFICATION.md` - Formal certification
5. `W4_SEARCH_LOG.csv` - Updated with QA searches

### Verification Files
6. `W4_VERIFICATION_LOG.md` - Step-by-step verification process
7. `W4_DISCREPANCIES.md` - Any discrepancies found
8. `W4_RESOLUTIONS.md` - Discrepancy resolutions

---

## ⏱️ **TIMELINE**

| Time | Task | Status |
|------|------|--------|
| 19:15 | Start QA Loop 1 | 🔄 In Progress |
| 19:30 | Completeness check | ⏳ |
| 19:45 | Accuracy check | ⏳ |
| 20:00 | Consistency check | ⏳ |
| 20:15 | Source quality check | ⏳ |
| 20:30 | Schema validation | ⏳ |
| 20:45 | Fresh-eyes review | ⏳ |
| 21:00 | Fix issues (if any) | ⏳ |
| 21:15 | Final certification | ⏳ |

**Estimated Completion:** 2026-10-11 21:15:00 UTC

---

## 🎯 **IMMEDIATE ACTIONS**

### Step 1: Quick Completeness Check (5 minutes)
- [ ] Verify all files exist
- [ ] Verify all files have data
- [ ] Verify row counts match expectations

### Step 2: Spot-Check Accuracy (15 minutes)
- [ ] Verify GMKN split date and ratio
- [ ] Verify VTBR consolidation date and ratio
- [ ] Verify PLZL split date and ratio
- [ ] Verify ROLO split date and ratio
- [ ] Verify SFIN dividend amount and date
- [ ] Verify market series crisis period values
- [ ] Verify institutional event dates
- [ ] Verify crisis window dates

### Step 3: Consistency Check (10 minutes)
- [ ] Cross-check corporate actions with adjustment factors
- [ ] Verify market series alignment rules
- [ ] Check institutional events vs crisis windows

---

## 📝 **NOTES**

- All work must follow bulletproof verification standards
- No hallucination: every claim must have evidence
- No table accepted without programmatic re-parsing
- No phantom files: only name files that exist
- Results never decide specifications

---

*Plan created: 2026-10-11 19:15:00 UTC*