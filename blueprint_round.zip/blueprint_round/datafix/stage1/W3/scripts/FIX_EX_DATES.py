#!/usr/bin/env python3
"""
Fix ex-dates calculation in dividends_verified.csv
Issue: All ex-dates are record_date - 1 calendar day, but 210 fall on weekends
Fix: Calculate proper ex-dates based on T+2 (before 2023-07-31) and T+1 (after 2023-07-31)
"""

import csv
from datetime import datetime, timedelta
import pandas as pd

print("=" * 80)
print("FIXING EX-DATES IN dividends_verified.csv")
print("=" * 80)

# Load dividends
with open('/home/user/blueprint_round/datafix/stage1/W3/dividends_verified.csv', 'r') as f:
    reader = csv.DictReader(f)
    dividends = list(reader)

print(f"\n✓ Loaded {len(dividends)} dividend records")

# Analyze current ex-dates
current_ex_dates = [d.get('ex_date', '') for d in dividends if d.get('ex_date')]
print(f"✓ Current ex-dates: {len(current_ex_dates)}")

# Count weekend ex-dates
weekend_count = 0
for d in dividends:
    ex_date_str = d.get('ex_date', '')
    if ex_date_str:
        try:
            ex_date = datetime.strptime(ex_date_str, '%Y-%m-%d')
            if ex_date.weekday() >= 5:  # Saturday (5) or Sunday (6)
                weekend_count += 1
        except:
            pass

print(f"✗ Weekend ex-dates: {weekend_count}/{len(current_ex_dates)} ({weekend_count/len(current_ex_dates)*100:.1f}%)")

# Define settlement rules
# T+2: Before 2023-07-31, ex-date = record_date - 2 business days
# T+1: After 2023-07-31, ex-date = record_date - 1 business day

def get_business_days_before(date_str, days_before):
    """Get the business day (Mon-Fri) that is `days_before` business days before date_str"""
    from datetime import datetime, timedelta
    
    date = datetime.strptime(date_str, '%Y-%m-%d')
    
    # Subtract days, then adjust to business day
    result = date
    days_subtracted = 0
    
    while days_subtracted < days_before:
        result -= timedelta(days=1)
        if result.weekday() < 5:  # Mon-Fri
            days_subtracted += 1
    
    return result.strftime('%Y-%m-%d')

def calculate_ex_date(record_date_str, settlement_rule):
    """
    Calculate ex-date based on settlement rule
    
    T+2 rule (before 2023-07-31):
    - Ex-date = last business day on or before record_date, minus 2 business days
    
    T+1 rule (after 2023-07-31):
    - Ex-date = last business day on or before record_date, minus 1 business day
    """
    if not record_date_str:
        return ''
    
    try:
        record_date = datetime.strptime(record_date_str, '%Y-%m-%d')
        
        if settlement_rule == 'T+1':
            # T+1: ex-date = record_date - 1 business day
            return get_business_days_before(record_date_str, 1)
        else:
            # T+2: ex-date = record_date - 2 business days
            return get_business_days_before(record_date_str, 2)
    except:
        return ''

print("\n📊 Step 1: Calculate proper ex-dates")

# Fix ex-dates
fixed_dividends = []
weekend_ex_dates_fixed = 0

for d in dividends:
    new_d = d.copy()
    
    record_date = d.get('record_date', '')
    if record_date:
        try:
            record_dt = datetime.strptime(record_date, '%Y-%m-%d')
            
            # Determine settlement rule
            if record_dt >= datetime(2023, 7, 31):
                settlement_rule = 'T+1'
            else:
                settlement_rule = 'T+2'
            
            # Calculate proper ex-date
            proper_ex_date = calculate_ex_date(record_date, settlement_rule)
            new_d['ex_date'] = proper_ex_date
            
            # Check if this was a weekend ex-date before
            old_ex_date = d.get('ex_date', '')
            if old_ex_date:
                try:
                    old_dt = datetime.strptime(old_ex_date, '%Y-%m-%d')
                    if old_dt.weekday() >= 5:
                        weekend_ex_dates_fixed += 1
                except:
                    pass
        except:
            new_d['ex_date'] = ''
    else:
        new_d['ex_date'] = ''
    
    fixed_dividends.append(new_d)

print(f"✓ Fixed {weekend_ex_dates_fixed} weekend ex-dates")

# Verify the fix
fixed_weekend_count = 0
for d in fixed_dividends:
    ex_date_str = d.get('ex_date', '')
    if ex_date_str:
        try:
            ex_date = datetime.strptime(ex_date_str, '%Y-%m-%d')
            if ex_date.weekday() >= 5:
                fixed_weekend_count += 1
        except:
            pass

print(f"✓ Remaining weekend ex-dates: {fixed_weekend_count}/{len(fixed_dividends)}")

# Save fixed file
with open('/home/user/blueprint_round/datafix/stage1/W3/dividends_verified.csv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=dividends[0].keys())
    writer.writeheader()
    writer.writerows(fixed_dividends)

print(f"\n✅ Fixed dividends_verified.csv saved")

# Also fix div_i_t.csv
print("\n📊 Step 2: Fix ex-dates in div_i_t.csv")

with open('/home/user/blueprint_round/datafix/stage1/W3/div_i_t.csv', 'r') as f:
    reader = csv.DictReader(f)
    div_i_t = list(reader)

fixed_div_i_t = []
for d in div_i_t:
    new_d = d.copy()
    record_date = d.get('record_date', '')
    if record_date:
        try:
            record_dt = datetime.strptime(record_date, '%Y-%m-%d')
            if record_dt >= datetime(2023, 7, 31):
                settlement_rule = 'T+1'
            else:
                settlement_rule = 'T+2'
            proper_ex_date = calculate_ex_date(record_date, settlement_rule)
            new_d['ex_date'] = proper_ex_date
        except:
            new_d['ex_date'] = ''
    fixed_div_i_t.append(new_d)

with open('/home/user/blueprint_round/datafix/stage1/W3/div_i_t.csv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=div_i_t[0].keys())
    writer.writeheader()
    writer.writerows(fixed_div_i_t)

print(f"✅ Fixed div_i_t.csv saved")

print("\n" + "=" * 80)
print("EX-DATES FIX: COMPLETE")
print("=" * 80)
print(f"✅ Fixed {weekend_ex_dates_fixed} weekend ex-dates in dividends_verified.csv")
print(f"✅ Fixed ex-dates in div_i_t.csv")
print(f"✅ Remaining weekend ex-dates: {fixed_weekend_count}")
print("\nNext: Fix source labeling")
