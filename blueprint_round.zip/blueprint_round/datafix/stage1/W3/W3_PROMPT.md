# Agent 3: Dividends, Ex-Dates and Dividend-Adjusted Series - Prompt

**Agent:** 3 - Dividends, Ex-Dates and Dividend-Adjusted Series (worker)  
**Role:** Verify dividend dates, ex-dates, amounts, and build dividend-adjusted series  
**Workspace:** `/home/user/blueprint_round/datafix/stage1/W3/`  
**Prefix:** `W3_`  
**Status:** NOT STARTED

---

## Mission

Verify ex-dividend dates and amounts for all dividends, then rebuild the dividend-adjusted series per Amendment V4-28.

---

## Tasks (Priority Order: P1 → P2 → P3 → P4)

### P1: Ex-Dates and Amounts (NOT STARTED)
**Goal:** Verify ex-dividend dates and amounts for the 587 dividend rows, largest effects first.

**Steps:**
1. Order rows by dividend yield (amount ÷ close before ex-week)
2. For each row (highest yield first):
   - Find T1 or two-T2 evidence of: record date, last day with right to dividend, ex-date, amount per share, share class, currency
   - Do highest-yield 150 rows first
   - Then every row from 2023-07-31 onward (T+1 era)
   - Then the rest
3. Compute ex-date from settlement rule only when no source states it, mark as `DERIVED`

**Output:** `dividends_verified.csv` (one row per dividend)

### P2: Completeness Check (NOT STARTED)
**Goal:** Ensure completeness of dividend data.

**Steps:**
1. Confirm 12 non-payers (JNOS, MFGS, RNFT, VJGZ, BLNG, CHMK, ROLO, UKUZ, UNAC, FESH, UTAR, MRKK) paid no dividend in 2018-2026
2. For 63 payers, search for missing dividends (special, interim, extra)
3. Verify share class: ensure each dividend belongs to the class traded under the panel's ticker
4. Audit 18 announced-not-paid exclusions (`phase1_exclusion_audit.csv`)
5. Reproduce: 587 record dates → 529 record-week cells, 2,110 Div=1 weeks, 2,108 valid lagged cells

**Output:** `dividend_count_bridge.csv`

### P3: Build Dividend-Adjusted Series (NOT STARTED)
**Goal:** Implement Amendment V4-28 on daily files with verified ex-dates and amounts.

**Steps:**
1. Create `rv_dividend_adjusted_weekly.csv` (TICKER, week_monday, rv_raw, rv_adj, n_dividends_in_week, ex_date, amount, yield, status)
2. Create `ret_total_weekly.csv` (dividend-added-back weekly return)
3. Report effect: how many weeks change, by how much
4. Report verified-vs-approximate-ex-date difference on rows where both exist
5. Report additive and multiplicative adjustment on 20 random ex-weeks (print seed)

**Output:** `rv_dividend_adjusted_weekly.csv`, `ret_total_weekly.csv`

### P4: Rebuild div_i_t.csv (NOT STARTED)
**Goal:** Rebuild dividend indicator matrix from verified table.

**Steps:**
1. Build `div_i_t.csv` (Div = 1 in the four weeks before the record week)
2. Use `week_monday` key only

**Output:** `div_i_t.csv`

---

## Deliverables

1. `dividends_verified.csv` - Verified dividend data
2. `dividend_count_bridge.csv` - Count bridge verification
3. `div_i_t.csv` - Dividend indicator matrix
4. `rv_dividend_adjusted_weekly.csv` - Dividend-adjusted RV series
5. `ret_total_weekly.csv` - Total return series
6. `REPRO/` - Reproduction scripts
7. `W3_CLAIMS.csv` - Claims for QA Loop 1
8. `W3_SOURCES.csv` - Sources for QA Loop 1
9. `W3_SEARCH_LOG.csv` - Search log (≥5 per unverified datum)
10. `W3_QA1_LOG.md` - QA Loop 1 attack phase
11. `W3_REPORT.md` - Report
12. `W3_JUDGE_BRIEF.md` - Judge brief
13. `W3_NOT_DONE.md` - Remaining tasks
14. `W3_STATE.md` - State tracker
15. `MANIFEST.md` - File hashes
16. `PROGRESS_SUMMARY.md` - Progress summary

---

## Key Rules

1. **Verification:** T1 sources (e-disclosure.ru material facts, issuer releases, MOEX) or two independent T2 sources
2. **Gap Rule:** At least 5 documented search attempts per unverified datum
3. **Amendment V4-28:** Weekly range volatility must be computed on dividend-adjusted daily bars
4. **Amendment V4-29:** Market leg of adjusted return must be consistent (total-return index)
5. **Status Tracking:** Maintain W3_STATE.md and W3_NOT_DONE.md

---

## Data Sources

- **Primary (T1):** e-disclosure.ru material facts, issuer releases, MOEX corporate-action pages
- **Secondary (T2):** Reuters, Bloomberg, Interfax
- **Data:** MOEX daily files, panel data

---

## Next Steps

1. Start P1: Create `dividends_verified.csv` template
2. Order dividend rows by yield
3. Verify ex-dates and amounts for highest-yield rows first
4. Document all sources and search attempts
5. Complete P1 before moving to P2

---

*Generated: 2026-10-10 22:45:00 UTC*
