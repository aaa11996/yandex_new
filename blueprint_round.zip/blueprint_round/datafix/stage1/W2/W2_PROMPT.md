# Agent 2: State Ownership and Sector Map - Prompt

**Agent:** 2 - State Ownership and Sector Map (worker)  
**Role:** Verify state ownership classification and sector mapping for all 75 firms  
**Workspace:** `/home/user/blueprint_round/datafix/stage1/W2/`  
**Prefix:** `W2_`  
**Status:** NOT STARTED

---

## Mission

Verify state ownership (SOE) classification and sector mapping for all 75 firms using primary sources. Do NOT open the published SOE paper until Part A is complete (blindness rule).

---

## Tasks (Priority Order: P1 → P2 → P3)

### P1: Independent SOE Classification (NOT STARTED)
**Goal:** Classify all 75 firms as SOE (1) or non-SOE (0) based on Russian state ownership ≥ 25% of voting shares.

**Steps:**
1. For each firm, find primary disclosures of ownership structure
2. Determine percentage held by Russian state (federal or regional, direct or indirect)
3. Document as-of date, source, tier
4. Record any changes of control during 2018-2026
5. Record free-float and golden share information where relevant
6. Record how classification changes under thresholds of 10%, 25%, and 50%

**Output:** `soe_blind_classification.csv` (75 rows with all fields)

### P2: Comparison with Published Table (NOT STARTED)
**Goal:** Compare blind classification with published SOE table.

**Steps:**
1. After Part A is saved, open published SOE table
2. List every firm that differs
3. Explain why and which evidence wins
4. Explicitly address knife-edge cases: VSMO, TATN, TTLK, UTAR, MGNT, RUAL, RGSS, PIKK, TRMK, LKOH, SNGS, CBOM, YAKG

**Output:** `soe_vs_published.csv`

### P3: Sector Map Check (NOT STARTED)
**Goal:** Verify each firm's sector against primary sources.

**Steps:**
1. For each firm, verify sector against main business from primary sources
2. Resolve disputed YAKG label

**Output:** `sector_map_check.csv`

---

## Deliverables

1. `soe_blind_classification.csv` - 75 rows with all fields
2. `soe_vs_published.csv` - Comparison with published table
3. `soe_time_variation.csv` - State share by firm and period (if changed)
4. `soe_continuous.csv` - Continuous state share variable
5. `sector_map_check.csv` - Sector verification
6. `W2_BLINDNESS_LOG.md` - Log of when published SOE paper was first opened
7. `W2_CLAIMS.csv` - Claims for QA Loop 1
8. `W2_SOURCES.csv` - Sources for QA Loop 1
9. `W2_SEARCH_LOG.csv` - Search log (≥5 per unverified datum)
10. `W2_QA1_LOG.md` - QA Loop 1 attack phase
11. `W2_REPORT.md` - Report
12. `W2_JUDGE_BRIEF.md` - Judge brief
13. `W2_NOT_DONE.md` - Remaining tasks
14. `W2_STATE.md` - State tracker
15. `MANIFEST.md` - File hashes
16. `PROGRESS_SUMMARY.md` - Progress summary

---

## Key Rules

1. **Blindness Rule:** Do NOT open `UNIFIED_PAPER_about_state_ownership.md`, `Combined_Data_File.md` §5, `THESIS_HANDOFF_BRIEF.md`, or `FINAL_REPORT.md` until Part A is finished and saved with its hash.
2. **SOE Definition:** SOE = 1 iff the Russian state (federal or regional, direct or through a state-controlled holding) holds ≥ 25% of voting shares.
3. **Verification:** T1 sources (issuer annual reports, Rosimushchestvo, e-disclosure.ru, MOEX) or two independent T2 sources.
4. **Gap Rule:** At least 5 documented search attempts per unverified datum.
5. **Status Tracking:** Maintain W2_STATE.md and W2_NOT_DONE.md.

---

## Data Sources

- **Primary (T1):** Issuer annual reports and ownership disclosures, Rosimushchestvo, e-disclosure.ru affiliate and ownership lists, issuer IR pages
- **Secondary (T2):** Reuters, Bloomberg, Interfax, Kommersant, RBC
- **Tertiary (T3):** Aggregators (smart-lab, dohod.ru, investing.com) - pointers only, never evidence

---

## Next Steps

1. Start P1: Create `soe_blind_classification.csv` template
2. Research ownership for each of the 75 firms
3. Document all sources and search attempts
4. Complete P1 before moving to P2

---

*Generated: 2026-10-10 22:45:00 UTC*
