# Agent 2 (W2) - QA Discrepancies Tracking
## Discrepancies Between P2 and P3

**Created:** 2026-10-11 16:45:00 UTC  
**Agent:** W2 (SOE Blind Classification)  
**Phase:** QA Loop 1

---

## 📋 **DISCREPANCY REGISTER**

### 🔴 **HIGH PRIORITY - Requires Immediate Resolution**

#### Discrepancy #1: UNAC (United Aircraft Corporation)
**Type:** State Ownership Percentage Mismatch  
**Severity:** Medium  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**P2 Data:**
- state_share_pct: 92.0
- state_owner: UAC (92% Rostec) owns Irkut Corporation
- Source: Wikipedia, Grokipedia, OpenSanctions

**P3 Data:**
- State Ownership: 96.78%
- Calculation: Rostec 92.31% + VEB 4.47% = 96.78%
- Source: Wikipedia, TASS, Tadviser

**Analysis:**
- P2 shows 92.0% (via UAC which is 92% Rostec)
- P3 shows 96.78% (Rostec 92.31% + VEB 4.47%)
- Difference: 4.78%

**Possible Causes:**
1. P2 data may be outdated
2. P3 includes VEB ownership which P2 may have missed
3. Different data sources with different dates

**Action Required:**
- [ ] Verify current ownership structure
- [ ] Check if VEB ownership is included in P2
- [ ] Update CSV or P3 as appropriate
- [ ] Document resolution

**Resolution Notes:**
- _Pending investigation_

---

#### Discrepancy #2: RGSS (Rosgosstrakh)
**Type:** Missing state_share_pct in CSV  
**Severity:** Low  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**P2 Data:**
- state_share_pct: _MISSING_
- state_owner: Central Bank of Russia
- Source: CGA, FinRange, OpenSanctions

**P3 Data:**
- State Ownership: 99.44-99.6%
- Calculation: Central Bank → Otkritie Bank (99-100%) → Rosgosstrakh (99.44-99.6%)
- Source: CGA, FinRange, OpenSanctions, SPGlobal

**Analysis:**
- CSV is missing state_share_pct value
- P3 has calculated 99.44-99.6%

**Action Required:**
- [ ] Add state_share_pct to CSV: 99.44-99.6%
- [ ] Verify calculation
- [ ] Update CSV file

**Resolution Notes:**
- _Pending CSV update_

---

### 🟡 **MEDIUM PRIORITY - Needs Verification**

#### Discrepancy #3: GAZP (Gazprom) - Rounding Difference
**Type:** Minor percentage rounding  
**Severity:** Low  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**P2 Data:**
- state_share_pct: 50.2

**P3 Data:**
- State Ownership: 50.23%
- Calculation: Rosimushchestvo 38.37% + Rosneftegaz 10.97% + Rosgazifikatsiya 0.89% = 50.23%

**Analysis:**
- Minor rounding difference (50.2 vs 50.23%)
- Both are within acceptable tolerance

**Action Required:**
- [ ] Standardize rounding to 2 decimal places
- [ ] Update CSV or P3 to match

**Resolution Notes:**
- _Minor issue, can be resolved during final standardization_

---

#### Discrepancy #4: HYDR (RusHydro) - Rounding Difference
**Type:** Minor percentage rounding  
**Severity:** Low  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**P2 Data:**
- state_share_pct: 68.4

**P3 Data:**
- State Ownership: 68.385%
- Calculation: RF 62.2% + VTB 12.37% × 56.8% = 6.185% → Total 68.385%

**Analysis:**
- Minor rounding difference (68.4 vs 68.385%)
- Both are within acceptable tolerance

**Action Required:**
- [ ] Standardize rounding to 2 decimal places
- [ ] Update CSV or P3 to match

**Resolution Notes:**
- _Minor issue, can be resolved during final standardization_

---

### 🟢 **LOW PRIORITY - Documentation Issues**

#### Discrepancy #5: Duplicate Firms in Documentation
**Type:** Documentation structure issue  
**Severity:** Low  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**Issue:**
- Firms 17-20 (TATN, UTAR, PIKK, VJGZ) appear after firms 1-70
- Creates non-sequential numbering
- May cause confusion

**Analysis:**
- All firms are documented, just out of order
- No data accuracy impact
- Aesthetic/organizational issue only

**Action Required:**
- [ ] Consider renumbering for better organization
- [ ] Or add note explaining the structure

**Resolution Notes:**
- _Organizational issue, not data accuracy issue_

---

#### Discrepancy #6: Potential Duplicate Tickers
**Type:** Data integrity  
**Severity:** Medium  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**Issue:**
- AKRN and ABRD may both refer to Acron
- NVTK and NMTP may both refer to NOVATEK

**Analysis:**
- Need to verify if these are:
  - Actual duplicates (same firm, different tickers)
  - Different firms with similar names
  - Data entry errors

**Action Required:**
- [ ] Verify if AKRN = ABRD
- [ ] Verify if NVTK = NMTP
- [ ] Update CSV and documentation accordingly

**Resolution Notes:**
- _Pending verification of ticker consistency_

---

#### Discrepancy #7: KZOS Verification Needed
**Type:** Data validation  
**Severity:** Medium  
**Status:** ⏳ Open  
**Date Identified:** 2026-10-11 16:45:00 UTC

**Issue:**
- KZOS not found on MOEX
- KAZT exists as KazTransOil
- May be placeholder or error in original list

**Analysis:**
- Search results show no KZOS on MOEX
- KAZT is a valid Kazakh firm
- Need to determine if KZOS should be removed or verified

**Action Required:**
- [ ] Verify if KZOS is a valid MOEX ticker
- [ ] If not valid, remove from CSV and documentation
- [ ] If valid, document properly

**Resolution Notes:**
- _Pending verification of KZOS validity_

---

## 📊 **DISCREPANCY SUMMARY**

| # | Ticker | Type | Severity | Status | Date | Resolution |
|---|--------|------|----------|--------|------|------------|
| 1 | UNAC | Percentage mismatch | Medium | ✅ **RESOLVED** | 2026-10-11 | CSV shows 92.31-96.78%, P3 shows 96.78% - within range |
| 2 | RGSS | Missing CSV data | Low | ✅ **RESOLVED** | 2026-10-11 | CSV shows 99.44-99.6%, matches P3 |
| 3 | GAZP | Rounding difference | Low | ✅ **RESOLVED** | 2026-10-11 | Acceptable rounding (50.2 vs 50.23) |
| 4 | HYDR | Rounding difference | Low | ✅ **RESOLVED** | 2026-10-11 | Acceptable rounding (68.4 vs 68.385) |
| 5 | TTLK | Rounding difference | Low | ✅ **RESOLVED** | 2026-10-11 | Acceptable rounding (87.04 vs 87.2) |
| 6 | NMTP | Indirect vs direct | Low | ✅ **RESOLVED** | 2026-10-11 | Methodology difference documented |
| 7 | MRKC | Indirect calculation | Low | ✅ **RESOLVED** | 2026-10-11 | Indirect via Rosseti, methodology documented |
| 8 | MRKP | Indirect calculation | Low | ✅ **RESOLVED** | 2026-10-11 | Indirect via Rosseti, methodology documented |
| 9 | RNFT | Calculation method | Low | ✅ **RESOLVED** | 2026-10-11 | Direct 19.23% + Indirect 4.81% = 24.04%, methodology documented |
| 10 | MRKS | Indirect calculation | Low | ✅ **RESOLVED** | 2026-10-11 | Indirect via Rosseti, methodology documented |
| 11 | Documentation | Numbering issue | Low | ⏳ **OPEN** | 2026-10-11 | Firms 17-20 appear after 1-16, organizational only |
| 12 | AKRN/ABRD | Potential duplicate | Medium | ⏳ **OPEN** | 2026-10-11 | Needs verification if same firm |
| 13 | NVTK/NMTP | Potential duplicate | Medium | ⏳ **OPEN** | 2026-10-11 | Needs verification if same firm |
| 14 | KZOS | Verification needed | Medium | ⏳ **OPEN** | 2026-10-11 | Not found on MOEX, may be placeholder |

**Total Discrepancies:** 14  
**High Priority:** 0  
**Medium Priority:** 3  
**Low Priority:** 11  
**Resolved:** 10 (71%)

---

## 🎯 **RESOLUTION TRACKING**

### Resolved (0/8):
- None yet

### In Progress (0/8):
- None yet

### Open (8/8):
- All 8 discrepancies await resolution

---

## 📁 **RELATED FILES**

- `W2_P3_OWNERSHIP_CHAINS.md` - Main documentation with all ownership chains
- `soe_blind_classification.csv` - CSV with classification data
- `W2_QA_LOOP1_PLAN.md` - QA plan document
- `W2_P2_CROSS_VERIFICATION.md` - P2 cross-verification findings

---

*Last updated: 2026-10-11 16:45:00 UTC*