#!/usr/bin/env python3
"""
Fix soe_blind_classification.csv structural issues
Issue: Commas in ownership_chain and other fields cause parsing errors
"""

import csv
import re

print("=" * 80)
print("FIXING soe_blind_classification.csv")
print("=" * 80)

# Read the file with csv module to handle it properly
with open('/home/user/blueprint_round/datafix/stage1/W2/soe_blind_classification.csv', 'r') as f:
    reader = csv.reader(f)
    rows = list(reader)

print(f"\n✓ Read {len(rows)} rows from soe_blind_classification.csv")

# The header is the first row
header = rows[0]
print(f"✓ Header: {header}")

# Process data rows
# We need to identify which fields contain commas and properly quote them
# The issue is in the ownership_chain field which has commas

# Let's manually define the columns based on the expected structure
# From the audit, we know the columns should be:
expected_columns = [
    'firm', 'full_name', 'soe_25pct', 'soe_50pct', 'soe_continuous',
    'state_share_pct', 'state_owner', 'ownership_chain', 'as_of_date',
    'source', 'tier', 'status', 'notes', 'free_float_pct',
    'golden_share', 'control_changes_2018_2026', 'soe_10pct'
]

print(f"\n✓ Expected columns: {len(expected_columns)}")
print(f"✓ Actual header fields: {len(header)}")

# The issue is that ownership_chain contains commas, so it gets split
# We need to reconstruct the rows properly

# For each row, we know the first 7 fields are:
# firm, full_name, soe_25pct, soe_50pct, soe_continuous, state_share_pct, state_owner
# Then ownership_chain (which may contain commas)
# Then the rest

# Let's use a different approach - read with a more robust method
import io

# The file has 17 columns but some rows have more due to commas in ownership_chain
# Let's manually parse each line

fixed_rows = []

with open('/home/user/blueprint_round/datafix/stage1/W2/soe_blind_classification.csv', 'r') as f:
    lines = f.readlines()

print(f"\n✓ Read {len(lines)} lines")

# Process header
header_line = lines[0].strip()
# Split header by comma
header_fields = header_line.split(',')
print(f"✓ Header has {len(header_fields)} fields")

# The expected header should have 17 fields
# But we have more due to the structure

# Let's use a smarter approach: we know the first 7 fields don't have commas
# Then ownership_chain may have commas
# Then the rest don't have commas

# For each data line, parse it manually
fixed_data = []

for i, line in enumerate(lines[1:], 1):
    line = line.strip()
    if not line:
        continue
    
    # Split the line
    parts = line.split(',')
    
    # First 7 fields are safe (no commas)
    if len(parts) < 7:
        print(f"⚠️  Line {i} has only {len(parts)} parts")
        continue
    
    firm = parts[0]
    full_name = parts[1]
    soe_25pct = parts[2]
    soe_50pct = parts[3]
    soe_continuous = parts[4]
    state_share_pct = parts[5]
    state_owner = parts[6]
    
    # The ownership_chain field starts at index 7 and may span multiple parts
    # It ends when we hit a field that looks like a date (as_of_date)
    # The as_of_date should be in YYYY-MM-DD format
    
    ownership_parts = []
    remaining_parts = parts[7:]
    
    # Find where ownership_chain ends (before as_of_date)
    for j, part in enumerate(remaining_parts):
        part = part.strip()
        # Check if this looks like a date
        if re.match(r'^\d{4}-\d{2}-\d{2}$', part):
            # This is the as_of_date
            as_of_date = part
            ownership_chain = ', '.join(ownership_parts)
            # The rest
            source = remaining_parts[j+1] if j+1 < len(remaining_parts) else ''
            tier = remaining_parts[j+2] if j+2 < len(remaining_parts) else ''
            status = remaining_parts[j+3] if j+3 < len(remaining_parts) else ''
            notes = remaining_parts[j+4] if j+4 < len(remaining_parts) else ''
            free_float_pct = remaining_parts[j+5] if j+5 < len(remaining_parts) else ''
            golden_share = remaining_parts[j+6] if j+6 < len(remaining_parts) else ''
            control_changes = remaining_parts[j+7] if j+7 < len(remaining_parts) else ''
            soe_10pct = remaining_parts[j+8] if j+8 < len(remaining_parts) else ''
            
            row = {
                'firm': firm,
                'full_name': full_name,
                'soe_25pct': soe_25pct,
                'soe_50pct': soe_50pct,
                'soe_continuous': soe_continuous,
                'state_share_pct': state_share_pct,
                'state_owner': state_owner,
                'ownership_chain': ownership_chain,
                'as_of_date': as_of_date,
                'source': source,
                'tier': tier,
                'status': status,
                'notes': notes,
                'free_float_pct': free_float_pct,
                'golden_share': golden_share,
                'control_changes_2018_2026': control_changes,
                'soe_10pct': soe_10pct
            }
            fixed_data.append(row)
            break
        else:
            ownership_parts.append(part)
    else:
        # If we didn't find a date, use all remaining as ownership_chain
        ownership_chain = ', '.join(remaining_parts)
        row = {
            'firm': firm,
            'full_name': full_name,
            'soe_25pct': soe_25pct,
            'soe_50pct': soe_50pct,
            'soe_continuous': soe_continuous,
            'state_share_pct': state_share_pct,
            'state_owner': state_owner,
            'ownership_chain': ownership_chain,
            'as_of_date': '',
            'source': '',
            'tier': '',
            'status': '',
            'notes': '',
            'free_float_pct': '',
            'golden_share': '',
            'control_changes_2018_2026': '',
            'soe_10pct': ''
        }
        fixed_data.append(row)

print(f"✓ Fixed {len(fixed_data)} rows")

# Save the fixed file
with open('/home/user/blueprint_round/datafix/stage1/W2/soe_blind_classification.csv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=expected_columns)
    writer.writeheader()
    writer.writerows(fixed_data)

print(f"\n✅ Fixed soe_blind_classification.csv saved")

# Verify it loads
try:
    with open('/home/user/blueprint_round/datafix/stage1/W2/soe_blind_classification.csv', 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    print(f"✅ Verification: {len(rows)} rows load successfully")
except Exception as e:
    print(f"✗ Verification failed: {e}")

# Also check for FEES
firm_list = [r['firm'] for r in rows]
if 'FEES' in firm_list:
    print(f"✅ FEES is present in SOE classification")
else:
    print(f"⚠️  FEES is NOT in SOE classification (subsidiary, expected)")

print("\n" + "=" * 80)
print("SOE CSV FIX: COMPLETE")
print("=" * 80)
