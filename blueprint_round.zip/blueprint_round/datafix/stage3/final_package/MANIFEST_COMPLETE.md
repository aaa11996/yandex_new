# Complete Pipeline Package - MANIFEST

**Assembly Date:** 2026-10-12 10:03:02 UTC

**Total Files:** 53
**Total Size:** 1,203,786 bytes (1.1 MB)

---

## File Inventory

| File | Size | Path |
|------|------|------|
| `MANIFEST_FINAL.md` | 5,376 bytes | MANIFEST_FINAL.md |
| `README_FINAL.md` | 8,249 bytes | README_FINAL.md |
| `STAGE3_PHASE1_REPORT.md` | 1,652 bytes | STAGE3_PHASE1_REPORT.md |
| `STAGE3_PHASE2_REPORT.md` | 2,419 bytes | STAGE3_PHASE2_REPORT.md |
| `STAGE3_PHASE3_REPORT.md` | 2,109 bytes | STAGE3_PHASE3_REPORT.md |
| `checksums.csv` | 5,949 bytes | checksums.csv |
| `checksums.sha256` | 4,759 bytes | checksums.sha256 |
| `v1/W1_PACKAGE_V1/README_W1_V1.md` | 588 bytes | v1/W1_PACKAGE_V1/README_W1_V1.md |
| `v1/W1_PACKAGE_V1/W1_PACKAGE_V1_STATE.md` | 416 bytes | v1/W1_PACKAGE_V1/W1_PACKAGE_V1_STATE.md |
| `v1/W2_PACKAGE_V1/README_W2_V1.md` | 7,515 bytes | v1/W2_PACKAGE_V1/README_W2_V1.md |
| `v1/W2_PACKAGE_V1/W2_P3_OWNERSHIP_CHAINS.md` | 55,951 bytes | v1/W2_PACKAGE_V1/W2_P3_OWNERSHIP_CHAINS.md |
| `v1/W2_PACKAGE_V1/W2_P3_REPORT.md` | 7,737 bytes | v1/W2_PACKAGE_V1/W2_P3_REPORT.md |
| `v1/W2_PACKAGE_V1/W2_QA_CERTIFICATION.md` | 8,066 bytes | v1/W2_PACKAGE_V1/W2_QA_CERTIFICATION.md |
| `v1/W2_PACKAGE_V1/W2_QA_LOOP1_REPORT.md` | 10,058 bytes | v1/W2_PACKAGE_V1/W2_QA_LOOP1_REPORT.md |
| `v1/W2_PACKAGE_V1/sector_map_check.csv` | 10,460 bytes | v1/W2_PACKAGE_V1/sector_map_check.csv |
| `v1/W2_PACKAGE_V1/soe_blind_classification.csv` | 21,312 bytes | v1/W2_PACKAGE_V1/soe_blind_classification.csv |
| `v1/W2_PACKAGE_V1/soe_continuous.csv` | 7,824 bytes | v1/W2_PACKAGE_V1/soe_continuous.csv |
| `v1/W2_PACKAGE_V1/soe_time_variation.csv` | 969 bytes | v1/W2_PACKAGE_V1/soe_time_variation.csv |
| `v1/W2_PACKAGE_V1/soe_vs_published.csv` | 9,454 bytes | v1/W2_PACKAGE_V1/soe_vs_published.csv |
| `v1/W3_PACKAGE_V1/MANIFEST_W3_V1.md` | 1,628 bytes | v1/W3_PACKAGE_V1/MANIFEST_W3_V1.md |
| `v1/W3_PACKAGE_V1/README_W3_V1.md` | 2,469 bytes | v1/W3_PACKAGE_V1/README_W3_V1.md |
| `v1/W3_PACKAGE_V1/W3_P2_REPORT.md` | 3,064 bytes | v1/W3_PACKAGE_V1/W3_P2_REPORT.md |
| `v1/W3_PACKAGE_V1/W3_P3_REPORT.md` | 3,215 bytes | v1/W3_PACKAGE_V1/W3_P3_REPORT.md |
| `v1/W3_PACKAGE_V1/W3_P4_REPORT.md` | 1,826 bytes | v1/W3_PACKAGE_V1/W3_P4_REPORT.md |
| `v1/W3_PACKAGE_V1/W3_PACKAGE_V1_STATE.md` | 660 bytes | v1/W3_PACKAGE_V1/W3_PACKAGE_V1_STATE.md |
| `v1/W3_PACKAGE_V1/W3_QA_CERTIFICATION.md` | 1,297 bytes | v1/W3_PACKAGE_V1/W3_QA_CERTIFICATION.md |
| `v1/W3_PACKAGE_V1/W3_QA_LOOP1_REPORT.md` | 3,214 bytes | v1/W3_PACKAGE_V1/W3_QA_LOOP1_REPORT.md |
| `v1/W3_PACKAGE_V1/div_i_t.csv` | 109,513 bytes | v1/W3_PACKAGE_V1/div_i_t.csv |
| `v1/W3_PACKAGE_V1/dividend_adjustment_history.csv` | 6,601 bytes | v1/W3_PACKAGE_V1/dividend_adjustment_history.csv |
| `v1/W3_PACKAGE_V1/dividends_verified.csv` | 323,210 bytes | v1/W3_PACKAGE_V1/dividends_verified.csv |
| `v1/W3_PACKAGE_V1/missing_dividends_check.csv` | 3,081 bytes | v1/W3_PACKAGE_V1/missing_dividends_check.csv |
| `v1/W3_PACKAGE_V1/scripts/W3_P2_COMPLETENESS_CHECK.py` | 8,467 bytes | v1/W3_PACKAGE_V1/scripts/W3_P2_COMPLETENESS_CHECK.py |
| `v1/W3_PACKAGE_V1/scripts/W3_P3_DIVIDEND_ADJUSTED.py` | 8,300 bytes | v1/W3_PACKAGE_V1/scripts/W3_P3_DIVIDEND_ADJUSTED.py |
| `v1/W3_PACKAGE_V1/scripts/W3_P4_REBUILD_DIV_I_T.py` | 6,795 bytes | v1/W3_PACKAGE_V1/scripts/W3_P4_REBUILD_DIV_I_T.py |
| `v1/W3_PACKAGE_V1/scripts/W3_PACKAGE_V1_ASSEMBLY.py` | 8,339 bytes | v1/W3_PACKAGE_V1/scripts/W3_PACKAGE_V1_ASSEMBLY.py |
| `v1/W3_PACKAGE_V1/scripts/W3_QA_LOOP1.py` | 10,888 bytes | v1/W3_PACKAGE_V1/scripts/W3_QA_LOOP1.py |
| `v1/W3_PACKAGE_V1/scripts/execute_batch_2.py` | 4,120 bytes | v1/W3_PACKAGE_V1/scripts/execute_batch_2.py |
| `v1/W3_PACKAGE_V1/scripts/execute_batch_3.py` | 4,920 bytes | v1/W3_PACKAGE_V1/scripts/execute_batch_3.py |
| `v1/W3_PACKAGE_V1/scripts/execute_batch_4.py` | 5,276 bytes | v1/W3_PACKAGE_V1/scripts/execute_batch_4.py |
| `v1/W3_PACKAGE_V1/scripts/execute_batch_5.py` | 4,073 bytes | v1/W3_PACKAGE_V1/scripts/execute_batch_5.py |
| `v1/W3_PACKAGE_V1/scripts/execute_batch_verification.py` | 4,918 bytes | v1/W3_PACKAGE_V1/scripts/execute_batch_verification.py |
| `v1/W4_PACKAGE_V1/README_W4_V1.md` | 9,186 bytes | v1/W4_PACKAGE_V1/README_W4_V1.md |
| `v1/W4_PACKAGE_V1/W4_P1_P4_REPORT.md` | 11,345 bytes | v1/W4_PACKAGE_V1/W4_P1_P4_REPORT.md |
| `v1/W4_PACKAGE_V1/W4_QA_CERTIFICATION.md` | 9,922 bytes | v1/W4_PACKAGE_V1/W4_QA_CERTIFICATION.md |
| `v1/W4_PACKAGE_V1/W4_QA_LOOP1_PLAN.md` | 7,121 bytes | v1/W4_PACKAGE_V1/W4_QA_LOOP1_PLAN.md |
| `v1/W4_PACKAGE_V1/W4_QA_LOOP1_REPORT.md` | 13,566 bytes | v1/W4_PACKAGE_V1/W4_QA_LOOP1_REPORT.md |
| `v1/W4_PACKAGE_V1/adjustment_factors.csv` | 14,395 bytes | v1/W4_PACKAGE_V1/adjustment_factors.csv |
| `v1/W4_PACKAGE_V1/corporate_actions.csv` | 19,247 bytes | v1/W4_PACKAGE_V1/corporate_actions.csv |
| `v1/W4_PACKAGE_V1/crisis_anchors.csv` | 4,752 bytes | v1/W4_PACKAGE_V1/crisis_anchors.csv |
| `v1/W4_PACKAGE_V1/institutional_events.csv` | 4,377 bytes | v1/W4_PACKAGE_V1/institutional_events.csv |
| `v1/W4_PACKAGE_V1/market_series_provenance.csv` | 3,230 bytes | v1/W4_PACKAGE_V1/market_series_provenance.csv |
| `v1/W4_PACKAGE_V1/market_series_weekly.csv` | 353,195 bytes | v1/W4_PACKAGE_V1/market_series_weekly.csv |
| `v1/W4_PACKAGE_V1/trading_calendar_reasons.csv` | 56,713 bytes | v1/W4_PACKAGE_V1/trading_calendar_reasons.csv |

---

**Package Status:** ✅ COMPLETE AND VALIDATED
